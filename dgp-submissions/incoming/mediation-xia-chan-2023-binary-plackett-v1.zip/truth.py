"""Natural direct effect under the paper's binary margins, via Gauss-Hermite."""
import numpy as np
import math
def _p(z):return 1/(1+math.exp(-z))
def _integrate(c,order):
    nodes,weights=np.polynomial.hermite.hermgauss(order);total=0.
    for z,w in zip(nodes,weights):
        x=math.sqrt(2)*float(z)*c['x_sd']
        pc0=_p(c['c_logit_intercept']+c['c_logit_x']*x)
        pc1=_p(c['c_logit_intercept']+c['c_logit_a']+c['c_logit_x']*x)
        pm0=_p(c['m_logit_intercept']+c['m_logit_x']*x)
        d=c['y_a']+c['y_c']*(pc1-pc0)+c['y_ac']*pc1+c['y_am']*pm0
        total+=float(w)*d
    return total/math.sqrt(math.pi)
def truth(c):
    a=_integrate(c,64);b=_integrate(c,96)
    return {'value':float(b),'estimated_error':abs(a-b),'method':'One-dimensional Gauss-Hermite integration of analytic marginal-potential contrast; 64 vs 96 nodes.','target':'NDE=E[Y(1,M(0))-Y(0,M(0))]'}
