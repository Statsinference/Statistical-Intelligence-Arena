"""Independent Simpson integral and exact Plackett-cell constraints."""
from pathlib import Path
import importlib.util,math
from copy import deepcopy
def verify(c):
    p=Path(__file__);s=importlib.util.spec_from_file_location('xia_bin_truth',p.with_name('truth.py'));t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
    s=importlib.util.spec_from_file_location('xia_bin_gen',p.with_name('generator.py'));g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
    def ex(z):return 1/(1+math.exp(-z))
    n=12000;lo=-9.;hi=9.;h=(hi-lo)/n;acc=0.
    for i in range(n+1):
        x=lo+i*h;p0=ex(c['c_logit_intercept']+c['c_logit_x']*x);p1=ex(c['c_logit_intercept']+c['c_logit_a']+c['c_logit_x']*x);m0=ex(c['m_logit_intercept']+c['m_logit_x']*x)
        val=(c['y_a']+c['y_c']*(p1-p0)+c['y_ac']*p1+c['y_am']*m0)*math.exp(-x*x/(2*c['x_sd']**2))/(math.sqrt(2*math.pi)*c['x_sd'])
        acc+=(1 if i in (0,n) else 4 if i%2 else 2)*val
    simpson=acc*h/3;val=t.truth(c)['value'];cells=[]
    for a in (0,1):
      for x in (-6.,-4.,-2.,0.,2.,4.,6.):
        pm,pc,theta=g.margins(c,a,x);q=g.joint11(pm,pc,theta)
        ratio=q*(1-pm-pc+q)/((pm-q)*(pc-q))
        cells.append(abs(ratio-theta)/theta<1e-6 and max(0,pm+pc-1)<=q<=min(pm,pc))
    null=deepcopy(c);null['y_a']=null['c_logit_a']=null['y_ac']=null['y_am']=0.
    checks=[{'name':'independent_simpson_integral','passed':abs(simpson-val)<1e-8,'details':f'Simpson {simpson:.12g}, Gauss-Hermite {val:.12g}'},{'name':'plackett_or_and_margins','passed':all(cells),'details':'Fourteen (A,X) points, including X=±6 tail values, satisfy the prescribed odds ratio and Bernoulli margins.'},{'name':'zero_direct_paths','passed':abs(t.truth(null)['value'])<1e-10,'details':'A->Y and A->C->Y direct paths removed.'},{'name':'source_binary_parameters','passed':c['copula_log_or_a']==-2 and c['y_ac']==4,'details':'Section 4.1 binary DGP.'}]
    return {'passed':all(z['passed'] for z in checks),'checks':checks,'shared_components':'Gauss-Hermite and Simpson are separate quadratures; odds-ratio check independently evaluates joint-cell algebra.'}
