Candidate T06 contribution; this and the continuous Xia-Chan design are independent structural families, pending human review.
