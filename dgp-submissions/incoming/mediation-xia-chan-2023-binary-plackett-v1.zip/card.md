# Binary Plackett-copula treatment-induced confounding (Xia & Chan, 2023)

**Status:** local candidate; named human scientific review pending.

## 1. Source and source version

Source: https://doi.org/10.1080/01621459.2021.1990765; accepted manuscript https://par.nsf.gov/servlets/purl/10300663 §4.1 “Binary C and M”. This is structurally distinct from this paper’s continuous Gaussian-copula experiment: both mediator and confounder are binary, with a treatment- and covariate-dependent Plackett odds ratio.

## 2. Generating mechanism

X~N(0,1); A|X~Bern(expit(-.2+.3X)); marginal M|A,X~Bern(expit(-.3-.2A+.5X)), C|A,X~Bern(expit(-.2-.1A+.3X)); joint odds ratio OR(M,C|A,X)=exp(1-2A+3X). The generator solves the Bernoulli 2x2 table exactly. Y=1+3A+6M+3C+6X+4AC+2AM+epsilon, epsilon~N(0,4²).

## 3. Causal target and population truth

NDE=E[Y(1,M(0))-Y(0,M(0))]=E_X[3+3(pC1-pC0)+4pC1+2pM0]=5.49547575821569. Paper reports approximately 5.50. The truth here is derived by Gaussian integration, with independent Simpson check.

## 4. Changes, checks and limits

Changes: exact 2x2 Bernoulli construction of paper’s Plackett conditional odds ratio; variable n interface, source n=1500 recorded. No PDF redistributed. AI-assisted transcription needs human scientific review.

## 5. Rights and AI assistance

This ZIP contains an independent Python implementation and source references. The paper PDF and author code are not redistributed. Codex assisted with source transcription, derivation, implementation and this card. `collect.py check --run` verifies the local interface and contributor-supplied mathematical checks; it does not confer scientific acceptance. A named human reviewer must compare all equations, parameters, estimand interpretation, and stated changes against the cited original before submission.
