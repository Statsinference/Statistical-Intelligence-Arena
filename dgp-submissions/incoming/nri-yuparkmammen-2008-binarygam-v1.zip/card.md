# N02 二元可加预测子的二项与泊松回归

Contribution: `nri-yuparkmammen-2008-binarygam-v1` · `synthetic_dgp` · `nonparametric_regression` · **v1**

## Source and reconstruction

Yu, K., Park, B. U. and Mammen, E. (2008). Smooth backfitting in generalized additive models. The Annals of Statistics 36(1), 228-260. DOI: 10.1214/009053607000000596.

[DOI](https://doi.org/10.1214/009053607000000596) · [固定阅读版本 0803.1922v1](https://arxiv.org/pdf/0803.1922v1)

实读 PDF SHA-256：`17fd20eb787b1f5a2de3aefb381c23c35277cac296300b5a9d8c0fe96647d559`。IMS electronic reprint of the published article; the actual first-page declaration says pagination and typographic detail differ from the original.

Formula bodies: (5) on PDF p.7. Section starts: Section 2.2 on PDF p.6, Section 5 on PDF p.20. Unnumbered paragraph on PDF p.20: "The simulation was done under the following two models" (two conditional-response laws and following design/normalisation paragraphs). All PDF pages are 1-based pages of the fixed reading file 0803.1922v1. No printed journal page is inferred by adding an offset.

**原文参数逐页登记**

- PDF p.20：Bernoulli/logit and Poisson/log with eta=sin(pi*x1)+.5*(x2+sin(pi*x2)); j1 independent standard normals conditioned[-1,1]^2; j2 pre-truncation correlation.9, variances1; actual truncated correlation.682; n100,500;1000 repetitions; Bernoulli Models(1,1),(1,2): source normalization paragraph gives unshifted components, intercept0; Poisson Model(2,1): component centring shifts(c1,c2)=(.4533,.3230),intercept=.7763; Poisson Model(2,2): component centring shifts(c1,c2)=(.5874,.4536),intercept=1.0410; The normalized first component is printed cos, in conflict with generating sin. Independent integrals support sin; that is not an author-issued erratum.。

**按实际执行顺序的生成步骤**

1. **First covariate** — X1~N(0,1) conditional on -1<=X1<=1, using rejection resampling. Source design j=1; pre-truncation mean=0, sd=1.
2. **Second covariate** — X2~N(0,1) conditional on -1<=X2<=1, independently of X1. Source j=1 correlation=0; the correlated j=2 design is not generated.
3. **Predictor** — eta=sin(pi*X1)+0.5*(X2+sin(pi*X2)). Deterministic source predictor; no extra noise.
4. **Response mean** — m=1/(1+exp(-eta)) for Bernoulli; m=exp(eta) for Poisson. Stable logistic evaluation; finite eta on [-1,1]^2.
5. **Observed response** — Y|X~Bernoulli(m) or Poisson(m); Bernoulli inversion or Knuth product sampler; return X1,X2,Y. Conditional variance=m*(1-m) or m, respectively; no independent additive error is used.

**抽样单位与依赖**：independent observation (X, Y) pair；iid across observations; the two covariate components are independent within an observation (no Markov, cluster or repeated-measure structure)

**边界与尺度**：The Bernoulli probability stays strictly between 0 and 1 on the declared support. Poisson means are finite and below 6 in these source scenarios; no clipping, zero inflation or fabricated additive error is introduced.

**与来源的改动及理由**

1. Select design j=1, with independent standard-normal components jointly truncated to [-1,1]^2; keep Bernoulli/logit and Poisson/log as two scenarios.
2. Use the source's generating predictor with sin(pi*x1). The later cos expression conflicts with it; weighted centring integrals support the sin reading, but do not constitute an author-issued erratum.
3. Add the fixed query (0.5,0.5) and target the conditional response mean; do not reproduce smooth-backfitting estimators or coverage.

固定点目标由已声明条件响应律识别：高斯模型使用零条件均值的误差/随机效应，广义回归直接用指定分布的链接均值。接口 n 和查询为适配；未把 n=128 说成论文原实验样本量。

**版本关系**：The actual fixed reading PDF is an IMS electronic reprint of the published article, not a separate author-preprint draft merely because it is hosted on arXiv. The first-page declaration explicitly notes pagination and typographic differences. We use only verified section/equation/1-based PDF locators and do not claim identical publisher typesetting, exact printed-page offsets or entire-text identity. No separate author-preprint-to-formal substitution is involved for this reading source; that conditional comparison is N/A.

## Target and identification

`m(x0) = E[Y | X = x0]`

Conditional mean of the response at the fixed query point x0 = (0.5, 0.5) in the superpopulation defined by the fixed DGP: m(x0) = expit(eta(x0)) in scenario original-bernoulli (a classification probability) and m(x0) = exp(eta(x0)) in scenario original-poisson (a conditional count mean), with eta(x) = sin(pi x1) + 0.5 [x2 + sin(pi x2)]. A pointwise scalar query only; it is not a simultaneous confidence band over the covariate region.

**登记场景与查询**

| Scenario | Parameters / query |
|:--|:--|
| `original-bernoulli`（默认） | `{"family": "bernoulli", "query_x1": 0.5, "query_x2": 0.5, "covariate_distribution": "truncated_standard_normal_independent", "covariate_correlation": 0.0, "truncation_min": -1.0, "truncation_max": 1.0, "eta_frequency": 3.141592653589793, "eta_first_component_coefficient": 1.0, "eta_second_component_coefficient": 0.5, "source_sample_sizes": [100, 500]}` |
| `original-poisson` | `{"family": "poisson", "query_x1": 0.5, "query_x2": 0.5, "covariate_distribution": "truncated_standard_normal_independent", "covariate_correlation": 0.0, "truncation_min": -1.0, "truncation_max": 1.0, "eta_frequency": 3.141592653589793, "eta_first_component_coefficient": 1.0, "eta_second_component_coefficient": 0.5, "source_sample_sizes": [100, 500]}` |

场景中的 original-* 表示保留的来源生成参数，不代表新增查询和接口样本量属于原文实验。本包两场景均沿用原文生成设定，未另设自选查询；不复制同义场景充数。

**抽样、设计与支持条件**

- Observations (X_i, Y_i) are independent and identically distributed; there is no clustering, serial, spatial or network dependence.
- Covariates follow the source distribution j=1: two independent standard normal components, each truncated to [-1, 1], so the joint support is the box [-1, 1]^2.
- The conditional response law is exactly the source model: Y | X = x ~ Bernoulli(expit(eta(x))) in scenario original-bernoulli and Y | X = x ~ Poisson(exp(eta(x))) in scenario original-poisson; no link misspecification and no extra noise component.
- The query point (0.5, 0.5) is interior to the covariate support, so the target is determined by the sampling law evaluated at a point of positive density; no extrapolation is involved.
- The target is a pointwise scalar, not a simultaneous band, not a coverage claim, and not the source's ISB/IV/MISE criterion; a correct pointwise check does not license any band or coverage statement.

固定点条件均值正确，不等于点态区间或同时置信带覆盖率达标。非因果任务不套用干预/无混杂假设。

## Truth and independent verification

Closed form: evaluate eta(x0) = sin(pi * 0.5) + 0.5 [0.5 + sin(pi * 0.5)] = 1.75 at the fixed query point and apply the scenario link, expit for original-bernoulli and exp for original-poisson. No quadrature and no simulation enter the oracle; the verifier re-derives the same value with a tanh-form logistic, a math.e power, and 60-digit decimal arithmetic.

`truth.tolerance=1e-08`。estimated_error 是浮点/数值路线诊断，不是严格统一误差界或统计标准误；其非负且不大于 tolerance。

**不同路线与解析特例**：链接函数的独立求值与截断二维正态的 Gauss–Legendre 加权积分；eta=0 时概率为 1/2、Poisson 均值为 1；另比较 sin/cos 的归一化常数。

**实际共享函数与独立边界**：verify 在 queried/origin/mirror 查询处调用 truth.truth，原点与镜像项属于解析一致性检查；generator.generate 只用于实际支撑/矩诊断。独立链接值由 tanh/Decimal 路线求出，归一化积分及 Monte Carlo 单独实现。

外部另按论文公式用 mpmath 70 位重算全部登记查询；另对各场景 generate(n=4096, seed=7312026) 实际观察列独立重构残差，不导入私有均值助手或 verify 作外部参照。N08 的源数学参照取精确 1/sqrt(3)，与配置中最短十进制权重的浮点差计入比较；阈值仍逐包取 tolerance，不靠放宽阈值通过。

## Diversity and scope

`dimension=2`，`effective_dimension=2`。Both covariates enter eta(x) = sin(pi x1) + 0.5 [x2 + sin(pi x2)] and are therefore effective. Nonlinearity comes from the sin(pi x1) and sin(pi x2) terms and from the logit link (Bernoulli) or log link (Poisson). The additive predictor contains no product term, so interactions is false. high_dimensional is false: d = 2 against the source sample sizes n = 100 and n = 500. The source's d = 3, 4, 5 extensions and its correlated covariate distribution j=2 are not included here and are recorded as candidate later scenarios of the same mechanism family.

The normalized additive components in source equation (5) are not the response-mean target. Follow the generating sin expression and disclose the later cos conflict as an evidence-supported interpretation, not an author erratum. No treatment/label/missingness mechanism is applicable.

处理分配、标注、缺失与真实数据分支均不适用。未执行论文估计器、bootstrap、点态/同时覆盖率、PFN 训练、大规模压力测试或第二人独立人工复现。

## Rights and assistance

Source equations are cited and independently implemented. Paper copyright is not transferred; no paper PDF, author software, original participant data or model weights are redistributed. No external author code was used. The contributor must confirm the release licence for the independently implemented code before publication; pending review is not a grant of rights. AI assisted equation extraction, implementation, numerical checks and drafting; named human scientific review and independent-person reproduction are not claimed.

**未使用作者原始代码或补充材料代码**；因此作者软件 commit 追溯项 N/A。本包依赖以 requirements.txt 为准：标准库或 NumPy 的使用不等于移植作者代码。论文全文、页图、作者软件、权重、数据银行、凭据不随贡献包分发。

**missing / 尚待确认**

- 当前已声明生成律不存在未给定的必要数值参数；这不等于作者算法、许可或科学接收已获确认。
- 本人须审核 AI 协助的来源提取、代码、数值和文本，并确认独立实现代码的发布许可；pending 不是授权。
- 具名科学审核、第二人独立人工复现：未执行。
- GitHub Fork/Sync/SUBMIT DGP/Actions/PR/收录确认：本次未执行。本地 submit 不等于网络提交或项目收件。

**状态**：以最终 checks/report.json 记录本地 runnable_dgp；归档仅 awaiting_scientific_review、scientific_acceptance=false。
