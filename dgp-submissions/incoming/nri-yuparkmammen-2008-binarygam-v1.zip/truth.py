"""Population value of the pointwise target m(x0) = E[Y | X = x0]; closed form.

The oracle evaluates the declared sampling law analytically at the fixed query point
carried by the scenario. It never reads generated rows and never estimates anything
from a sample.
"""
import math

FAMILIES = ("bernoulli", "poisson")


def expit(value):
    if value >= 0.0:
        return 1.0 / (1.0 + math.exp(-value))
    v = math.exp(value)
    return v / (1.0 + v)


def linear_predictor(x1, x2, config):
    """eta(x) = sin(pi x1) + 0.5 [x2 + sin(pi x2)] evaluated at the query point."""
    pi = config["eta_frequency"]
    return (config["eta_first_component_coefficient"] * math.sin(pi * x1)
            + config["eta_second_component_coefficient"] * (x2 + math.sin(pi * x2)))


def truth(config):
    """Return {value: finite number, estimated_error: nonnegative number}."""
    if config["family"] not in FAMILIES:
        raise ValueError("family must be one of " + ", ".join(FAMILIES))
    x1 = float(config["query_x1"])
    x2 = float(config["query_x2"])
    eta = linear_predictor(x1, x2, config)
    if config["family"] == "bernoulli":
        value = expit(eta)
        link = "logit: m(x0) = expit(eta(x0))"
    else:
        value = math.exp(eta)
        link = "log: m(x0) = exp(eta(x0))"
    return {
        "value": value,
        "estimated_error": 1e-12,
        "method": "Closed form. Evaluate eta(x0) = sin(pi x1) + 0.5 [x2 + sin(pi x2)] at the fixed query point and apply the link (" + link + "). No quadrature, no simulation, no sample-based estimation.",
        "error_interpretation": "Floating-point round-off bound for one sin/logistic evaluation, not a statistical error and not a rigorous uniform error theorem.",
        "target": "m(x0) = E[Y | X = x0] at x0 = (" + repr(x1) + ", " + repr(x2) + ")",
        "eta_at_query": eta,
        "family": config["family"]
    }
