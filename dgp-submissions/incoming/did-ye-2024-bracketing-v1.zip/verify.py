import importlib.util
from pathlib import Path
import numpy as np
def load_generate():
    spec=importlib.util.spec_from_file_location('local_dgp_under_test',Path(__file__).with_name('generator.py'))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod.generate
def check(name,passed,**details):
    return {'name':name,'passed':bool(passed),'details':details}

import itertools
def verify(config):
    means=np.asarray(config['untreated_means'],float)
    effects=np.asarray(config['effects'],float)
    observed=means.copy();observed[2]+=effects
    k=int(config['target_time'])-1
    # Independent causal intervention calculation, retaining common errors.
    grid=np.array([-3.,-1.,0.,2.,4.])
    contrast=(means[2,k]+grid+effects[k])-(means[2,k]+grid)
    checks=[check('potential-outcome contrast at five disturbance values',np.allclose(contrast,effects[k],atol=1e-12,rtol=0))]
    # Enumerate all time-varying choices of control; no call to truth.py.
    paths=[]
    for choices in itertools.product((0,1),repeat=k):
        paths.append(sum((observed[2,j+1]-observed[2,j])-(observed[g,j+1]-observed[g,j]) for j,g in enumerate(choices)))
    lo,hi=float(min(paths)),float(max(paths))
    dt=np.diff(means,axis=1)
    bracket=np.all((dt[2]>=np.minimum(dt[0],dt[1])) & (dt[2]<=np.maximum(dt[0],dt[1])))
    checks.append(check('monotone-trend restrictions and identified interval',bracket and lo<=effects[k]<=hi,lower=lo,upper=hi,structural_truth=float(effects[k])))
    g=load_generate();data=g(config,50000,91729)
    group=np.asarray(data['G']);y=np.column_stack([data[f'Y{t}'] for t in range(1,5)])
    errors=y-observed[group]
    max_z=0.
    for a in range(3):
        residual=errors[group==a]
        max_z=max(max_z,float(np.max(np.abs(residual.mean(axis=0))*np.sqrt(len(residual))/config['noise_sd'])))
    covariance=np.cov(errors,rowvar=False,bias=True)/(config['noise_sd']**2)
    checks.append(check('generator reproduces group-time means, variance and independent errors',max_z<6 and np.max(np.abs(covariance-np.eye(4)))<0.03,max_standardized_mean=max_z,max_covariance_error=float(np.max(np.abs(covariance-np.eye(4))))))
    counts=np.bincount(group,minlength=3).tolist()
    checks.append(check('fixed source group allocation at n=50000',counts==[10000,25000,15000],counts=counts))
    zero=dict(config,effects=[0,0,0,0]);d0=g(zero,1000,317);d1=g(config,1000,317)
    diff=np.column_stack([np.asarray(d1[f'Y{t}'])-d0[f'Y{t}'] for t in range(1,5)])
    expected=(np.asarray(d1['G'])[:,None]==2)*effects
    checks.append(check('common-random-number intervention only shifts treated group',np.allclose(diff,expected,atol=1e-12,rtol=0)))
    return {'passed':all(c['passed'] for c in checks),'checks':checks}
