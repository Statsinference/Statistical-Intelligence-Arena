def truth(config):
    # Under intervention only the treated group's additive effect changes.
    t=int(config['target_time'])
    if t not in (2,3,4): raise ValueError('target_time must be post-treatment')
    return {'value':float(config['effects'][t-1]),'estimated_error':0.0,
            'method':'Exact additive potential-outcome contrast for G=2; not an identified-set endpoint.'}
