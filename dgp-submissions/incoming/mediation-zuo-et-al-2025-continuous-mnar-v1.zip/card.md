# M16 — continuous mediator and outcome under MNAR

**Status:** local candidate; named human scientific review pending.

## 1. Source and source version

Source: Zuo et al. (2025), JASA DOI 10.1080/01621459.2024.2359132, §5.1 Setting C / Assumption III. Exact coefficient vector: arXiv:2212.05577v3 Supplement Table S1, PDF p.72.

## 2. Generating mechanism

Generation: X~N(0,1); T~Bern(.5); M~N(T+X,1); Y~N(M+T+MT+X,1); logit P(R_M=1)=1.4+M+T+X; logit P(R_Y=1)=1.8+Y+T+X. Independent Gaussian and Bernoulli disturbance draws.

## 3. Causal target and population truth

Target: full-data NIE_1=E[Y(1,M(1))-Y(1,M(0))]=1*(1+1)=2. The MNAR masks do not alter this full-data truth, but make it harder to identify from observed values.

## 4. Changes, checks and limits

Adaptation: export M_obs0 and Y_obs0 as zero when missing, with R_M and R_Y flags. The exact decoding rule is `M_obs = M_obs0 if R_M=1 else missing` and `Y_obs = Y_obs0 if R_Y=1 else missing`; the four columns must be consumed together. An observed value of zero with indicator 1 remains a real observed zero. The zero fills are neither measured zeros nor mean imputations. A benchmark loader that drops the indicators or treats zero fills as observed data is incompatible with this package and needs a mask-aware adapter. Only one structural family is claimed.

## 5. Rights and AI assistance

This ZIP contains an independent Python implementation and source references. The paper PDF and author code are not redistributed. Codex assisted with source transcription, derivation, implementation and this card. `collect.py check --run` verifies the local interface and contributor-supplied mathematical checks; it does not confer scientific acceptance. A named human reviewer must compare all equations, parameters, estimand interpretation, and stated changes against the cited original before submission.
