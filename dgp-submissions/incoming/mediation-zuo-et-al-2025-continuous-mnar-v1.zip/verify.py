"""Coupled-potential simulation and missingness mechanism check."""
from copy import deepcopy
import importlib.util
import math
from pathlib import Path
import random

def _oracle(c):
    s=importlib.util.spec_from_file_location("zuo_truth",Path(__file__).with_name("truth.py")); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.truth(c)["value"]

def verify(config):
    sg=importlib.util.spec_from_file_location("zuo_generator",Path(__file__).with_name("generator.py"))
    generator=importlib.util.module_from_spec(sg); sg.loader.exec_module(generator)
    observed=generator.generate(config,512,20251031)
    mask_ok=(any(v==0 for v in observed["R_M"]) and any(v==0 for v in observed["R_Y"])
             and all(v==0. for r,v in zip(observed["R_M"],observed["M_obs0"]) if r==0)
             and all(v==0. for r,v in zip(observed["R_Y"],observed["Y_obs0"]) if r==0)
             and all(r in (0,1) for r in observed["R_M"]+observed["R_Y"]))
    r=random.Random(2025); differences=[]
    for _ in range(1000):
        x=r.gauss(0,1); em=r.gauss(0,1); ey=r.gauss(0,1)
        m0=config["alpha_0"]+config["alpha_x"]*x+em
        m1=config["alpha_0"]+config["alpha_t"]+config["alpha_x"]*x+em
        def y(m): return config["beta_0"]+config["beta_m"]*m+config["beta_t"]+config["beta_mt"]*m+config["beta_x"]*x+ey
        differences.append(y(m1)-y(m0))
    empirical=math.fsum(differences)/len(differences); value=_oracle(config)
    no_m=deepcopy(config); no_m["alpha_t"]=0.
    no_y=deepcopy(config); no_y["beta_m"]=no_y["beta_mt"]=0.
    checks=[
      {"name":"coupled_potential_outcomes","passed":abs(empirical-value)<1e-12,"details":f"1000 coupled-potential average={empirical:.15g}, product={value:.15g}"},
      {"name":"source_table_S1_setting_C_III","passed":config["alpha_t"]==1 and config["beta_m"]==1 and config["beta_mt"]==1 and config["lambda_0"]==1.4 and config["gamma_0"]==1.8,"details":"Compared with arXiv v3 supplement Table S1, PDF p.72."},
      {"name":"null_A_to_M","passed":_oracle(no_m)==0.,"details":"Zero alpha_t removes mediation."},
      {"name":"null_M_to_Y","passed":_oracle(no_y)==0.,"details":"Zero beta_m and beta_mt removes mediation."},
      {"name":"mnar_edges_present","passed":config["lambda_m"]!=0 and config["gamma_y"]!=0,"details":"M->R_M and Y->R_Y are both present."},
      {"name":"mask_zero_fill_contract","passed":mask_ok,"details":"For 512 seeded draws, missing M/Y have zero placeholders and both mask columns remain binary; masks are required to decode missingness."}
    ]
    return {"passed":all(q["passed"] for q in checks),"checks":checks,"shared_components":"Coupled-potential route is independent of the product formula but shares structural coefficients; named scientific review remains pending."}
