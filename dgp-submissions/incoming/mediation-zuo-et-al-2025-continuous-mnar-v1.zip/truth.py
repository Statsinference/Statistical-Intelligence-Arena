"""Natural indirect effect at outcome treatment one under the complete-data law."""
def truth(config):
    value=config["alpha_t"]*(config["beta_m"]+config["beta_mt"])
    return {"value":float(value),"estimated_error":0.,"method":"Exact linear structural product; missingness does not change the full-data target.","target":"NIE_1 = E[Y(1,M(1))-Y(1,M(0))]"}
