Status: runnable candidate; scientific review and benchmark missingness-policy review pending.
