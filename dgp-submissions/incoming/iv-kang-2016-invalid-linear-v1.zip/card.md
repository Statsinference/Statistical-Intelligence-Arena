# IV：部分无效工具与线性内生处理

## 来源与定位
Kang, H., Zhang, A., Cai, T. T. and Small, D. S. (2016). Instrumental Variables Estimation With Some Invalid Instruments and its Application to Mendelian Randomization. JASA 111(513), 132–144. DOI: 10.1080/01621459.2014.994705.

https://arxiv.org/abs/1401.5755v3

arXiv v3 (2014-09-21), §4 PDF pp.22–23; fixed parameters from hyunseungkang/sisVIVE README.md Examples lines 24–38, commit 0ae8499f260f37edd68a057d1e2f0634b1b98b42.

作者代码固定链接：https://github.com/hyunseungkang/sisVIVE/blob/0ae8499f260f37edd68a057d1e2f0634b1b98b42/README.md

## 原始机制与参数
- Zⱼ iid N(0,1), j=1,…,10; Z independent of (ξ,ε).
- (ξ,ε) joint normal: mean 0, variances 1, correlation ρ=0.8.
- D=1+Σⱼ₌₁¹⁰ Zⱼ+ξ.
- Y=1+Z₁+Z₂+Z₃+βD+ε; β=1.

逐个固定参数见 config.json。本包含 1 个具名场景；默认场景为 `author_readme_fixed`。各场景的 effect_scale（如存在）均为1。源码检查使用小样本，不改变单个个体的总体机制。

## 目标与真值
Constant structural slope beta = E[Y(do(D=d+1))-Y(do(D=d))], with natural Z and errors held under the same intervention law.

改变 D 一单位并保持 Z 和结构误差时，Y 增加 beta=1。对 Z4–Z10，Cov(Zj,Y)/Cov(Zj,D)=1；前3个工具的比值为2，不能把它们当有效工具。

默认场景真值：1。truth 返回解析值，estimated_error=0 指无积分/Monte Carlo 近似，不是浮点误差的严格零界。固定查询点在 config.json 中记录，不通过生成样本选择。

## 识别条件
- Consistency and well-defined treatment interventions.
- Independent identically distributed units; no interference.
- Ten independent standard normal candidate instruments, independent of jointly Gaussian structural errors.
- Structural equation Y=1+Z1+Z2+Z3+beta*D+epsilon has a constant causal slope.
- Z4–Z10 are relevant and satisfy exclusion; Z1–Z3 violate exclusion. Do not apply all-IV validity.
- More than half of candidate instruments are valid (7/10); the linear invalid-IV identification framework applies.

## 维数、交互和样本结构
无额外基线 X；10列 Z 为候选工具，不计入 baseline dimension。工具数单列记录为10。线性、无交互；rho=0.8造成内生性，Z1–Z3直接作用于Y。

导出列：Z1, Z2, Z3, Z4, Z5, Z6, Z7, Z8, Z9, Z10, D, Y。仅输出观察变量；内部噪声、Q、潜在结果及逐行真值均不输出。真值与参数供维护端核验，不应作为估计器输入特征。

## 明确适配与范围
- 使用新写的 Python/NumPy PCG64 实现；保持所选场景的分布，不保证与 R 同种子逐行相同。
- n=128、seed=1729 仅用于接口运行检查；不复跑论文估计器、不报告覆盖率。
- 机制来自论文 §4；参数完整固定为作者 README 示例：10个独立标准正态工具，前3个直接作用于Y，rho=0.8，各一阶段系数、两截距和 beta 均为1。
- 此为论文机制的作者示例参数化，不宣称复现论文 n=2000 的集中参数校准网格；作者 README 的原始样本量为1000。
- 不导出结构误差或逐列有效性 oracle 标签；哪些工具无效仅在机制说明/核验中记录。

与现有 Hartford demand、Dikkala sine 机制不同；部分候选工具明确违反排除限制。

常数与一阶段向量取自作者示例；论文其他浓度参数、相关矩阵和失效比例网格尚未复现。本包有已知结构真值不表示任意无效工具组合均可识别。

## 独立核验与可复现性
verify 不调用生成器的结构函数求真值。它用独立标量公式、潜在结果/观察律积分或总体矩恒等式核对 truth，并检查零效应、反向效应、源方程逐行重建和输入不变。自动运行检查还覆盖 schema、有限值、同 seed 重现、不同 seed 变化及观察列限制。积分阶数对照属于数值诊断，不等于严格误差界。

在学生包根目录执行：
```powershell
& .\.venv\Scripts\python.exe collect.py check contributions/iv-kang-2016-invalid-linear-v1 --run --n 128 --seed 1729
& .\.venv\Scripts\python.exe collect.py pack contributions/iv-kang-2016-invalid-linear-v1 --out submissions/iv-kang-2016-invalid-linear-v1.zip
```
改源文件后须重跑全部场景检查，并使用新 ZIP 文件名。

## 权利与审核状态
仅提供独立实现与来源链接，不包含论文 PDF 或原作者程序。论文版权归原权利人；正式发布权利审核待维护人完成。 固定作者仓库 LICENSE 为 MIT；本包没有复制作者源文件。

AI 协助：OpenAI Codex，2026-10-25；包括文献核对、代码实现、报告与本地检查。没有代签人类原文阅读或独立人员复现。认领、跨库去重、具名科学审核与正式接收待维护人处理；本地运行通过不等于正式接收。未训练 PFN、未拟合估计器、未测 CI coverage。
