"""Constant structural treatment slope, equal to a unit do(D) contrast."""
from generator import validate_config


def truth(config):
    validate_config(config)
    return {'value':float(config['beta']),'estimated_error':0.0,
            'method':'Y(d+1,z)-Y(d,z)=beta, holding z and the structural error fixed.',
            'error_interpretation':'Analytic; no numerical integration in truth.'}
