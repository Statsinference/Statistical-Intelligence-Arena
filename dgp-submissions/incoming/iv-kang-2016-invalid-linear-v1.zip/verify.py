"""Independent covariance and intervention integration; invalid IVs are not treated as valid."""
import copy
import math
import numpy as np
from generator import generate
from truth import truth
from common import result


def verify(config):
    before=copy.deepcopy(config); checks=[]
    def record(name,ok,**details): checks.append({'name':name,'passed':bool(ok),**details})
    # Vector v=(Z1,...,Z10,xi,epsilon) and its population covariance.
    covariance=np.eye(12); covariance[10,11]=covariance[11,10]=config['rho']
    d=np.array([config['first_stage']]*10+[1.,0.])
    direct=np.array([1.]*3+[0.]*7+[0.,1.])
    y=direct+config['beta']*d
    cov_d=covariance@d; cov_y=covariance@y
    ratios=cov_y[:10]/cov_d[:10]
    target=truth(config)['value']
    record('independent_population_IV_moments',np.max(abs(ratios[3:]-target))<1e-12,
           valid_IV_ratios=ratios[3:].tolist(),invalid_IV_ratios=ratios[:3].tolist())
    record('invalid_IV_exclusion_violation',np.all(abs(ratios[:3]-target)>1e-8),
           invalid_instrument_indices=[1,2,3],valid_instrument_indices=list(range(4,11)))
    # Numerical integration of two do(D) outcome means, over aggregate Z1+Z2+Z3 and epsilon.
    nodes,weights=np.polynomial.hermite.hermgauss(12)
    errors=[]
    for beta in [config['beta'],0.0,-1.0,2.0]:
        means=[]
        for treatment in [0.,1.]:
            mean=0.0
            for i,z in enumerate(nodes):
                for j,e in enumerate(nodes):
                    outcome=config['outcome_intercept']+math.sqrt(6)*z+beta*treatment+math.sqrt(2)*e
                    mean+=weights[i]*weights[j]*outcome/math.pi
            means.append(mean)
        c=copy.deepcopy(config); c['beta']=beta
        errors.append(abs((means[1]-means[0])-truth(c)['value']))
    record('independent_intervention_integration_and_controls',max(errors)<1e-10,max_absolute_error=max(errors))
    record('endogenous_structural_errors',abs(covariance[10,11]-config['rho'])<1e-12,
           covariance_xi_epsilon=float(covariance[10,11]),conditional_OLS_slope=float(config['beta']+config['rho']))
    n,seed=73,81025; data=generate(config,n,seed)
    rng=np.random.Generator(np.random.PCG64(seed)); z=rng.normal(size=(n,10)); e=rng.normal(size=(n,2))
    err=0.
    for i in range(n):
        d=config['treatment_intercept']+config['first_stage']*sum(float(t) for t in z[i])+float(e[i,0])
        y=config['outcome_intercept']+sum(float(t) for t in z[i,:3])+config['beta']*d
        y+=config['rho']*float(e[i,0])+math.sqrt(1-config['rho']**2)*float(e[i,1])
        err=max(err,abs(d-data['D'][i]),abs(y-data['Y'][i]))
    record('scalar_source_equation_replay',err<1e-10,max_error=err,rows=n)
    record('observed_only',set(data)=={*(f'Z{j}' for j in range(1,11)),'D','Y'})
    record('configuration_unchanged',config==before)
    return result(checks)
