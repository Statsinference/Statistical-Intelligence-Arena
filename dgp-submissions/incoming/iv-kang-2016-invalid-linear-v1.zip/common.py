"""Input validation only: no causal equations or truth calculations."""
import math
import numpy as np


def finite(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(label + ' must be finite numeric')


def sampling(n, seed):
    if isinstance(n, bool) or not isinstance(n, int) or n < 1:
        raise ValueError('n must be a positive integer')
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError('seed must be a nonnegative integer')
    return np.random.Generator(np.random.PCG64(seed))


def query(config, dimension):
    if not isinstance(config['query_point'], list) or len(config['query_point']) != dimension:
        raise ValueError('query_point has incorrect dimension')
    for x in config['query_point']:
        finite(x, 'query coordinate')
    finite(config['effect_scale'], 'effect_scale')


def result(checks):
    return {'passed': all(c['passed'] for c in checks), 'checks': checks,
            'scope': 'Deterministic mechanism/truth checks, not estimator performance or scientific acceptance.'}
