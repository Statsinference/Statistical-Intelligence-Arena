"""Population scalar functional. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'songlinear', 'dimension': 4, 'source_n_labeled': 250, 'source_n_unlabeled': 1000, 'rho': 0.5, 'noise_sd': 1.0, 'query_coordinate': 1}



def truth(config):
    if config != SOURCE_CONFIG:
        raise ValueError('This contribution supports exactly the declared original scenario')
    c=config
    def integrand(z):
        h=math.exp(0.045+z+2*math.cos(z))+0.1*math.exp(z+math.sin(z))+2.5*z**3
        return z*h*math.exp(-z*z/2)/(4*math.sqrt(2*math.pi))
    value,error=quad(integrand,-14,14,epsabs=1e-12,epsrel=1e-12,limit=200)
    return dict(value=value,estimated_error=error+1e-30,method='Gaussian covariance identity with adaptive one-dimensional quadrature; finite-tail diagnostic')
