"""Population scalar functional. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'cosine', 'dimension': 50, 'source_n_labeled': 100, 'source_n_unlabeled': 1000, 'amplitude': 3.0, 'noise_sd': 0.5}



def truth(config):
    if config != SOURCE_CONFIG:
        raise ValueError('This contribution supports exactly the declared original scenario')
    c=config
    value=c['amplitude']*math.exp(-1.5)
    return dict(value=value,estimated_error=0.0,method='analytic Gaussian characteristic function')
