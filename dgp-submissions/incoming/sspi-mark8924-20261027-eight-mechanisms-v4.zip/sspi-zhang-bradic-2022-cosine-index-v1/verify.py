"""Independent numerical routes and source algebra fixtures. SPDX-License-Identifier: Apache-2.0."""
import importlib.util
from pathlib import Path
import math
import numpy as np
from scipy.integrate import quad, cumulative_simpson
from scipy.interpolate import CubicSpline
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'cosine', 'dimension': 50, 'source_n_labeled': 100, 'source_n_unlabeled': 1000, 'amplitude': 3.0, 'noise_sd': 0.5}

def _load(name):
    spec=importlib.util.spec_from_file_location('verify_local_'+name,Path(__file__).with_name(name+'.py'))
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

def _normal(z): return np.exp(-z*z/2)/math.sqrt(2*math.pi)

def _simpson(f,a=-12,b=12,n=24000):
    x=np.linspace(a,b,n+1); y=f(x)
    return float((b-a)/(3*n)*(y[0]+y[-1]+4*y[1:-1:2].sum()+2*y[2:-1:2].sum()))



def verify(config):
    c=config; g=_load('generator'); t=_load('truth')
    checks=[]
    def check(name,passed,details):checks.append(dict(name=name,passed=bool(passed),details=details))
    check('source_scenario',c==SOURCE_CONFIG,'Fixed source setting and declared scalar query')
    got=t.truth(c)
    independent=_simpson(lambda z:3*np.cos(math.sqrt(3)*z)*_normal(z))
    check('independent_truth_route',abs(got['value']-independent)<1e-8,
          dict(truth=got['value'],independent=float(independent),difference=float(abs(got['value']-independent))))
    check('truth_precision',got['estimated_error']<=1e-8,got['estimated_error'])
    x=np.zeros((1,c['dimension']));check('zero_index',g._response(x,np.zeros(1),c)[0]==3,'At zero index the conditional mean is three')
    a=g.generate(c,128,1729); b=g.generate(c,128,1729)
    r=np.asarray(a['R']); y=np.asarray(a['Y_obs'])
    check('observed_data_contract',set(a)=={f'X{j+1}' for j in range(c['dimension'])}|{'R','Y_obs'} and all(len(v)==128 for v in a.values()) and np.all(y[r==0]==0),'All covariates, R and masked outcome only')
    check('replay',a==b,'Same seed gives identical observations')
    check('finite',all(np.isfinite(v).all() for v in map(np.asarray,a.values())),'Finite numeric output')
    return dict(passed=all(x['passed'] for x in checks),checks=checks,
        shared_components='These computations use the same documented distribution and configuration. The numerical oracle route is separate from truth.py; algebra/mask fixtures intentionally exercise generator.py. Computational review by the contributor with AI assistance; human review remains pending.')
