# Cosine single-index mean with Gaussian covariates

Contributor: 马铭远 / Mark8924. Task: SSPI T05/T06. Status: prepared for contributor review and subsequent scientific review.

## Source and reconstruction

Zhang, Y. and Bradic, J. (2022). High-dimensional semi-supervised learning: in search of optimal inference of the mean. Biometrika 109(2), 387–403.

DOI: https://doi.org/10.1093/biomet/asab042

Reading source: https://par.nsf.gov/servlets/purl/10345775

Version: Final journal PDF, author/public-access copy.

Locator: Section 5.1, Model 2, PDF p. 11 / journal p. 397; Model 1 defines Gaussian noise; Figure 2 supplies n and m/n. Section 1 defines the two samples.

Source PDF SHA-256: 133540a561376c631f2fad39a24cf413442e2f4321229ff2a99af85e5d0a7cd9.

- X_j iid N(0,1), j=1,...,50; epsilon~N(0,0.25), independent of X.
- Y=3*cos(X_1+X_2+X_3)+epsilon. Source p=51 includes an intercept.
- Two independent samples from the same population: source_n_labeled rows with observed Y and source_n_unlabeled rows with observed X only. R=1 in the first labeled block; Y_obs=Y there. R=0 in the remaining block; Y_obs=0 is a placeholder.

## Fixed original scenario

- `observation_rule`: `two_independent_samples`
- `placeholder`: `0.0`
- `mechanism`: `cosine`
- `dimension`: `50`
- `source_n_labeled`: `100`
- `source_n_unlabeled`: `1000`
- `amplitude`: `3.0`
- `noise_sd`: `0.5`

Every parameter belongs to this single named scenario. The source allocation is reproduced at total n=1100. At another n, the integer allocation in collection.json preserves the source ratio approximately while retaining both sample groups. The generator accepts this declared configuration exactly.

## Observation, sampling and target

The target is **E[Y]**: Population mean of Y in the common labeled/unlabeled population.

Independent units are sampled from the same population. Label availability is fixed independently of X and Y. X is observed in both sample groups. R identifies the labeled rows. For R=0, Y_obs=0 is an interface placeholder; every downstream method must mask it using R. Internal latent variables and unused outcomes stay internal. The output contains exactly the schema columns. For the discrete-surrogate mechanism, X1 is the explicitly observed auxiliary prediction.

The generator exposes covariates as auxiliary information; fitted predictions are supplied by subsequent statistical methods using permitted labeled data and their documented training or cross-fitting splits. This contribution supplies the sampling law and observed data; later methods specify training and validation partitions. Prediction columns are absent.

## Truth and verification

S=X1+X2+X3~N(0,3); E[Y]=3*exp(-3/2).

Reference scalar: **0.669390480445289**. Estimated numerical error: 0. Analytic zeros in the error field denote zero integration error; ordinary floating-point rounding still applies. Numerical estimates describe convergence/rounding diagnostics for this fixed configuration.

truth.py computes the population functional. verify.py supplies a separate numerical calculation and a hand-checkable special case. The route and numerical difference are recorded in checks/report.json. Both calculations share the documented law and fixed parameters. The tolerance is 1e-8, set before validation. Tests also check the observation mask, output columns, finite values and seeded replay.

## Properties and scope

Three direct response coordinates among 50; the cosine of their sum is nonlinear and nonadditive. Dimension 50 is below source labeled n=100. effective_dimension counts inputs that determine the conditional response law, including an observed surrogate or the sole tail-dependent auxiliary variable; correlated extra coordinates may carry additional information. high_dimensional compares total dimension with source labeled sample size. Interactions marks a nonadditive response/probability map.

This contribution covers the declared source scenario, scalar population target and observed-data contract. Confidence intervals, fitted estimators and model performance belong to the subsequent benchmark stage.

## Adaptations

1. Select the source n=100, m=1000 setting; map source p=51 to 50 observed covariates.
2. Represent independent labeled/unlabeled samples in a single table: all X columns, label indicator R and Y_obs. A zero on an R=0 row is a finite placeholder.
3. The generate argument n counts total rows. Source total yields exact source allocation; other n use nearest-integer ratio allocation with both groups nonempty.
4. Use local PCG64 random streams, with independent covariate and response-noise streams. Each row remains an independent population draw.

## Reproduce

From the teacher toolkit root, substitute this directory for CONTRIBUTION:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTPUT.zip
```

The eight required files, source_audit.json, checks/ evidence and the generated MANIFEST.json accompany the official archive. Checks must be repeated after source edits. The source constants, noise parameterizations and observation masks were reviewed before execution.

## Rights, assistance and review

Article rights remain with their respective rights holders. This contribution contains independently written Apache-2.0 code and factual source descriptions. Source PDFs, figures and author software remain in local research materials. All generated records are synthetic.

AI assistance: Codex supported source reading, coding, numerical derivation and computational review. The user reviews the contribution before submission. Named human scientific review, independent-person replication and final acceptance are maintained by the project team. Family is semi_supervised; the current six-category registry queues this family for maintainer classification.
