# Explained variance for dense decaying regression with AR covariance

Contributor: 马铭远 / Mark8924. Task: SSPI T05/T06. Status: prepared for contributor review and subsequent scientific review.

## Source and reconstruction

Cai, T. T. and Guo, Z. (2020). Semisupervised inference for explained variance in high dimensional linear regression and its applications. JRSS-B 82(2), 391–419.

DOI: https://doi.org/10.1111/rssb.12357

Reading source: https://arxiv.org/pdf/1806.06179v2

Version: arXiv:1806.06179v2, 30 November 2020; selected Setting 4 checked against publisher HTML Section 6.1.1.

Locator: Equation (1) and Section 6 simulation setup, PDF p. 21; Section 6.1 Setting 4 and Table 1, PDF p. 22. Publisher Section 6.1.1: https://academic.oup.com/jrsssb/article/82/2/391/7056037 .

Source PDF SHA-256: 6b767d46f4f208e1b767f244a06182d3fdfcaefc25a69bc3b955abe0014485cd.

- X~N_800(0,Sigma), Sigma_ij=0.5^abs(i-j); epsilon~N(0,1) independently.
- beta_j=1.5*0.8^j for j=1,...,800; Y=sum_j beta_j*X_j+epsilon.
- Two independent samples from the same population: source_n_labeled rows with observed Y and source_n_unlabeled rows with observed X only. R=1 in the first labeled block; Y_obs=Y there. R=0 in the remaining block; Y_obs=0 is a placeholder.

## Fixed original scenario

- `observation_rule`: `two_independent_samples`
- `placeholder`: `0.0`
- `mechanism`: `explained`
- `dimension`: `800`
- `source_n_labeled`: `400`
- `source_n_unlabeled`: `2000`
- `rho`: `0.5`
- `coefficient_scale`: `1.5`
- `coefficient_decay`: `0.8`
- `noise_sd`: `1.0`

Every parameter belongs to this single named scenario. The source allocation is reproduced at total n=2400. At another n, the integer allocation in collection.json preserves the source ratio approximately while retaining both sample groups. The generator accepts this declared configuration exactly.

## Observation, sampling and target

The target is **beta^T Sigma beta**: Explained population variance Var(E[Y|X])=beta^T Sigma beta.

Independent units are sampled from the same population. Label availability is fixed independently of X and Y. X is observed in both sample groups. R identifies the labeled rows. For R=0, Y_obs=0 is an interface placeholder; every downstream method must mask it using R. Internal latent variables and unused outcomes stay internal. The output contains exactly the schema columns. For the discrete-surrogate mechanism, X1 is the explicitly observed auxiliary prediction.

The generator exposes covariates as auxiliary information; fitted predictions are supplied by subsequent statistical methods using permitted labeled data and their documented training or cross-fitting splits. This contribution supplies the sampling law and observed data; later methods specify training and validation partitions. Prediction columns are absent.

## Truth and verification

Compute the finite quadratic form sum_{i,j=1}^{800} beta_i beta_j rho^abs(i-j). An independent AR innovation expansion gives the same variance.

Reference scalar: **9.33333333333334**. Estimated numerical error: 5e-13. Analytic zeros in the error field denote zero integration error; ordinary floating-point rounding still applies. Numerical estimates describe convergence/rounding diagnostics for this fixed configuration.

truth.py computes the population functional. verify.py supplies a separate numerical calculation and a hand-checkable special case. The route and numerical difference are recorded in checks/report.json. Both calculations share the documented law and fixed parameters. The tolerance is 1e-8, set before validation. Tests also check the observation mask, output columns, finite values and seeded replay.

## Properties and scope

All 800 coefficients are nonzero and dimension exceeds labeled n=400; their geometric decay means strengths differ substantially. The response is linear and homoskedastic. effective_dimension counts inputs that determine the conditional response law, including an observed surrogate or the sole tail-dependent auxiliary variable; correlated extra coordinates may carry additional information. high_dimensional compares total dimension with source labeled sample size. Interactions marks a nonadditive response/probability map.

This contribution covers the declared source scenario, scalar population target and observed-data contract. Confidence intervals, fitted estimators and model performance belong to the subsequent benchmark stage.

## Adaptations

1. Select Setting 4 and N=2000 from Table 1.
2. Preserve the original finite 800-coordinate target; record effective dimension as exact support size.
3. Represent independent labeled/unlabeled samples in a single table: all X columns, label indicator R and Y_obs. A zero on an R=0 row is a finite placeholder.
4. The generate argument n counts total rows. Source total yields exact source allocation; other n use nearest-integer ratio allocation with both groups nonempty.
5. Use local PCG64 random streams, with independent covariate and response-noise streams. Each row remains an independent population draw.

## Reproduce

From the teacher toolkit root, substitute this directory for CONTRIBUTION:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTPUT.zip
```

The eight required files, source_audit.json, checks/ evidence and the generated MANIFEST.json accompany the official archive. Checks must be repeated after source edits. The source constants, noise parameterizations and observation masks were reviewed before execution.

## Rights, assistance and review

Article rights remain with their respective rights holders. This contribution contains independently written Apache-2.0 code and factual source descriptions. Source PDFs, figures and author software remain in local research materials. All generated records are synthetic.

AI assistance: Codex supported source reading, coding, numerical derivation and computational review. The user reviews the contribution before submission. Named human scientific review, independent-person replication and final acceptance are maintained by the project team. Family is semi_supervised; the current six-category registry queues this family for maintainer classification.
