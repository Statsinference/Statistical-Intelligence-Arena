"""Population scalar functional. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'explained', 'dimension': 800, 'source_n_labeled': 400, 'source_n_unlabeled': 2000, 'rho': 0.5, 'coefficient_scale': 1.5, 'coefficient_decay': 0.8, 'noise_sd': 1.0}



def truth(config):
    if config != SOURCE_CONFIG:
        raise ValueError('This contribution supports exactly the declared original scenario')
    c=config
    b=c['coefficient_scale']*c['coefficient_decay']**np.arange(1,c['dimension']+1)
    value=float(np.dot(b,b)+2*math.fsum(c['rho']**h*float(np.dot(b[:-h],b[h:])) for h in range(1,len(b))))
    return dict(value=value,estimated_error=5e-13,method='finite 800-coordinate covariance lag sum; rounding diagnostic')
