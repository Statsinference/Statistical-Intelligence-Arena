"""Population scalar functional. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'quadratic', 'dimension': 1, 'source_n_labeled': 100, 'source_n_unlabeled': 200, 'alpha': 0.5, 'beta': 1.0, 'noise_sd': 1.0}



def truth(config):
    if config != SOURCE_CONFIG:
        raise ValueError('This contribution supports exactly the declared original scenario')
    c=config
    return dict(value=c['beta'],estimated_error=0.0,method='population covariance divided by variance; Gaussian third moment zero')
