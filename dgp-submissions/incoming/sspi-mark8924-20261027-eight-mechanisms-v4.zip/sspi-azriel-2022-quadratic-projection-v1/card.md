# Best linear slope under a quadratic Gaussian response

Contributor: 马铭远 / Mark8924. Task: SSPI T05/T06. Status: prepared for contributor review and subsequent scientific review.

## Source and reconstruction

Azriel, D., Brown, L. D., Sklar, M., Berk, R., Buja, A. and Zhao, L. (2022). Semi-Supervised Linear Regression. JASA 117(540), 2238–2251.

DOI: https://doi.org/10.1080/01621459.2021.1915320

Reading source: https://arxiv.org/pdf/1612.02391v4

Version: arXiv:1612.02391v4, 13 April 2021; version linked by the first author under the published JASA article.

Locator: Section 5.1, equation (27), PDF p. 18; Figure 1, PDF p. 19 (alpha=1/2, beta=1, n=100, m=2n); Section 1.1 and Section 2 define sampling and projection.

Source PDF SHA-256: 5736a6c23905fd62121b7aec85ce40d568a80f4f7b8a23f05d7d349b274e0b1f.

- X~N(0,1) and epsilon~N(0,1) independently.
- Y=0.5*X^2+X+epsilon.
- Two independent samples from the same population: source_n_labeled rows with observed Y and source_n_unlabeled rows with observed X only. R=1 in the first labeled block; Y_obs=Y there. R=0 in the remaining block; Y_obs=0 is a placeholder.

## Fixed original scenario

- `observation_rule`: `two_independent_samples`
- `placeholder`: `0.0`
- `mechanism`: `quadratic`
- `dimension`: `1`
- `source_n_labeled`: `100`
- `source_n_unlabeled`: `200`
- `alpha`: `0.5`
- `beta`: `1.0`
- `noise_sd`: `1.0`

Every parameter belongs to this single named scenario. The source allocation is reproduced at total n=300. At another n, the integer allocation in collection.json preserves the source ratio approximately while retaining both sample groups. The generator accepts this declared configuration exactly.

## Observation, sampling and target

The target is **beta_L2**: Slope in the population least-squares projection of Y on (1,X).

Independent units are sampled from the same population. Label availability is fixed independently of X and Y. X is observed in both sample groups. R identifies the labeled rows. For R=0, Y_obs=0 is an interface placeholder; every downstream method must mask it using R. Internal latent variables and unused outcomes stay internal. The output contains exactly the schema columns. For the discrete-surrogate mechanism, X1 is the explicitly observed auxiliary prediction.

The generator exposes covariates as auxiliary information; fitted predictions are supplied by subsequent statistical methods using permitted labeled data and their documented training or cross-fitting splits. This contribution supplies the sampling law and observed data; later methods specify training and validation partitions. Prediction columns are absent.

## Truth and verification

Cov(X,Y)/Var(X)=[0.5 E(X^3)+E(X^2)]/1=1; the projection intercept is 0.5.

Reference scalar: **1**. Estimated numerical error: 0. Analytic zeros in the error field denote zero integration error; ordinary floating-point rounding still applies. Numerical estimates describe convergence/rounding diagnostics for this fixed configuration.

truth.py computes the population functional. verify.py supplies a separate numerical calculation and a hand-checkable special case. The route and numerical difference are recorded in checks/report.json. Both calculations share the documented law and fixed parameters. The tolerance is 1e-8, set before validation. Tests also check the observation mask, output columns, finite values and seeded replay.

## Properties and scope

One active covariate; a quadratic conditional mean with a linear-projection target. effective_dimension counts inputs that determine the conditional response law, including an observed surrogate or the sole tail-dependent auxiliary variable; correlated extra coordinates may carry additional information. high_dimensional compares total dimension with source labeled sample size. Interactions marks a nonadditive response/probability map.

This contribution covers the declared source scenario, scalar population target and observed-data contract. Confidence intervals, fitted estimators and model performance belong to the subsequent benchmark stage.

## Adaptations

1. Select alpha=1/2 and n=100 from the source Figure 1 grid, beta=1 and m=2n.
2. Return the slope component of the population linear projection through the scalar truth interface.
3. Represent independent labeled/unlabeled samples in a single table: all X columns, label indicator R and Y_obs. A zero on an R=0 row is a finite placeholder.
4. The generate argument n counts total rows. Source total yields exact source allocation; other n use nearest-integer ratio allocation with both groups nonempty.
5. Use local PCG64 random streams, with independent covariate and response-noise streams. Each row remains an independent population draw.

## Reproduce

From the teacher toolkit root, substitute this directory for CONTRIBUTION:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTPUT.zip
```

The eight required files, source_audit.json, checks/ evidence and the generated MANIFEST.json accompany the official archive. Checks must be repeated after source edits. The source constants, noise parameterizations and observation masks were reviewed before execution.

## Rights, assistance and review

Article rights remain with their respective rights holders. This contribution contains independently written Apache-2.0 code and factual source descriptions. Source PDFs, figures and author software remain in local research materials. All generated records are synthetic.

AI assistance: Codex supported source reading, coding, numerical derivation and computational review. The user reviews the contribution before submission. Named human scientific review, independent-person replication and final acceptance are maintained by the project team. Family is semi_supervised; the current six-category registry queues this family for maintainer classification.
