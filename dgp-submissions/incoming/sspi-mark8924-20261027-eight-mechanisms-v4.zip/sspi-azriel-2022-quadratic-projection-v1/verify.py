"""Independent numerical routes and source algebra fixtures. SPDX-License-Identifier: Apache-2.0."""
import importlib.util
from pathlib import Path
import math
import numpy as np
from scipy.integrate import quad, cumulative_simpson
from scipy.interpolate import CubicSpline
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'quadratic', 'dimension': 1, 'source_n_labeled': 100, 'source_n_unlabeled': 200, 'alpha': 0.5, 'beta': 1.0, 'noise_sd': 1.0}

def _load(name):
    spec=importlib.util.spec_from_file_location('verify_local_'+name,Path(__file__).with_name(name+'.py'))
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

def _normal(z): return np.exp(-z*z/2)/math.sqrt(2*math.pi)

def _simpson(f,a=-12,b=12,n=24000):
    x=np.linspace(a,b,n+1); y=f(x)
    return float((b-a)/(3*n)*(y[0]+y[-1]+4*y[1:-1:2].sum()+2*y[2:-1:2].sum()))



def verify(config):
    c=config; g=_load('generator'); t=_load('truth')
    checks=[]
    def check(name,passed,details):checks.append(dict(name=name,passed=bool(passed),details=details))
    check('source_scenario',c==SOURCE_CONFIG,'Fixed source setting and declared scalar query')
    got=t.truth(c)
    independent=_simpson(lambda z:z*(0.5*z*z+z)*_normal(z))/_simpson(lambda z:z*z*_normal(z))
    check('independent_truth_route',abs(got['value']-independent)<1e-8,
          dict(truth=got['value'],independent=float(independent),difference=float(abs(got['value']-independent))))
    check('truth_precision',got['estimated_error']<=1e-8,got['estimated_error'])
    y=g._response(np.array([[-1.0],[1.0]]),np.zeros(2),c);check('symmetric_slope',abs((y[1]-y[0])/2-1)<1e-12,'The quadratic cancels between x=+1 and x=-1')
    a=g.generate(c,128,1729); b=g.generate(c,128,1729)
    r=np.asarray(a['R']); y=np.asarray(a['Y_obs'])
    check('observed_data_contract',set(a)=={f'X{j+1}' for j in range(c['dimension'])}|{'R','Y_obs'} and all(len(v)==128 for v in a.values()) and np.all(y[r==0]==0),'All covariates, R and masked outcome only')
    check('replay',a==b,'Same seed gives identical observations')
    check('finite',all(np.isfinite(v).all() for v in map(np.asarray,a.values())),'Finite numeric output')
    return dict(passed=all(x['passed'] for x in checks),checks=checks,
        shared_components='These computations use the same documented distribution and configuration. The numerical oracle route is separate from truth.py; algebra/mask fixtures intentionally exercise generator.py. Computational review by the contributor with AI assistance; human review remains pending.')
