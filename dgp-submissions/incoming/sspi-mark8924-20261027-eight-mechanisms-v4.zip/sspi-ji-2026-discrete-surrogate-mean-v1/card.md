# Population mean with a miscalibrated three-level surrogate

Contributor: 马铭远 / Mark8924. Task: SSPI T05/T06. Status: prepared for contributor review and subsequent scientific review.

## Source and reconstruction

Ji, W., Lei, L. and Zrnic, T. (2026). Predictions as Surrogates: Revisiting Surrogate Outcomes in the Age of AI. Biometrika, asag053, advance online accepted manuscript, published 10 September 2026.

DOI: https://doi.org/10.1093/biomet/asag053

Reading source: https://arxiv.org/pdf/2501.09731v2

Version: arXiv:2501.09731v2, 21 June 2026 (PDF dated 23 June); an explicitly identified preprint of the Biometrika article. The equation-level source here is this version..

Locator: Section 4.3.1, PDF p. 16 (mixture law and observed prediction); Appendix E.1.3 and Figure 6, PDF p. 42 (mu1=-2,mu2=0,sigma^2=1,n=1000,N=9000; choose plotted mu3=4).

Source PDF SHA-256: 62662931445da2a8698310ef7d8e75a054809f0e7d9682a1707d60608bcca64e.

- Z~Uniform({1,2,3}); epsilon~N(0,1) independently; Y=mu_Z+epsilon, with (mu1,mu2,mu3)=(-2,0,4).
- The source assumes an observed fixed surrogate prediction Y_hat=Z. Export it as X1 with role auxiliary_prediction, on both labeled and unlabeled rows.
- Two independent samples from the same population: source_n_labeled rows with observed Y and source_n_unlabeled rows with observed X only. R=1 in the first labeled block; Y_obs=Y there. R=0 in the remaining block; Y_obs=0 is a placeholder.

## Fixed original scenario

- `observation_rule`: `two_independent_samples`
- `placeholder`: `0.0`
- `mechanism`: `discrete`
- `dimension`: `1`
- `source_n_labeled`: `1000`
- `source_n_unlabeled`: `9000`
- `component_means`: `[-2.0, 0.0, 4.0]`
- `noise_sd`: `1.0`

Every parameter belongs to this single named scenario. The source allocation is reproduced at total n=10000. At another n, the integer allocation in collection.json preserves the source ratio approximately while retaining both sample groups. The generator accepts this declared configuration exactly.

## Observation, sampling and target

The target is **E[Y]**: Population mean of Y, aided by the observed discrete prediction.

Independent units are sampled from the same population. Label availability is fixed independently of X and Y. X is observed in both sample groups. R identifies the labeled rows. For R=0, Y_obs=0 is an interface placeholder; every downstream method must mask it using R. Internal latent variables and unused outcomes stay internal. The output contains exactly the schema columns. For the discrete-surrogate mechanism, X1 is the explicitly observed auxiliary prediction.

The source provides a fixed stylized prediction Y_hat=Z on every row; X1 stores this observed auxiliary prediction. It requires no model fitting or training split in the DGP. Recalibration methods fit their map using labeled data and must specify their own splitting rule.

## Truth and verification

Average the three equally likely conditional means: E[Y]=(-2+0+4)/3=2/3. Independent integration of the three Gaussian component densities gives the same value.

Reference scalar: **0.666666666666667**. Estimated numerical error: 0. Analytic zeros in the error field denote zero integration error; ordinary floating-point rounding still applies. Numerical estimates describe convergence/rounding diagnostics for this fixed configuration.

truth.py computes the population functional. verify.py supplies a separate numerical calculation and a hand-checkable special case. The route and numerical difference are recorded in checks/report.json. Both calculations share the documented law and fixed parameters. The tolerance is 1e-8, set before validation. Tests also check the observation mask, output columns, finite values and seeded replay.

## Properties and scope

One observed discrete prediction input. Conditional means -2,0,4 are nonaffine in its numeric levels 1,2,3. Conditional outcome variance equals one. effective_dimension counts inputs that determine the conditional response law, including an observed surrogate or the sole tail-dependent auxiliary variable; correlated extra coordinates may carry additional information. high_dimensional compares total dimension with source labeled sample size. Interactions marks a nonadditive response/probability map.

This contribution covers the declared source scenario, scalar population target and observed-data contract. Confidence intervals, fitted estimators and model performance belong to the subsequent benchmark stage.

## Adaptations

1. Select mu3=4 from Figure 6; keep source n=1000,N=9000.
2. Name the observed surrogate X1 to match the numeric table interface; its schema role is auxiliary_prediction. The surrogate is part of the specified sampling law and is available before target labels.
3. Represent independent labeled/unlabeled samples in a single table: all X columns, label indicator R and Y_obs. A zero on an R=0 row is a finite placeholder.
4. The generate argument n counts total rows. Source total yields exact source allocation; other n use nearest-integer ratio allocation with both groups nonempty.
5. Use local PCG64 random streams, with independent covariate and response-noise streams. Each row remains an independent population draw.

## Reproduce

From the teacher toolkit root, substitute this directory for CONTRIBUTION:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTPUT.zip
```

The eight required files, source_audit.json, checks/ evidence and the generated MANIFEST.json accompany the official archive. Checks must be repeated after source edits. The source constants, noise parameterizations and observation masks were reviewed before execution.

## Rights, assistance and review

Article rights remain with their respective rights holders. This contribution contains independently written Apache-2.0 code and factual source descriptions. Source PDFs, figures and author software remain in local research materials. All generated records are synthetic.

AI assistance: Codex supported source reading, coding, numerical derivation and computational review. The user reviews the contribution before submission. Named human scientific review, independent-person replication and final acceptance are maintained by the project team. Family is semi_supervised; the current six-category registry queues this family for maintainer classification.
