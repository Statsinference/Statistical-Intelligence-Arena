"""Population scalar functional. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'discrete', 'dimension': 1, 'source_n_labeled': 1000, 'source_n_unlabeled': 9000, 'component_means': [-2.0, 0.0, 4.0], 'noise_sd': 1.0}



def truth(config):
    if config != SOURCE_CONFIG:
        raise ValueError('This contribution supports exactly the declared original scenario')
    c=config
    return dict(value=math.fsum(c['component_means'])/3,estimated_error=0.0,method='mean of equally weighted Gaussian component means')
