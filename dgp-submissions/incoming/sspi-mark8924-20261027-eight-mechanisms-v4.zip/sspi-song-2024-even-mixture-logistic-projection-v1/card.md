# Logistic projection under an even nonlinear Gaussian-mixture response

Contributor: 马铭远 / Mark8924. Task: SSPI T05/T06. Status: prepared for contributor review and subsequent scientific review.

## Source and reconstruction

Song, S., Lin, Y. and Zhou, Y. (2024). A General M-estimation Theory in Semi-Supervised Framework. JASA 119(546), 1065–1075.

DOI: https://doi.org/10.1080/01621459.2023.2169699

Reading source: https://tandf.figshare.com/articles/dataset/22191384/1

Version: Official published supplementary material, Figshare article 22191384 version 1, released 28 February 2023; file 39438924 contains the supplement and reproducibility R code..

Locator: Official supplement Section 3.2, Setting S2, PDF p. 43; sample grid p. 44; Figure 12(b), p. 51. Released dataGeneration.R: GenerateData option S2 and g_S2.

Source PDF SHA-256: c38b9b93cba8a34cdaf9a08a4bc2c24aa75677f173e395667c4336351cb0db8e.

- B is equiprobable on {-1,+1}; G~N_4(0,Sigma), Sigma_jk=0.8^abs(j-k), independently. X=B*1+G.
- Y|X~Bernoulli(expit(sum_{j=1}^4 [0.9*X_j^4*sin(X_j)^6-2*X_j^2+2.2])). Conditional draws are independent across rows.
- Two independent samples from the same population: source_n_labeled rows with observed Y and source_n_unlabeled rows with observed X only. R=1 in the first labeled block; Y_obs=Y there. R=0 in the remaining block; Y_obs=0 is a placeholder.

## Fixed original scenario

- `observation_rule`: `two_independent_samples`
- `placeholder`: `0.0`
- `mechanism`: `songlogit`
- `dimension`: `4`
- `source_n_labeled`: `250`
- `source_n_unlabeled`: `1000`
- `rho`: `0.8`
- `mixture_shift`: `1.0`
- `query_coordinate`: `1`

Every parameter belongs to this single named scenario. The source allocation is reproduced at total n=1250. At another n, the integer allocation in collection.json preserves the source ratio approximately while retaining both sample groups. The generator accepts this declared configuration exactly.

## Observation, sampling and target

The target is **theta_logistic[1]**: First slope in the population logistic-loss projection of Y on (1,X1,...,X4).

Independent units are sampled from the same population. Label availability is fixed independently of X and Y. X is observed in both sample groups. R identifies the labeled rows. For R=0, Y_obs=0 is an interface placeholder; every downstream method must mask it using R. Internal latent variables and unused outcomes stay internal. The output contains exactly the schema columns. For the discrete-surrogate mechanism, X1 is the explicitly observed auxiliary prediction.

The generator exposes covariates as auxiliary information; fitted predictions are supplied by subsequent statistical methods using permitted labeled data and their documented training or cross-fitting splits. This contribution supplies the sampling law and observed data; later methods specify training and validation partitions. Prediction columns are absent.

## Truth and verification

The distribution of X is centrally symmetric and its response probability q satisfies q(-X)=q(X). Hence E[X]=E[X*q(X)]=0. At zero slopes and intercept logit(E[q(X)]), every population score vanishes. Full support makes the logistic risk strictly convex, so all projection slopes are exactly zero.

Reference scalar: **0**. Estimated numerical error: 0. Analytic zeros in the error field denote zero integration error; ordinary floating-point rounding still applies. Numerical estimates describe convergence/rounding diagnostics for this fixed configuration.

truth.py computes the population functional. verify.py supplies a separate numerical calculation and a hand-checkable special case. The route and numerical difference are recorded in checks/report.json. Both calculations share the documented law and fixed parameters. The tolerance is 1e-8, set before validation. Tests also check the observation mask, output columns, finite values and seeded replay.

## Properties and scope

All four coordinates affect the nonlinear response probability even though the linear logistic projection slopes vanish by symmetry. effective_dimension counts the generating response support. The Gaussian mixture is correlated; Bernoulli conditional variance varies with X. effective_dimension counts inputs that determine the conditional response law, including an observed surrogate or the sole tail-dependent auxiliary variable; correlated extra coordinates may carry additional information. high_dimensional compares total dimension with source labeled sample size. Interactions marks a nonadditive response/probability map.

This contribution covers the declared source scenario, scalar population target and observed-data contract. Confidence intervals, fitted estimators and model performance belong to the subsequent benchmark stage.

## Adaptations

1. Select S2 with p=4,n=250,N=1000 from Figure 12(b).
2. Return the first slope of the source population logistic projection; its zero truth follows from central symmetry.
3. Represent independent labeled/unlabeled samples in a single table: all X columns, label indicator R and Y_obs. A zero on an R=0 row is a finite placeholder.
4. The generate argument n counts total rows. Source total yields exact source allocation; other n use nearest-integer ratio allocation with both groups nonempty.
5. Use local PCG64 random streams, with independent covariate and response-noise streams. Each row remains an independent population draw.

## Reproduce

From the teacher toolkit root, substitute this directory for CONTRIBUTION:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTPUT.zip
```

The eight required files, source_audit.json, checks/ evidence and the generated MANIFEST.json accompany the official archive. Checks must be repeated after source edits. The source constants, noise parameterizations and observation masks were reviewed before execution.

## Rights, assistance and review

Article rights remain with their respective rights holders. This contribution contains independently written Apache-2.0 code and factual source descriptions. Source PDFs, figures and author software remain in local research materials. All generated records are synthetic.

AI assistance: Codex supported source reading, coding, numerical derivation and computational review. The user reviews the contribution before submission. Named human scientific review, independent-person replication and final acceptance are maintained by the project team. Family is semi_supervised; the current six-category registry queues this family for maintainer classification.
