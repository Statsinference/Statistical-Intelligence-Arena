"""Population scalar functional. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'songlogit', 'dimension': 4, 'source_n_labeled': 250, 'source_n_unlabeled': 1000, 'rho': 0.8, 'mixture_shift': 1.0, 'query_coordinate': 1}



def truth(config):
    if config != SOURCE_CONFIG:
        raise ValueError('This contribution supports exactly the declared original scenario')
    c=config
    return dict(value=0.0,estimated_error=0.0,method='central symmetry and uniqueness of population logistic projection')
