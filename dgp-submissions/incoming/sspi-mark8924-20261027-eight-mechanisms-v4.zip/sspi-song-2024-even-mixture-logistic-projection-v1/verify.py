"""Independent numerical routes and source algebra fixtures. SPDX-License-Identifier: Apache-2.0."""
import importlib.util
from pathlib import Path
import math
import numpy as np
from scipy.integrate import quad, cumulative_simpson
from scipy.interpolate import CubicSpline
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'songlogit', 'dimension': 4, 'source_n_labeled': 250, 'source_n_unlabeled': 1000, 'rho': 0.8, 'mixture_shift': 1.0, 'query_coordinate': 1}

def _load(name):
    spec=importlib.util.spec_from_file_location('verify_local_'+name,Path(__file__).with_name(name+'.py'))
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

def _normal(z): return np.exp(-z*z/2)/math.sqrt(2*math.pi)

def _simpson(f,a=-12,b=12,n=24000):
    x=np.linspace(a,b,n+1); y=f(x)
    return float((b-a)/(3*n)*(y[0]+y[-1]+4*y[1:-1:2].sum()+2*y[2:-1:2].sum()))

def _logistic_projection(c,order):
    from scipy.special import roots_hermitenorm
    from scipy.optimize import root
    nodes,weights=roots_hermitenorm(order)
    weights=weights/math.sqrt(2*math.pi)
    grid=np.stack(np.meshgrid(*([nodes]*4),indexing='ij'),axis=-1).reshape(-1,4)
    w=np.prod(np.stack(np.meshgrid(*([weights]*4),indexing='ij'),axis=-1),axis=-1).ravel()/2
    sigma=c['rho']**np.abs(np.subtract.outer(np.arange(4),np.arange(4)))
    plus=grid@np.linalg.cholesky(sigma).T+1
    x=np.concatenate([plus,-plus]);w=np.concatenate([w,w])
    a=np.column_stack([np.ones(len(x)),x])
    # Re-express the conditional probability independently of generator.py.
    q=1/(1+np.exp(-np.sum(.9*x**4*np.sin(x)**6-2*x*x+2.2,axis=1)))
    def score(t):return a.T@(w*(expit(a@t)-q))
    def hessian(t):
        v=expit(a@t);return a.T@((w*v*(1-v))[:,None]*a)
    fitted=root(score,np.array([.4,.03,-.02,.01,-.04]),jac=hessian,tol=1e-11)
    if np.max(np.abs(score(fitted.x)))>1e-9:raise RuntimeError('Logistic score solve failed')
    return float(fitted.x[1]),float(np.max(np.abs(score(fitted.x)))),float(np.linalg.eigvalsh(hessian(fitted.x)).min())


def verify(config):
    c=config; g=_load('generator'); t=_load('truth')
    checks=[]
    def check(name,passed,details):checks.append(dict(name=name,passed=bool(passed),details=details))
    check('source_scenario',c==SOURCE_CONFIG,'Fixed source setting and declared scalar query')
    got=t.truth(c)
    independent,score,hessian_min=_logistic_projection(c,13)
    coarse,_,_=_logistic_projection(c,9)
    check('projection_normal_equations',score<1e-9 and hessian_min>0,'Tensor-normal quadrature solves the full intercept-and-slopes logistic score; Hessian positive')
    check('projection_symmetry_on_two_grids',abs(independent-coarse)<1e-8,'Independent quadrature orders 9 and 13 give zero first slope')
    check('independent_truth_route',abs(got['value']-independent)<1e-8,
          dict(truth=got['value'],independent=float(independent),difference=float(abs(got['value']-independent))))
    check('truth_precision',got['estimated_error']<=1e-8,got['estimated_error'])
    x=np.array([[.2,-.7,1.1,2.0],[-.2,.7,-1.1,-2.0]]);q=g._probability(x,c);check('even_response',abs(q[0]-q[1])<1e-14,'Central sign reversal preserves the source conditional probability')
    a=g.generate(c,128,1729); b=g.generate(c,128,1729)
    r=np.asarray(a['R']); y=np.asarray(a['Y_obs'])
    check('observed_data_contract',set(a)=={f'X{j+1}' for j in range(c['dimension'])}|{'R','Y_obs'} and all(len(v)==128 for v in a.values()) and np.all(y[r==0]==0),'All covariates, R and masked outcome only')
    check('replay',a==b,'Same seed gives identical observations')
    check('finite',all(np.isfinite(v).all() for v in map(np.asarray,a.values())),'Finite numeric output')
    return dict(passed=all(x['passed'] for x in checks),checks=checks,
        shared_components='These computations use the same documented distribution and configuration. The numerical oracle route is separate from truth.py; algebra/mask fixtures intentionally exercise generator.py. Computational review by the contributor with AI assistance; human review remains pending.')
