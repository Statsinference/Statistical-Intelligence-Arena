# Marginal distribution inference with sparse Gaussian linear signal

Contributor: 马铭远 / Mark8924. Task: SSPI T05/T06. Status: prepared for contributor review and subsequent scientific review.

## Source and reconstruction

Wen, M., Jia, Y., Ren, H., Wang, Z. and Zou, C. (2025). Semi-supervised distribution learning. Biometrika 112(1), asae056.

DOI: https://doi.org/10.1093/biomet/asae056

Reading source: https://mtwen.github.io/documents/BASD24.pdf

Version: Final journal PDF from first author, downloaded copy dated 21 January 2025.

Locator: Section 3, unnumbered DGP equations, PDF p. 6; Table 1, Figure 1 and sample sizes, PDF p. 7. Section 2 defines labeled/unlabeled samples and marginal CDF.

Source PDF SHA-256: 1eb4cdf85a7f8fe388f9b6993306d9743fee374e2e3b24daf90a6cd9a5e22efc.

- X~N_100(0,I); epsilon~N(0,1) independently; s=ceil(0.1*p)=10.
- Y=sum_{j=1}^{10} X_j/sqrt(10)+0.5*epsilon.
- Two independent samples from the same population: source_n_labeled rows with observed Y and source_n_unlabeled rows with observed X only. R=1 in the first labeled block; Y_obs=Y there. R=0 in the remaining block; Y_obs=0 is a placeholder.

## Fixed original scenario

- `observation_rule`: `two_independent_samples`
- `placeholder`: `0.0`
- `mechanism`: `cdf`
- `dimension`: `100`
- `source_n_labeled`: `1000`
- `source_n_unlabeled`: `10000`
- `sparsity`: `10`
- `noise_sd`: `0.5`
- `cdf_threshold`: `1.0`

Every parameter belongs to this single named scenario. The source allocation is reproduced at total n=11000. At another n, the integer allocation in collection.json preserves the source ratio approximately while retaining both sample groups. The generator accepts this declared configuration exactly.

## Observation, sampling and target

The target is **F_Y(1)**: Marginal population CDF Pr(Y<=1), using the semi-supervised observation design.

Independent units are sampled from the same population. Label availability is fixed independently of X and Y. X is observed in both sample groups. R identifies the labeled rows. For R=0, Y_obs=0 is an interface placeholder; every downstream method must mask it using R. Internal latent variables and unused outcomes stay internal. The output contains exactly the schema columns. For the discrete-surrogate mechanism, X1 is the explicitly observed auxiliary prediction.

The generator exposes covariates as auxiliary information; fitted predictions are supplied by subsequent statistical methods using permitted labeled data and their documented training or cross-fitting splits. This contribution supplies the sampling law and observed data; later methods specify training and validation partitions. Prediction columns are absent.

## Truth and verification

The signal is N(0,1), independent of noise N(0,0.25), so Y~N(0,1.25) and F_Y(1)=Phi(1/sqrt(1.25)).

Reference scalar: **0.814453315238651**. Estimated numerical error: 2e-15. Analytic zeros in the error field denote zero integration error; ordinary floating-point rounding still applies. Numerical estimates describe convergence/rounding diagnostics for this fixed configuration.

truth.py computes the population functional. verify.py supplies a separate numerical calculation and a hand-checkable special case. The route and numerical difference are recorded in checks/report.json. Both calculations share the documented law and fixed parameters. The tolerance is 1e-8, set before validation. Tests also check the observation mask, output columns, finite values and seeded replay.

## Properties and scope

Ten direct response coordinates among 100; source labeled n=1000. The conditional mean is linear and the conditional variance is constant. effective_dimension counts inputs that determine the conditional response law, including an observed surrogate or the sole tail-dependent auxiliary variable; correlated extra coordinates may carry additional information. high_dimensional compares total dimension with source labeled sample size. Interactions marks a nonadditive response/probability map.

This contribution covers the declared source scenario, scalar population target and observed-data contract. Confidence intervals, fitted estimators and model performance belong to the subsequent benchmark stage.

## Adaptations

1. Select p=100,n=1000,m=10000 from Table 1.
2. Fix scalar CDF query y=1, within the Figure 1 evaluation region. The source studies the full CDF; the interface checks this single query.
3. Represent independent labeled/unlabeled samples in a single table: all X columns, label indicator R and Y_obs. A zero on an R=0 row is a finite placeholder.
4. The generate argument n counts total rows. Source total yields exact source allocation; other n use nearest-integer ratio allocation with both groups nonempty.
5. Use local PCG64 random streams, with independent covariate and response-noise streams. Each row remains an independent population draw.

## Reproduce

From the teacher toolkit root, substitute this directory for CONTRIBUTION:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTPUT.zip
```

The eight required files, source_audit.json, checks/ evidence and the generated MANIFEST.json accompany the official archive. Checks must be repeated after source edits. The source constants, noise parameterizations and observation masks were reviewed before execution.

## Rights, assistance and review

Article rights remain with their respective rights holders. This contribution contains independently written Apache-2.0 code and factual source descriptions. Source PDFs, figures and author software remain in local research materials. All generated records are synthetic.

AI assistance: Codex supported source reading, coding, numerical derivation and computational review. The user reviews the contribution before submission. Named human scientific review, independent-person replication and final acceptance are maintained by the project team. Family is semi_supervised; the current six-category registry queues this family for maintainer classification.
