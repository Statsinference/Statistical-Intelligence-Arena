"""Population scalar functional. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'cdf', 'dimension': 100, 'source_n_labeled': 1000, 'source_n_unlabeled': 10000, 'sparsity': 10, 'noise_sd': 0.5, 'cdf_threshold': 1.0}



def truth(config):
    if config != SOURCE_CONFIG:
        raise ValueError('This contribution supports exactly the declared original scenario')
    c=config
    value=float(ndtr(c['cdf_threshold']/math.sqrt(1+c['noise_sd']**2)))
    return dict(value=value,estimated_error=2e-15,method='normal marginal CDF; floating-point diagnostic')
