# Extreme quantile with a tail-dependent Cauchy auxiliary variable

Contributor: 马铭远 / Mark8924. Task: SSPI T05/T06. Status: prepared for contributor review and subsequent scientific review.

## Source and reconstruction

Ahmed, H., Einmahl, J. H. J. and Zhou, C. (2025). Extreme Value Statistics in Semi-Supervised Models. JASA 120(549), 291–304.

DOI: https://doi.org/10.1080/01621459.2024.2333582

Reading source: https://www.tandfonline.com/doi/full/10.1080/01621459.2024.2333582

Version: Published publisher HTML; online 15 May 2024, journal issue 2025. PDF download returned HTTP 403; governing equation was read in full-text HTML..

Locator: Section 2.1 defines independent samples; Section 4, first-quadrant bivariate Cauchy construction and equation (16); extreme-quantile paragraph preceding Table 3 (s=0,n=500,m=1000,p=0.002).

Source PDF SHA-256: HTML source; exact section and equation recorded above.

- (V,U) has the bivariate standard Cauchy law restricted to V>0,U>0, with scale matrix I_2 (source s=0).
- Equivalent independent-normal construction: G0,G1,G2 iid N(0,1), V=abs(G1)/abs(G0), U=abs(G2)/abs(G0).
- F_0(v)=2*atan(v)/pi for v>=0. Outcome Y=-log(1-F_0(V)); observed covariate X1=U. Source gamma=0 in equation (16).
- Two independent samples from the same population: source_n_labeled rows with observed Y and source_n_unlabeled rows with observed X only. R=1 in the first labeled block; Y_obs=Y there. R=0 in the remaining block; Y_obs=0 is a placeholder.

## Fixed original scenario

- `observation_rule`: `two_independent_samples`
- `placeholder`: `0.0`
- `mechanism`: `tail`
- `dimension`: `1`
- `source_n_labeled`: `500`
- `source_n_unlabeled`: `1000`
- `cauchy_scale_offdiagonal`: `0.0`
- `gamma`: `0.0`
- `tail_probability`: `0.002`

Every parameter belongs to this single named scenario. The source allocation is reproduced at total n=1500. At another n, the integer allocation in collection.json preserves the source ratio approximately while retaining both sample groups. The generator accepts this declared configuration exactly.

## Observation, sampling and target

The target is **Q_Y(0.998)**: Marginal quantile inf{y:Pr(Y<=y)>=0.998} in the common population; tail probability is fixed at 0.002.

Independent units are sampled from the same population. Label availability is fixed independently of X and Y. X is observed in both sample groups. R identifies the labeled rows. For R=0, Y_obs=0 is an interface placeholder; every downstream method must mask it using R. Internal latent variables and unused outcomes stay internal. The output contains exactly the schema columns. For the discrete-surrogate mechanism, X1 is the explicitly observed auxiliary prediction.

The generator exposes covariates as auxiliary information; fitted predictions are supplied by subsequent statistical methods using permitted labeled data and their documented training or cross-fitting splits. This contribution supplies the sampling law and observed data; later methods specify training and validation partitions. Prediction columns are absent.

## Truth and verification

The probability integral transform gives Y~Exponential(rate=1). Thus Q_Y(0.998)=-log(0.002). Dependence with X1 is retained by the common denominator.

Reference scalar: **6.21460809842219**. Estimated numerical error: 0. Analytic zeros in the error field denote zero integration error; ordinary floating-point rounding still applies. Numerical estimates describe convergence/rounding diagnostics for this fixed configuration.

truth.py computes the population functional. verify.py supplies a separate numerical calculation and a hand-checkable special case. The route and numerical difference are recorded in checks/report.json. Both calculations share the documented law and fixed parameters. The tolerance is 1e-8, set before validation. Tests also check the observation mask, output columns, finite values and seeded replay.

## Properties and scope

One auxiliary covariate with infinite first moment; Y has an exponential marginal. Dependence persists even with source s=0. The target density equals 0.002 at the queried quantile. effective_dimension counts inputs that determine the conditional response law, including an observed surrogate or the sole tail-dependent auxiliary variable; correlated extra coordinates may carry additional information. high_dimensional compares total dimension with source labeled sample size. Interactions marks a nonadditive response/probability map.

This contribution covers the declared source scenario, scalar population target and observed-data contract. Confidence intervals, fitted estimators and model performance belong to the subsequent benchmark stage.

## Adaptations

1. Select s=0,gamma=0,n=500,m=1000 and p=1/500 from the source quantile setting.
2. Rename source target X as Y and source auxiliary Y as X1 to match the collection schema.
3. Use the equivalent absolute-normal construction for the s=0 first-quadrant law and evaluate the survival probability with atan2 for tail stability.
4. Represent independent labeled/unlabeled samples in a single table: all X columns, label indicator R and Y_obs. A zero on an R=0 row is a finite placeholder.
5. The generate argument n counts total rows. Source total yields exact source allocation; other n use nearest-integer ratio allocation with both groups nonempty.
6. Use local PCG64 random streams, with independent covariate and response-noise streams. Each row remains an independent population draw.

## Reproduce

From the teacher toolkit root, substitute this directory for CONTRIBUTION:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTPUT.zip
```

The eight required files, source_audit.json, checks/ evidence and the generated MANIFEST.json accompany the official archive. Checks must be repeated after source edits. The source constants, noise parameterizations and observation masks were reviewed before execution.

## Rights, assistance and review

Article rights remain with their respective rights holders. This contribution contains independently written Apache-2.0 code and factual source descriptions. Source PDFs, figures and author software remain in local research materials. All generated records are synthetic.

AI assistance: Codex supported source reading, coding, numerical derivation and computational review. The user reviews the contribution before submission. Named human scientific review, independent-person replication and final acceptance are maintained by the project team. Family is semi_supervised; the current six-category registry queues this family for maintainer classification.
