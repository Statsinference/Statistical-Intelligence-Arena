"""Population scalar functional. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import expit, ndtr

SOURCE_CONFIG = {'observation_rule': 'two_independent_samples', 'placeholder': 0.0, 'mechanism': 'tail', 'dimension': 1, 'source_n_labeled': 500, 'source_n_unlabeled': 1000, 'cauchy_scale_offdiagonal': 0.0, 'gamma': 0.0, 'tail_probability': 0.002}



def truth(config):
    if config != SOURCE_CONFIG:
        raise ValueError('This contribution supports exactly the declared original scenario')
    c=config
    value=-math.log(c['tail_probability'])
    return dict(value=value,estimated_error=0.0,method='probability integral transform and inverse exponential survival')
