# ATE DGP: Section 5.1 binary-outcome observational design

Status: candidate; not scientifically accepted.

## Source and exact location

Benkeser, Carone, van der Laan and Gilbert (2017), “Doubly robust nonparametric inference on the average treatment effect”, *Biometrika* 104(4), 863–880, DOI [10.1093/biomet/asx053](https://doi.org/10.1093/biomet/asx053). The source was read in the PMC full-text rendering, Section 5.1 “Data-generating mechanism and crossvalidation set-up” (journal printed pages approximately 870–871). The equations are unnumbered prose. The PMC text renderer exposes the expressions; the PDF page mapping was not visually verified in this run and must be checked by the maintainer against the journal PDF.

## Original generation sequence

1. Draw baseline covariates independently: `W1 ~ Uniform(-2,+2)` and `W2 ~ Bernoulli(1/2)`.
2. Draw treatment: `A | W=w ~ Bernoulli(g0(w))`, where `g0(w1,w2)=expit(-w1 + 2*w1*w2)`.
3. Draw binary outcome: `Y | A=a,W=w ~ Bernoulli(Qbar0(a,w))`, where `Qbar0(a,w)=expit(0.2*a - w1 + 2*w1*w2)`.

The binary draws are conditionally Bernoulli; no separate additive noise term or variance parameter is specified. Individuals are iid. There is dependence within each individual through the treatment and outcome conditionals, but no between-individual dependence or interference.

## Target and truth

The paper studies ATE and counterfactual means. This DGP implies `Y(a)|W=w` has mean `Qbar0(a,w)`. Thus `ATE = E_W[Qbar0(1,W)-Qbar0(0,W)]`. Integrating W2 over {0,1} with probability 1/2 and W1 uniformly over [-2,2] gives `0.0380264273106555` (Gauss-Legendre quadrature). An independently coded composite Simpson integration is used in `verify.py`. Numerical convergence diagnostics are not formal uniform error bounds.

Identification requires consistency, conditional exchangeability given W, and positivity. The specified propensity is expit of a finite function on compact covariate support, so pointwise positivity holds. The source's simulation has two covariates; it is not high-dimensional. The concrete interaction `W1*W2` appears in both logistic predictors. Nonlinearity refers to the expit link.

## Relation to paper's simulation scenarios

Section 5.1 subsequently compares three nuisance-estimation scenarios: (I) outcome regression consistently estimated only; (II) propensity score consistently estimated only; (III) both consistently estimated. These scenarios alter the working nuisance-estimation procedure, not the DGP itself. This contribution encodes the common underlying source DGP once; it does not mislabel the three estimator scenarios as separate DGP families. Sample-size values are rendered as inline equation images in the accessible full-text extraction and are not transcribed here. They are not needed to define the population mechanism.

## Scope, rights and open checks

This is an independently written implementation of the source equations. No PDF, author code, or data are included. No author code commit was identified or run. Maintainer should visually verify the printed/PDF page mapping and check the supplementary material's additional simulations before scientific acceptance. No PFN training, bootstrap, coverage study, or estimator reproduction was performed.
