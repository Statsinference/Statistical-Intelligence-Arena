import math
import numpy as np

def _expit(x):
    x = np.asarray(x, dtype=float)
    return 1.0/(1.0+np.exp(-x))

def _simpson(f, a, b, m=20000):
    if m % 2: m += 1
    x = np.linspace(a, b, m+1)
    y = f(x)
    h = (b-a)/m
    return h/3.0*(y[0]+y[-1]+4.0*np.sum(y[1:-1:2])+2.0*np.sum(y[2:-1:2]))/(b-a)

def verify(config):
    low, high = float(config["w1_low"]), float(config["w1_high"])
    p2 = float(config["w2_probability"])
    # Independent composite-Simpson route, enumerating W2.
    val = 0.0
    for w2, pw in ((0,1-p2),(1,p2)):
        def integrand(x):
            base = float(config["outcome_intercept"])+float(config["outcome_w1"])*x+float(config["outcome_w1w2"])*x*w2
            return _expit(base+float(config["outcome_treatment"]))-_expit(base)
        val += pw*_simpson(integrand,low,high)
    # Independent analytic sanity: with treatment coefficient zero, ATE must be exactly zero.
    zero = dict(config); zero["outcome_treatment"] = 0.0
    zero_val = 0.0
    for w2,pw in ((0,1-p2),(1,p2)):
        base = float(zero["outcome_intercept"])+float(zero["outcome_w1"])*np.array([low,high])+float(zero["outcome_w1w2"])*np.array([low,high])*w2
        zero_val += pw*float(np.mean(_expit(base)-_expit(base)))
    expected = 0.0380264273106555
    checks = [
      {"name":"independent Simpson integral agrees with source reference", "passed": bool(abs(val-expected)<2e-8), "details":f"Simpson={val:.15g}; reference={expected:.15g}"},
      {"name":"zero treatment-effect path gives zero ATE", "passed": bool(abs(zero_val)<1e-14), "details":f"zero-path ATE={zero_val:.3g}"},
      {"name":"propensity and outcome probabilities are strictly inside (0,1) on compact support", "passed": bool(all(0.0 < float(_expit(z)) < 1.0 for z in [-6.0,6.0])), "details":"expit of finite linear predictors; source covariate support is compact"}
    ]
    return {"passed": all(c["passed"] for c in checks), "checks":checks}
