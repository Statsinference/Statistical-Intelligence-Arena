import numpy as np

def _expit(x):
    return 1.0 / (1.0 + np.exp(-np.asarray(x, dtype=float)))

def truth(config):
    # Gauss-Legendre quadrature for W1 uniform on [low, high].
    nodes, weights = np.polynomial.legendre.leggauss(256)
    low, high = float(config["w1_low"]), float(config["w1_high"])
    w1 = (high-low)*nodes/2.0 + (high+low)/2.0
    w = weights/2.0  # uniform expectation on the transformed interval
    total = 0.0
    for w2, prob in ((0, 1-float(config["w2_probability"])), (1, float(config["w2_probability"]))):
        base = float(config["outcome_intercept"]) + float(config["outcome_w1"])*w1 + float(config["outcome_w1w2"])*w1*w2
        q1 = _expit(base + float(config["outcome_treatment"]))
        q0 = _expit(base)
        total += prob * float(np.sum(w*(q1-q0)))
    return {"value": float(total), "estimated_error": 1e-12, "method": "256-point Gauss-Legendre integration over W1 and exact enumeration of binary W2", "target": "E[Y(1)-Y(0)]"}
