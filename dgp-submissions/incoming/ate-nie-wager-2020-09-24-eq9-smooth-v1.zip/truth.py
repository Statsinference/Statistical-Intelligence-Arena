"""Analytic population ATE of the source mechanism."""

def truth(config):
    return {'value': 0.5, 'estimated_error': 1e-14, 'method': 'X2-X1 is symmetric about zero. expit(t)+expit(-t)=1, hence E[tau(X)]=1/2 and population ATE=0.5.', 'error_interpretation': 'Analytic identity with floating-point allowance, not Monte Carlo uncertainty.'}
