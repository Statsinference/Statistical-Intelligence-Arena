# 来源认领记录

mediation-cheng-li-2025-principal-strata-kang-schafer-v1

Cheng, C. and Li, F. (2025). Identification and multiply robust estimation in causal mediation analysis across principal strata. Journal of the Royal Statistical Society Series B: Statistical Methodology 88(1), 1-22. DOI: 10.1093/jrsssb/qkaf037.

实际阅读版本：arXiv:2304.10025v4 (2024-09-13) 预印本。期刊正式版未取得。

定位：§5 A simulation study，预印本 PDF 第 23 页的生成机制展示式；ITT-NIE / ITT-NDE 定义同在第 23 页；Figure 2 及其目标 theta^(10)_10 在第 24 页。页码为预印本 PDF 页码，非期刊页码 1-22。

机制区别：随机化处理 Z + 定义 principal strata 的二值事后事件 D（不依从）+ 二值中介 M + Kang-Schafer 式结局（误设模型下 positivity 实际被违背）；目标为**总体层面的 ITT 自然直接效应**，事后事件随干预变动。

**登记目标与原文 Figure 2 的目标不同**：原文画的是 principal stratum 条件量 theta^(10)_10 = E[Y_{1M_0} | U = 10]，而展示式只给出 D 在 (Z,X) 下的条件律，**没有规定 (D(1), D(0)) 的联合反事实律**，故该量不由展示式唯一确定，**不予登记**。登记的是原文自己定义的 ITT 自然直接效应（均值差尺度），它只依赖边际反事实均值。

真值：原文未给数值。登记 ITT-NDE = 1.180857104770165（二维 Gauss-Hermite 求积，阶 80/160 收敛至 1.2e-14），同时锚定 ITT-NIE = 0.3448130538915679。均为收集者推导，需审稿人核对。

已在 2026-10-30 的仓库快照内查重：mediation 域仅有 nie-eric-original-v1，incoming/ 中无 mediation-* 包。未向维护人发送，待维护人认领/全库查重与具名科学审核。
