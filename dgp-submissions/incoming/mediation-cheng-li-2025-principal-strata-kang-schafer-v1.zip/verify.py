"""Independent verification of the registered ITT natural direct effect.

Routes that do not share code with truth.py:
  * full four-dimensional Gauss-Hermite quadrature over X itself, with no Cholesky
    reduction to the two linear predictors;
  * two fixed-seed structural simulations that build the counterfactuals D(z) and M(z)
    under TWO DIFFERENT counterfactual couplings (shared uniforms and independent
    uniforms).  Both must agree with the registered value, which is exactly the
    evidence that the target needs no joint counterfactual law of (D(1), D(0)).
Plus source-constant, exact-identity, zero-path, anchor and scope checks.
"""
from copy import deepcopy
import importlib.util
import itertools
import math
from pathlib import Path

import numpy as np

FIXTURE = {
    "covariate_dimension": 4,
    "covariate_sd": 1.0,
    "treatment_coefficients": [-1.0, 0.5, -0.25, -0.1],
    "event_intercept": -1.0,
    "event_treatment_coefficient": 2.0,
    "event_coefficients": [1.0, -0.8, 0.6, -1.0],
    "mediator_intercept": -1.8,
    "mediator_treatment_coefficient": 2.0,
    "mediator_event_coefficient": 1.5,
    "mediator_coefficients": [1.0, -0.5, 0.9, -1.0],
    "outcome_intercept": 210.0,
    "outcome_treatment_coefficient": 1.5,
    "outcome_event_coefficient": -1.0,
    "outcome_mediator_coefficient": 1.0,
    "outcome_coefficients": [27.4, 13.7, 13.7, 13.7],
    "outcome_noise_sd": 1.0,
    "quadrature_orders": [80, 160],
    "target": "ITT_NDE",
}
MONTE_CARLO_TOLERANCE = 0.02


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("cl_collection_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _expit(values):
    return 1.0 / (1.0 + np.exp(-values))


def _full_quadrature(config, order):
    """Four-dimensional product Gauss-Hermite directly over X."""
    raw, weights = np.polynomial.hermite.hermgauss(order)
    weights = weights / math.sqrt(math.pi)
    raw = math.sqrt(2.0) * float(config["covariate_sd"]) * raw
    a_d = np.asarray(config["event_coefficients"], dtype=float)
    grid = np.array(list(itertools.product(raw, repeat=4)))
    mass = np.prod(np.array(list(itertools.product(weights, repeat=4))), axis=1)
    linear = grid @ a_d
    means = {}
    for z in (0.0, 1.0):
        event = _expit(float(config["event_intercept"])
                       + float(config["event_treatment_coefficient"]) * z + linear)
        means[z] = float(mass @ event)
    return (float(config["outcome_treatment_coefficient"])
            + float(config["outcome_event_coefficient"]) * (means[1.0] - means[0.0]))


def _simulated(config, n, seed, shared_uniforms):
    sampler = _module("generator.py")
    rng = np.random.Generator(np.random.PCG64(seed))
    x = float(config["covariate_sd"]) * rng.standard_normal((n, 4))
    noise = float(config["outcome_noise_sd"]) * rng.standard_normal(n)
    u_event = rng.random(n)
    u_mediator = rng.random(n)
    u_event_alt = u_event if shared_uniforms else rng.random(n)
    u_mediator_alt = u_mediator if shared_uniforms else rng.random(n)

    def event(z, uniform):
        linear = (float(config["event_intercept"])
                  + float(config["event_treatment_coefficient"]) * z
                  + x @ np.asarray(config["event_coefficients"], dtype=float))
        return (uniform < sampler.expit(linear)).astype(float)

    def mediator(z, d, uniform):
        linear = (float(config["mediator_intercept"])
                  + float(config["mediator_treatment_coefficient"]) * z
                  + float(config["mediator_event_coefficient"]) * d
                  + x @ np.asarray(config["mediator_coefficients"], dtype=float))
        return (uniform < sampler.expit(linear)).astype(float)

    d1 = event(1.0, u_event)
    d0 = event(0.0, u_event_alt)
    m0 = mediator(0.0, d0, u_mediator_alt)

    def outcome(z, d, m):
        return (float(config["outcome_intercept"])
                + float(config["outcome_treatment_coefficient"]) * z
                + float(config["outcome_event_coefficient"]) * d
                + float(config["outcome_mediator_coefficient"]) * m
                + x @ np.asarray(config["outcome_coefficients"], dtype=float) + noise)

    return float(np.mean(outcome(1.0, d1, m0) - outcome(0.0, d0, m0)))


def verify(config):
    oracle = _module("truth.py")
    oracle_result = oracle.truth(config)
    reference = oracle_result["value"]
    high_order = config["quadrature_orders"][1]

    quadrature = _full_quadrature(config, 12)
    shared = _simulated(config, 400000, 20261030, True)
    independent = _simulated(config, 400000, 20261030, False)

    means = oracle.counterfactual_means(config, high_order)
    indirect = oracle.itt_natural_indirect_effect(config, high_order)

    no_direct = deepcopy(config)
    no_direct["outcome_treatment_coefficient"] = 0.0
    no_direct["event_treatment_coefficient"] = 0.0
    no_mediator_path = deepcopy(config)
    no_mediator_path["outcome_mediator_coefficient"] = 0.0

    checks = [
        {"name": "source_constants_section_5",
         "passed": config == FIXTURE,
         "details": "All coefficients equal the Section 5 display of arXiv:2304.10025v4 page 23."},
        {"name": "independent_four_dimensional_quadrature",
         "passed": abs(quadrature - reference) < 1e-09,
         "details": f"Order-12 product Gauss-Hermite over X in four dimensions (20736 nodes) gives {quadrature:.14g}; the bivariate reduction in truth.py gives {reference:.14g}; difference {abs(quadrature - reference):.3g}. This route never forms the Cholesky factor, so a mis-registered covariance would break it."},
        {"name": "simulation_under_shared_counterfactual_coupling",
         "passed": abs(shared - reference) < MONTE_CARLO_TOLERANCE,
         "details": f"400000 units with D(1) and D(0) driven by the SAME uniform give {shared:.5f} against {reference:.14g}; deviation {abs(shared - reference):.3g} within the declared Monte Carlo tolerance {MONTE_CARLO_TOLERANCE}."},
        {"name": "simulation_under_independent_counterfactual_coupling",
         "passed": abs(independent - reference) < MONTE_CARLO_TOLERANCE,
         "details": f"The same simulation with INDEPENDENT uniforms for D(1) and D(0) gives {independent:.5f}, also within tolerance. Agreement under two different couplings is the evidence that the registered target needs only marginal counterfactual means, which is why the source's principal-stratum target theta^(10)_10 is deliberately not registered here."},
        {"name": "exact_event_symmetry_identity",
         "passed": abs(means["E[D(1)]"] + means["E[D(0)]"] - 1.0) < 1e-12,
         "details": f"E[D(1)] + E[D(0)] = {means['E[D(1)]'] + means['E[D(0)]']:.16g}. The identity holds exactly because the event intercept -1 and the treatment coefficient 2 are symmetric about zero and a_D^T X is symmetric, so it is a sharp check on both the intercept and the coefficient."},
        {"name": "quadrature_convergence",
         "passed": oracle_result["estimated_error"] < 1e-12,
         "details": f"Orders 80 and 160 differ by {oracle_result['estimated_error']:.3g}; an observed convergence diagnostic, not a rigorous bound."},
        {"name": "derived_anchors",
         "passed": (abs(reference - 1.180857104770165) < 1e-12
                    and abs(indirect - 0.3448130538915679) < 1e-12),
         "details": f"ITT-NDE = {reference:.15g} and ITT-NIE = {indirect:.15g} are DERIVED by the collector; the source prints no numerical truth. Both are registered so the direct effect cannot be confused with the indirect one."},
        {"name": "zero_direct_path",
         "passed": abs(oracle.truth(no_direct)["value"]) < 1e-12,
         "details": "Removing Z from the outcome equation and from the post-treatment-event equation gives an ITT natural direct effect of exactly 0."},
        {"name": "indirect_path_isolated",
         "passed": (abs(oracle.itt_natural_indirect_effect(no_mediator_path, high_order)) < 1e-12
                    and abs(oracle.truth(no_mediator_path)["value"] - reference) < 1e-12),
         "details": "Removing M from the outcome equation zeroes the ITT indirect effect and leaves the registered direct effect unchanged, as the decomposition requires."},
        {"name": "mechanism_excludes_estimation_transforms",
         "passed": not any(key.startswith("transformed") or "xtilde" in key.lower() for key in config),
         "details": "The Kang-Schafer style transforms exp(0.5 X1), X2/(1+X1), (X2 X3/25 + 0.6)^3 and (X2+X4+20)^2 are the source's misspecified working-model inputs, not part of the mechanism; no such parameter appears in the registered configuration and no such column is generated."},
    ]
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": "All routes necessarily share the registered structural equations. truth.py integrates the two linear predictors after a Cholesky factorisation; the quadrature route integrates X in four dimensions directly; the two simulation routes sample the mechanism under different counterfactual couplings. Transcription from the preprint and independent-person reproduction remain separate review tasks.",
        "limits": "Numerical diagnostics only. They do not establish the identification assumptions, do not pin down the source's principal-stratum target, and do not confirm that the preprint matches the published JRSS-B article. Positivity is poor by design in this Kang-Schafer style mechanism; the checks do not claim otherwise.",
    }
