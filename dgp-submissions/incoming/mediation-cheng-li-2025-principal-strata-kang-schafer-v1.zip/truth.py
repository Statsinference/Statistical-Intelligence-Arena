"""Population ITT natural direct effect by bivariate Gauss-Hermite quadrature.

The two linear predictors a_D^T X and a_M^T X are jointly normal, so E[D(z)] and
E[M(z)] are two-dimensional integrals.  The outcome is linear in (Z, D, M, X) with
mean-zero noise, so only those marginal counterfactual means are needed and no joint
counterfactual law of (D(1), D(0)) has to be assumed.
"""
import math

import numpy as np


def _nodes(config, order):
    a_d = np.asarray(config["event_coefficients"], dtype=float)
    a_m = np.asarray(config["mediator_coefficients"], dtype=float)
    variance = float(config["covariate_sd"]) ** 2
    covariance = variance * np.array([[a_d @ a_d, a_d @ a_m], [a_d @ a_m, a_m @ a_m]])
    factor = np.linalg.cholesky(covariance)
    raw, weights = np.polynomial.hermite.hermgauss(order)
    weights = weights / math.sqrt(math.pi)
    raw = math.sqrt(2.0) * raw
    first, second = np.meshgrid(raw, raw, indexing="ij")
    product = np.outer(weights, weights).ravel()
    linear = factor @ np.stack([first.ravel(), second.ravel()])
    return linear[0], linear[1], product


def _expit(values):
    return 1.0 / (1.0 + np.exp(-values))


def counterfactual_means(config, order):
    event_linear, mediator_linear, weights = _nodes(config, order)
    means = {}
    for z in (0.0, 1.0):
        event = _expit(float(config["event_intercept"])
                       + float(config["event_treatment_coefficient"]) * z + event_linear)
        base = (float(config["mediator_intercept"])
                + float(config["mediator_treatment_coefficient"]) * z + mediator_linear)
        with_event = _expit(base + float(config["mediator_event_coefficient"]))
        without_event = _expit(base)
        means[f"E[D({int(z)})]"] = float(weights @ event)
        means[f"E[M({int(z)})]"] = float(weights @ (event * with_event + (1.0 - event) * without_event))
    return means


def itt_natural_direct_effect(config, order):
    means = counterfactual_means(config, order)
    return (float(config["outcome_treatment_coefficient"])
            + float(config["outcome_event_coefficient"]) * (means["E[D(1)]"] - means["E[D(0)]"]))


def itt_natural_indirect_effect(config, order):
    means = counterfactual_means(config, order)
    return float(config["outcome_mediator_coefficient"]) * (means["E[M(1)]"] - means["E[M(0)]"])


def truth(config):
    low_order, high_order = config["quadrature_orders"]
    low = itt_natural_direct_effect(config, low_order)
    high = itt_natural_direct_effect(config, high_order)
    return {
        "value": high,
        "estimated_error": abs(high - low) + 1e-15,
        "method": f"Bivariate Gauss-Hermite quadrature on the joint law of the two linear predictors at orders {low_order} and {high_order}, then the linear outcome contrast.",
        "error_interpretation": "Observed quadrature convergence between the two orders, not a rigorous uniform error bound. The source prints no numerical truth to compare against.",
        "target": "ITT-NDE = E[Y_{1 M_0}] - E[Y_{0 M_0}]; NOT the principal-stratum quantity theta^(10)_10 plotted by the source",
        "components": counterfactual_means(config, high_order),
    }
