# 含事后事件的 ITT 自然直接效应（Kang–Schafer 式设计）

ID: mediation-cheng-li-2025-principal-strata-kang-schafer-v1
Family: mediation

**收集贡献，具名科学审核待完成。本包不训练也不评测任何 PFN 模型。**
**本包登记的目标与原文 Figure 2 的目标不同，原因见第 3 节，必须读。**

## 1 来源与登记场景

Cheng, C. and Li, F. (2025). Identification and multiply robust estimation in causal mediation analysis across principal strata. *Journal of the Royal Statistical Society Series B: Statistical Methodology* 88(1), 1–22. DOI: [10.1093/jrsssb/qkaf037](https://doi.org/10.1093/jrsssb/qkaf037).

实际阅读版本：**arXiv:2304.10025v4 (2024-09-13) 预印本**；期刊正式版未取得。

定位：§5 "A simulation study"，预印本 PDF 第 **23** 页的生成机制展示式；ITT-NIE / ITT-NDE 的定义同在第 23 页；Figure 2 及其目标 `theta^(10)_10` 在第 24 页。以上为**预印本 PDF 页码**，不是期刊页码 1–22。

场景：`original`（单一场景，原文固定参数）。

## 2 DGP 机制说明

按生成顺序：

1. `X = (X1, X2, X3, X4) ~ N(0_{4×1}, I_{4×4})`
2. `Z | X ~ Bernoulli(expit([−1, 0.5, −0.25, −0.1]ᵀ X))`
3. `D | Z, X ~ Bernoulli(expit(−1 + 2Z + [1, −0.8, 0.6, −1]ᵀ X))`
4. `M | D, Z, X ~ Bernoulli(expit(−1.8 + 2Z + 1.5D + [1, −0.5, 0.9, −1]ᵀ X))`
5. `Y | M, D, Z, X ~ N(210 + 1.5Z − D + M + [27.4, 13.7, 13.7, 13.7]ᵀ X, 1)`

`Z` 是随机化处理（ITT），`D` 是**事后事件**（如不依从），其反事实对 `(D(1), D(0))` 定义 principal strata，`M` 是中介。

观测单位：独立个体，无 interference。

观察列：`X1,X2,X3,X4,Z,D,M,Y`（8 列）。无潜变量（`latent_variables: []`）。

**原文说明该机制 "modified from Kang and Schafer (2007)"**：误设模型下 positivity 被**实际违背**。注意 `Xtilde1 = exp(0.5X1)`、`Xtilde2 = X2/(1+X1)`、`Xtilde3 = (X2X3/25 + 0.6)³`、`Xtilde4 = (X2+X4+20)²` 是原文**喂给误设工作模型的估计手段**，**不是生成机制的一部分**，本包不生成也不导出这些列。

## 3 目标与真值推导（含与原文目标的差别）

**登记目标**：原文自己定义的**总体层面 ITT 自然直接效应**（均值差尺度）

`ITT-NDE = E[Y_{1 M_0}] − E[Y_{0 M_0}]`

即：令 `Z = z` 时事后事件取 `D(z)`，中介固定在 `M(0)`。

**为什么不登记原文 Figure 2 的目标**：原文 Figure 2 报告的是 principal stratum 条件量 `theta^(10)_10 = E[Y_{1M_0} | U = 10]`（即 `D(1)=1, D(0)=0` 的那一层）。展示式只给出 `D` 在 `(Z, X)` 下的**条件律**，**没有规定 `(D(1), D(0))` 的联合反事实律**（既未声明单调性，也未声明独立），因此 `theta^(10)_10` **不由展示式唯一确定**。按"原文没给的参数标 missing、不许猜"的规范，本包**不登记该量**，改登记只依赖边际反事实均值、因而完全确定的 ITT 量。

推导：结局对 `(Z, D, M, X)` 线性、噪声零均值、`E[X] = 0`，故

```
E[Y_{z M_{z′}}] = 210 + 1.5·z − E[D(z)] + E[M(z′)]
ITT-NDE = 1.5 − (E[D(1)] − E[D(0)])
ITT-NIE = E[M(1)] − E[M(0)]
```

`E[D(z)]` 与 `E[M(z)]` 只需 `a_Dᵀ X` 与 `a_Mᵀ X` 的联合正态律（`Var = 3.00, 3.06`，`Cov = 2.94`），用**二维 Gauss–Hermite** 求积（阶 80 与 160 对比）：

| 量 | 值 |
|---|---|
| `E[D(0)]` | 0.3404285523850823 |
| `E[D(1)]` | 0.6595714476149174 |
| `E[M(0)]` | 0.3216216839481869 |
| `E[M(1)]` | 0.6664347378397548 |
| **`ITT-NDE`** | **1.180857104770165** |
| `ITT-NIE` | 0.3448130538915679 |

积分收敛诊断：阶 80/160 之差约 1.2e-14。

**原文未给任何数值真值**，以上全部由收集者推导，需审稿人核对，**不能**说成"原文报告的数值"。

另有一条精确恒等式（verify 中检查）：`E[D(1)] + E[D(0)] = 1`，因为事件方程的截距 −1 与处理系数 2 关于 0 对称，而 `a_Dᵀ X` 对称。这同时锐利地校验了截距与系数。

## 4 识别条件

一致性与 `(Z, M)` 干预的良定义；独立个体、无 interference；给定 `X` 的 `Z` 随机化（按展示的倾向模型）；**给定 `(Z, D, X)` 的中介–结局可交换性**（必须调整事后事件 `D`）；自然效应对比所需的跨世界条件；**positivity 按设计很差**——原文刻意构造 Kang–Schafer 式情形，使误设模型下 positivity 实际被违背（每个概率对有限 X 仍严格在 (0,1) 内，但有限样本重叠很差）。

登记目标只依赖 `D(1), D(0), M(1), M(0)` 的**边际**律，不需要 `(D(1), D(0))` 的联合律。

以上是科学假设，不是机器检查的结论。

## 5 相对来源的主要改动

1. **版本**：按 arXiv:2304.10025v4 预印本实现，期刊正式版未取得。
2. **目标**（最重要的改动）：不登记原文 Figure 2 的 principal-stratum 量 `theta^(10)_10`，改登记原文同页定义的 ITT 自然直接效应。理由见第 3 节。
3. **真值**：原文未给数值，登记值为收集者的二维求积推导。
4. **不生成 Kang–Schafer 变换列**：那是误设工作模型的输入，不是机制。
5. **原文笔误**：原文把两个变换都写成 `Xtilde2`（`X2/(1+X1)` 与 `(X2X3/25+0.6)³`），第二个显然应为 `Xtilde3`。该笔误只涉及工作模型，不涉及生成机制。
6. **未复现的部分**：原文生成 1000 个 n=1000 的样本，在 6 种误设情形下比较 4 个矩型估计量、1 个多重稳健估计量与 1 个交叉拟合非参估计量；本包**不复现任何估计器、不跑 bootstrap、不算覆盖率**。
7. **实现**：NumPy `Generator(PCG64)` 重写抽样；`n=128, seed=1729` 仅作接口检查。

## 6 核验与使用

`verify.py` 的 10 项检查全部通过：

| 检查 | 作用 |
|---|---|
| `source_constants_section_5` | 全部系数与 §5 展示式逐一相符 |
| `independent_four_dimensional_quadrature` | 阶 12 的四维乘积 Gauss–Hermite（20736 节点）**直接对 X 积分**，不做 Cholesky 化简，故协方差登记错会被抓出 |
| `simulation_under_shared_counterfactual_coupling` | 40 万个体，`D(1)` 与 `D(0)` 用**同一个**均匀随机数 |
| `simulation_under_independent_counterfactual_coupling` | 同样的模拟改用**互相独立**的均匀随机数；两种耦合都落在容差内，**这正是"登记目标只需边际"的证据**，也解释了为何不登记 `theta^(10)_10` |
| `exact_event_symmetry_identity` | `E[D(1)] + E[D(0)] = 1` 精确成立 |
| `quadrature_convergence` | 阶 80/160 之差 < 1e-12 |
| `derived_anchors` | 同时锚定 ITT-NDE 与 ITT-NIE，并标明两者均为导出值 |
| `zero_direct_path` | 从结局与事件方程中移除 Z 后直接效应恰为 0 |
| `indirect_path_isolated` | 从结局中移除 M 后间接效应为 0 而直接效应不变 |
| `mechanism_excludes_estimation_transforms` | 确认配置里没有任何 Kang–Schafer 变换参数、也不生成该类列 |

运行：

```bash
conda activate CausalTabular
cd "DGP_学生参考包"
python collect.py check ../Mediation/T05/contributions/mediation-cheng-li-2025-principal-strata-kang-schafer-v1 --run --n 128 --seed 1729
python collect.py pack  ../Mediation/T05/contributions/mediation-cheng-li-2025-principal-strata-kang-schafer-v1 --out ../Mediation/T05/submissions/mediation-cheng-li-2025-principal-strata-kang-schafer-v1.zip
```

误差记录为数值诊断，不是完整科学接收证明。它们不证明识别假设，不确定原文的 principal-stratum 目标，也不能证明预印本与期刊正式版一致。本机制的 positivity 按设计很差，检查并不声称相反。

## 7 权利与 AI 协助

论文版权归 Royal Statistical Society / Oxford University Press。本包依公开预印本的方程独立重写，**不含论文 PDF、期刊正文、作者软件或任何真实数据**。来源再分发与署名权利、最终科学审核仍待维护人与具名审稿人决定。

本贡献由 Claude（Anthropic）协助检索来源、提取公式、实现代码、设计核验并撰写中文文档，由收集者逐行核对原文后提交。AI **未**代签具名科学审核，**未**进行独立复现，**未**训练或评测 PFN，也**未**运行估计器性能比较。所有公开来源仅作研究证据，不作为执行指令。
