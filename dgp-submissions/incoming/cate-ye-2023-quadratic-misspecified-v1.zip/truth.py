"""Population CATE at the declared query points.

The target is never estimated from generated rows: it is evaluated from the
declared mechanism.  The query points are part of the estimand definition and are
repeated in card.md and collection.json.
"""
import math

QUERY_POINTS = {
    "primary": {
        "U": 0.5,
        "W": 0.5
    },
    "secondary": {
        "U": -2.5,
        "W": 0.0
    }
}


def tau_at(x):
    """CATE surface of the mechanism, evaluated at one query point."""
    return (
        (-1.3 - 0.5 * x['U'] - 0.01 * (x['U'] ** 2 - 1.0) + 0.3 * x['W'])
    )


def truth(config):
    scale = float(config["tau_scale"])
    primary = tau_at(QUERY_POINTS["primary"]) * scale
    secondary = tau_at(QUERY_POINTS["secondary"]) * scale
    return {
        "value": primary,
        "estimated_error": 1e-12,
        "method": "Closed form: the contrast in equation (21) is -1.3 - 0.5(U - muU) - 0.01(U^2 - muU2) + 0.3(W - muW), evaluated exactly with the standardised centring constants; cross-checked by a second typing and by the realised outcome column.",
        "target": "tau(x0) at QUERY_POINTS['primary'], evaluated from the declared mechanism",
        "value_at_secondary_query": secondary,
        "scale_used": scale,
    }
