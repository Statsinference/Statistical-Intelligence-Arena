# Ye-Shao-Yi-Zhao (2023) setting 2: quadratic-in-U effect with a misspecified working model

**Contribution `cate-ye-2023-quadratic-misspecified-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `ye-2023-quadratic-misspecified`

## Source and reconstruction

- Citation: Ye, T., Shao, J., Yi, Y. and Zhao, Q. (2023). Toward better practice of covariate adjustment in analyzing randomized clinical trials. Journal of the American Statistical Association 118(544), 2370-2382. DOI: 10.1080/01621459.2022.2049278.
- Venue / year: Journal of the American Statistical Association, 2023
- Link: https://arxiv.org/abs/2009.11828
- **Exact locator**: Section 4.1 'Simulation results', equation (21) on PDF p.24 ('Y (2) = -1.3 + Y (1) - 0.5(U - muU) - 0.01(U^2 - muU2) + 0.3(W - muW)'), with the sentence 'a quadratic term U^2 - muU2 appears in the data generating process (21) but is not adjusted by ANCOVA or ANHECOVA' on the same page. Author manuscript, 62 pages.
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **U, W**: `U, W ~ Normal(0,1) independently (standardised surrogate for the trial's empirical distribution)`
2. **Treatment**: `P(A=1) = 0.5 (simple randomisation, two arms at 1:1)`
3. **Potential responses**: `Y(1) = eps, Y(2) = -1.3 + Y(1) - 0.5(U - muU) - 0.01(U^2 - muU2) + 0.3(W - muW)`
4. **Heterogeneity**: `tau(U, W) = -1.3 - 0.5 U - 0.01(U^2 - 1) + 0.3 W`
5. **Observed**: `Y = eps + A tau(U, W)`

Sampling unit: patient · dependence: independent and identically distributed

Fixed parameters: intercept -1.3, slopes -0.5 (U) and 0.3 (W), quadratic coefficient -0.01, centring muU = muW = 0 and muU2 = 1, noise variance 1.

### Adaptations relative to the source

- Three arms reduced to two: only the arm-2 versus arm-1 contrast is kept, so the registered target is the binary-treatment CATE of that contrast. The surface is exactly the increment in equation (21).
- Y(1) in the source is the observed placebo-arm response of 481 real patients and is not distributed with the paper; this package replaces it with independent N(0,1) noise, which preserves the low R-squared reported for the real baseline but sets the paper's beta1 = -0.240 to 0. Declared deviation.
- (U,W) are drawn as independent standard normals, with the paper's centring constants set to muU = muW = 0 and muU2 = E[U^2] = 1.
- The source runs simple randomisation, stratified permuted blocks and Pocock-Simon minimisation with allocation 1:1:1 or 1:2:2 over three arms; this package uses simple randomisation with two arms at 1:1, so e = 0.5.
- The source draws a random sample of n = 200 or 400 from the 481 subjects; no resampling of real subjects occurs here.

## Target and identification

- Symbol: `tau(u0, w0) = E[Y(1) - Y(0) | U = u0, W = w0]`
- Definition: Conditional average treatment effect at the declared query points for the arm-2 versus arm-1 contrast; affine in U and W with a small negative quadratic term in U, so the surface is curved but close to linear over the bulk of the covariate law.
- Query points (part of the estimand): `primary`: (U = 0.5, W = 0.5); `secondary`: (U = -2.5, W = 0.0)

Identification assumptions:

- SUTVA: one version of treatment, no interference between patients
- Randomised assignment: e = 0.5, so treatment is independent of the potential responses by design
- Overlap: e = 0.5 with margin 0.5
- The baseline response Y(1) is independent of (U,W) in this package, the declared surrogate for the source's low R-squared

The source uses this design to show that omitting U^2 biases ANCOVA while ANHECOVA stays consistent; the CATE surface is therefore the object that a misspecified working model attacks. It also has a non-zero average effect of -1.3, unlike the zero-mean sibling.

## Truth and independent verification

Observed outcome is eps + A tau(U,W) with eps independent of A and (U,W), so the contrast is tau(u,w). At (0.5, 0.5): -1.3 - 0.25 - 0.01(0.25-1) + 0.15 = -1.3925. At (-2.5, 0): -1.3 + 1.25 - 0.01(6.25-1) = -0.1025.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and confirms end-to-end that the realised
outcome column of `generator.py` carries the declared surface (arm-contrast shift
equals the mean of tau over treated rows, at identical seed). Both routes share the
declared mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 2 (effective 2) · high dimensional: False · interactions: True · nonlinear: True
- Curvature is small relative to the intercept, so a linear working model is only mildly misspecified; the design is included because the source uses exactly this misspecification to compare ANCOVA with ANHECOVA. No weak-overlap region and no claim beyond the quadratic surface.

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| U | covariate | float | · | · | true |
| W | covariate | float | · | · | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by Taylor & Francis for the American Statistical Association. Supplementary materials are not redistributed.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: Baseline response is a declared surrogate; covariate-adaptive randomisation and the three-arm structure are not reproduced.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
