"""Standalone scientific audit of the public observation interface.

No production truth/generator helper is used to compute reference moments.
"""
import argparse
import importlib.util
import json
import math
from pathlib import Path
import sys
import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
CONTRIB = ROOT

def load(name):
    spec = importlib.util.spec_from_file_location('audit_' + name, CONTRIB / (name+'.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def main(panels):
    gen, oracle, verifier = (load(n) for n in ('generator','truth','verify'))
    config = json.loads((CONTRIB/'config.json').read_text(encoding='utf-8'))['scenarios']['baseline']
    checks=[]
    def record(name, passed, **evidence):
        checks.append({'name':name,'passed':bool(passed),**evidence})
    def rejects(fn):
        try: fn()
        except ValueError: return True
        return False
    first=gen.generate(config,3,1729)
    record('same_seed_replay', first==gen.generate(config,3,1729))
    record('different_seed_changes_counts', first!=gen.generate(config,3,1730))
    record('roles_and_strict_schema',len(first)==202 and first['G']==[1,0,0] and first['P']==[0,0,1] and
           list(first)==['G','P']+[f'Y_pre{i:03}' for i in range(1,101)]+[f'Y_post{i:03}' for i in range(1,101)])
    record('observed_nonnegative_integer_counts',all(type(v) is int and v>=0 for k,col in first.items() if k not in ('G','P') for v in col))
    record('reject_n',all(rejects(lambda n=n:gen.generate(config,n,1)) for n in (0,1,2,4,100,3.0,True,None)))
    record('reject_seed',all(rejects(lambda s=s:gen.generate(config,3,s)) for s in (-1,1.5,True,None)))
    bad_configs=[{},dict(config,extra=0),dict(config,beta=0),dict(config,factor_sd=.2),dict(config,T_pre=50),dict(config,zeta=.1),dict(config,r=True),dict(config,beta=float('nan'))]
    record('all_hooks_reject_invalid_parameters',all(rejects(lambda c=c,f=f:f(c)) for c in bad_configs for f in (lambda c:gen.generate(c,3,1),oracle.truth,verifier.verify)))
    frozen=json.dumps(config,sort_keys=True)
    gen.generate(config,3,22);oracle.truth(config);verifier.verify(config)
    record('no_input_mutation',frozen==json.dumps(config,sort_keys=True))
    state_before=np.random.get_state();gen.generate(config,3,33);state_after=np.random.get_state()
    record('local_rng_only',state_before[0]==state_after[0] and np.array_equal(state_before[1],state_after[1]) and state_before[2:]==state_after[2:])
    record('exact_analytic_truth',oracle.truth(config)['value']==-2 and oracle.truth(config)['estimated_error']==0)
    record('independent_integral_verify',verifier.verify(config)['passed'],result=verifier.verify(config))
    # Intercept only the primitive RNG boundary, never expose latent values in output.
    # Reconstruct all600 rates separately, including rejected endpoint redraws.
    class TraceRNG:
        def __init__(self):self.normal_calls=[];self.rates=None
        def normal(self,loc,scale,size):
            self.normal_calls.append((loc,scale,size))
            if len(self.normal_calls)==1:
                x=np.linspace(.3,.7,200);x[0]=0.;x[1]=1.;return x
            return np.array([.2,.8])
        def poisson(self,rates):
            self.rates=rates.copy()
            return np.arange(600,dtype=np.int64).reshape(3,200)
    traced=TraceRNG();factory=gen.np.random.default_rng
    try:
        gen.np.random.default_rng=lambda seed:traced
        mapped=gen.generate(config,3,7)
    finally: gen.np.random.default_rng=factory
    path=[.3+.4*t/199 for t in range(200)];path[0]=.2;path[1]=.8
    expected=np.array([[math.exp(x-(2 if t>=100 else 0)) for t,x in enumerate(path)],
                       [x/(math.e-1) for x in path],[x/(math.e-1) for x in path]])
    record('primitive_trace_joint_rates_and_rejection',traced.normal_calls==[(.5,.1,200),(.5,.1,2)] and np.max(np.abs(traced.rates-expected))<1e-14,
           max_rate_error=float(np.max(np.abs(traced.rates-expected))),factor_vector_length=200,poisson_matrix_shape=list(traced.rates.shape))
    record('primitive_trace_all_units_and_times_mapping',all(mapped[(f'Y_pre{t+1:03}' if t<100 else f'Y_post{t-99:03}')]==[t,200+t,400+t] for t in range(200)))
    # Independent deterministic Gauss-Legendre integration of the factor law.
    x,w=np.polynomial.legendre.leggauss(160);x=(x+1)/2;w=w/2
    weight=w*np.exp(-.5*((x-.5)/.1)**2);weight/=weight.sum()
    def avg(a):return float(weight@a)
    c=1/(math.e-1);EL=avg(x);VL=avg((x-EL)**2);ME=avg(np.exp(x));VE=avg((np.exp(x)-ME)**2);CLE=avg((x-EL)*(np.exp(x)-ME))
    expected_control_mean=c*EL;expected_control_variance=c*EL+c*c*VL
    record('reference_truncated_factor_symmetry',abs(EL-.5)<1e-14 and 0<VL<.01,mean=EL,variance=VL)
    rows=np.empty((panels,3,200),dtype=np.int16)
    keys=list(first)[2:]
    for i in range(panels):
        out=gen.generate(config,3,500000+i)
        rows[i]=np.asarray([out[k] for k in keys],dtype=np.int16).T
    def moment(name,a,b=None,target=None,kind='mean'):
        a=np.asarray(a,dtype=float).ravel();ma=float(a.mean())
        if kind=='mean':estimate=ma;influence=a-ma
        elif kind=='variance':estimate=float(np.mean((a-ma)**2));influence=(a-ma)**2-estimate
        else:
            b=np.asarray(b,dtype=float).ravel();mb=float(b.mean());products=(a-ma)*(b-mb);estimate=float(products.mean());influence=products-estimate
        se=float(influence.std(ddof=1)/math.sqrt(a.size));limit=8*se+1e-9
        record(name,abs(estimate-target)<=limit,estimate=estimate,target=target,mc_se=se,tolerance=limit,n_pairs_or_values=int(a.size),z_score=(estimate-target)/se if se else 0.)
    ctrl1=rows[:,1,:];ctrl2=rows[:,2,:]
    moment('control_mixed_poisson_mean',ctrl1,target=expected_control_mean)
    moment('control_mixed_poisson_variance',ctrl1,target=expected_control_variance,kind='variance')
    moment('proxy_mixed_poisson_mean',ctrl2,target=expected_control_mean)
    moment('proxy_mixed_poisson_variance',ctrl2,target=expected_control_variance,kind='variance')
    moment('donor_proxy_common_factor_covariance',ctrl1,ctrl2,target=c*c*VL,kind='covariance')
    cov_check=checks[-1]
    record('covariance_test_resolves_unconditional_independence',cov_check['tolerance']<.5*(c*c*VL) and cov_check['estimate']>cov_check['tolerance'],
           model_covariance=c*c*VL,eight_se_tolerance=cov_check['tolerance'])
    for phase,s,scale in [('pre',slice(0,100),1.),('post',slice(100,200),math.exp(-2))]:
        y=rows[:,0,s];donor=rows[:,1,s]
        moment('treated_'+phase+'_mixed_poisson_mean',y,target=scale*ME)
        moment('treated_'+phase+'_mixed_poisson_variance',y,target=scale*ME+scale**2*VE,kind='variance')
        moment('treated_donor_'+phase+'_factor_covariance',y,donor,target=scale*c*CLE,kind='covariance')
        moment('treated_'+phase+'_time_independence',y[:,::2],y[:,1::2],target=0.,kind='covariance')
    moment('control_time_independence',ctrl1[:,::2],ctrl1[:,1::2],target=0.,kind='covariance')
    moment('cross_unit_cross_time_independence',ctrl1[:,::2],ctrl2[:,1::2],target=0.,kind='covariance')
    result={'passed':all(x['passed'] for x in checks),'panels':panels,'unit_rows_per_panel':3,'time_periods':200,
            'threshold_method':'8 plug-in influence-function Monte Carlo SE plus1e-9 integration floor; asymptotic diagnostic, no finite-sample coverage claim. Nonoverlapping lag pairs avoid pair reuse.',
            'reference_method':'160-node Gauss-Legendre integration of truncated normal; no production helper used',
            'checks':checks,'environment':{'python':sys.version.split()[0],'numpy':np.__version__}}
    (ROOT/'checks'/'independent_audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'passed':result['passed'],'panels':panels,'checks':len(checks),'failed':[x['name'] for x in checks if not x['passed']]}))
    return 0 if result['passed'] else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--panels',type=int,default=30000);args=parser.parse_args()
    if args.panels<30000:raise ValueError('At least30000 independent panels required to resolve small donor/proxy covariance')
    raise SystemExit(main(args.panels))
