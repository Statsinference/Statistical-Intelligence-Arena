# Shi et al. (2026), adapted Poisson proxy count panel

## Scope, source, and authorization
This is one independent count-panel mechanism family, with one declared baseline.
It is adapted_from_source, not an exact reproduction. Formal source: Shi et al.,
*Theory for Identification and Inference with Synthetic Controls: A Proximal
Causal Inference Framework*, JASA (2026), DOI
https://doi.org/10.1080/01621459.2026.2639734 . Formal supplement J.8 PDF49-51,
Eq(S.25), FigS.8: https://doi.org/10.6084/m9.figshare.31627658.v1 . Main Section4
specifies loadings, with its loading formula evaluated at r=1 and its second
control group identical to the first. The dated decision audit is
stage6/A/math_decision.md in the research parent; implementation authorization
was subsequently explicitly relayed by the coordinator.

## Complete registered baseline
There is one treated unit (row0), one donor (row1), one supplemental proxy
(row2). r=1, N=2, mu0=mu1=mu2=1, alpha1=1. Tpre=Tpost=100 and total T=200;
100 never denotes the total period count. zeta=0, with no measured covariate
term. For t=1,...,200, lambda_t follows N(.5,.1^2) truncated to the open
interval(0,1). X_t=1(t>100) is deterministic for the treated unit. Conditional
marginal laws from S.25 are

    Y_t | lambda_t ~ Poisson(exp(lambda_t - 2 X_t)),
    W_1t | lambda_t ~ Poisson(lambda_t/(e-1)),
    W_2t | lambda_t ~ Poisson(lambda_t/(e-1)).

The parameter beta is fixed at -2. The donor is the first control, as specified
in J.8; the supplemental proxy is the second. Neither is treated. There is no
AR recursion, presample history, or initialization. No old uniform factor,
50-period choice, or nonzero covariate branch is used. Factors are sampled by
normal rejection, not clipping. Each invocation uses np.random.default_rng(seed)
and never changes the process-wide random state.

## Joint law and explicit cross-version boundary
J.8 gives these Poisson marginals but does not explicitly state a complete
unit-by-time independence law. Its independent-normal wording concerns the
factor vector; the time-iid interpretation is not silently attributed to J.8.
The authorized adaptation takes iid factor paths and a conditional product
Poisson law across every unit and period from fixed author code version
1973d7c8fc2ecd2a94b73292b58a594361db0542 (2023),
Simulation/myfunctions_NonlinearSetting.R: lines26-44 loop over units and make
fresh rpois(n=t,lambda=mean.Y) calls at34/41; lines116-118 and130 generate
independent factor paths. That old source uses U(0,1), old 50/50 settings and
general I_r loadings. Only its joint-sampling pattern is retained; this package
uses the formal2026 parameters. This is not a claim to replicate old code or
its R random bitstream. Generic Gaussian iid errors in main Section4 do not
supply a missing Poisson independence statement.

Given the full factor path all 600 count draws are independent. Unconditionally
units are dependent at the same time through lambda. Periods are independent.
For c=1/(e-1), Cov(W_1t,W_2t)=c^2 Var(lambda)>0 and
Cov(Y_t,W_jt)=c exp(-2X_t) Cov(exp(lambda),lambda)>0.
The donor and proxy are not unconditional independent rows.

## Target choice and preserved source conflict
The formal text after S.25 prints beta=E[Y(1)]/E[Y(0)]=-2. That is impossible
for the positive Poisson means in S.25; the source conflict is preserved here.
Under the user's instruction to implement F04, the coordinator registered the
scalar log population rate ratio implied by S.25; the source contradiction
and joint-law adaptation are disclosed:

    log_RR_pop = log(E[Y_t(1)] / E[Y_t(0)]) = -2, for each post t.

This is neither additive ATT nor finite-sample SATT nor the printed negative
rate ratio. With Phi the standard-normal CDF,

    M(a) = exp(.5a + .005a^2)
           * [Phi(5-.1a)-Phi(-5-.1a)]/[Phi(5)-Phi(-5)].

The population means are M(1) and exp(-2)M(1), respectively; M(1)>0 cancels
exactly. truth.py returns -2 with zero numerical approximation error (an exact
algebraic constant). verify.py imports neither generator.py nor truth.py and
independently integrates both mean-rate functions by composite Simpson with
1024/2048 intervals, verifies positivity, convergence, and a zero-beta
counterfactual-path check. The latter is an internal mathematical diagnostic,
not another registered scenario. No coupling of the two potential Poisson
outcomes is needed for this population estimand; no finite-sample effect is
claimed.

## Observations and interface
n is exactly the number of unit rows: only integer n=3 is accepted. No resampling,
duplication, extrapolation, or n-dependent group construction is provided.
Every invocation returns 202 numeric columns: G=[1,0,0], P=[0,0,1], then
Y_pre001,...,Y_pre100,Y_post001,...,Y_post100. Each count column holds the
three observed counts at that period. G=P=0 identifies the donor. P is known
supplemental-proxy design identity, not the measured zeta covariate. All count
columns have nonnegative integer support with no finite upper bound. There are
no emitted factors, rates, residuals, potential outcomes, or truth labels.
properties.dimension=effective_dimension=0 counts baseline measured covariates;
fixed design indicators and repeated outcomes are not counted as covariates.
The internal factor is not an observed dimension. There are no measured
interaction terms. Nonlinearity concerns the treated exponential mean.

Identification and estimator inference require their own assumptions and are
not guaranteed by runnable data. This package encodes consistency, no effect
on controls, fixed donor/proxy identity, shared loadings, the authorized joint
law, and the multiplicative post effect. It does not implement PI, GLM, SC
weights, confidence intervals, or a claim of their validity.

## Independent audit and limits
The companion tests/test_f04.py uses only the public generated observations for
sampling checks. Numerical integration supplies marginal mixed-Poisson means,
variances and contemporaneous cross-unit covariances, independently of the
production sampling code. Moment checks use eight estimated Monte Carlo
standard errors with a 1e-9 numerical floor; influence functions account for
estimated means in variances/covariances. These are conservative asymptotic
Monte Carlo diagnostics, not finite-sample probability guarantees. Many
independent panels and iid time entries provide the replicate sample; n is
never enlarged. Lag checks use nonoverlapping adjacent-period pairs. Tests also
check deterministic replay, different seeds, malformed parameters, roles,
integer support, no output leakage, and local RNG state. No successful smoke
check constitutes scientific acceptance.

## Rights and assistance
The prior source audit records the formal article and formal supplement as
CC BY4.0; this records those source rights, not a newly selected software
license. The fixed2023 author's independent repository software license was
not verified. No MIT license or license grant for this independently written
Python code is inferred. No source PDF or author code is bundled. AI assisted
source analysis, mathematical specification, implementation and audit; a named
human scientific acceptance remains pending.
