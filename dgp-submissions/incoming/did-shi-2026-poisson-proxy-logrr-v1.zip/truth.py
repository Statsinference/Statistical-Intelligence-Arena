"""Population log rate ratio, analytically derived without sampling."""
import math
import numbers


def truth(config):
    expected = {"r": 1, "zeta": 0.0, "T_pre": 100, "T_post": 100,
                "beta": -2.0, "factor_mean": 0.5, "factor_sd": 0.1,
                "factor_lower": 0.0, "factor_upper": 1.0,
                "mu_treated": 1.0, "mu_donor": 1.0, "mu_proxy": 1.0}
    if not isinstance(config, dict) or set(config) != set(expected):
        raise ValueError("A complete registered baseline is required")
    for key, val in config.items():
        if isinstance(val, bool) or not isinstance(val, numbers.Real) or not math.isfinite(float(val)) or val != expected[key]:
            raise ValueError("Unsupported parameter: " + key)
    # E[Y(1)] = exp(-2) M_L(1), E[Y(0)] = M_L(1) > 0.
    # The common positive factor moment cancels before floating-point arithmetic.
    return {"value": -2.0, "estimated_error": 0.0,
            "method": "Exact log population rate ratio from S.25: log(exp(-2)M(1)/M(1))=-2; registered adaptation, not the printed negative ratio"}
