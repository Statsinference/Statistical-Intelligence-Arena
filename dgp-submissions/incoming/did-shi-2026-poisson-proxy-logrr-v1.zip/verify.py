"""Independent quadrature of population potential mean rates; no hook imports."""
import math
import numbers


def _simpson(fn, intervals):
    h = 1.0 / intervals
    return h / 3.0 * (fn(0.0) + fn(1.0) +
        4.0 * math.fsum(fn(i*h) for i in range(1, intervals, 2)) +
        2.0 * math.fsum(fn(i*h) for i in range(2, intervals, 2)))


def verify(config):
    expected = {"r": 1, "zeta": 0.0, "T_pre": 100, "T_post": 100,
                "beta": -2.0, "factor_mean": 0.5, "factor_sd": 0.1,
                "factor_lower": 0.0, "factor_upper": 1.0,
                "mu_treated": 1.0, "mu_donor": 1.0, "mu_proxy": 1.0}
    if not isinstance(config, dict) or set(config) != set(expected):
        raise ValueError("A complete registered baseline is required")
    for key, val in config.items():
        if isinstance(val, bool) or not isinstance(val, numbers.Real) or not math.isfinite(float(val)) or val != expected[key]:
            raise ValueError("Unsupported parameter: " + key)
    # Directly integrate the unnormalized density and both mean-rate integrands.
    density = lambda x: math.exp(-0.5*((x-0.5)/0.1)**2)
    answers = []
    means = []
    for mesh in (1024, 2048):
        norm = _simpson(density, mesh)
        untreated = _simpson(lambda x: math.exp(x)*density(x), mesh) / norm
        treated = _simpson(lambda x: math.exp(x-2.0)*density(x), mesh) / norm
        means.append((untreated, treated))
        answers.append(math.log(treated / untreated))
    checks = [
        {"name": "independent_Simpson_population_log_ratio", "passed": abs(answers[-1]+2.0) < 1e-12, "value": answers[-1]},
        {"name": "mesh_doubling", "passed": abs(answers[1]-answers[0]) < 1e-12, "difference": abs(answers[1]-answers[0])},
        {"name": "positive_means_and_rate_ratio", "passed": 0.0 < means[-1][1] < means[-1][0], "untreated_mean": means[-1][0], "treated_mean": means[-1][1]},
    ]
    # Independent no-treatment-path special case; not a declared extra scenario.
    null_num = _simpson(lambda x: math.exp(x)*density(x), 2048)
    null_den = _simpson(lambda x: math.exp(x)*density(x), 1024)
    checks.append({"name": "zero_beta_special_case", "passed": abs(math.log(null_num/null_den)) < 1e-11})
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "scope": "Deterministic numerical diagnostic, not a proof of sampling-law correctness or scientific acceptance"}
