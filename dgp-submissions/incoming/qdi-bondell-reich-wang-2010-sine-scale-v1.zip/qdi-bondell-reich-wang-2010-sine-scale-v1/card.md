# Conditional quantile in the Bondell-Reich-Wang sine-scale mechanism

编号 Q05 · 线性位置与正弦尺度。状态：本地核验后仍待科学审核；未提交 GitHub。

## 来源与精确定位

Bondell, H. D., Reich, B. J. and Wang, H. (2010). Noncrossing quantile regression curve estimation. Biometrika 97(4), 825-838. DOI: https://doi.org/10.1093/biomet/asq048

实际读取：Published journal PDF, 14 pages, journal pagination 825-838。下载链接：https://www.math.pku.edu.cn/teachers/xirb/Courses/QR2013/ReadingForFinal/Biometrika-2010-Bondell-825-38.pdf

定位：Section 4.2, Example 5; PDF page 9 = journal page 833; unnumbered Y=f(X)+g(X)*epsilon model and immediately following example.

读取 PDF 的 SHA-256：5eff78911ec3400db4bb6f9a41dd0a077d49f7ea07bf1a439544473569a5c974。不依赖作者源码，无代码 commit 需要引用。source_audit.json 另列版本及查重证据。

## 完整生成机制

\[
X_i\sim U(0,1),\quad\varepsilon_i\sim\mathcal N(0,1),\quad X_i\perp\varepsilon_i
\]

\[
Y_i=3X_i+\{0.5+2X_i+\sin(2\pi X_i-0.5)\}\varepsilon_i
\]

\[
Q_\tau(x)=m(x)+s(x)\Phi^{-1}(\tau)
\]

生成顺序：先抽协变量，再独立抽噪声，最后按显示方程构造响应。不同观察行独立；协变量和噪声按显示公式及下列实现约定独立。参数全部在 config.json。X1 到 X1 以及 Y 完全观测；无缺失、删失、标注抽样或因果处理分配。误差及混合成分只在生成器内部使用，不输出给模型。

样本量由 generate(config,n,seed) 的 n 决定；source_n 是原文样本量记录，不替代 n。随机数生成器为 NumPy PCG64，固定种子及相同依赖版本可复现；不声称与 R 或论文逐行随机数相同。所有列为等长有限数值列表。不对 Y 裁剪、截断或重新标准化；均匀分布的右端点在实现中不取，连续理论分布不受影响。

## 目标与真值

Conditional 0.9 quantile at X=0.5 in source Example 5.

$m(x)=3x$，$s(x)=0.5+2x+\sin(2\pi x-0.5)>0$。因此 $Q_\tau(x)=m(x)+s(x)\Phi^{-1}(\tau)$。

默认场景真值为 **4.03673589787718**。这是按本包目标推导的新真值；未将论文估计值当作 oracle。truth.py 返回标量以及 1e-12 的浮点/求根诊断，非严格统一误差界。数值反演使用初始区间 [-100,100] 和 60 次二分，适用于登记的固定水平。verify.py 不调用生成器，使用独立密度 Simpson 积分和 1024/2048 网格（Q01 卷积为 2048/4096），并核对对称/支持/边界特例。两条路线仍由同一 AI 编写，不等于独立研究者复现。

分位数统一定义为 $Q_\tau=\inf\{y:F(y)\ge\tau\}$。正态误差；g 按标准差解释。通过端点与驻点计算全支持的最小尺度；在 x=0 处约为 0.02057446，边界可近乎无噪声。

## 多样性及范围

One active covariate; nonlinear scale; no cross-coordinate interactions. Same source but structurally distinct location versus scale effects; seeds and quantile levels do not create new families. high_dimensional=false 指本包维数相对于原文样本量以及 n=128 核验而言，不承诺 n 小于维数时仍属低维。多个噪声或查询场景不重复计数。标量真值核验不意味着整条分布函数带或分位曲线的覆盖率通过。所有登记场景见 config.json。

## 相对来源的改动

1. Fixed x=0.5 and tau=0.9 select one scalar query from source curves; the data-generating coefficients are retained.
2. The source calls g a variance function but multiplies epsilon by g. This implementation follows the displayed equation: g is the conditional standard deviation and Var(Y|X)=g^2. Independence of X and epsilon and iid rows are explicit implementation conventions.
3. Independent Python/NumPy implementation from mathematical formulas; no author code is redistributed. PCG64(seed) replaces unspecified/source software random-number generation. Sample size is the generate n argument; source_n only records the published sample sizes. No fitting, bootstrap, confidence-band coverage experiment or PFN training is included.

## 权利与 AI 协助

原论文归原著作权人；本包不含论文 PDF、真实个体数据或作者源码。方程被重新转写并单独实现。使用 AI 辅助提取、推导、编程、核验及排版，尚无具名科学审核人及独立复现者；不得将本地 PASS 或收件测试写为正式接收。提交人姓名由用户在 GitHub 提交说明中填写，不由 AI 代签。
