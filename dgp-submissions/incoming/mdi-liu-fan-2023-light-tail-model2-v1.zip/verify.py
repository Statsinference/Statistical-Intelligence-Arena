"""Independent beta-density integral and source-constant checks."""
import math

def verify(config):
    fixture = {"gamma":2.5,"noise_scale_c":1.0,"chi_square_df":4,"model":2,
               "missing_outcome_placeholder":0.0,"paper_sample_size":2000,"paper_simulation_repetitions":5000}
    gamma = float(config["gamma"])
    # Integrate (1-p)(gamma-1)p^(gamma-2) over [0,1] by antiderivative.
    integral = (gamma-1)*(1/(gamma-1)-1/gamma)
    checks = [
      {"name":"source_constants","passed":config==fixture,"details":"Example 1 gamma=2.5, c=1, Model 2, N=2000, M=5000."},
      {"name":"independent_beta_integral","passed":abs(integral-0.4)<1e-12,"details":f"Integral of conditional mean against beta density: {integral:.17g}."},
      {"name":"centered_noise","passed":config["chi_square_df"]==4,"details":"E(eta)=4, so E[(eta-4)/sqrt(8)]=0."},
      {"name":"observation_rate","passed":abs((gamma-1)/gamma-0.6)<1e-12,"details":"E(D)=E(P)=0.6; missing fraction 0.4."},
      {"name":"placeholder_finite","passed":math.isfinite(float(config["missing_outcome_placeholder"])),"details":"No full-data Y is exported."}
    ]
    return {"passed":all(x["passed"] for x in checks),"checks":checks,"shared_components":"Uses published density and mean, but an explicit integral rather than truth.py's beta expectation shortcut."}
