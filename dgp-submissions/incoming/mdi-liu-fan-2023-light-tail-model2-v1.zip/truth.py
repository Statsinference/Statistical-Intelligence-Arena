"""Analytic population mean, independent of generated rows."""
import math

def truth(config):
    gamma = float(config["gamma"])
    c = float(config["noise_scale_c"])
    if not (math.isfinite(gamma) and gamma>1 and math.isfinite(c) and config["chi_square_df"]==4 and config["model"]==2):
        raise ValueError("invalid scenario")
    return {"value":1/gamma,"estimated_error":0.0,
            "method":"Beta(gamma-1,1) mean plus centered chi-square(4) noise", "target":"Full-data E(Y)"}
