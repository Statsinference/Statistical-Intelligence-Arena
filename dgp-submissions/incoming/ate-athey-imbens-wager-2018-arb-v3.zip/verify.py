"""Independent checks for source parameters and the ATE contrast.
This module does not import truth.py; it shares the declared DGP/configuration.
"""
import math
import numpy as np


def _raw_beta(profile, p):
    indices = np.arange(1, p + 1, dtype=float)
    if profile == "inverse_square" or profile == "very_sparse":
        return indices ** -2.0
    if profile == "dense":
        return indices ** -0.5
    raise ValueError("Unknown profile")


def _normalized_beta(profile, norm, p):
    raw = _raw_beta(profile, p)
    return raw * (float(norm) / np.linalg.norm(raw))


def _contrast_independent(config, effect_override=None):
    # A deterministic diagnostic grid is enough because the structural
    # contrast cancels X^T beta_Y and epsilon_2 exactly.
    p = int(config["p"])
    beta_y = _normalized_beta(config["beta_y_profile"], config["beta_y_norm"], p)
    x = np.zeros((5, p), dtype=float)
    x[0, 0] = 1.0
    x[1, 1] = -2.0
    x[2, :5] = np.array([1., -1., 2., -2., 0.5])
    x[3, -5:] = np.array([-3., 0.25, 1., 4., -1.])
    x[4, :] = np.linspace(-0.75, 0.75, p)
    error = np.array([-2.0, -0.1, 0.0, 0.7, 3.0])
    tau = float(config["treatment_effect"] if effect_override is None else effect_override)
    y1 = x @ beta_y + tau + error
    y0 = x @ beta_y + error
    return float(np.mean(y1 - y0))


def _check_covariance_factor(rho):
    # Independently verify that the AR(1) innovation factor produces the
    # declared p=5 Toeplitz covariance matrix.
    m = 5
    factor = np.zeros((m, m), dtype=float)
    factor[0, 0] = 1.0
    for j in range(1, m):
        factor[j, :j] = rho * factor[j - 1, :j]
        factor[j, j] = math.sqrt(1.0 - rho * rho)
    covariance_from_factor = factor @ factor.T
    indices = np.arange(m)
    declared_covariance = rho ** np.abs(indices[:, None] - indices[None, :])
    return float(np.max(np.abs(covariance_from_factor - declared_covariance)))


def _expit_negative(theta):
    # Separate scalar formulation of the source probability 1/(1+exp(theta)).
    if theta >= 0:
        z = math.exp(-theta)
        return z / (1.0 + z)
    return 1.0 / (1.0 + math.exp(theta))


def verify(config):
    p = int(config["p"])
    rho = float(config["rho"])
    beta_w = _normalized_beta(config["beta_w_profile"], config["beta_w_norm"], p)
    beta_y = _normalized_beta(config["beta_y_profile"], config["beta_y_norm"], p)
    beta_w_expected = float(config["beta_w_norm"])
    beta_y_expected = float(config["beta_y_norm"])
    theta_grid = [-12.0, -3.0, -0.5, 0.0, 0.5, 3.0, 12.0]
    max_logistic_error = max(
        abs(_expit_negative(t) - 1.0 / (1.0 + math.exp(t)))
        for t in theta_grid
    )
    contrast = _contrast_independent(config)
    zero_contrast = _contrast_independent(config, effect_override=0.0)
    covariance_error = _check_covariance_factor(rho)
    checks = [
        {
            "name": "source_table3_parameters",
            "passed": p == 2000 and int(config["n_reference"]) == 1000 and math.isclose(rho, 0.5, abs_tol=0.0),
            "details": f"n_reference={config['n_reference']}, p={p}, rho={rho}; Table 3 footnote reports n=1000, p=2000, rho=0.5."
        },
        {
            "name": "beta_y_profile_and_norm",
            "passed": config["beta_y_profile"] == "inverse_square" and math.isclose(float(np.linalg.norm(beta_y)), beta_y_expected, rel_tol=1e-12, abs_tol=1e-12),
            "details": f"beta_Y,j proportional to j^-2; reconstructed L2 norm={np.linalg.norm(beta_y):.15g}, target={beta_y_expected}."
        },
        {
            "name": "beta_w_profile_and_norm",
            "passed": config["beta_w_profile"] in ("very_sparse", "dense") and math.isclose(float(np.linalg.norm(beta_w)), beta_w_expected, rel_tol=1e-12, abs_tol=1e-12),
            "details": f"profile={config['beta_w_profile']}; reconstructed L2 norm={np.linalg.norm(beta_w):.15g}, target={beta_w_expected}; exact support={int(np.count_nonzero(beta_w))}/{p}."
        },
        {
            "name": "AR1_covariance_factorization",
            "passed": covariance_error < 1e-14,
            "details": f"max absolute discrepancy in the p=5 covariance identity LL^T=Sigma: {covariance_error:.3g}; recursion is distribution-equivalent to Normal(0,Sigma)."
        },
        {
            "name": "source_logistic_sign_and_boundaries",
            "passed": max_logistic_error < 1e-14 and all(0.0 < _expit_negative(t) < 1.0 for t in theta_grid),
            "details": f"Stable expit(-theta) agrees with 1/(1+exp(theta)) on a fixed finite grid; max discrepancy={max_logistic_error:.3g}. This is a finite-grid code check, not a uniform-overlap proof."
        },
        {
            "name": "ATE_intervention_contrast_independent_route",
            "passed": abs(contrast - float(config["treatment_effect"])) < 1e-12,
            "details": f"Directly computed mean[Y(1)-Y(0)] on a deterministic diagnostic design={contrast:.15g}; declared treatment effect={config['treatment_effect']}; does not call truth.py."
        },
        {
            "name": "zero_effect_analytic_special_case",
            "passed": abs(zero_contrast) < 1e-12,
            "details": f"Verification-only override tau=0 yields ATE={zero_contrast:.3g}; this is a check, not a declared source scenario."
        }
    ]
    return {
        "passed": all(item["passed"] for item in checks),
        "checks": checks,
        "shared_components": "The verifier does not import or call truth.py and independently reconstructs coefficient profiles and structural contrasts. It still shares the source DGP equations and configuration; it is not an independent-person reproduction.",
        "unresolved_science": "The source does not enumerate every cross-independence relation involving X and the two errors; the executable implementation uses independent draws. Pointwise positivity is distinct from uniform overlap on unbounded Gaussian support."
    }
