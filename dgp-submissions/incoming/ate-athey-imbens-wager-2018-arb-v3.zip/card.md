# ATE DGP collection: Section 5.2 sparse two-stage setting

**Status: candidate; automated checks do not constitute scientific acceptance.**

## Source and reconstruction

Athey, Susan, Guido W. Imbens and Stefan Wager (2018), “Approximate residual balancing: Debiased inference of average treatment effects in high dimensions,” *Journal of the Royal Statistical Society: Series B (Statistical Methodology)*, 80(4), 597–623. DOI [10.1111/rssb.12268](https://doi.org/10.1111/rssb.12268). The actually read source is the 27-page electronic-reprint PDF linked at [this stable copy](https://file-lianxh.oss-cn-shenzhen.aliyuncs.com/Refs/Spring2024/Athey_2018_Approximate_Residual_Balancing.pdf). The publisher's official page is [here](https://rss.onlinelibrary.wiley.com/doi/10.1111/rssb.12268).

**Exact source locator:** Section 5.2, unnumbered paragraph “sparse two-stage setting,” spanning the end of printed p.617 and the beginning of p.618 (PDF reader pages 21–22/27, zero-based indices 20–21). Table 3 and its footnote are on printed p.618 / PDF reader page 22/27 (zero-based index 21). These simulation equations are not numbered. Table 3 footnote gives `n=1000`, `p=2000`, `rho=0.5`, and 400 replications. The table headings show `||beta_W||_2` in `{1,4}` and `||beta_Y||_2` in `{1,4}`. The publisher lists a supplementary PDF described as proofs, but its download returned HTTP 403 in this run; the simulation equations and parameters below come from the main text and Table 3. The paper cites the `balanceHD` R package but this contribution did not use author code or pin a code commit.

### Original mechanism, in generation order

1. Draw the observed covariate vector for each individual: `X_i ~ Normal_p(0, Sigma)`, with `Sigma_ij = rho^|i-j|`, `rho=0.5`, `p=2000`. Table 3 uses reference sample size `n=1000`. The covariance makes coordinates within a row dependent; implementation samples rows independently.
2. Define the latent first-stage index `theta_i = X_i^T beta_W + epsilon_i1`.
3. Draw treatment `W_i | theta_i ~ Bernoulli(1 / (1 + exp(theta_i)))`. The negative sign in the logistic argument matters: this is `expit(-theta_i)`, not `expit(theta_i)`.
4. Draw outcome noise `epsilon_i2 ~ Normal(0,1)` and set `Y_i = X_i^T beta_Y + 0.5 W_i + epsilon_i2`.
5. The two errors `epsilon_i1` and `epsilon_i2` are described in the source as independent standard Gaussian errors. The main text does not enumerate every cross-independence relation with `X` and across individual indices. For a runnable version, this implementation independently samples `X`, both error arrays, and individuals, preserving the stated conditional structure. This is explicitly an implementation convention/adaptation pending scientific review, not a claim that every independence clause was stated verbatim.

### Coefficient profiles and all Table 3 scenarios

For `j=1,...,p`, the structure/outcome coefficient profile is `beta_Y,j proportional to 1/j^2`. The propensity/first-stage coefficient profile is either the paper's “very sparse” profile `beta_W,j proportional to 1/j^2` or “dense” profile `beta_W,j proportional to 1/sqrt(j)`. Each vector is rescaled to the norm listed by the Table 3 heading. The table crosses the two propensity profiles, `||beta_W||_2 in {1,4}`, and `||beta_Y||_2 in {1,4}`, producing eight scenarios. This contribution preserves all eight as scenarios within one mechanism family; seeds/parameter variants are not counted as separate DGP families.

Important label precision: all entries of `1/j^2` are nonzero for finite `j`. Thus the source's “very sparse” is retained as the source's name for a rapidly decaying profile, but under exact-support counting `beta_W` and `beta_Y` both have `p=2000` nonzero entries. The signal is concentrated near early coordinates, not mathematically exactly sparse.

### Implementation adaptation

To sample the specified Gaussian covariance, `generator.py` uses the recursion `X[:,j] = rho * X[:,j-1] + sqrt(1-rho^2) * Z[:,j]` with independent standard normal innovations and `X[:,1] ~ N(0,1)` (index convention in code is zero-based). This gives exactly the requested `Sigma_ij=rho^|i-j|` distribution, though it does not reproduce the authors' random-number sequence. `n=128` during the collection check is only a smoke-test size; the reference experiment uses `n=1000` and 400 replications, which are not rerun here.

## Target and identification

For the explicit ATE benchmark target, interpret the observed outcome equation structurally as `Y_i(w)=X_i^T beta_Y + 0.5 w + epsilon_i2`, sharing the same `X_i` and outcome disturbance for both intervention levels. Then

`Y_i(1)-Y_i(0) = 0.5`, so `ATE = E[Y_i(1)-Y_i(0)] = 0.5` exactly.

Because the treatment effect is constant, the corresponding population ATE and ATT coincide at `0.5`; this avoids a target mismatch even though the paper discusses ATT-style targets in its general notation.

The causal interpretation requires consistency, no interference, and treatment exchangeability conditional on `X`. Under the implementation convention that `epsilon_i1` is independent of `epsilon_i2` and `X`, treatment depends on `X` and first-stage noise but not on potential-outcome noise, so exchangeability holds conditional on `X`. For each finite `X`, the propensity is strictly between zero and one after averaging over the first-stage Gaussian error. However, with unbounded Gaussian covariates and a nonzero `beta_W`, **uniform overlap bounded away from 0 and 1 is not established**. This is a meaningful scientific review item; it is not concealed by the machine check.

## Truth and independent verification

`truth.py` returns `value=0.5` and `estimated_error=0.0` from the analytic intervention contrast, not from simulated observations. `verify.py` independently reconstructs the normalized coefficient profiles, checks the signal norms and profile support, confirms the logistic sign convention, checks the AR(1) covariance factorization, and computes the potential-outcome contrast on a deterministic diagnostic array without importing `truth.py`. It also checks a verification-only zero-effect special case. The verifier still shares the declared scientific model/configuration, so it is not an independent-person reproduction.

## Diversity and scope

- Total covariate dimension: `p=2000`; reference `n=1000`, so `p>n`.
- Exact active dimension: `2000` for `beta_Y` and for both `beta_W` profiles because every coefficient is nonzero. The “very sparse” source label means an inverse-square decay profile, not exact zeros.
- Interaction terms: none.
- Nonlinear part: treatment assignment probability uses `1/(1+exp(theta_i))`; the conditional outcome mean is linear.
- Within-individual coordinate dependence: Gaussian Toeplitz covariance `rho^|j-k|`, `rho=.5`; no repeated measures or interference. Individuals are iid under the implementation convention.
- The generator returns only `X1`–`X2000`, `W`, and `Y`; latent `theta`, error terms, potential outcomes, coefficient vectors and ATE are not returned as learner input.

## Rights and assistance

This package contains an independently written implementation and source citation only; it does not redistribute the article PDF, original data, or author software. Source/code redistribution terms and scientific acceptance remain for maintainer review. AI assisted source extraction, coding and local checks; no named scientific review is claimed. No PFN training, large bootstrap, coverage simulation, PR, or external submission was performed.

## Unresolved source/review items

1. Confirm the implementation's independence convention for `X`, `epsilon_i1`, `epsilon_i2`, and individuals, since the paragraph explicitly identifies the two errors as independent standard Gaussian but does not spell out every cross-independence relation.
2. Confirm that the benchmark accepts the stated population ATE target. Because treatment effects are constant at `0.5`, it also equals the paper's treated-population effect in this DGP.
3. Confirm whether the absence of a uniform overlap bound on the unbounded Gaussian support should be retained as a deliberate stress property of this source DGP.
4. Supplementary proof PDF was not inspected because the publisher download returned HTTP 403; main-text equations and Table 3 were read. If maintenance requires supplemental review, provide an accessible copy.
5. No authors' code commit was pinned or executed; no independent human replication was performed.
