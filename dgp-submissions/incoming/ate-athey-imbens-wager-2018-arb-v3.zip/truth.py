"""Analytical population ATE for the sparse two-stage DGP."""
import math


def truth(config):
    if "treatment_effect" not in config:
        raise ValueError("Missing treatment_effect")
    effect = float(config["treatment_effect"])
    if not math.isfinite(effect):
        raise ValueError("treatment_effect must be finite")
    return {
        "value": effect,
        "estimated_error": 0.0,
        "method": "Exact algebraic intervention contrast; Y(1)=X^T beta_Y + tau + epsilon_2 and Y(0)=X^T beta_Y + epsilon_2.",
        "error_interpretation": "Zero numerical error because the target is an exact constant contrast; no numerical integration or Monte Carlo estimate is used.",
        "target": "ATE = E[Y(1)-Y(0)] for interventions setting W=1 versus W=0, sharing each individual's X and epsilon_2."
    }
