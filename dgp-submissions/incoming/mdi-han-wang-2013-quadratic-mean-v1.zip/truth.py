"""Analytic uniform-moment population truth, independent of generated data."""
import math

def truth(config):
    a = float(config["x_half_width"])
    c = [float(v) for v in config["outcome_mean_coefficients"]]
    if not (math.isfinite(a) and a > 0 and len(c)==3 and all(map(math.isfinite,c))):
        raise ValueError("invalid scenario")
    return {"value":c[0]+c[2]*a*a/3,"estimated_error":0.0,
            "method":"Exact E(X)=0 and E(X^2)=a^2/3 for Uniform(-a,a)","target":"Full-data E(Y)"}
