"""Source constants, independent antiderivative, and observation spot checks."""
import math

def verify(config):
    fixture = {"x_half_width":2.5,"outcome_mean_coefficients":[1.0,2.0,3.0],
               "outcome_variance_coefficients":[2.0,4.0],"observation_logit_coefficients":[-0.8,-0.5,0.3],
               "missing_outcome_placeholder":0.0,"paper_sample_sizes":[300,1000],"paper_simulation_repetitions":5000}
    a = float(config["x_half_width"])
    c = [float(v) for v in config["outcome_mean_coefficients"]]
    primitive = lambda x: c[0]*x + c[1]*x*x/2 + c[2]*x*x*x/3
    integral = (primitive(a)-primitive(-a))/(2*a)
    b = config["observation_logit_coefficients"]
    logits = [b[0],b[0]+b[1]+b[2],b[0]-b[1]+b[2]]
    checks = [
      {"name":"source_constants","passed":config==fixture,"details":"Section 6 first model; Table 1 sample sizes and repetitions."},
      {"name":"independent_integral","passed":abs(integral-7.25)<1e-12,"details":f"Antiderivative integration: {integral:.17g}."},
      {"name":"observation_logit_spot_checks","passed":all(abs(x-y)<1e-12 for x,y in zip(logits,[-0.8,-1.0,0.0])),"details":"Logits at X=0,1,-1."},
      {"name":"variance_spot_checks","passed":config["outcome_variance_coefficients"]==[2.0,4.0],"details":"Conditional variances at X=0 and X=1 are 2 and 6."},
      {"name":"placeholder_finite","passed":math.isfinite(float(config["missing_outcome_placeholder"])),"details":"No full-data Y is exported."}
    ]
    return {"passed":all(x["passed"] for x in checks),"checks":checks,"shared_components":"Uses published coefficients but an integral instead of truth.py's moment formula."}
