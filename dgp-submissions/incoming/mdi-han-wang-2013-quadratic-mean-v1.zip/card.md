# Han and Wang (2013): first MAR simulation model

**Candidate MDI mechanism; claim/deduplication and named scientific review remain pending.**

Han and Wang, “Estimation with missing data: beyond double robustness,” *Biometrika* 100(2):417–430, DOI [10.1093/biomet/ass087](https://doi.org/10.1093/biomet/ass087). The [journal PDF](https://citeseerx.ist.psu.edu/document?doi=e0e997142bf0e86fa244b33aa966801e942d9d16&repid=rep1&type=pdf), Section 6, journal p. 426/PDF p. 10, lists four combinations. This contribution takes the **first** combination, confirmed by the column order in Table 1 on journal p. 427/PDF p. 11. A local reading copy sits outside this ZIP at `论文资料/Han_Wang_2013_Biometrika_Beyond_Double_Robustness.pdf`.

For each iid subject, X~Uniform(-2.5,2.5). Given X=x, Y~Normal(1+2x+3x², **variance** 4x²+2). R|X=x~Bernoulli(1/[1+exp(0.8+0.5x-0.3x²)]); R=1 means Y measured. R depends only on fully observed X, so missingness is MAR. The source reports about 55% missing responses for this observation function. Conditional observation probabilities are strictly positive on the bounded X support.

Target theta=E(Y)=1+2E(X)+3E(X²)=1+3(2.5²/3)=**7.25**; this is derived from the published DGP. The paper reports n=300 and 1000, with 5000 Monte Carlo repetitions. One `generate` call returns one iid sample and does not reproduce estimator performance. The output contains X, R, Y_observed. For R=0, Y_observed=0 is an interface placeholder, not a measured outcome; always mask with R. Full Y is never exported.

`truth.py` uses the exact uniform moment, and `verify.py` separately integrates the quadratic mean by its antiderivative and checks source constants. The code uses only Python's standard library. Source PDF is not redistributed in the ZIP. AI assisted extraction and code drafting; equation and Table 1 page were visually checked. This is not named scientific acceptance or an independent reproduction.
