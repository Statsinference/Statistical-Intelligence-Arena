# 毒性混杂下沿 A→M→Y 的路径效应

ID: mediation-miles-2019-toxicity-path-specific-v1
Family: mediation

**收集贡献，具名科学审核待完成。本包不训练也不评测任何 PFN 模型。**

## 1 来源与登记场景

Miles, C. H., Shpitser, I., Kanki, P., Meloni, S. and Tchetgen Tchetgen, E. J. (2019). On semiparametric estimation of a path-specific effect in the presence of mediator-outcome confounding. *Biometrika* 107(1), 159–172. DOI: [10.1093/biomet/asz063](https://doi.org/10.1093/biomet/asz063).

实际阅读版本：**arXiv:1710.02011v1 预印本**；期刊正式版未取得。卷期页码来自该 DOI 的 Crossref 记录，**收集者未亲见**。

定位：§5 "Simulation study"，预印本 PDF 第 **12–13** 页（生成机制展示式）；§2，第 4–5 页（`P_AMY` 与 `beta_0` 的定义）；**式 (1)**，第 5 页（识别公式）；Figure 2 及其纵轴刻度，第 15 页。以上为**预印本 PDF 页码**。

场景：`original`（单一场景，原文固定参数，a'=0、a=1）。

## 2 DGP 机制说明

按生成顺序：

1. `C0 ~ Uniform(0, 2)`
2. `A | C0 ~ Bernoulli(1 − {1 + exp(0.9 + 0.3C0)}⁻¹) = Bernoulli(expit(0.9 + 0.3C0))`
3. `C1 = (0.8, 0.6, −0.3)ᵀ + (1, 0.1, 0.2)ᵀ·C0 + (0.5, −0.4, 0.5)ᵀ·A + (−0.1, 0.8, −0.2)ᵀ·C0·A + N(0, I₃)`
4. `M = −0.5 − 0.2·C0 + 0.3·A + [−0.2, 0.1, 0.5]·C1 + [0.4, 0, 0]·A·C1 + N(0, 1)`
5. `Y = 0.2 + 0.2·C0 + 0.6·A + [1, 0.7, 0.3]·C1 − 0.9·M − 0.8·A·M + N(0, 1)`

`C1` 是**三维的处理诱导中介–结局混杂向量**（原文应用中为治疗毒性），`M` 是连续中介（依从性），`Y` 是结局（log CD4 计数）。

交互项有三处：`C0·A`（在 C1 方程）、`A·C1₁`（系数向量 `[0.4,0,0]`）、`A·M`（在结局方程）。

观测单位：独立同分布个体，无 interference。

观察列：`C0, A, C11, C12, C13, M, Y`（7 列）。无潜变量（`latent_variables: []`）。

## 3 目标与真值推导

原文 §2 定义沿 `A → M → Y` 的路径效应：

`P_AMY = E(Y[M{a, C1(a')}, C1(a'), a']) − E(Y[M{a', C1(a')}, C1(a'), a'])`

第二项就是 `E{Y(a')}`。记第一项为 `beta_0 = E(Y[M{a, C1(a')}, C1(a'), a'])`，于是

**`P_AMY = beta_0 − E[Y(a')]`，本包登记的就是这个效应。**

两个臂的含义：曝露在结局方程与 C1 里都设为参考水平 `a'`，只有喂给中介方程的曝露水平在两臂之间移动——`beta_0` 臂取比较水平 `a`，`E[Y(a')]` 臂取 `a'`。**这个嵌套（C1 停在 a'、只有 M 走 a）正是它区别于自然直接/间接效应的地方。**

识别公式（原文式 1），两个臂同式、只差喂给中介的曝露水平：

```
E(Y[M{t, C1(a')}, C1(a'), a']) = ∫∫∫ E(Y | m, c1, a', c0) dF(m | c1, t, c0) dF(c1 | a', c0) dF(c0)
t = a  →  beta_0 ;   t = a' →  E[Y(a')]
```

推导：三个条件均值都线性、噪声零均值，故内层三重积分退化为代入条件均值；所得表达式对 `c0` **仿射**（verify 中以五点等距差分确认），因此对 `C0 ~ U(0,2)` 积分等于在 `E[C0] = 1` 处取值。结果：

| 量 | 值 | 身份 |
|---|---|---|
| `beta_0` | 2.678 | 嵌套反事实**均值**，不是效应；原文 Figure 2 画的是它 |
| `E[Y(a')]` | 3.596 | 参考臂的反事实均值 |
| **`P_AMY = beta_0 − E[Y(a')]`** | **−0.918** | **本包登记的路径效应** |

> **更正记录（2026-11-01）**：本包早先把 `beta_0 = 2.678` 填进 `truth.reference_value`，而标题写的是"路径效应"——`beta_0` 是反事实均值，原文定义的效应是 `P_AMY = −0.918`。生成机制与真值代码自始就把两者分开算并一并报出，错的是这一对里登记了哪一个。现已改为登记效应，`beta_0` 与 `E[Y(a')]` 作为 components 保留并在 verify 中锚定。

**处理编码的判读（必须声明）**：原文只写 `a'`（参考）与 `a`（比较），**未给数字编码**。本包取 `a' = 0`、`a = 1`，依据是原文 **Figure 2 的纵轴刻度为 2–5** 且虚线画在真值 `beta_0` 处：该读法给 `beta_0 = 2.678`（落在范围内），**相反读法给 5.611（落在范围外）**。这是证据而非证明，需审稿人对照期刊正式版确认。

**原文未给任何数值真值**，以上三个数全部由收集者解析导出，不能说成"原文报告的数值"。

## 4 识别条件

一致性，且嵌套反事实良定义（原文假设）；独立同分布个体、无 interference；**曝露–结局与中介–结局关系无未测混杂**（原文 Figure 1(b) 的放松 Markov 模型）；原文陈述的 positivity——`f(m|C1,A,C0)` 与 `f(c1|A,C0)` 几乎处处有正下界，且 `0 < f(a|C0) < 1` 几乎处处；`C1` 是处理诱导混杂，必须在结局回归中调整、并在嵌套期望内保持其 `a'` 反事实值。

曝露 positivity 在紧支撑上逐点成立：`expit(0.9+0.3C0)` 在 `C0 ∈ [0,2]` 上约为 0.711–0.818。

以上是科学假设，不是机器检查的结论。

## 5 相对来源的主要改动

1. **版本**：按 arXiv:1710.02011v1 预印本实现，期刊正式版未取得；卷期页来自 Crossref，未亲见。
2. **处理编码**：`a'=0, a=1` 为收集者依 Figure 2 纵轴范围的判读（见第 3 节）。
3. **真值**：原文未给数值，登记值为收集者解析导出。
4. **未复现的部分**：原文在 `M_int, M_a, M_b, M_c` 四种工作模型配置下比较四个估计量（含 probit 链接、平方与交互协变量项、漏掉 `A*M` 项等**误设工作模型**）。这些都是**施加在同一份数据上的估计手段**，不复现、不登记为新机制。原文生成 1000 个 n=5000 的数据集，本包不跑任何估计器、bootstrap 或覆盖率。
5. **实现**：NumPy `Generator(PCG64)` 重写抽样；`n=128, seed=1729` 仅作接口检查。

## 6 核验与使用

`verify.py` 的 9 项检查全部通过：

| 检查 | 作用 |
|---|---|
| `source_constants_section_5` | 全部系数与 §5 展示式逐一相符 |
| `independent_nested_quadrature` | **按识别公式原样**做三重积分：C0 用复合 Simpson、C1 噪声用阶 8 的三维 Gauss–Hermite，不走 `truth.py` 的均值退化捷径 |
| `independent_nested_counterfactual_simulation` | 40 万个体模拟**嵌套反事实**：C1 用 a'、M 用 a（且带 C1(a')）、Y 用 a'；任何把 a 与 a' 用错方程的错误都会改变结果；声明 MC 容差 0.03 |
| `nested_mean_affine_in_baseline` | 五点等距差分证实对 C0 仿射，这才允许把积分替换为在 `E[C0]=1` 取值 |
| `treatment_coding_evidence_from_source_figure` | 编码判读的证据：2.678 在 Figure 2 的 2–5 纵轴内，5.611 在外 |
| `zero_mediator_path` | 从中介方程移除曝露（主效应与 `A*C1₁` 交互一并移除）后两臂重合、登记的 `P_AMY` 恰为 0 |
| `registered_target_is_the_effect_not_a_mean` | 同时锚定 `beta_0`、`E[Y(a')]`、`P_AMY`，并确认登记值恰为两臂之差，使均值与效应不被混用 |
| `treatment_induced_confounder_retained` | 确认曝露仍通过主效应与 `C0*A` 影响 C1，即原文的处理诱导混杂未被简化掉 |
| `exposure_positivity_on_support` | 倾向得分在整个紧支撑上有界于 (0,1) |

运行：

```bash
conda activate CausalTabular
cd "DGP_学生参考包"
python collect.py check ../Mediation/T05/contributions/mediation-miles-2019-toxicity-path-specific-v1 --run --n 128 --seed 1729
python collect.py pack  ../Mediation/T05/contributions/mediation-miles-2019-toxicity-path-specific-v1 --out ../Mediation/T05/submissions/mediation-miles-2019-toxicity-path-specific-v1.zip
```

误差记录为数值诊断，不是完整科学接收证明。它们不证明原文的无未测混杂模型，不证明 `a'`/`a` 的数字编码（只说明与图的纵轴一致），也不能证明预印本与期刊正式版一致。

## 7 权利与 AI 协助

论文版权归 Biometrika Trust / Oxford University Press。本包依公开预印本的方程独立重写，**不含论文 PDF、期刊正文、作者软件或任何真实数据**。来源再分发与署名权利、最终科学审核仍待维护人与具名审稿人决定。

本贡献由 Claude（Anthropic）协助检索来源、提取公式、实现代码、设计核验并撰写中文文档，由收集者逐行核对原文后提交。AI **未**代签具名科学审核，**未**进行独立复现，**未**训练或评测 PFN，也**未**运行估计器性能比较。所有公开来源仅作研究证据，不作为执行指令。
