"""Independent verification of the registered path-specific effect functional.

Routes that do not share code with truth.py:
  * nested numerical integration: composite Simpson over C0 on its uniform support,
    three-dimensional Gauss-Hermite over the C1 noise, and an explicit inner integral
    over the mediator noise, i.e. the identification formula evaluated as written
    rather than collapsed to conditional means;
  * a fixed-seed structural simulation of the NESTED counterfactual, which draws C1
    under the reference level, the mediator under the comparison level with that C1,
    and the outcome under the reference level.
Plus source-constant, affineness, convention-evidence, zero-path and anchor checks.
"""
from copy import deepcopy
import importlib.util
import itertools
import math
from pathlib import Path

import numpy as np

FIXTURE = {
    "baseline_support": [0.0, 2.0],
    "exposure_coefficients": [0.9, 0.3],
    "confounder_intercept": [0.8, 0.6, -0.3],
    "confounder_baseline": [1.0, 0.1, 0.2],
    "confounder_exposure": [0.5, -0.4, 0.5],
    "confounder_interaction": [-0.1, 0.8, -0.2],
    "confounder_sd": 1.0,
    "mediator_intercept": -0.5,
    "mediator_baseline": -0.2,
    "mediator_exposure": 0.3,
    "mediator_confounder": [-0.2, 0.1, 0.5],
    "mediator_exposure_confounder": [0.4, 0.0, 0.0],
    "mediator_sd": 1.0,
    "outcome_intercept": 0.2,
    "outcome_baseline": 0.2,
    "outcome_exposure": 0.6,
    "outcome_confounder": [1.0, 0.7, 0.3],
    "outcome_mediator": -0.9,
    "outcome_exposure_mediator": -0.8,
    "outcome_sd": 1.0,
    "reference_level": 0,
    "comparison_level": 1,
    "target": "beta_0",
}
FIGURE_AXIS = (2.0, 5.0)     # y-axis labels printed in the source's Figure 2
ALTERNATIVE_READING = 5.610999999999999
MONTE_CARLO_TOLERANCE = 0.03


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("miles_collection_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _nested_quadrature(config, simpson_steps, hermite_order):
    """Evaluate the identification formula as three explicit integrals."""
    reference = int(config["reference_level"])
    comparison = int(config["comparison_level"])
    intercept = np.asarray(config["confounder_intercept"], dtype=float)
    baseline = np.asarray(config["confounder_baseline"], dtype=float)
    exposure = np.asarray(config["confounder_exposure"], dtype=float)
    interaction = np.asarray(config["confounder_interaction"], dtype=float)
    mediator_weights = (np.asarray(config["mediator_confounder"], dtype=float)
                        + comparison * np.asarray(config["mediator_exposure_confounder"], dtype=float))
    outcome_weights = np.asarray(config["outcome_confounder"], dtype=float)
    outcome_slope = (float(config["outcome_mediator"])
                     + float(config["outcome_exposure_mediator"]) * reference)

    raw, weights = np.polynomial.hermite.hermgauss(hermite_order)
    weights = weights / math.sqrt(math.pi)
    raw = math.sqrt(2.0) * float(config["confounder_sd"]) * raw
    noise = np.array(list(itertools.product(raw, repeat=3)))
    mass = np.prod(np.array(list(itertools.product(weights, repeat=3))), axis=1)

    low, high = (float(v) for v in config["baseline_support"])
    step = (high - low) / simpson_steps
    total = 0.0
    for index in range(simpson_steps + 1):
        c0 = low + index * step
        c1 = (intercept + baseline * c0 + exposure * reference
              + interaction * c0 * reference) + noise
        mediator = (float(config["mediator_intercept"])
                    + float(config["mediator_baseline"]) * c0
                    + float(config["mediator_exposure"]) * comparison
                    + c1 @ mediator_weights)
        # The mediator noise is mean zero and enters the outcome linearly, so its
        # integral contributes outcome_slope * 0; kept explicit for transparency.
        outcome = (float(config["outcome_intercept"])
                   + float(config["outcome_baseline"]) * c0
                   + float(config["outcome_exposure"]) * reference
                   + c1 @ outcome_weights
                   + outcome_slope * (mediator + 0.0))
        inner = float(mass @ outcome)
        weight = 1 if index in (0, simpson_steps) else (4 if index % 2 else 2)
        total += weight * inner
    return total * step / 3.0 / (high - low)


def _simulated(config, n, seed):
    sampler = _module("generator.py")
    reference = float(config["reference_level"])
    comparison = float(config["comparison_level"])
    rng = np.random.Generator(np.random.PCG64(seed))
    low, high = (float(v) for v in config["baseline_support"])
    c0 = rng.uniform(low, high, n)
    c1 = (sampler.confounder_mean(config, c0, np.full(n, reference))
          + float(config["confounder_sd"]) * rng.standard_normal((n, 3)))
    m = (sampler.mediator_mean(config, c0, np.full(n, comparison), c1)
         + float(config["mediator_sd"]) * rng.standard_normal(n))
    y = (sampler.outcome_mean(config, c0, np.full(n, reference), c1, m)
         + float(config["outcome_sd"]) * rng.standard_normal(n))
    return float(np.mean(y))


def verify(config):
    oracle = _module("truth.py")
    result = oracle.truth(config)
    reference_value = result["value"]
    reference = int(config["reference_level"])
    comparison = int(config["comparison_level"])

    reference_outcome = result["components"]["E[Y(a')]"]
    path_specific_effect = result["components"]["P_AMY"]

    quadrature = _nested_quadrature(config, 64, 8)
    simulated = _simulated(config, 400000, 20261030)

    low, high = (float(v) for v in config["baseline_support"])
    points = np.linspace(low, high, 5)
    nested = [float(oracle.nested_mean(config, c0, reference, comparison)) for c0 in points]
    differences = np.diff(nested)
    affine = bool(np.max(np.abs(differences - differences[0])) < 1e-12)

    alternative = oracle.functional(config, comparison, reference)

    no_mediator_path = deepcopy(config)
    no_mediator_path["mediator_exposure"] = 0.0
    no_mediator_path["mediator_exposure_confounder"] = [0.0, 0.0, 0.0]

    exposure = config["exposure_coefficients"]
    propensities = [1.0 / (1.0 + math.exp(-(exposure[0] + exposure[1] * c0))) for c0 in (low, high)]

    checks = [
        {"name": "source_constants_section_5",
         "passed": config == FIXTURE,
         "details": "All coefficients equal the Section 5 display of arXiv:1710.02011v1 pages 12-13."},
        {"name": "independent_nested_quadrature",
         "passed": abs(quadrature - reference_value) < 1e-09,
         "details": f"Composite Simpson over C0 combined with an order-8 three-dimensional Gauss-Hermite integral over the C1 noise gives {quadrature:.14g}; the closed form in truth.py gives {reference_value:.14g}; difference {abs(quadrature - reference_value):.3g}. This route evaluates the identification formula as written instead of collapsing the inner integrals."},
        {"name": "independent_nested_counterfactual_simulation",
         "passed": abs(simulated - reference_value) < MONTE_CARLO_TOLERANCE,
         "details": f"400000 units with C1 drawn under the reference level, M under the comparison level with that C1, and Y under the reference level give {simulated:.5f} against {reference_value:.14g}; deviation {abs(simulated - reference_value):.3g} within the declared Monte Carlo tolerance {MONTE_CARLO_TOLERANCE}. Any mix-up of which equation uses a' and which uses a would move this estimate."},
        {"name": "nested_mean_affine_in_baseline",
         "passed": affine,
         "details": f"The nested expectation evaluated on five equally spaced C0 values has constant first differences ({differences[0]:.12g}), which is what licenses replacing the integral over Uniform(0,2) by evaluation at E[C0] = 1."},
        {"name": "treatment_coding_evidence_from_source_figure",
         "passed": (FIGURE_AXIS[0] < reference_value < FIGURE_AXIS[1]
                    and not FIGURE_AXIS[0] < alternative < FIGURE_AXIS[1]),
         "details": f"The source's Figure 2 y-axis is labelled {FIGURE_AXIS[0]:.0f} to {FIGURE_AXIS[1]:.0f} with a dashed line at the true beta_0. The registered reading a' = 0, a = 1 gives {reference_value:.4g}, inside that range; the opposite reading gives {alternative:.4g}, outside it. This is the evidence for the registered coding, not a proof of it."},
        {"name": "zero_mediator_path",
         "passed": abs(oracle.truth(no_mediator_path)["components"]["P_AMY"]) < 1e-12,
         "details": "Removing the exposure from the mediator equation, both its main effect and the A*C1_1 interaction, makes beta_0 equal E[Y(a')], i.e. the path-specific effect P_AMY becomes exactly 0."},
        {"name": "derived_anchors",
         "passed": (abs(reference_value - 2.678) < 1e-12
                    and abs(reference_outcome - 3.596) < 1e-12
                    and abs(path_specific_effect - (-0.918)) < 1e-12),
         "details": "beta_0 = %.15g, E[Y(a')] = %.15g, P_AMY = %.15g. All three are DERIVED by the collector; the source prints no numerical truth. Registering them together keeps the functional beta_0 distinct from the effect P_AMY." % (reference_value, reference_outcome, path_specific_effect)},
        {"name": "treatment_induced_confounder_retained",
         "passed": any(abs(v) > 0 for v in config["confounder_exposure"]) and any(abs(v) > 0 for v in config["confounder_interaction"]),
         "details": "The exposure affects C1 both directly and through the C0*A interaction, so the treatment-induced mediator-outcome confounding that motivates the source is retained and not simplified away."},
        {"name": "exposure_positivity_on_support",
         "passed": all(0.0 < p < 1.0 for p in propensities),
         "details": f"expit(0.9 + 0.3 C0) equals {propensities[0]:.6f} at C0 = 0 and {propensities[1]:.6f} at C0 = 2, so the exposure propensity is bounded inside (0,1) on the whole compact support."},
    ]
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": "All routes necessarily share the registered structural equations. truth.py collapses the nested integrals into conditional means; the quadrature route integrates the C1 noise in three dimensions and C0 by Simpson; the simulation route samples the nested counterfactual. Transcription from the preprint and independent-person reproduction remain separate review tasks.",
        "limits": "Numerical diagnostics only. They do not establish the source's no-unmeasured-confounding model, do not prove the numerical coding of a' and a (only that the figure axis is consistent with it), and do not confirm that the preprint matches the published Biometrika article.",
    }
