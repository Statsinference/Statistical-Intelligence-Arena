"""Independent verification of the registered path-specific effect P_AMY.

The registered target is a CONTRAST of two nested counterfactual means,
P_AMY = beta_0 - E[Y(a')], so every independent route below computes both arms and
compares the difference; the two arms are also anchored separately so that the effect
can never be confused with either mean.

Routes that do not share code with truth.py:
  * nested numerical integration: composite Simpson over C0 on its uniform support and
    a three-dimensional Gauss-Hermite integral over the C1 noise, i.e. the
    identification formula evaluated as written rather than collapsed to conditional
    means, run once per arm;
  * a fixed-seed structural simulation of both nested counterfactuals under COMMON
    random numbers, which also checks the exact per-unit identity
    Y_arm(a) - Y_arm(a') = outcome_slope * (M(a, C1(a')) - M(a', C1(a'))).
Plus source-constant, affineness, convention-evidence, zero-path and anchor checks.
"""
from copy import deepcopy
import importlib.util
import itertools
import math
from pathlib import Path

import numpy as np

FIXTURE = {
    "baseline_support": [0.0, 2.0],
    "exposure_coefficients": [0.9, 0.3],
    "confounder_intercept": [0.8, 0.6, -0.3],
    "confounder_baseline": [1.0, 0.1, 0.2],
    "confounder_exposure": [0.5, -0.4, 0.5],
    "confounder_interaction": [-0.1, 0.8, -0.2],
    "confounder_sd": 1.0,
    "mediator_intercept": -0.5,
    "mediator_baseline": -0.2,
    "mediator_exposure": 0.3,
    "mediator_confounder": [-0.2, 0.1, 0.5],
    "mediator_exposure_confounder": [0.4, 0.0, 0.0],
    "mediator_sd": 1.0,
    "outcome_intercept": 0.2,
    "outcome_baseline": 0.2,
    "outcome_exposure": 0.6,
    "outcome_confounder": [1.0, 0.7, 0.3],
    "outcome_mediator": -0.9,
    "outcome_exposure_mediator": -0.8,
    "outcome_sd": 1.0,
    "reference_level": 0,
    "comparison_level": 1,
    "target": "P_AMY",
}
FIGURE_AXIS = (2.0, 5.0)          # y-axis labels printed in the source's Figure 2
SOURCE_BETA_0 = 2.678             # derived; the quantity the source's Figure 2 plots
SOURCE_REFERENCE_OUTCOME = 3.596  # derived
SOURCE_P_AMY = -0.918             # derived; the registered effect
MONTE_CARLO_TOLERANCE = 0.01


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("miles_collection_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _nested_quadrature(config, simpson_steps, hermite_order, mediator_level):
    """Evaluate one arm of the identification formula as three explicit integrals."""
    reference = int(config["reference_level"])
    intercept = np.asarray(config["confounder_intercept"], dtype=float)
    baseline = np.asarray(config["confounder_baseline"], dtype=float)
    exposure = np.asarray(config["confounder_exposure"], dtype=float)
    interaction = np.asarray(config["confounder_interaction"], dtype=float)
    mediator_weights = (np.asarray(config["mediator_confounder"], dtype=float)
                        + mediator_level * np.asarray(config["mediator_exposure_confounder"],
                                                      dtype=float))
    outcome_weights = np.asarray(config["outcome_confounder"], dtype=float)
    outcome_slope = (float(config["outcome_mediator"])
                     + float(config["outcome_exposure_mediator"]) * reference)

    raw, weights = np.polynomial.hermite.hermgauss(hermite_order)
    weights = weights / math.sqrt(math.pi)
    raw = math.sqrt(2.0) * float(config["confounder_sd"]) * raw
    noise = np.array(list(itertools.product(raw, repeat=3)))
    mass = np.prod(np.array(list(itertools.product(weights, repeat=3))), axis=1)

    low, high = (float(v) for v in config["baseline_support"])
    step = (high - low) / simpson_steps
    total = 0.0
    for index in range(simpson_steps + 1):
        c0 = low + index * step
        c1 = (intercept + baseline * c0 + exposure * reference
              + interaction * c0 * reference) + noise
        mediator = (float(config["mediator_intercept"])
                    + float(config["mediator_baseline"]) * c0
                    + float(config["mediator_exposure"]) * mediator_level
                    + c1 @ mediator_weights)
        # The mediator noise is mean zero and enters the outcome linearly, so its
        # integral contributes outcome_slope * 0; kept explicit for transparency.
        outcome = (float(config["outcome_intercept"])
                   + float(config["outcome_baseline"]) * c0
                   + float(config["outcome_exposure"]) * reference
                   + c1 @ outcome_weights
                   + outcome_slope * (mediator + 0.0))
        inner = float(mass @ outcome)
        weight = 1 if index in (0, simpson_steps) else (4 if index % 2 else 2)
        total += weight * inner
    return total * step / 3.0 / (high - low)


def _simulated_arms(config, n, seed):
    """Both nested counterfactuals under common random numbers.

    Returns (mean beta_0 arm, mean reference arm, max per-unit identity gap).
    """
    sampler = _module("generator.py")
    reference = float(config["reference_level"])
    comparison = float(config["comparison_level"])
    rng = np.random.Generator(np.random.PCG64(seed))
    low, high = (float(v) for v in config["baseline_support"])
    c0 = rng.uniform(low, high, n)
    confounder_noise = float(config["confounder_sd"]) * rng.standard_normal((n, 3))
    mediator_noise = float(config["mediator_sd"]) * rng.standard_normal(n)
    outcome_noise = float(config["outcome_sd"]) * rng.standard_normal(n)

    c1 = sampler.confounder_mean(config, c0, np.full(n, reference)) + confounder_noise

    def arm(mediator_level):
        m = (sampler.mediator_mean(config, c0, np.full(n, mediator_level), c1)
             + mediator_noise)
        y = (sampler.outcome_mean(config, c0, np.full(n, reference), c1, m)
             + outcome_noise)
        return m, y

    m_comparison, y_comparison = arm(comparison)
    m_reference, y_reference = arm(reference)

    outcome_slope = (float(config["outcome_mediator"])
                     + float(config["outcome_exposure_mediator"]) * reference)
    identity_gap = float(np.max(np.abs(
        (y_comparison - y_reference) - outcome_slope * (m_comparison - m_reference))))
    return float(y_comparison.mean()), float(y_reference.mean()), identity_gap


def verify(config):
    oracle = _module("truth.py")
    result = oracle.truth(config)
    registered = float(result["value"])
    reference = int(config["reference_level"])
    comparison = int(config["comparison_level"])

    beta_0 = float(result["components"]["beta_0 = E(Y[M{a, C1(a')}, C1(a'), a'])"])
    reference_outcome = float(result["components"]["E[Y(a')]"])

    quad_beta_0 = _nested_quadrature(config, 64, 8, comparison)
    quad_reference = _nested_quadrature(config, 64, 8, reference)
    quad_effect = quad_beta_0 - quad_reference
    quad_gap = abs(quad_effect - registered)

    sim_beta_0, sim_reference, identity_gap = _simulated_arms(config, 400000, 20261030)
    sim_effect = sim_beta_0 - sim_reference
    sim_gap = abs(sim_effect - registered)

    low, high = (float(v) for v in config["baseline_support"])
    points = np.linspace(low, high, 5)
    nested = [float(oracle.nested_mean(config, c0, reference, comparison)) for c0 in points]
    differences = np.diff(nested)
    affine = bool(np.max(np.abs(differences - differences[0])) < 1e-12)

    # Swapping a' and a gives the reading the source's figure rules out.
    alternative = oracle.functional(config, comparison, reference)

    no_mediator_path = deepcopy(config)
    no_mediator_path["mediator_exposure"] = 0.0
    no_mediator_path["mediator_exposure_confounder"] = [0.0, 0.0, 0.0]
    knockout = float(oracle.truth(no_mediator_path)["value"])

    exposure = config["exposure_coefficients"]
    propensities = [1.0 / (1.0 + math.exp(-(exposure[0] + exposure[1] * c0)))
                    for c0 in (low, high)]

    checks = [
        {"name": "source_constants_section_5",
         "passed": config == FIXTURE,
         "details": "All coefficients equal the Section 5 display of arXiv:1710.02011v1 pages 12-13."},
        {"name": "registered_target_is_the_effect_not_a_mean",
         "passed": (abs(registered - SOURCE_P_AMY) < 1e-12
                    and abs(beta_0 - SOURCE_BETA_0) < 1e-12
                    and abs(reference_outcome - SOURCE_REFERENCE_OUTCOME) < 1e-12
                    and abs((beta_0 - reference_outcome) - registered) < 1e-15),
         "details": ("The source defines P_AMY = E(Y[M{a, C1(a')}, C1(a'), a']) - E[Y(a')]. "
                     "The registered value is the EFFECT, P_AMY = %.15g; its two arms are "
                     "beta_0 = %.15g and E[Y(a')] = %.15g, and beta_0 - E[Y(a')] reproduces "
                     "the registered value exactly. beta_0 on its own is a nested "
                     "counterfactual MEAN, not a path-specific effect, and is deliberately "
                     "carried only as a component."
                     % (registered, beta_0, reference_outcome))},
        {"name": "independent_nested_quadrature",
         "passed": quad_gap < 1e-09,
         "details": ("Composite Simpson over C0 with an order-8 three-dimensional "
                     "Gauss-Hermite integral over the C1 noise, run once per arm, gives "
                     "beta_0 = %.14g and E[Y(a')] = %.14g, hence P_AMY = %.14g against the "
                     "registered %.14g; difference %.3g. This route evaluates the "
                     "identification formula as written instead of collapsing the inner "
                     "integrals."
                     % (quad_beta_0, quad_reference, quad_effect, registered, quad_gap))},
        {"name": "independent_nested_counterfactual_simulation",
         "passed": sim_gap < MONTE_CARLO_TOLERANCE and identity_gap < 1e-09,
         "details": ("400000 units, C1 drawn once under the reference level and shared by "
                     "both arms, the mediator drawn at the comparison level in one arm and "
                     "at the reference level in the other, the outcome at the reference "
                     "level in both: P_AMY = %.5f against the registered %.14g, deviation "
                     "%.3g within the declared Monte Carlo tolerance %.3g. Under common "
                     "random numbers the per-unit identity "
                     "Y_a - Y_a' = outcome_slope * (M_a - M_a') holds to %.3g, so any "
                     "mix-up of which equation uses a' and which uses a would surface here."
                     % (sim_effect, registered, sim_gap, MONTE_CARLO_TOLERANCE,
                        identity_gap))},
        {"name": "nested_mean_affine_in_baseline",
         "passed": affine,
         "details": ("The nested expectation evaluated on five equally spaced C0 values has "
                     "constant first differences (%.12g), which is what licenses replacing "
                     "the integral over Uniform(0,2) by evaluation at E[C0] = 1."
                     % differences[0])},
        {"name": "treatment_coding_evidence_from_source_figure",
         "passed": (FIGURE_AXIS[0] < beta_0 < FIGURE_AXIS[1]
                    and not FIGURE_AXIS[0] < alternative < FIGURE_AXIS[1]),
         "details": ("The source's Figure 2 y-axis is labelled %.0f to %.0f with a dashed "
                     "line at the true beta_0, so this check is about beta_0, not about the "
                     "registered effect. The registered reading a' = 0, a = 1 gives "
                     "beta_0 = %.4g, inside that range; the opposite reading gives %.4g, "
                     "outside it. This is the evidence for the registered coding, not a "
                     "proof of it."
                     % (FIGURE_AXIS[0], FIGURE_AXIS[1], beta_0, alternative))},
        {"name": "zero_mediator_path",
         "passed": abs(knockout) < 1e-12,
         "details": ("Removing the exposure from the mediator equation, both its main effect "
                     "and the A*C1_1 interaction, makes the two arms coincide and the "
                     "registered P_AMY exactly %.3g. The effect is zero exactly when the "
                     "A -> M arrow is cut, which is the behaviour a path-specific effect "
                     "must have and which beta_0 alone would not show." % knockout)},
        {"name": "treatment_induced_confounder_retained",
         "passed": (any(abs(v) > 0 for v in config["confounder_exposure"])
                    and any(abs(v) > 0 for v in config["confounder_interaction"])),
         "details": ("The exposure affects C1 both directly and through the C0*A "
                     "interaction, so the treatment-induced mediator-outcome confounding "
                     "that motivates the source is retained and not simplified away.")},
        {"name": "exposure_positivity_on_support",
         "passed": all(0.0 < p < 1.0 for p in propensities),
         "details": ("expit(0.9 + 0.3 C0) equals %.6f at C0 = 0 and %.6f at C0 = 2, so the "
                     "exposure propensity is bounded inside (0,1) on the whole compact "
                     "support." % (propensities[0], propensities[1]))},
    ]
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": ("All routes necessarily share the registered structural "
                              "equations. truth.py collapses the nested integrals into "
                              "conditional means; the quadrature route integrates the C1 "
                              "noise in three dimensions and C0 by Simpson, once per arm; "
                              "the simulation route samples both nested counterfactuals "
                              "under common random numbers. Transcription from the preprint "
                              "and independent-person reproduction remain separate review "
                              "tasks."),
        "limits": ("Numerical diagnostics only. They do not establish the source's "
                   "no-unmeasured-confounding model, do not prove the numerical coding of "
                   "a' and a (only that the figure axis is consistent with it), and do not "
                   "confirm that the preprint matches the published Biometrika article."),
    }
