# 来源认领记录

mediation-miles-2019-toxicity-path-specific-v1

Miles, C. H., Shpitser, I., Kanki, P., Meloni, S. and Tchetgen Tchetgen, E. J. (2019). On semiparametric estimation of a path-specific effect in the presence of mediator-outcome confounding. Biometrika 107(1), 159-172. DOI: 10.1093/biomet/asz063.

实际阅读版本：arXiv:1710.02011v1 预印本。期刊正式版未取得；卷期页来自该 DOI 的 Crossref 记录，收集者未亲见。

定位：§5 Simulation study，预印本 PDF 第 12-13 页（生成机制展示式）；§2，第 4-5 页（P_AMY 与 beta_0 的定义）；式 (1)，第 5 页（识别公式）；Figure 2 及其纵轴刻度，第 15 页。页码为预印本 PDF 页码。

机制区别：三维的**处理诱导中介–结局混杂向量 C1**（毒性）位于曝露与连续中介（依从性）之间；目标是沿 A → M → Y 的路径效应，其嵌套反事实把 C1 固定在参考水平、而中介取比较水平的值。这一嵌套正是它与自然直接/间接效应的区别。

**处理编码的判读**：原文只用 a'（参考）与 a（比较），未给数字编码。本包取 a'=0、a=1，依据是原文 Figure 2 的纵轴刻度为 2–5 且虚线画在真值处：该读法给 beta_0 = 2.678（在范围内），相反读法给 5.611（在范围外）。这是证据而非证明，需审稿人确认。

真值：原文未给数值。登记 beta_0 = 2.678，并锚定 E[Y(a')] = 3.596 与 P_AMY = -0.918。均为收集者解析导出。

同作者 2017 年 JASA 的 PEPFAR 论文**未收集**：其仿真参数由保密真实数据拟合而来、原文未公布，无法忠实复现。

已在 2026-10-30 的仓库快照内查重：mediation 域仅有 nie-eric-original-v1，incoming/ 中无 mediation-* 包。未向维护人发送，待维护人认领/全库查重与具名科学审核。
