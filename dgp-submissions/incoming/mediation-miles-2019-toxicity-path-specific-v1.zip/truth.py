"""Population path-specific effect functional beta_0; integrates the law, not the sample.

beta_0 = int int int E(Y|m, c1, a', c0) dF(m|c1, a, c0) dF(c1|a', c0) dF(c0)

Every conditional mean is linear with additive mean-zero noise, so the three inner
integrals collapse to substitutions of conditional means, and the resulting expression
is affine in c0; integrating the affine function over Uniform(low, high) therefore
amounts to evaluating it at the midpoint E[C0].
"""
import numpy as np


def nested_mean(config, c0, reference, comparison):
    """The inner three integrals of the identification formula at a fixed c0."""
    intercept = np.asarray(config["confounder_intercept"], dtype=float)
    baseline = np.asarray(config["confounder_baseline"], dtype=float)
    exposure = np.asarray(config["confounder_exposure"], dtype=float)
    interaction = np.asarray(config["confounder_interaction"], dtype=float)
    # C1 is kept at its reference-level counterfactual mean.
    c1_mean = intercept + baseline * c0 + exposure * reference + interaction * c0 * reference
    # The mediator is taken at the comparison level, with that same C1.
    mediator_weights = (np.asarray(config["mediator_confounder"], dtype=float)
                        + comparison * np.asarray(config["mediator_exposure_confounder"], dtype=float))
    mediator_mean = (float(config["mediator_intercept"])
                     + float(config["mediator_baseline"]) * c0
                     + float(config["mediator_exposure"]) * comparison
                     + mediator_weights @ c1_mean)
    # The outcome is taken at the reference level.
    outcome_slope = (float(config["outcome_mediator"])
                     + float(config["outcome_exposure_mediator"]) * reference)
    return (float(config["outcome_intercept"])
            + float(config["outcome_baseline"]) * c0
            + float(config["outcome_exposure"]) * reference
            + np.asarray(config["outcome_confounder"], dtype=float) @ c1_mean
            + outcome_slope * mediator_mean)


def functional(config, reference, comparison):
    low, high = (float(v) for v in config["baseline_support"])
    return float(nested_mean(config, 0.5 * (low + high), reference, comparison))


def truth(config):
    reference = int(config["reference_level"])
    comparison = int(config["comparison_level"])
    value = functional(config, reference, comparison)
    reference_outcome = functional(config, reference, reference)
    return {
        "value": value,
        "estimated_error": 0.0,
        "method": "Closed form. The nested expectation is affine in C0, so integrating over Uniform(0,2) is evaluation at E[C0] = 1; no quadrature or Monte Carlo is used.",
        "error_interpretation": "Exact up to IEEE-754 double rounding; not a statistical error bar. The source prints no numerical truth to compare against.",
        "target": "beta_0 = E(Y[M{a, C1(a')}, C1(a'), a']) with a' = reference_level, a = comparison_level",
        "components": {"E[Y(a')]": reference_outcome, "P_AMY": value - reference_outcome},
    }
