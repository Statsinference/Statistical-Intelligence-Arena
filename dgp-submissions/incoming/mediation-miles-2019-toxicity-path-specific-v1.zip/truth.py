"""Population path-specific effect P_AMY; integrates the law, not the sample.

The source defines, in its Section 2,

    P_AMY = E(Y[M{a, C1(a')}, C1(a'), a']) - E{Y(a')} = beta_0 - E[Y(a')],

so the EFFECT is a contrast of two nested counterfactual means, not either mean on
its own.  Both arms are built by the same identification formula

    E(Y[M{t, C1(a')}, C1(a'), a'])
        = int int int E(Y | m, c1, a', c0) dF(m | c1, t, c0) dF(c1 | a', c0) dF(c0),

and they differ only in the exposure level t fed to the MEDIATOR equation: t = a for
beta_0 and t = a' for E[Y(a')].  In both arms the confounder vector C1 and the outcome
stay at the reference level a'.

Every conditional mean is linear with additive mean-zero noise, so the three inner
integrals collapse to substitutions of conditional means, and the resulting expression
is affine in c0; integrating an affine function over Uniform(low, high) therefore
amounts to evaluating it at the midpoint E[C0].

The two arms are kept as named components so that the registered effect can never be
confused with either counterfactual mean.
"""
import numpy as np


def nested_mean(config, c0, reference, comparison):
    """The inner three integrals of the identification formula at a fixed c0.

    `reference` is the level a' used for C1 and for the outcome; `comparison` is the
    level fed to the mediator equation.  Setting comparison = reference gives the
    ordinary counterfactual mean E[Y(a')].
    """
    intercept = np.asarray(config["confounder_intercept"], dtype=float)
    baseline = np.asarray(config["confounder_baseline"], dtype=float)
    exposure = np.asarray(config["confounder_exposure"], dtype=float)
    interaction = np.asarray(config["confounder_interaction"], dtype=float)
    # C1 is kept at its reference-level counterfactual mean.
    c1_mean = intercept + baseline * c0 + exposure * reference + interaction * c0 * reference
    # The mediator is taken at the comparison level, with that same C1.
    mediator_weights = (np.asarray(config["mediator_confounder"], dtype=float)
                        + comparison * np.asarray(config["mediator_exposure_confounder"], dtype=float))
    mediator_mean = (float(config["mediator_intercept"])
                     + float(config["mediator_baseline"]) * c0
                     + float(config["mediator_exposure"]) * comparison
                     + mediator_weights @ c1_mean)
    # The outcome is taken at the reference level.
    outcome_slope = (float(config["outcome_mediator"])
                     + float(config["outcome_exposure_mediator"]) * reference)
    return (float(config["outcome_intercept"])
            + float(config["outcome_baseline"]) * c0
            + float(config["outcome_exposure"]) * reference
            + np.asarray(config["outcome_confounder"], dtype=float) @ c1_mean
            + outcome_slope * mediator_mean)


def functional(config, reference, comparison):
    """E(Y[M{comparison, C1(reference)}, C1(reference), reference])."""
    low, high = (float(v) for v in config["baseline_support"])
    return float(nested_mean(config, 0.5 * (low + high), reference, comparison))


def arms(config):
    """(beta_0, E[Y(a')]) -- the two nested means whose contrast is P_AMY."""
    reference = int(config["reference_level"])
    comparison = int(config["comparison_level"])
    return (functional(config, reference, comparison),
            functional(config, reference, reference))


def path_specific_effect(config):
    """P_AMY = beta_0 - E[Y(a')]."""
    beta_0, reference_outcome = arms(config)
    return beta_0 - reference_outcome


def truth(config):
    beta_0, reference_outcome = arms(config)
    return {
        "value": beta_0 - reference_outcome,
        "estimated_error": 0.0,
        "method": ("Closed form. Both arms of the contrast are evaluated from the same "
                   "identification formula, differing only in the exposure level fed to "
                   "the mediator equation; each nested expectation is affine in C0, so "
                   "integrating over Uniform(0,2) is evaluation at E[C0] = 1. No "
                   "quadrature and no Monte Carlo is used."),
        "error_interpretation": ("Exact up to IEEE-754 double rounding; not a statistical "
                                 "error bar. The source prints no numerical truth to "
                                 "compare against."),
        "target": ("P_AMY = E(Y[M{a, C1(a')}, C1(a'), a']) - E[Y(a')] "
                   "with a' = reference_level, a = comparison_level"),
        "components": {
            "beta_0 = E(Y[M{a, C1(a')}, C1(a'), a'])": beta_0,
            "E[Y(a')]": reference_outcome,
        },
    }
