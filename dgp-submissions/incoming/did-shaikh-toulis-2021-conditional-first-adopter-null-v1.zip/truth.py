"""Conditional first-adopter ATT/SATT from native additive null."""
from generator import validate
def truth(config):
    validate(config)
    return {"value":0.0,"estimated_error":0.0,"method":"Native tau=0 implies pathwise zero on nonempty first-adopter post cells conditional on whole-experiment success; conditional ATT and SATT both0"}
