"""Independent potential-outcome cancellation under arbitrary accepted design."""
import numpy as np
from generator import validate
def verify(config):
    validate(config)
    # Construct a different accepted design without using generator/truth outputs.
    u=np.arange(25,dtype=float)/25
    y0=np.column_stack([u+.1*j for j in range(1000)])
    d=np.zeros((25,1000)); d[13,422:]=1
    y1=y0+0*d
    value=float(np.mean((y1-y0)[d==1]))
    checks=[{"name":"nonempty_conditioned_treated_post","passed":int(d.sum())==578},
            {"name":"independent_pathwise_null_cancellation","passed":value==0.,"value":value}]
    return {"passed":all(q["passed"] for q in checks),"checks":checks}
