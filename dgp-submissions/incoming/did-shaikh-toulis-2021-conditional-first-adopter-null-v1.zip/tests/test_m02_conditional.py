import unittest,sys,json,platform
from pathlib import Path
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import generator as g
import truth,verify
CFG=dict(g.EXPECTED)
class Tests(unittest.TestCase):
 def test_structure_seed_locality(self):
  np.random.seed(903); before=np.random.get_state()
  a=g.generate(CFG,25,7); b=g.generate(CFG,25,7)
  self.assertEqual(a,b); self.assertNotEqual(a,g.generate(CFG,25,8))
  after=np.random.get_state(); self.assertTrue(np.array_equal(before[1],after[1])); self.assertEqual(before[2:],after[2:])
  self.assertEqual(len(a),1005); self.assertTrue(all(len(v)==25 for v in a.values())); self.assertEqual(sum(a['G']),1)
  self.assertTrue(all(np.isfinite(v).all() for v in map(np.asarray,a.values())))
  self.assertTrue(set(a)=={'G','X1','Tmax','first_adoption','pre_last_index'}|{f'Y_t{j:04d}' for j in range(1,1001)})
 def test_invalid(self):
  for n in [True,24,26,25.,None]:
   with self.assertRaises(ValueError):g.generate(CFG,n,1)
  for seed in [True,-1,1.,None]:
   with self.assertRaises(ValueError):g.generate(CFG,25,seed)
  for cfg in [{},dict(CFG,units=26),dict(CFG,periods=999),dict(CFG,extra=1),dict(CFG,units=25.)]:
   for fun,args in [(g.generate,(25,1)),(truth.truth,()),(verify.verify,())]:
    with self.assertRaises(ValueError):fun(cfg,*args)
 def test_independent_reference_and_ar(self):
  # Separately reconstruct raw draws and matrix-free closed form.
  r=np.random.default_rng(11); xc=r.uniform(-10,10,(10000,25)); tc=r.exponential(np.exp(-1-.5*xc))
  st=np.sort(tc,axis=1); h=float(np.max(.4*st[:,3]+.6*st[:,4]))
  x=r.uniform(-10,10,25); ti=r.exponential(np.exp(-1-.5*x)); self.assertLess(ti.min(),h)
  e=r.normal(0,.15,25000).reshape(25,1000,order='F'); a=g.generate(CFG,25,11)
  self.assertAlmostEqual(h,a['Tmax'][0]); self.assertEqual(a['G'].index(1),int(ti.argmin())); np.testing.assert_array_equal(x,a['X1'])
  y=np.array([a[f'Y_t{j:04d}'] for j in range(1,1001)]).T
  residual=y-.2*np.column_stack([np.zeros(25),y[:,:-1]])-.5*x[:,None]-.5*np.sqrt(np.arange(1,1001))
  np.testing.assert_allclose(residual,e,atol=1e-14,rtol=0)
  # C upper shift convolution, independently evaluated at selected columns.
  forcing=.5*x[:,None]+.5*np.sqrt(np.arange(1,1001))+e
  for j in [0,1,17,999]:
   expected=sum(.2**(j-l)*forcing[:,l] for l in range(j+1))
   np.testing.assert_allclose(y[:,j],expected,atol=2e-14)
  time=np.linspace(0,h,1000); k=a['pre_last_index'][0]; t=a['first_adoption'][0]
  self.assertLessEqual(time[k-1],t); self.assertGreater(time[k],t); self.assertEqual(k,int(np.sum(time<=ti.min())))
 def test_whole_rejection_and_exact_boundary(self):
  class Rng:
   def __init__(self):self.cal=0;self.panel=0;self.uniform_cal=0;self.normal_calls=0
   def uniform(self,lo,hi,size):
    if isinstance(size,tuple):self.uniform_cal+=1
    return np.zeros(size)
   def exponential(self,scale):
    if scale.ndim==2:
     self.cal+=1;return np.full(scale.shape,1. if self.cal==1 else 3.)
    self.panel+=1
    # First attempt all times==h: exact source failure; second min strictly<h.
    return np.full(scale.shape,1. if self.panel==1 else .5)
   def normal(self,mean,sd,size):self.normal_calls+=1;return np.zeros(size)
  r=Rng()
  with patch.object(g.np.random,'default_rng',return_value=r):a,d=g._generate_with_diagnostics(CFG,25,0)
  self.assertEqual(d,{'attempts':2,'rejections':1});self.assertEqual(r.cal,2);self.assertEqual(r.panel,2);self.assertEqual(r.uniform_cal,2);self.assertEqual(r.normal_calls,1)
  self.assertEqual(a['Tmax'],[3.]*25);self.assertEqual(a['first_adoption'],[.5]*25);self.assertEqual(a['G'],[1]+[0]*24)
 def test_empirical_error_and_acceptance_audit(self):
  residuals=[];attempts=0;ks=[];hs=[]
  for seed in range(100):
   a,d=g._generate_with_diagnostics(CFG,25,seed);attempts+=d['attempts'];ks.append(a['pre_last_index'][0]);hs.append(a['Tmax'][0])
   y=np.array([a[f'Y_t{j:04d}'] for j in range(1,1001)]).T;x=np.array(a['X1'])
   residuals.append(y-.2*np.column_stack([np.zeros(25),y[:,:-1]])-.5*x[:,None]-.5*np.sqrt(np.arange(1,1001)))
  z=np.stack(residuals);self.assertLess(abs(z.mean()),.0005);self.assertLess(abs(z.var()-.15**2),.0001)
  lag=float(np.corrcoef(z[:,:,:-1].ravel(),z[:,:,1:].ravel())[0,1]);cross=float(np.corrcoef(z[:,:-1,:].ravel(),z[:,1:,:].ravel())[0,1]);self.assertLess(abs(lag),.004);self.assertLess(abs(cross),.004)
  audit={'experiments':100,'attempts':attempts,'rejections':attempts-100,'observed_acceptance_rate':100/attempts,'rejections_per_experiment':(attempts-100)/100,'error_mean':float(z.mean()),'error_variance':float(z.var()),'error_lag_correlation':lag,'error_cross_unit_correlation':cross,'pre_last_range':[min(ks),max(ks)],'Tmax_range':[min(hs),max(hs)],'python':platform.python_version(),'numpy':np.__version__,'rng':'NumPy default_rng/PCG64; not R bitwise','population':'whole-experiment generation success conditional; no retry cap'}
  Path(__file__).resolve().parents[1].joinpath('checks/implementation_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
 def test_truth(self):
  self.assertEqual(truth.truth(CFG)['value'],0);self.assertTrue(verify.verify(CFG)['passed'])
if __name__=='__main__':unittest.main(verbosity=2)
