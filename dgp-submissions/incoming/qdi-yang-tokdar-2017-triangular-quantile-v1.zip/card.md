# QDI3 正式版三角形机制来源与完整生成律审查

**状态：awaiting_scientific_review；scientific_acceptance=false。**

ID：`qdi-yang-tokdar-2017-triangular-quantile-v1`；修订：`source-completeness-audit-20261101`；kind=`synthetic_dgp`；family=`quantile_distribution`；mechanism_family_id=`yang-tokdar-2017-triangular-quantile`。本轮是同一贡献的来源记录修订，不新增机制或 scenario。截至2026-11-01，本轮基线为此前已采纳包 `a790ce219f314f8c680110df0532207437291efa01fa03d486dc723927aa33b3`，该历史包保留不覆盖。正式版字面机制和重心查询的既有用户决定继续生效，不重新提出版本选择。

## 来源核对表

Yang, Yun and Tokdar, Surya T. (2017). *Joint Estimation of Quantile Planes Over Arbitrary Predictor Spaces*. **Journal of the American Statistical Association 112(519),1107–1120**. [DOI 10.1080/01621459.2016.1192545](https://doi.org/10.1080/01621459.2016.1192545)。正式版出版社封面列 online 2017-04-12；属于指定四刊。本包没有 real_data_claim。

| 核对项 | 版本及精确定位 | 结论 |
|---|---|---|
| 作者、题名、期刊年份、DOI | 所供正式版 PDF p.1 出版社封面、p.2/JASA1107 文首 | 已亲读；15页含封面；SHA256 `cf9d41fbbac216f86d2a9887fa44c54681185d038f8f1ce101f550a19da6fe8b` |
| 生成主来源 | 正式版 §1.3 讨论及 Figure1 图注；PDF p.3 / JASA p.1108，图注未编号方程 | 顶点(-1,1),(-1,2),(2,-1)，X联合均匀，正态均值0/1、方差1/0.2²，原图n=1000；整页文字与图像复核 |
| 条件分位数／共享秩 | PDF p.2 / JASA1107，式(1)后定义、式(2)逆变换、式(3)非交叉 | 只使用一个共享U，等价一个Z；不是独立mixture或独立正态之和 |
| 单位与独立性 | PDF p.5 / JASA1110 §2.3 密度及逐行似然；PDF p.7 / JASA1112 §4 stochastic design | 行间iid，X坐标同单位相关，条件响应服从所给law |
| 原点约定 | PDF p.4 / JASA1109 §2.1 | 估计参数化允许平移到内部点；本包不平移观察X，原坐标(0,0)在域外 |
| 补充材料 | [出版社补充](https://www.tandfonline.com/doi/suppl/10.1080/01621459.2016.1192545)，所供13页PDF；p.1、B.1 pp.9–11 | 已取得和阅读，非missing；SHA256 `2f553ad07f09f099940ee3e57f45a84d209bb25210c900166495aae8c1cfa33b`；密度恒等式及中心化为辅助证据，不覆盖图注 |
| 查询和真值 | 本包用户已授权的target adaptation | x*=(0,2/3), tau*=19/20；不是原文报告的标量；详见推导 |
| 历史预印本差异 | [arXiv:1507.03130v1](https://arxiv.org/abs/1507.03130v1)，2015-07-11；PDF/印刷pp.11–12 §5.1 Eq.(15) | 原域顶点(-1,-1),(-1,2),(2,-1)，n=200；显示分位方程相同。仅作差异记录，不能用以改写正式版，不声称作者笔误 |
| 代码证据 | 下文列固定commit、文件、函数/行号；完整哈希见source_records.json | 官方估计软件与本包独立DGP实现明确区分；原实验脚本搜索范围及结论逐项保留 |

当前正式版 §5.1 是另一个单变量实验，不将其公式号或参数挪用为本三角形来源。预印本SHA256 `c0cfd968254209971c831b11303b0908f39c63abffde33f04246709d9c4e9b7b`。

## 按生成顺序的完整变量与依赖表

| 顺序 | 变量及可见性 | 分布、方程和参数 | 来源或推导 |
|---|---|---|---|
| 0 | n, seed, fixed constants | Published illustration n=1000; check n=128, seed=1729 are collector choices. A=(-1,1), B=(-1,2), C=(2,-1); normal means (0,1), standard deviations (1,1/5). | JASA p.1108 / PDF p.3, Figure 1 caption; check seed and size are not author experimental values. |
| 1 | R_i,T_i; u_i,v_i (internal) | R_i,T_i iid Uniform(0,1); if R_i+T_i>1 then (u_i,v_i)=(1-R_i,1-T_i), else (R_i,T_i). Density of (u_i,v_i) is 2 on u>=0,v>=0,u+v<=1. | Collector-written equivalent area-uniform sampling algorithm; not attributed to author code. |
| 2 | X_i=(X1_i,X2_i) (observed) | X_i=A+u_i(B-A)+v_i(C-A)=(-1+3v_i,1+u_i-2v_i); X_i~Uniform_area(D). D={x1>=-1,2x1+3x2>=1,x1+x2<=1}; area=3/2, density=2/3. | Published Figure 1 joint uniform law; affine Jacobian |det|=3 and area/density derived. |
| 3 | s_i,a_i,b_i (internal deterministic values) | s_i=X1_i+X2_i in [0,1]; a_i=(1-s_i)/3 in [0,1/3]; b_i=(2+s_i)/3 in [2/3,1]; a_i+b_i=1. | Published caption weights; ranges derived at the three vertices. No mixture membership variable is drawn. |
| 4 | Z_i (internal common rank) | Z_i~N(0,1), independent of (R_i,T_i), X_i and other rows. Equivalently U_i=Phi(Z_i)~Uniform(0,1). L0_i=Z_i and L1_i=1+(1/5)Z_i share this same Z_i, hence have correlation 1. | Published p.1107 / PDF p.2 Eq.(2) inverse transform and Figure 1 quantile combination; Gaussian reduction derived, not an additional independent error. |
| 5 | Y_i (observed) | Y_i=a_i Z_i+b_i(1+Z_i/5)=mu_i+sigma_i Z_i; mu_i=(2+s_i)/3, sigma_i=(7-4s_i)/15 in [1/5,7/15]. Y_i|X_i~N(mu_i,sigma_i^2). epsilon_i=Y_i-mu_i has conditional variance sigma_i^2; epsilon_i is not marginally independent of X_i because its scale varies. | Algebraic equivalent of published Figure 1, whose Q_N second parameter denotes variance. Independent latent Z is distinguished from heteroskedastic residual epsilon. |
| 6 | Observed table and independent rows | Repeat the row law iid for i=1,...,n. Return X1,X2,Y only. Within-row X1/X2 covariance=-5/12; Y depends on their sum. No treatment/mediator, assignment, label selection, missingness, censoring, measurement error, predictor training, cluster, panel or interference mechanism. | Figure 1 full synthetic observations, p.1110/PDF p.5 Sec.2.3 row likelihood and p.1112/PDF p.7 Sec.4 independent stochastic design. No unobserved labels or latent columns are exposed. |

在理想随机生成律中，各行 `(R_i,T_i,Z_i)` 相互独立；实际用局部 `random.Random(seed)` 作可重现伪随机实现。R/T、反射后的u/v、s、a/b、Z/U及条件均值/方差均为内部量，只返回X1/X2/Y。

两个正态分位项对应潜在量 `L0=Z`、`L1=1+0.2Z`，相关系数1；故标准差是 `a+0.2b`，不是独立误差相加的 `sqrt(a²+0.04b²)`。两权重虽和为1，并不表示以权重随机选择混合成分。

边界规则：D是闭三角形，三条边/顶点都属于支持的闭包；边界面积概率为0，无额外边界点质量。反射仅在u+v>1时发生，等号保留；不会裁剪/重抽X或Y。有限伪随机数可能落在可表示边界，代码保留它们。Y条件支持为整个R；不做尾部截断或winsorize。目标tau限定(0,1)，不返回端点无限分位数；当前固定19/20。生成器精确分数校验查询三边；验证观察样本允许1e-14浮点误差，此阈值不是改变支持。

处理分配、中介、观测/标注指示、缺失值占位、删失、预测器来源/样本划分均不适用于此完整观察的非因果QDI任务。概念上观察概率为1，不另生成一个全1指示列，也不添加不必要的因果假设。

由原方程还可推得 `beta0(tau)=2/3+(7/15)Phi^-1(tau)`，`beta1(tau)=beta2(tau)=1/3-(4/15)Phi^-1(tau)`；联合密度为 `(2/3)1_D(x)phi((y-mu(x))/sigma(x))/sigma(x)`。这些是方程推导，未增加参数。

## 正式版生成机制与观察输出


```text
A=(-1,1), B=(-1,2), C=(2,-1)
D=conv{A,B,C}
 ={ -1<=x1<=2, (1-2*x1)/3<=x2<=1-x1 }
X ~ Uniform(D)
s=x1+x2
a=(1-s)/3, b=(2+s)/3
Q_Y(tau|x)=a Q_N(tau|0,1)+b Q_N(tau|1,0.2^2)
          =(2+s)/3+(7-4s)/15 * Phi^(-1)(tau)
Z~N(0,1), independent of X
Y=a Z+b(1+0.2 Z)
 =(2+X1+X2)/3+(7-4(X1+X2))/15 * Z
```

两个正态分位函数使用同一个 rank；不是正态混合抽样，也不是两个独立 Gaussian draws 的加权和。每行 sampling unit 为完整观察向量 `(X1,X2,Y)`；行间 iid，同行 X1/X2 相关。输出只含这三个有限数值列表，无 Z/U、oracle mean/variance、真值或个体效应列。无缺失、删失、预测器训练、网络、面板或干扰结构。

对 X 的实现：独立取 `R,T~Uniform(0,1)`，若 `R+T>1` 则设 `(u,v)=(1-R,1-T)`，否则 `(u,v)=(R,T)`。映射

```text
X=A+u(B-A)+v(C-A)=(-1+3v, 1+u-2v).
```

这是自行实现的等价采样算法，不称为原作者算法。单位三角形的密度为 2；仿射映射绝对行列式为 3，所以新域面积 `3/2`、密度 `2/3`。局部 `random.Random(seed)` 不改变全局 RNG 或 config。

新域完整三边条件为 `x1>=-1`、`2*x1+3*x2>=1`、`x1+x2<=1`。仅检查坐标范围或总和上界不足以检验本域。`schema.csv` 保留单列范围，联合约束由生成器的查询校验及 verifier 检验。

三角形均匀分布的 barycentric 权重服从 Dirichlet(1,1,1)。对三个顶点向量 `v_i`，可得 `E[X]=sum(v_i)/3`，`E[Xj Xk]=[(sum v_ij)(sum v_ik)+sum v_ij v_ik]/12`，故

```text
E[X1]=0; E[X2]=2/3
E[X1^2]=1/2; E[X2^2]=5/6; E[X1 X2]=-5/12
Var(X1)=1/2; Var(X2)=7/18; Cov(X1,X2)=-5/12.
```

这些是从正式三角形推得的诊断量。各坐标边际不是均匀分布。

## 固定 QDI 目标、假设与推导

```text
x*=(0,2/3), tau*=19/20
s*=2/3, a*=1/9, b*=8/9
mu(x*)=8/9, sigma(x*)=13/45
Y|X=x* ~ N(8/9,(13/45)^2)
theta=inf{y:F_Y(y|X=x*)>=19/20}
     =8/9+(13/45)*Phi^(-1)(19/20)
     ≈1.3640688255637583.
```

这是条件分位数的点态标量目标，不是边际分位数、整条分位曲面或同时置信带。`query_x` 中的数字方便接口读取，`query_x_exact=["0","2/3"]` 与 `quantile_level_exact="19/20"` 是精确定义。代码校验二者相符，以 Fraction/Decimal 保留精确查询；这并未改变观察表只能含有限数值的约定。

适用的抽样／观测／正则性条件如下：

1. 行间 iid，所有 X 和 Y 完整可见；没有另加缺失或测量机制。Z 与 X 独立，用共享秩实现给定条件 law。
2. 重心严格内部：三个半平面松弛量依次为 `1,1,1/3`；邻域密度 `f_X=2/3>0`。因连续 X 恰等于 x* 的概率为零，查询采用正式方程规定的、关于 x 连续的条件分布版本；不能在任意修改零概率点的条件版本下声称同一目标。
3. s 在凸域上为仿射函数，在三顶点取值 0、1、1，故整个域 `s∈[0,1]`，`sigma∈[1/5,7/15]`。因此 `dQ/dtau=sigma/phi(Phi^-1(tau))>0`，条件 CDF 连续严格递增、目标唯一，目标密度 `phi(Phi^-1(19/20))/(13/45)>0`。尾部为高斯，未添加重尾噪声。
4. 原坐标 `(0,0)` 不在 D，因为 `2*x1+3*x2<1`。若使用 §2.1 的参数化理论，可在说明时令 `X'=X-(0,2/3)`，并同步调整截距；**本包不对观察列执行此平移**，也不声称原点在域内。
5. 非因果推断，不套用干预、无混杂、处理正值性或中介跨世界条件。

矩形外延仍可能交叉：形式代入 `(2,2)` 得 `sigma=-0.6`；该点不属于 D。这里的全域非交叉证明是 law 有效性证明，不是任何区间／置信带覆盖率验证。

## 真值与既有核验

`truth.py` 由精确分数查询推出 mu、sigma，再调用标准库 `NormalDist.inv_cdf`。`estimated_error` 包含 CDF 回代残差、tau 转为 binary64 的误差除以密度，以及 32 ulps 的舍入诊断。**容差沿用 `1e-12`，运行前固定，不放宽。** 误差估计不是严格统一误差界。

`verify.py` 用不同的数值路线：Decimal Machin 公式计算 pi，对 `exp(-t^2/2)` 的幂级数积分得到 CDF，直接在响应尺度以150步二分反演，比较60/80位精度。它不调用主程序的 inverse CDF、erf 或 erfc；半区间只是数值诊断，未采用认证区间算术。

前次已采纳的正式版修订对旧几何依赖检查作了如下替换；本轮全部保留：

| 检查范围 | 正式版修订后的检查及理由 |
|---|---|
| 参数来源 | 固定检查 Figure 1 三顶点、n=1000、正态标准差及 adaptation 查询，防止旧参数残留。 |
| 三角形几何 | 从顶点行列式及精确 barycentric 矩公式重算面积、均值、二阶矩。旧域的矩不适用，不能继续作为 fixture。 |
| 支持与查询 | 接受三个顶点和三边中点；分别构造违反三边的点；明确拒绝旧原点；验证重心严格内部。 |
| 解析特例 | A 点为 `N(2/3,(7/15)^2)`；B、C及整条 BC 边为 `N(1,0.04)`；重心中位数 `8/9`，`.05/.95` 分位数和 `16/9`。旧机制域外特例不再适用。 |
| 实际生成器 | 用预先指定的 RNG 返回值驱动实际 `generate`，核对反射两分支、三个顶点及重心映射、每行恰一个 Gaussian rank。 |
| 数据 law | 另用 seed=314159 的2048行瞬时样本检查全部三边、有限观察列、均匀三角形矩及独立标准化高斯残差。数据不保留为银行。 |
| 阈值 | 五项有界矩采用预先规定的 Hoeffding 联合 alpha=1e-6；高斯矩采用6-SE诊断，其中 XZ 阈值按正式版 E[Xj²] 计算。没有事后调宽或删除失败检查。 |

这些替换来自用户授权的来源／机制修订，不是删除失败场景获取 PASS。只声明一个场景 `published_triangle_centroid`；内部特殊查询只是同一 law 的测试，不另计贡献或场景。

共享部分：同一论文方程、配置、Python 运行时及 AI 作者；generator/truth 共用配置校验；解析特例调用被检验 truth。Decimal 路线实现独立，但不是另一人独立复现。实际运行与逐项证据只能以新生成的 `checks/report.json` 为准，不复制旧 PASS 报告。

## 维数、交互和非线性标签

输入协变量总数2、活跃原始列数2，故 `dimension=2,effective_dimension=2`。条件 law 仅依赖单指标 `s=X1+X2`，内在指标维数是1，不能宣称两个独立有效方向。相对原图 n=1000 或检查 n=128 都非高维。

条件分位数为关于 X 的仿射函数，没有 X1*X2 项，故 `interactions=false,nonlinear=false` 指预测量的条件分位数／均值曲面。`Phi^-1(tau)` 对 tau 非线性，条件方差为 `((7-4s)/15)^2`，这是异方差性质；不将其冒充非线性预测量分位曲面或高维混杂。


## 代码来源与精确定位

本包独立实现保持不变：`generator.py:validate` 第16–54行、`generate` 第57–80行；`truth.py:truth` 第8–32行；`verify.py:_atan_inverse` 第24–36行、`_decimal_phi` 第39–50行、`_independent_quantile` 第58–75行、`verify` 第87–205行。当前本地文件以SHA256固定，非声称上游Git commit；完整函数范围与哈希见 `source_records.json.code_locators`。`requirements.txt`明确Python>=3.10且仅标准库；没有运行或打包R、作者软件或外部代码。

亲自核读共享的CRAN源码和手册，关闭旧包“CRAN源码archive未取得”记录。证据为 [qrjoint 2.1-0源码](https://cran.r-project.org/src/contrib/qrjoint_2.1-0.tar.gz)，SHA256 `8c0139e8523fe7a31bbeed469eda22184f79fb73e46ac57e0a791815fb1eb14e`，以及 [CRAN手册](https://cran.r-project.org/web/packages/qrjoint/qrjoint.pdf)，SHA256 `f93f3f4ac8327d2e7f0003ad2d842f51c23722fa3cbe2e6b874cfba94b2cd33f`。手册共25页，p.1声明2.1-0、2026-09-10、GPL-2；p.2为chull.center，pp.14–18为qrjoint。它们是本轮取得的2026软件证据，不宣称是论文2017实验代码或实时永恒最新版。

对tar全部35个普通文件计算Git blob SHA1，全部匹配 [CRAN镜像固定commit 002edfa33343520699a0c47a6c4ba291aff5d112](https://github.com/cran/qrjoint/tree/002edfa33343520699a0c47a6c4ba291aff5d112)（2026-09-11）；又重建5个目录树，根树 `76448ae7bbfc14f77b02c92e9ab91ba645deeea3` 匹配commit记录。31个共享目录中已解压文件也逐字节匹配；其他成员直接读取tar核验，无需解包/运行。只对源码文本作检索，未反序列化两个rda数据文件；不将任何上游源码/数据放入贡献包。

| 仓库与固定commit | 文件及函数/行号 | 用途与边界 |
|---|---|---|
| cran/qrjoint `002edfa33343520699a0c47a6c4ba291aff5d112` | DESCRIPTION 第1–4、14–20、26–27行 | 原始元数据字节：版本2.1-0、GPL-2、R/C++依赖；不是本Python包依赖 |
| 同上 | R/qrjoint.R，qrjoint 第3–363行，亲读入口3–30行及初始化片段 | 估计器；高斯抽样为先验初始化，非Figure1生成器 |
| 同上 | R/qrjoint.R，chull.center 第1081–1117行 | 估计前中心化；1094行是绘图jitter，不能添加到本DGP |
| 同上 | man/chull.center.Rd 第1–29行；man/qrjoint.Rd 第1–45、106–160行 | 9维B-spline例子和plasma/UIS拟合示例，非三角形模拟 |
| tokdarstat/qrjoint `45d3ba7fc68f8de7c4f2f2c988743580a2885350` | README.md 第1–12行；test.R 第1–3行 | 官方软件/DOI链；test.R仅对-4:4做qde小例子 |
| 同上 | qrjoint/DESCRIPTION 第1–12行；qrjoint.Rcheck/00_pkg_src/qrjoint/DESCRIPTION 第1–12行 | 2.0-3、GPL-2；根文件Packaged2016与Date2019不一致，Rcheck副本为2019，保留这一历史事实 |
| tokdarstat/qrjoint `3a1a63d2cbf7a34c963202516d72567c844dbc7f` | 根目录及R/man/data等17项树清单；commit日期 2016-06-28T03:13:11Z | 本任务核到目录和树哈希，不能声称全部历史文本已搜索 |

检索范围：CRAN qrjoint 2.1-0 tar全部35普通文件绑定到镜像commit 002edfa33343520699a0c47a6c4ba291aff5d112；其中33文本按triang/set.seed/qnorm/rnorm/runif/Figure1/simulat检索。作者commit45d3ba7fc68f8de7c4f2f2c988743580a2885350的23份已保留文本再核哈希并检索；另核作者2016 commit3a1a63d2cbf7a34c963202516d72567c844dbc7f的17项目录树，仅目录级，不宣称检索全部历史blob/压缩包。CRAN25页手册全文提取并关键词检索，p.1、2、14–18及抽样函数命中页亲读。 原图专用脚本、seed及精确实验commit在这些范围内仍未定位；不是断言全网不存在。未把软件接口的MCMC参数、censoring支持、中心化算法或示例数据当成本DGP参数。原作者精确随机流不属于当前公式law复现声明。

## 已解决和仍保留的事项

下表完整检索范围和证据在 `missing_items.json` 与 `source_records.json`。status=`not_found_in_searched_scope`只表示具体检查范围内未定位，不能推为“作者没有”。所有条目的“影响”专指当前已选数学机制是否缺必需参数；科研接收流程另行保留。

| 项目 | 当前状态 | 调查结论 | 影响数学机制完整性 |
|---|---|---|---|
| published_source_and_supplement | resolved | 正式版和补充材料已经取得并阅读，不是 missing。主机制明确定位 Figure1 / PDF3 / JASA1108；补充 p.1、B.1 pp.9–11。 | 否 |
| full_generation_law | resolved | 按生成顺序记录联合面积均匀、等价反射采样、共同秩、全部权重/尺度、三条边、iid 与完整观察；没有必需分布或数值参数缺口。 | 否 |
| version_and_query_selection | resolved_by_existing_user_decision | 预印本顶点(-1,-1),(-1,2),(2,-1)、n=200；正式版顶点(-1,1),(-1,2),(2,-1)、n=1000；分位方程相同。继续正式版字面law及内部重心query adaptation，不重启来源选择，不推断作者笔误或意图。 | 否 |
| cran_source_manual_description | resolved | 已取得并亲核CRAN 2.1-0源码tar、25页PDF手册和原始DESCRIPTION字节；35/35 Git blob SHA1及全部5个目录树与固定镜像commit一致。关闭旧版“源码archive未取得”限制。DESCRIPTION第1–4、14–20、26–27行和手册p.1给出版本、依赖和GPL-2。这是2026估计器软件，不是2017实验锁定源码。 | 否 |
| figure1_exact_generation_script | not_found_in_searched_scope | 上述文本/手册/目录范围未定位正式版Figure1三角形专用生成脚本。rnorm命中是先验初始化、绘图jitter、plasma及cos曲线示例；triangular命中为矩阵运算，chull.center示例为9维B-spline，均不挪用。本包方程有正式来源，使用独立等价采样算法；不声称原脚本复刻。 | 否 |
| figure1_original_seed | not_found_in_searched_scope | 未定位能够归属于Figure1的原始随机种子；1729为收集检查seed，314159为诊断seed，不能标作作者seed。缺此项只影响相同随机流重放，不影响分布/真值定义。 | 否 |
| figure1_experiment_commit | not_found_in_searched_scope | 有固定的软件commit，但上述证据没有把任一commit指认为Figure1原始实验commit。保留区别，不把较新软件日期等同论文实验日期；不影响当前公式确定的law。 | 否 |
| remote_publisher_byte_identity | not_required_for_current_law | 这是获取渠道/字节同一性边界，不是“原文未读到”或机制参数 missing；使用所供正式版内容足以定位当前已选数学机制。 | 否 |
| scientific_acceptance_and_distribution_review | pending_workflow | AI审查、数值核验和归档PASS不授予科学接收；此流程状态不是生成律缺参，也不额外要求作者确认。 | 否 |

当前必要分布、尺度、支持、依赖、观察规则和查询没有未指定参数。没有增加作者确认门槛；原实验seed或脚本只关系同一随机流/估计图复现，不阻止本已明示law的实现。

## 改动 权利及交付边界

本轮只修订 `collection.json`、`card.md`、`source_records.json`，新增 `missing_items.json`。生成器、truth、verify、config、schema及依赖文件与已采纳包逐字节一致；容差仍1e-12、一个declared scenario，原17项核验完整保留。任何新元数据修改均完成代码复审后，以原学生工具重做静态check、全部场景check --run及pack，实际结果见新生成checks/report.json。

论文版权为ASA；上游软件许可只作为其自身来源事实，不套用给本独立实现。没有分发PDF、作者代码/数据包、敏感数据、凭据或权重；维护人的发布与科学审核流程尚未执行。AI不是具名审核人，计算路线不同不等于独立人员复现。

项目中文PDF、首次任务DOCX与2026-10-27学生指南均已审阅；附件中的外发/PR步骤不替代用户本轮“仅本地”授权。简短交付report、临时主聊天复查/版本采用状态单独保存在包外，不构成本包科学审核状态。保持同一ID/family，不双重计数；不运行PFN、MCMC、大型bootstrap/coverage，不对外提交/联系维护人。
