"""Published-triangle checks with a separate Decimal conditional-CDF solver.

Shared scientific equation and AI authorship are explicitly acknowledged.
No NormalDist or erf/erfc is used in the independent numerical route.
"""
from copy import deepcopy
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import importlib.util
import math
from pathlib import Path
import random
from unittest.mock import patch


def _load(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("published_triangle_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _atan_inverse(integer, precision):
    x = D(1) / integer
    power, total, k = x, x, 1
    cutoff = D(10) ** (-precision - 5)
    while True:
        power *= -(x * x)
        term = power / (2 * k + 1)
        total += term
        if abs(term) < cutoff:
            return total
        k += 1
        if k > 2000:
            raise ArithmeticError("Machin series did not converge")


def _decimal_phi(z, sqrt_two_pi, precision):
    # Integral from 0 to z of exp(-t^2/2), via its entire power series.
    term, total, k = z, z, 0
    cutoff = D(10) ** (-precision + 10)
    while True:
        k += 1
        term *= -z * z * (2 * k - 1) / (D(2) * k * (2 * k + 1))
        total += term
        if abs(term) < cutoff:
            return D("0.5") + total / sqrt_two_pi
        if k > 2000:
            raise ArithmeticError("Gaussian integral series did not converge")


def _decimal_rational(text):
    parts = text.split("/")
    return D(parts[0]) if len(parts) == 1 else D(parts[0])/D(parts[1])


def _independent_quantile(config, precision):
    with localcontext() as ctx:
        ctx.prec = precision
        pi = 16*_atan_inverse(5,precision)-4*_atan_inverse(239,precision)
        normalizer = (2*pi).sqrt()
        s = sum(_decimal_rational(v) for v in config["query_x_exact"])
        mu, sd = (2+s)/3, (7-4*s)/15
        tau = _decimal_rational(config["quantile_level_exact"])
        lo, hi = mu-10*sd, mu+10*sd
        if not _decimal_phi(D(-10),normalizer,precision) < tau < _decimal_phi(D(10),normalizer,precision):
            raise ValueError("Independent bracket does not contain the query")
        for _ in range(150):
            mid = (lo+hi)/2
            if _decimal_phi((mid-mu)/sd,normalizer,precision) < tau:
                lo = mid
            else:
                hi = mid
        return (lo+hi)/2, (hi-lo)/2


def _case(config, x, tau="19/20"):
    case = deepcopy(config)
    case["query_x_exact"] = [str(F(v)) for v in x]
    case["query_x"] = [float(F(v)) for v in x]
    case["quantile_level_exact"] = str(F(tau))
    case["quantile_level"] = float(F(tau))
    return case


def verify(config):
    gen, oracle = _load("generator.py"), _load("truth.py")
    checks = []
    def add(name, passed, details):
        checks.append({"name":name,"passed":bool(passed),"details":details})
    fixture = {
        "triangle_vertices":[[-1.0,1.0],[-1.0,2.0],[2.0,-1.0]],
        "normal_means":[0.0,1.0],"normal_sds":[1.0,0.2],
        "query_x":[0.0,2/3],"query_x_exact":["0","2/3"],
        "quantile_level":0.95,"quantile_level_exact":"19/20","paper_n":1000,
    }
    add("published_figure1_fixture",config == fixture,
        "JASA p.1108 Figure1: A=(-1,1), B=(-1,2), C=(2,-1), n=1000, SD2=.2; centroid/.95 is collection adaptation.")
    vertices = [tuple(F(str(v)) for v in row) for row in config["triangle_vertices"]]
    a,b,c = vertices
    det = (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    area = abs(det)/2
    mean = [sum(p[j] for p in vertices)/3 for j in range(2)]
    second = [(sum(p[j] for p in vertices)**2+sum(p[j]**2 for p in vertices))/12 for j in range(2)]
    cross = (sum(p[0] for p in vertices)*sum(p[1] for p in vertices)+sum(p[0]*p[1] for p in vertices))/12
    add("exact_triangle_geometry_and_moments",area == F(3,2) and mean == [F(0),F(2,3)]
        and second == [F(1,2),F(5,6)] and cross == F(-5,12),
        f"From vertex determinant/Dirichlet(1,1,1) moments: area={area}, density={1/area}, mean={mean}, second={second}, cross={cross}.")
    def slacks(x):
        x1,x2 = map(F,x)
        return [x1+1,2*x1+3*x2-1,1-x1-x2]
    probes = [([-1,1],True),([-1,2],True),([2,-1],True),([-1,F(3,2)],True),
              ([F(1,2),0],True),([F(1,2),F(1,2)],True),
              ([F(-11,10),F(3,2)],False),([0,F(1,5)],False),([0,F(11,10)],False),([0,0],False)]
    statuses=[]
    for x,valid in probes:
        agrees = all(v >= 0 for v in slacks(x)) == valid
        for hook in (lambda cfg:gen.generate(cfg,1,1729),oracle.truth):
            try:
                hook(_case(config,x)); accepted=True
            except ValueError:
                accepted=False
            agrees = agrees and accepted == valid
        statuses.append(agrees)
    add("three_edges_vertices_and_outside_rejection",all(statuses),
        "All vertices/three edge midpoints accepted; separate violations of each half-plane and old origin rejected by generate/truth. No replacement by enclosing rectangle.")
    centroid = [F(v) for v in config["query_x_exact"]]
    add("centroid_strictly_interior",centroid == mean and all(v>0 for v in slacks(centroid)),
        f"Exact centroid={centroid}; half-plane slacks={slacks(centroid)}. Observed X is not centered or transformed.")
    ref=oracle.truth(config)
    q60,w60=_independent_quantile(config,60)
    q80,w80=_independent_quantile(config,80)
    difference=abs(ref["value"]-float(q80))
    add("independent_conditional_cdf_inversion",difference<=1e-12,
        f"Primary={ref['value']:.17g}; Decimal80={q80}; binary64 difference={difference:.3g}.")
    add("precision_refinement",abs(q60-q80)<D("1e-35") and w80<D("1e-40"),
        f"Decimal60/80 difference={abs(q60-q80)}; half-bracket={w80}. Not certified interval arithmetic.")
    add("truth_error_diagnostic",difference<=ref["estimated_error"]<=1e-12,
        f"estimated_error={ref['estimated_error']:.3g}; unchanged predeclared tolerance=1e-12.")
    median=oracle.truth(_case(config,centroid,"1/2"))
    add("analytic_centroid_median",median["conditional_mean_exact"]=="8/9"
        and median["conditional_sd_exact"]=="13/45" and abs(median["value"]-8/9)<2e-15,
        "At centroid: mu=8/9, sigma=13/45, median=8/9 exactly.")
    z=(q80-D(8)/9)/(D(13)/45)
    special_errors=[]
    for point in [a,b,c,(F(1,2),F(1,2))]:
        expected = D(2)/3+D(7)/15*z if point==a else 1+D("0.2")*z
        special_errors.append(abs(oracle.truth(_case(config,point))["value"]-float(expected)))
    add("analytic_vertex_and_constant_sum_edge",max(special_errors)<1e-12,
        f"A gives N(2/3,(7/15)^2); B,C and BC midpoint give N(1,.04). Max difference={max(special_errors):.3g}.")
    symmetry=abs(oracle.truth(_case(config,centroid,"1/20"))["value"]+ref["value"]-16/9)
    add("centroid_quantile_symmetry",symmetry<1e-12,f"Q(.05|centroid)+Q(.95|centroid)=16/9; error={symmetry:.3g}.")
    sums=[sum(p) for p in vertices]; scales=[(7-4*s)/15 for s in sums]
    add("global_noncrossing_from_vertices",min(sums)==0 and max(sums)==1 and min(scales)==F(1,5) and max(scales)==F(7,15),
        "s affine on convex triangle -> s in [0,1]; sigma in [1/5,7/15]; dQ/dtau=sigma/phi(z_tau)>0 for all tau. No band-coverage claim.")
    add("rectangle_crossing_counterexample",(7-4*4)/15<0,
        "Formal extension at (2,2) has scale -.6 and is excluded from support.")
    scripts=[(0.,0.,-2.),(1.,0.,1.5),(0.,1.,-1.5),(1/3,1/3,0.),(.75,.75,2.),(.8,.6,-.5)]
    scripted_errors=[];gauss_counts=[]
    for u,v,z0 in scripts:
        calls=[]
        class FixedRNG:
            def __init__(self,seed):self.draws=iter([u,v])
            def random(self):return next(self.draws)
            def gauss(self,mu,sd):
                if (mu,sd)!=(0.,1.):raise AssertionError("Expected standard normal rank")
                calls.append(1);return z0
        with patch.object(gen.random,"Random",FixedRNG):
            sample=gen.generate(deepcopy(config),1,1729)
        # Independent piecewise coordinate formula for the actual sampler.
        x1=-1+3*v if u+v<=1 else 2-3*v
        x2=1+u-2*v if u+v<=1 else 2*v-u
        s=x1+x2; y=(2+s)/3+(7-4*s)/15*z0
        scripted_errors.extend(abs(sample[name][0]-target) for name,target in zip(["X1","X2","Y"],[x1,x2,y]))
        gauss_counts.append(len(calls))
    add("actual_sampler_affine_map_and_shared_rank",max(scripted_errors)<2e-14 and all(n==1 for n in gauss_counts),
        f"Both reflection branches, all vertices, centroid and one Gaussian draw per row checked; max difference={max(scripted_errors):.3g}.")
    state=random.getstate(); original=deepcopy(config)
    data=gen.generate(config,2048,314159);n=len(data["Y"])
    add("local_rng_and_no_config_mutation",state==random.getstate() and config==original,
        "Local Random(seed), no change to global random state or caller config.")
    support_ok=set(data)=={"X1","X2","Y"} and all(len(v)==n for v in data.values()) and all(
        math.isfinite(x1) and math.isfinite(x2) and math.isfinite(y)
        and x1>=-1-1e-14 and 2*x1+3*x2>=1-1e-14 and x1+x2<=1+1e-14
        for x1,x2,y in zip(data["X1"],data["X2"],data["Y"]))
    add("visible_columns_and_all_three_support_edges",support_ok,
        "X1,X2,Y only; checks all three triangle half-planes with fixed 1e-14 floating-point allowance. No latent columns.")
    sample_moments=[math.fsum(data[k])/n for k in ["X1","X2"]]
    sample_moments += [math.fsum(x*x for x in data[k])/n for k in ["X1","X2"]]
    sample_moments += [math.fsum(x*y for x,y in zip(data["X1"],data["X2"]))/n]
    targets=[0.,2/3,.5,5/6,-5/12]
    h=math.sqrt(math.log(10/1e-6)/(2*n))
    bounds=[3*h,3*h,4*h,4*h,F(9,4)*h]
    add("published_uniform_triangle_moments",all(abs(v-t)<=b for v,t,b in zip(sample_moments,targets,bounds)),
        f"2048 diagnostic rows; targets={targets}, observed={sample_moments}, Hoeffding bounds={bounds}, union alpha=1e-6 fixed before execution.")
    residuals=[(y-(2+x1+x2)/3)/((7-4*(x1+x2))/15) for x1,x2,y in zip(data["X1"],data["X2"],data["Y"])]
    zm=math.fsum(residuals)/n;z2=math.fsum(z*z for z in residuals)/n
    xz=[math.fsum(x*z for x,z in zip(data[k],residuals))/n for k in ["X1","X2"]]
    add("conditional_gaussian_residual_diagnostic",abs(zm)<6/math.sqrt(n)
        and abs(z2-1)<6*math.sqrt(2/n) and abs(xz[0])<6*math.sqrt(.5/n) and abs(xz[1])<6*math.sqrt((5/6)/n),
        f"Observed-data residual mean={zm:.5g}, second={z2:.5g}, XZ={xz}; fixed 6-SE diagnostics, not coverage/truth estimation.")
    return {"passed":all(c["passed"] for c in checks),"checks":checks,
        "independent_quantile_decimal":str(q80),"independent_half_bracket":str(w80),"absolute_truth_difference":difference,
        "shared_components":"Same published equation, config and AI author; generator/truth share validation. Decimal CDF, pi and inversion are independently implemented. Analytic cases call the truth under test. No independent-person scientific review is claimed."}
