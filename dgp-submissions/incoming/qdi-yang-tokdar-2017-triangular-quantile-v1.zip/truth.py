"""Scalar QDI target for the published Figure 1 law, with exact query metadata."""
from fractions import Fraction
from statistics import NormalDist
import math
from generator import validate


def truth(config):
    x, tau = validate(config)
    s = sum(x)
    a, b = (1-s)/3, (2+s)/3
    means = [Fraction(str(v)) for v in config["normal_means"]]
    sds = [Fraction(str(v)) for v in config["normal_sds"]]
    mu_exact, sd_exact = a*means[0] + b*means[1], a*sds[0] + b*sds[1]
    mu, sd = float(mu_exact), float(sd_exact)
    z = NormalDist().inv_cdf(float(tau))
    value = mu + sd*z
    density = math.exp(-z*z/2)/(sd*math.sqrt(2*math.pi))
    standardized = (value-mu)/sd
    residual = abs(0.5*math.erfc(-standardized/math.sqrt(2))-float(tau))
    tau_roundoff = float(abs(Fraction.from_float(float(tau))-tau))
    estimated_error = (residual + tau_roundoff)/density + 32*math.ulp(max(1.0,abs(value),abs(mu),abs(sd*z)))
    return {
        "value": value, "estimated_error": estimated_error,
        "target": "inf{y:F_Y(y|X=query_x_exact)>=quantile_level_exact}",
        "query_x": list(config["query_x"]), "query_x_exact": list(config["query_x_exact"]),
        "quantile_level": config["quantile_level"], "quantile_level_exact": config["quantile_level_exact"],
        "conditional_mean_exact": str(mu_exact), "conditional_sd_exact": str(sd_exact),
        "density_at_quantile": density, "cdf_residual": residual,
        "method": "Exact-rational query and Gaussian reduction; statistics.NormalDist.inv_cdf",
        "error_interpretation": "CDF residual and tau conversion error divided by density, plus 32 ulps; numerical diagnostic, not a certified uniform error bound. Independent Decimal conditional-CDF inversion is in verify.py.",
    }
