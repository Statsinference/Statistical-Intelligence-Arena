"""Analytic median at x=0.5, tau=.5, evaluated with Decimal.

Softplus/cubic: monotonicity; square: generalized inverse with zero atom.
Printed log: q=ln3-1/2 < ln2, so only the left branch contributes;
its preimage is (-inf,0.5], yielding F(q;0.5)=.5. No global monotonicity.
"""
# Source: official supplement C.1/Table C.1 p.2; fixed-code discrepancy is
# documented in source_record.json and does not change this printed definition.
from decimal import Decimal, localcontext
from generator import validate


def _analytic(name, precision):
    with localcontext() as ctx:
        ctx.prec = precision
        if name == "softplus":
            return (Decimal(1) + Decimal("0.5").exp()).ln()
        if name == "square":
            return Decimal(1) / Decimal(8)
        if name == "cubic":
            return Decimal(1) / Decimal(24)
        if name == "log":
            return Decimal(3).ln() - Decimal("0.5")
        raise ValueError("Unknown transform")


def truth(config):
    validate(config)
    low, high = (_analytic(config["transform"], p) for p in (60, 80))
    value = float(high)
    with localcontext() as ctx:
        ctx.prec = 90
        change = abs(high - low)
        rounding = abs(Decimal.from_float(value) - high)
        error = change + rounding + Decimal("1e-58")
    return {"value": value, "estimated_error": float(error),
            "target": "inf{y: F_s(y; x=0.5) >= 0.5}",
            "method": "Analytic median; Decimal 60/80 digits and float conversion audit",
            "high_precision_value": str(high),
            "precision_refinement_difference": float(change),
            "float_rounding_estimate": float(rounding),
            "error_interpretation": "Numerical diagnostic, not a uniform bound, statistical SE, or source-ambiguity allowance.",
            "log_interpretation": "Literal printed log(u) right branch; no author-code correction."}
