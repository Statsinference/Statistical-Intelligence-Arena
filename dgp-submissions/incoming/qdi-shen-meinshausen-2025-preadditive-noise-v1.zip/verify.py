"""Separate inverse-image CDF, Simpson integration and bisection.

CDF construction does not call generator transform or truth analytic helper.
"""
from decimal import Decimal, localcontext
import math
import random
from generator import generate, transform
from truth import truth


def normal_cdf(z, steps):
    # Gaussian symmetry; omitted tail beyond 12 SD <1.78e-33.
    # This numerical integration limit does not truncate DGP noise.
    a = min(abs(z), 12.)
    h = a / steps
    terms = []
    for i in range(steps + 1):
        v = i * h
        weight = 1 if i in (0, steps) else (4 if i % 2 else 2)
        terms.append(weight * math.exp(-v * v / 2.))
    integral = math.fsum(terms) * h / (3. * math.sqrt(2. * math.pi))
    return .5 + math.copysign(integral, z)


def cdf(name, y, x, sd, steps):
    def phi(u):
        return normal_cdf((u - x) / sd, steps)
    if name == "softplus":
        return 0. if y <= 0. else phi(math.log(math.expm1(y)))
    if name == "square":
        return 0. if y < 0. else phi(math.sqrt(2. * y))
    if name == "cubic":
        return phi(math.copysign(abs(3. * y) ** (1. / 3.), y))
    if name == "log":
        left = phi(min(2., 2. + 3. * (y - math.log(3.))))
        right = phi(math.exp(y)) - phi(2.) if y > math.log(2.) else 0.
        return left + right
    raise ValueError("Unknown transform")


def quantile(name, x, sd, steps):
    lo, hi = -32., 32.
    if not (cdf(name, lo, x, sd, steps) < .5 <= cdf(name, hi, x, sd, steps)):
        raise ArithmeticError("Quantile bracket does not enclose target")
    for _ in range(48):
        mid = (lo + hi) / 2.
        if cdf(name, mid, x, sd, steps) >= .5:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2., hi - lo


def decimal_transform(name, u):
    with localcontext() as ctx:
        ctx.prec = 60
        z = Decimal.from_float(u)
        if name == "softplus":
            v = (Decimal(1) + z.exp()).ln()
        elif name == "square":
            v = max(z, Decimal(0)) ** 2 / 2
        elif name == "cubic":
            v = z ** 3 / 3
        elif name == "log":
            v = (z - 2) / 3 + Decimal(3).ln() if z <= 2 else z.ln()
        else:
            raise ValueError("Unknown transform")
        return float(v)


def verify(config):
    name, x, sd = config["transform"], config["query_x"], config["noise_sd"]
    oracle = truth(config)
    coarse, _ = quantile(name, x, sd, 4096)
    fine, width = quantile(name, x, sd, 8192)
    residual = abs(cdf(name, oracle["value"], x, sd, 8192) - .5)
    fixtures = {"softplus": (-2, 2, 1, 50000), "square": (0, 2, 1, 50000),
                "cubic": (-2, 2, 1.1, 100000), "log": (0, 2, 1, 100000)}
    actual = tuple(config[k] for k in ("x_lower", "x_upper", "noise_sd", "source_training_n"))
    anchors = [-4., -1., 0., 2., 2.000001, 2.5, 3., 6.]
    anchor_error = max(abs(transform(name, u) - decimal_transform(name, u)) for u in anchors)
    before = random.getstate()
    sample = generate(config, 128, 1729)
    state_unchanged = before == random.getstate()
    replay_rng = random.Random(1729)
    expected_x, expected_y = [], []
    for _ in range(128):
        xx = replay_rng.uniform(config["x_lower"], config["x_upper"])
        ee = replay_rng.gauss(0., sd)
        expected_x.append(xx)
        expected_y.append(decimal_transform(name, xx + ee))
    sample_error = max(abs(a-b) for a, b in zip(sample["Y"], expected_y))
    special_x = 4. if name == "log" else 0.
    expected = {"softplus": math.log(2.), "square": 0., "cubic": 0., "log": math.log(4.)}[name]
    special, _ = quantile(name, special_x, sd, 8192)
    checks = [
        {"name": "interior_query_and_fixed_tau", "passed": config["x_lower"] < x < config["x_upper"] and x == .5 and config["tau"] == .5,
         "details": {"query_x": x, "tau": config["tau"], "support": [config["x_lower"],config["x_upper"]]}},
        {"name": "printed_table_parameters", "passed": actual == fixtures[name] and config["tau"] == .5 and x == .5 and config["source_variant"] == "literal_printed_table",
         "details": "Official supplement Table C.1 distributions; H.1 source n; fixed query is an adaptation."},
        {"name": "independent_CDF_quantile", "passed": abs(fine-oracle["value"]) < 1e-10,
         "details": {"cdf_root": fine, "analytic": oracle["value"], "difference": abs(fine-oracle["value"]), "root_bracket_width": width}},
        {"name": "numerical_refinement_and_CDF_residual", "passed": abs(fine-coarse) < 1e-11 and residual < 1e-11 and oracle["estimated_error"] < 1e-12,
         "details": {"Simpson4096_8192_quantile_change": abs(fine-coarse), "CDF_residual": residual, "truth_error": oracle["estimated_error"]}},
        {"name": "analytic_special_case", "passed": abs(special-expected) < 1e-10,
         "details": {"query_x": special_x, "median": expected, "CDF_root": special,
                     "reason": "Symmetry for softplus/cubic; zero atom for square x=0; for log x=4, ln4 is above both overlap thresholds."}},
        {"name": "generator_decimal_anchors", "passed": anchor_error < 1e-12,
         "details": {"u_values": anchors, "max_absolute_difference": anchor_error}},
        {"name": "generator_preadditive_reconstruction", "passed": sample["X"] == expected_x and sample_error < 1e-12,
         "details": {"n": 128, "seed": 1729, "max_y_difference": sample_error,
                     "limitation": "Shares random.Random and draw order; uses separate Decimal response transforms."}},
        {"name": "observed_only_support_and_local_RNG", "passed": set(sample) == {"X", "Y"} and state_unchanged and all(config["x_lower"] <= v <= config["x_upper"] for v in sample["X"]),
         "details": "Only X,Y; original scenario-specific X support; global RNG state unchanged."}
    ]
    if name == "square":
        atom = cdf(name, 0., x, sd, 8192)
        expected_atom = .5 * math.erfc(x / (sd * math.sqrt(2)))
        checks.append({"name": "square_atom_at_active_query", "passed": abs(atom-expected_atom) < 1e-12 and 0 < atom < .5 and oracle["value"] > 0,
                       "details": {"query_x":x, "mass_at_zero":atom, "erfc_reference":expected_atom, "median_in_continuous_part":True}})
        checks.append({"name": "square_atom_generalized_inverse", "passed": cdf(name,-1e-9,0,sd,8192) == 0. and abs(cdf(name,0,0,sd,8192)-.5) < 1e-12,
                       "details": "At x=0, P(Y=0)=.5; no unrectified-square substitution."})
    if name == "log":
        q, h = oracle["value"], 1e-5
        left_density = (cdf(name,q,x,sd,8192)-cdf(name,q-h,x,sd,8192))/h
        right_density = (cdf(name,q+h,x,sd,8192)-cdf(name,q,x,sd,8192))/h
        expected_density = 3/(sd*math.sqrt(2*math.pi))
        left_only_cdf = normal_cdf((2+3*(q-math.log(3))-x)/sd,8192)
        checks.append({"name":"log_local_CDF_regular_at_active_query", "passed": q+h < math.log(2) and abs(left_only_cdf-.5) < 1e-11 and abs(left_density-expected_density) < 1e-8 and abs(right_density-expected_density) < 1e-8,
                       "details":{"query_x":x,"median":q,"log2_threshold":math.log(2),"left_branch_CDF":left_only_cdf,"left_density_difference_quotient":left_density,"right_density_difference_quotient":right_density,"analytic_local_density":expected_density,"step":h}})
        at_two = cdf(name, math.log(3.), 2., sd, 8192)
        checks.append({"name": "log_nonmonotonicity_explicit", "passed": transform(name,2.) > transform(name,2.000001) and abs(at_two-normal_cdf(1.,8192)) < 1e-12 and at_two > .8,
                       "details": {"F_log3_at_x2": at_two, "reason": "g(2)=ln3 is not the median at x=2; the selected interior query result cannot be generalized by monotonicity."}})
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "shared_components": "Same source reconstruction/config/runtime. Truth shares config validation with generator. CDF/integration/root code does not call generator transform or truth analytic helper. One AI author, not independent-person reproduction.",
            "normal_integration_tail_bound": math.erfc(12/math.sqrt(2))/2,
            "limitations": "Fixed scalar checks only; no CI, coverage, simultaneous bands, or scientific acceptance."}
