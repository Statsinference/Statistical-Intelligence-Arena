# 本地复现与来源边界

使用学生包的独立收集器，保留贡献目录内的全部文件。若从ZIP解压，将其根内容放到仓库 `contributions/qdi-shen-meinshausen-2025-preadditive-noise-v1/`。先阅读 `generator.py`、`truth.py`、`verify.py`，再在含 `collect.py` 的仓库根目录运行：

```sh
python collect.py check contributions/qdi-shen-meinshausen-2025-preadditive-noise-v1
python collect.py check contributions/qdi-shen-meinshausen-2025-preadditive-noise-v1 --run --n 128 --seed 1729
python collect.py pack contributions/qdi-shen-meinshausen-2025-preadditive-noise-v1 --out submissions/qdi-shen-meinshausen-2025-preadditive-noise-v1-fixed-source-completion-20261101.zip
```

不传 `--scenario` 即检查全部四场景。不要覆盖历史ZIP；若同名结果已存在，使用新的输出文件名。代码执行不是沙箱。贡献运行只用Python标准库；本包不安装或运行作者的PyTorch代码、不下载PDF或数据，也不执行训练。`init` 在最初创建阶段已执行，本次是既有贡献修订，不重复初始化。

活动目标固定 `x=0.5,tau=0.5`，ID和family保持不变。源参数来自正式补充Table C.1；一般模拟器默认参数不可覆盖它们。Log继续使用印刷版右支 `ln(u)`，不是固定作者快照中的 `ln(1+u)`。`source_record.json` 给出正式PDF、补充PDF、固定归档及被读文件的SHA-256、定位、已知示例seed=0与原实验seed未知的区别。

本轮仅更新来源记录与说明；数学实现、配置、schema和核验容差与紧邻内部点修订版相同。实际环境、真值精度、各检查结果见 `checks/report.json`；样本摘录只含观察X/Y，见 `checks/sample.json`。不同Python/libm环境可能有最后一位舍入差异，历史样本哈希只在同环境包外比较，不作为跨平台科学结论。

PASS不表示区间coverage、同时置信带、原论文训练复现、独立人员复现或科学接收。状态保持 `awaiting_scientific_review`；由维护人核原文、安排独立复现并决定接收。最终文件夹落位与外部提交未执行。
