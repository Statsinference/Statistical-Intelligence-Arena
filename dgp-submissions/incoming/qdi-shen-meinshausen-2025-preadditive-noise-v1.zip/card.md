# Engression：正式补充表格的四场景与内部点条件中位数

修订：2026-11-01。状态：**awaiting_scientific_review**；`scientific_acceptance=false`。
类型 `synthetic_dgp`，family `quantile_distribution`。一项 contribution、一个 mechanism family、四个 scenario。当前唯一活动目标是 **query_x=0.5、tau=0.5**。本轮不训练、不评估覆盖率、不发送外部服务。

贡献 ID：`qdi-shen-meinshausen-2025-preadditive-noise-v1`。
机制族 ID：`shen-meinshausen-engression-preadditive-noise`。

## Source and reconstruction / 来源、认领与本轮选择

Shen, Xinwei and Meinshausen, Nicolai (2025). *Engression: extrapolation through the lens of distributional regression*. Journal of the Royal Statistical Society Series B: Statistical Methodology, **87(3):653–677**. [DOI](https://doi.org/10.1093/jrsssb/qkae108)。期刊卷期为2025年7月；正式首页注明 advance access 2024-11-26，二者不是矛盾的出版年。

**主来源为正式发表版及其官方补充材料。** 本轮亲读用户新增的25页正式PDF：抽取文本并目视核对PDF第1、3、4、10、11、19页，分别覆盖题名、出版与许可、式(2)、§2.1式(4)、§3.2独立性及定理条件、§6模拟实验定位。同时亲读官方补充PDF第2、29页，并只读检查固定commit归档的模拟器、LICENSE、README和示例notebook。原正式PDF二进制及固定代码内容访问缺口已解决；不声称目视审阅了论文全部页面。

认领说明：拟收集官方补充 C.1/Table C.1 的预加性噪声机制，四场景 Softplus/Square/Cubic/Log，主要目标为支持内部 x=0.5 的条件中位数。本次未联系维护人，也未完成维护人侧认领查重。

| 核对项 | 精确定位与实际采用内容 |
|---|---|
| 正式主文机制 | §2.1 式(4)，期刊 p.656；正文自身PDF p.4：`Y=g(WX+η)+βᵀX`。正文式(2)，期刊 p.655（正文PDF p.3）为 `Y=g(X+η)`，也是本次仿真特例。 |
| 模拟实验位置 | 正式主文 §6，期刊 p.671（正文PDF p.19），将模拟结果指向在线补充 Appendix C.1；不能把arXiv §6.1/Table1 p.21写成正式主文位置。 |
| 页码口径与正式PDF | 新增正式PDF共25页、无封面，文件PDF p.1=期刊p.653；期刊页号=PDF页号+652。SHA-256：`c1174a83aff50f8b71b5f9f98c85c6294d793247131a664089cd30ad60ff44e3`。不再以旧ETH带封面副本推测文件页序。 |
| 官方补充 | 用户提供 `qkae108_supplementary_data.pdf`，33页；C.1/Table C.1 PDF p.2，H.1 PDF p.29。其SHA-256为 `e9e54ad7e0051e011bf22d5b92b8b0337c7a708111ad95318d3f05ca3f5155a2`。 |
| Softplus | Table C.1 p.2：`g(u)=ln(1+exp(u))`；`X~Unif[-2,2]`；`η~N(0,1)`，SD=1。 |
| Square | 同表：`g(u)=max(u,0)^2/2`；`X~Unif[0,2]`；`η~N(0,1)`。正部定义也见正式主文§1.2期刊p.656。不是普通平方。 |
| Cubic | 同表：`g(u)=u^3/3`；`X~Unif[-2,2]`；`η~N(0,1.1^2)`，SD=1.1、方差1.21。 |
| Log | 同表：u≤2 时 `(u−2)/3+ln3`，u>2 时 `ln(u)`；`X~Unif[0,2]`；`η~N(0,1)`。严格保留表格字面公式。 |
| 独立性 | 正式主文§3.2，期刊pp.662–663，声明η独立于X并归一化为零中位数；本仿真按独立行实现。各行内先抽X和独立η，再算Y。 |
| 生成式特例 | 补充C.1明确引用主文式(2)，因此收集 `Y=g_s(X+η)`，与一般式(4)的d=k=1、W=1、β=0一致；没有额外响应噪声。 |
| 原训练规模 | H.1 p.29：Softplus/Square各50k，Cubic/Log各100k；1/3层网络、每层100神经元、Adam学习率0.05、10k训练迭代。C.1描述20次重复。本包只保留来源n，不训练。 |
| 原文研究目标 | C.1研究条件中位数、均值及分布外推函数；本轮改为一个内部固定点的中位数。`x=0.5, τ=0.5` 是用户授权的scalar adaptation，不是原论文指定值。 |
| arXiv比较版本 | `2307.00835v3`（2024-07-05），§2.1/(4) p.5、§6.1/Table1 p.21、E.1 p.55；前轮已读，仅作版本对照。四行表格与官方补充一致。 |
| 官方代码固定引用 | [固定模拟器](https://github.com/xwshen51/engression/blob/eb6b83b1613458b5b3547e4e44a81da4712ab581/engression-python/engression/data/simulator.py#L6-L57)；commit `eb6b83b1613458b5b3547e4e44a81da4712ab581`。实际归档文件 `engression-python/engression/data/simulator.py`，1基行6–57；变换22–30、Log30、噪声35–40、训练生成42–46、评估48–57。前轮main网页行号不再作为当前定位。 |
| 固定归档与校验 | [固定ZIP](https://github.com/xwshen51/engression/archive/eb6b83b1613458b5b3547e4e44a81da4712ab581.zip) SHA-256 `100260a2055997501bebcb7572790771cb9a2440e16a57809fa33f94550de798`；ZIP comment为该SHA，67成员/57文件，CRC全部通过。去除顶层目录后与用户提供main归档的57文件逐字节一致；main仅作对照。模拟器文件SHA-256 `747b9e36373891bea200d1f60c6c9d984f7d99a4563394179e73ad797b7b4047`。 |
| 参数来源边界 | 固定模拟器默认n=10000、X[0,2]、SD=1，不代表四行论文设置。本包保持Table C.1的Softplus/Cubic X[-2,2]及Cubic SD=1.1。评估代码均值用10000抽样，补充C.1文字用100000；不主张完整实验一致。 |
| 已知示例seed | `engression-python/examples/example_simu.ipynb`，0基cell0内第6行 `torch.manual_seed(0)`；cell3是Square训练n=10000、X[0,2]、SD=1和评估n=1000、X[0,4]。明确记录seed=0，但不能外推为原论文四场景实验seed。 |
| 原实验commit/seed：unknown | 已逐文件搜索36个代码/Markdown/notebook文件中的seed、random_state及模拟器调用，保留包外审计。README第71、73、102行含GEM、arXiv:2610.01823及v1.1.0内容；该快照不能被认定为原2024/2025实验版本。原实验绑定仍需当时脚本/归档或作者确认。 |

完整实际访问范围、失败路径、已读许可及版本区别在 `source_record.json`。原始PDF和作者软件不随贡献ZIP分发。

### 已决定的Log来源选择与仍存的冲突

用户已明确选择**官方补充Table C.1的字面公式**；此选择不再等待用户决策。表格在u=2的值为ln3、右极限为ln2，存在向下跳跃，故全局不单调。固定commit `eb6b83b1613458b5b3547e4e44a81da4712ab581` 的模拟器第30行右支为ln(1+u)，与左支连续且一阶导数连续。这是机制差异，不是浮点误差。

补充C.1文字将中位数函数写成g(x)，但该说法不能普遍适用于字面Log：在x=2，`F(g(2);2)=Φ(1)≈0.841344746`，不是0.5。此反例保留为诊断。我们不声称作者已确认排版错误、勘误已证实或原训练实验已复现。

本次新查询处，两种Log右支不参与中位数阈值下的事件，因此其标量中位数恰好相同；这不消除它们在其余分布部分的差异。包中只实现字面表格的一个Log场景，不把代码版暗中混入或另算第五个family。

## Target and identification / 目标、观测与正则性

对场景s定义

`F_s(y;x)=Pη{g_s(x+η)≤y}`，`q_s=inf{y:F_s(y;0.5)≥0.5}`。

query_x=0.5严格位于两类原始X支持内部，设计密度分别为1/4或1/2。原X分布保持不变。条件核在查询附近关于x连续；将点值用于统计推断仍需相应局部平滑、正设计密度和方法条件，而非只依赖任意版本的条件概率。此目标不再涉及支持外的非参数识别缺口。

抽样单位为完整观察行 `(X_i,Y_i)`；行间iid，η_i独立于X_i。没有缺失、选择、标签机制或辅助预测器，不需要因果交换性或干预假设。只输出X、Y；η与真值不作为模型输入。`n`是观察训练行数，`source_training_n`仅记录原实验规模。

Gaussian总体不截断。Table C.1表注ηmax约2是有限样本讨论，不能用作总体支持上界或裁剪规则。积分器的数值积分区间也不改变生成噪声。

Square含零点原子，当前查询其质量为 `Φ(−0.5)=0.30853753872598694<0.5`；中位数1/8在连续部分。Softplus、Square、Cubic在所选中位数处的密度分别为 `φ(0)/sigmoid(0.5)`、`φ(0)/0.5`、`φ(0)/(1.1×0.5²)`，均有限且为正。尽管正式主文一般记号有绝对连续的常规假定，仍须如实保留表格Square机制的原子，不能以该常规假定删除或平滑它。

Log的所选中位数 `ln3−1/2<ln2`，在其邻域只有左线性分支贡献，CDF光滑且密度 `3φ(0)>0`。旧目标的CDF不可微问题不属于新目标。局部规则不等于全局单调：Square的平坦区、Log的跳跃仍使它们不能直接套用正式主文Theorem1的全局严格单调/二次可微假设；本包不主张四场景已获外推定理保证，也不主张已验证任何估计器的区间覆盖。

`schema.csv`的X范围是四场景公共包络[-2,2]；config和verify另检查各自的实际支持。Y未设共同界，Cubic/Log可为负；Square非负且有零原子、Softplus为正。总协变量维数1、有效维数1、观察列2；high_dimensional=false、interactions=false、nonlinear=true。非线性来源就是表中四个函数；潜噪声与X的多项式乘积不是多个观察协变量之间的交互，网络内部100维噪声也不是DGP输入维数。

## Truth and independent verification / 推导与核验

令Φ、φ为标准正态CDF和密度，σ为场景噪声SD。完整CDF（不仅查询处的局部公式）：

| 场景 | 条件CDF | 当前精确真值 |
|---|---|---|
| Softplus | y≤0时0；y>0时 `Φ((ln(expm1(y))−x)/σ)` | `ln(1+exp(0.5))` ≈0.974076984180106681 |
| Square | y<0时0；y≥0时 `Φ((sqrt(2y)−x)/σ)`，包含零原子 | `1/8` =0.125 |
| Cubic | `Φ((cbrt(3y)−x)/σ)`，带符号实根 | `1/24` ≈0.041666666666666667 |
| Log | 下述两分支原像概率之和 | `ln3−1/2` ≈0.598612288668109691 |

Log令a=ln3，

`F(y;x)=Φ((min{2,2+3(y−a)}−x)/σ)+1{y>ln2}[Φ((exp(y)−x)/σ)−Φ((2−x)/σ)]`。

当前q=a−1/2<ln2，所以右支空集，左支原像 `u≤2+3(q−a)=0.5`，从而 `F(q;0.5)=Φ(0)=0.5`；邻域严格增长，故q为唯一中位数。该推导不假设g全局单调，也不将“q=g(x)”一般化。

`truth.py`直接计算解析式，不依赖随机样本。Decimal精度60与80位的差、float转换误差及1e-58保护量构成 `estimated_error`。Square可精确二进制表示；Cubic的1/24不可以，转换误差明确记录。该数值是计算诊断，不是统计标准误、全参数统一误差定理或对来源冲突的不确定性处理。

`verify.py`独立实现完整分段原像CDF，以Gaussian密度Simpson4096/8192分段积分、48轮二分求根；区间[-32,32]最终宽约2.27e-13。积分利用对称性并在12个标准差处截断，单尾遗漏约1.78e-33，仅适用于积分精度审计。解析值对CDF根的阈值仍为1e-10，网格根变化和CDF残差阈值1e-11，truth误差阈值1e-12；未放宽旧容差。

核验还包括：

- 四场景查询均严格在各自X支持内部；活动query/tau断言一致。
- Square在当前查询的零原子质量与独立`erfc`路线比较，并保留x=0原子恰为0.5的特例。
- Log查询附近完整CDF左右差商与解析密度3φ(0)比较；另检查u=2的全局下降跳跃及x=2反例。
- Softplus/Cubic在x=0的可解析中位数；Log在x=4的解析特例只作诊断，非活动目标或新增scenario。
- 分支端点与负值等函数锚点对独立Decimal变换；128行确定性重建检验预加性位置和噪声尺度。
- 本轮包外审计比较三个入口文件的完整AST、配置及schema与紧邻内部点修订版一致，并比较同环境同seed完整表哈希，以检查来源补全没有改变生成机制或真值计算。此历史哈希不作为跨平台运行verify的硬条件（不同libm/Python环境可能有最后位差异）；包内预加性重建检查保留。收集器另检同seed复现、不同seed变化、观察列/长度/有限值，验证器检查全局RNG状态不变。

独立性边界：truth与generator共享参数校验；CDF积分/求根不调用生成器变换或truth解析内部函数。但它们共享同一来源重建、配置与Python环境；样本重建还共享Random算法及抽样顺序。它们是不同算法路线的AI自核验，不是另一位研究者独立复现。点态数值检查不是同时置信带验证。

## Adaptation and revision history / 改动与历史

四场景的g、X分布、噪声独立性、均值0、标准差、W=1、β=0以及生成顺序不变。当前适配为内部固定标量中位数、调用者控制n和小样本CPU核验、局部标准库随机流及解析真值计算；不复现源论文的神经网络训练和函数外推比较。

历史包的query_x=3已退役，不是本包活动目标。原ZIP的SHA-256 `a83969721f2209fee6309998b0ee6a67d8ea112212071144e58fe8ade1b94e56` 保留不覆盖；紧邻内部点修订ZIP的SHA-256 `8ce065547d5455fd52dc7847a2c7f401f4a18bb5bf4994118ee85eb55f3db993` 也保留。本轮仅补来源与文档，以带 `fixed-source-completion-20261101` 的新文件名打包。ID和机制族不变，不能重复计算为新family。

## Rights, assistance and outstanding issues / 权利与状态

正式主文PDF第1页实际声明 **CC BY 4.0**；[固定快照LICENSE](https://github.com/xwshen51/engression/blob/eb6b83b1613458b5b3547e4e44a81da4712ab581/LICENSE)实际声明 **BSD-3-Clause**，版权2023 Xinwei Shen和Nicolai Meinshausen。LICENSE文件SHA-256 `09677c922161ecfdf9fdfaee80e3d7df46242bd9782fe324f6598fcf8b361190`。本包独立实现数学定义并注明来源，没有再分发PDF、作者软件或源数据；不代用户授予其贡献新的许可。

已解决：内部查询选择、四场景目标与正则性推导、正式主文关键页码及PDF二进制哈希、官方补充参数核对、当前引用代码固定快照/行号/许可核对，以及用户采用字面Log的决策。此前固定版本网络读取失败保存在 `source_record.json` 的历史记录中，现已由本地新增文件解决，不再列为当前阻塞。

仍需区分三类事项：

- **科学来源冲突**：字面Log与固定代码不一致；补充文字的普遍median=g(x)主张不适用于字面Log。保留用户选定的机制，但没有作者勘误确认。
- **历史实验信息**：原论文实验commit/seed尚未确认；示例seed=0已知。当前可追溯固定快照不自动成为原实验版本。
- **科学接收**：具名审核、另一位研究者独立复现、维护人认领查重与接收尚未完成。机器PASS只支持格式和小样本运行核验。

因此，本包可以称为**已补齐当前引用来源的本地待科学复核候选**；其范围是上述实际读取的机制页与代码快照，并不表示原实验完全复现或科学问题清零。状态仍为 `awaiting_scientific_review`、`scientific_acceptance=false`。

复现步骤见 `REPRODUCE.md`，包外中文报告列出本轮实际命令与结果；包内checks保存运行证据。本轮没有外部上传、PR、维护人消息、submit、PFN训练、大型bootstrap/coverage、真实数据认领或模型权重改动。保留旧包；本次先提交新包供主审复核，未复制到最终 `QDI task-v1` 文件夹。
