"""Analytic scalar NRI truth for the selected monomial scenario."""
import math
import sys


def _validate(config):
    if not isinstance(config, dict):
        raise ValueError("config must be a scenario dictionary")
    s = config.get("s")
    x_star = config.get("x_star")
    if isinstance(s, bool) or not isinstance(s, (int, float)) or not math.isfinite(float(s)):
        raise ValueError("s must be finite numeric")
    if not 0.0 <= float(s) < 1.0:
        raise ValueError("s must lie in [0,1)")
    if isinstance(x_star, bool) or not isinstance(x_star, (int, float)) or not math.isfinite(float(x_star)):
        raise ValueError("x_star must be finite numeric")
    if not 0.0 < float(x_star) < 1.0:
        raise ValueError("the scalar query x_star must be an interior point of [0,1]")


def truth(config):
    """Return m_s(x_star)=E[Y|X=x_star]=x_star**(1-s)."""
    _validate(config)
    s = float(config["s"])
    x_star = float(config["x_star"])
    exponent = 1.0 - s
    value = x_star ** exponent
    alternate = math.exp(exponent * math.log(x_star))
    estimated_error = abs(value - alternate) + 2.0 * sys.float_info.epsilon
    return {
        "value": float(value),
        "estimated_error": float(estimated_error),
        "method": "Closed-form conditional Bernoulli mean x_star**(1-s); exp((1-s)*log(x_star)) is the independent numerical audit route.",
        "error_interpretation": "Floating-point agreement between two analytic evaluations; not a confidence-band or coverage error bound.",
        "target": "m_s(x_star)=E[Y|X=x_star]=p_s(x_star)",
        "query": {"x_star": x_star, "s": s}
    }
