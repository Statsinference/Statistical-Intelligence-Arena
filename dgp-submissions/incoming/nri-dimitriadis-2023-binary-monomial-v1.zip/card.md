# Source-grounded DGP contribution

Status: candidate; not scientifically accepted.

## Source and reconstruction

Primary source checked: Dimitriadis, Dümbgen, Henzi, Puke & Ziegel (2023), “Honest calibration assessment for binary outcome predictions”, *Biometrika* 110(3):663–680, DOI `10.1093/biomet/asac068`. The actual DGP reading for this contribution is the local preprint **arXiv:2203.04065v2 (2022-11-02), PDF printed page 8, Section 5, item 1 (Monomial)**. The page also states `X ~ U[0,1]`, `Y ~ Bern{p_s(X)}`, `s in S={0,0.1,...,1}`, and the simulation sample-size range 512 through 32768. The paper's replication link is `https://github.com/marius-cp/replication_DDHPZ22`.

The reconstructed original mechanism is:

1. `X_i ~ Uniform[0,1]`, independently across individuals.
2. `p_s(x) = x^(1-s)`, with `s in {0,0.1,...,1}\{1}`.
3. `Y_i | X_i=x ~ Bernoulli(p_s(x))`, independently conditional on the covariates.

The source simulation uses 1000 replications, alpha=0.05, and the raw/non-crossing simultaneous confidence-band methods with rounding `K=10^3`; those settings are recorded in every scenario for provenance. This contribution does not implement the confidence band or its coverage experiment.

The package keeps the source parameter grid as ten named scenarios `s=0,...,0.9`, with `s=0.5` as the default. `s=1` is excluded exactly as in the source because `p_s(x)=x^0` has the endpoint convention problem at x=0. The s=0 monomial is the diagonal `p(x)=x`; if the s_shape/kink/wave families are also collected, their s=0 diagonal cases must be deduplicated rather than registered as new mechanism families.

No fixed code commit was given in the PDF, and no local replication checkout was used. The formal Biometrika version and its DGP differences from arXiv v2 were not checked. These are unresolved provenance items for maintainer review.

## Target and identification

This is a **noncausal NRI** task. For each scenario, the scalar target is

`m_s(x*) = E[Y | X=x*] = p_s(x*)`, with fixed query `x*=0.5`.

It is a conditional event probability, not an intervention effect, NIE, NDE, ATE, or future-response prediction interval. Because `Y|X=x` is Bernoulli with mean `p_s(x)`, the target is identified directly by the declared conditional law. The applicable conditions are iid individual sampling, the stated Uniform[0,1] covariate law, the Bernoulli observation model, and the interior fixed query. For all registered scenarios `s<=0.9`, `p_s` is nondecreasing, which is the source method's shape condition. No causal exchangeability, treatment, mediator, interference, or missing-data assumption is introduced.

## Truth and independent verification

The truth hook evaluates the closed form

`m_s(0.5) = 0.5^(1-s)`.

For the default `s=0.5`, this is `sqrt(0.5) = 0.7071067811865476`. The hook reports a floating-point agreement estimate from a separate `exp((1-s)*log(0.5))` calculation; it is not a confidence-band error bound. `verify.py` independently recomputes the value without calling `truth.py`, checks agreement of the power and log-exp routes, checks probability support and monotonicity on a grid, and checks the s=0 diagonal and s=0.5 square-root anchors when applicable. Both routes necessarily share the source equation and query, so source reconstruction and an independent-person reproduction remain outstanding.

The scalar check does **not** validate the paper's simultaneous band over all x. The current collection interface supplies one scalar truth per scenario; multiple point checks would not constitute simultaneous-coverage validation.

## Diversity and scope

Total covariate dimension and effective dimension are both 1. There are no interactions. The power function is nonlinear for `s>0`, while `s=0` is the nested linear diagonal. Outcomes are binary and bounded; there is no latent variable, oracle nuisance, potential outcome, or unobserved response column. The generator returns only observed `X` and `Y`, uses a local seeded RNG, and does not use source replication counts to launch a large simulation.

Unsupported here: the source's full confidence-band computation, 1000-replication coverage rates, large bootstrap, PFN training, and formal-version/code-commit comparison.

## Rights and assistance

The PDF is retained outside the contribution ZIP. The ZIP contains independently written code and metadata only; no PDF, replication checkout, model weights, credentials, sensitive data, or data bank is included. AI assistance was used to extract the cited equations from the supplied PDF, draft the metadata, implement the standard-library hooks, and inspect local check output. Automated PASS is a format/run result and does not constitute named scientific review or acceptance. Maintainer review must resolve the formal-version DGP comparison, replication code commit, and independent reproduction.
