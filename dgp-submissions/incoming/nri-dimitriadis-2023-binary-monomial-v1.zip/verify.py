"""Independent analytic and shape checks for the monomial NRI target."""
import math


def _p(x, s):
    return x ** (1.0 - s)


def verify(config):
    s = float(config["s"])
    x_star = float(config["x_star"])
    direct = _p(x_star, s)
    log_route = math.exp((1.0 - s) * math.log(x_star))
    grid = [i / 100.0 for i in range(101)]
    values = [_p(x, s) for x in grid]
    checks = [
        {
            "name": "independent_log_exp_truth_route",
            "passed": abs(direct - log_route) <= 2e-15,
            "details": f"power={direct:.17g}; exp-log={log_route:.17g}; difference={abs(direct-log_route):.3g}."
        },
        {
            "name": "conditional_probability_support",
            "passed": all(0.0 <= value <= 1.0 for value in values),
            "details": "The monomial probabilities on the checked [0,1] grid stay in [0,1]."
        },
        {
            "name": "source_monotonicity_on_grid",
            "passed": all(values[i] <= values[i + 1] + 1e-15 for i in range(len(values) - 1)),
            "details": "p_s is nondecreasing for every declared s<1, matching the source band assumption."
        },
        {
            "name": "endpoint_special_case",
            "passed": abs(_p(0.0, s)) < 1e-15 and abs(_p(1.0, s) - 1.0) < 1e-15,
            "details": "For s<1, p_s(0)=0 and p_s(1)=1."
        }
    ]
    if abs(s - 0.5) < 1e-15 and abs(x_star - 0.5) < 1e-15:
        anchor = math.sqrt(0.5)
        checks.append({
            "name": "default_s05_anchor",
            "passed": abs(direct - anchor) <= 2e-15,
            "details": f"p_0.5(0.5)={direct:.17g}; sqrt(0.5)={anchor:.17g}."
        })
    if abs(s) < 1e-15:
        checks.append({
            "name": "s0_diagonal_anchor",
            "passed": abs(direct - x_star) <= 2e-15,
            "details": "s=0 reduces to p_0(x)=x; this endpoint is retained for source fidelity and deduplicated across other shape families."
        })
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": "The independent route shares the declared monomial equation and query, but does not call truth.py; no source replication code or confidence-band computation is included.",
        "scope": "These checks cover the scalar analytic truth and source shape conditions only; they do not establish simultaneous confidence-band coverage."
    }
