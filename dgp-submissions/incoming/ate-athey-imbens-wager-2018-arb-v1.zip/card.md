# ATE DGP: two-cluster high-dimensional linear outcome design

**Contribution ID:** `ate-athey-imbens-wager-2018-arb-v1`  
**Current status:** candidate; local machine checks do not constitute scientific acceptance.

## Source and exact locator

Athey, S., Imbens, G. W. and Wager, S. (2018), “Approximate residual balancing: Debiased inference of average treatment effects in high dimensions,” *Journal of the Royal Statistical Society: Series B (Statistical Methodology)*, 80(4), 597–623. DOI: [10.1111/rssb.12268](https://doi.org/10.1111/rssb.12268).

Actual reading version: 2018 journal/electronic reprint PDF, 27 pages. The target is Section 5.2, **“Simulation designs”**, two-cluster layout, printed journal pages 616–617 (PDF viewer pages 20–21 of 27, i.e. zero-based PDF page indices 19–20). The source DGP equations are written in prose, not numbered equations. Table 1 footnote on printed p. 616 specifies `n=500`, `p=2000`, signal normalization `||beta||_2=2`, and 400 simulation replications. The publisher lists its supplementary PDF as “Proofs”, but the supplement download returned HTTP 403 in this session, so its contents were not read; the supplement remains an open source-review item and no parameter is attributed to it. The paper notes an R implementation at [swager/balanceHD](https://github.com/swager/balanceHD), but this package does not import author code and no author-code commit is claimed.

## Original source equations and parameter details

The two-cluster outcome paragraph specifies the observed outcome equation (un-numbered in Section 5.2):

\[
Y_i=(C_i+Z_i)^Teta+W_i+\epsilon_i.
\]

The paper states:

\[
W_i\sim\operatorname{Bernoulli}(0.5),\quad
Z_i\sim N_p(0,I_p),\quad
\epsilon_i\sim N(0,1),
\]

and the cluster center `C_i` is either `0` or `delta`, with

\[
P(C_i=0\mid W_i=0)=0.8,\qquad P(C_i=0\mid W_i=1)=0.2.
\]

The implied observed feature vector is `X_i=C_i+Z_i`, so the outcome is `Y_i=X_i^T beta+W_i+epsilon_i`. Table 1 uses `p=2000`, `n=500` and `||beta||_2=2`. The two source forms for the between-cluster vector are:

\[
\delta=(4/\sqrt n)\,\mathbf 1_p
\]

(dense cluster separation), and

\[
\delta_j=(40/\sqrt n)\,\mathbf 1\{j=1\pmod {10}\},\quad j=1,\ldots,p
\]

(sparse cluster separation). The four beta shapes stated in Section 5.2 are:

- **Dense:** `beta` proportional to `(1, 1/sqrt(2), ..., 1/sqrt(p))`.
- **Harmonic:** `beta` proportional to `(1/10, 1/11, ..., 1/(p+9))`.
- **Moderately sparse:** proportional to ten entries equal to 10, followed by 90 entries equal to 1, followed by `p-100` zeros.
- **Very sparse:** proportional to ten entries equal to 1, followed by `p-10` zeros.

The table states that the signal is scaled to `||beta||_2=2` in the two-cluster setting. The code normalizes each raw shape to this norm, instead of leaving the proportionality constant implicit. All four beta profiles are crossed with both delta profiles as eight **scenarios within one mechanism family**, not eight independent DGP families.

## Implemented generation order

1. Draw a latent cluster membership `C_i=0` with probability 0.5; otherwise `C_i=delta`.
2. Draw treatment conditional on cluster membership: `P(W_i=1|C_i=0)=0.2` and `P(W_i=1|C_i=delta)=0.8`.
3. Draw `Z_i` with independent `N(0,1)` coordinates and form observed covariates `X_i=C_i+Z_i`.
4. Draw `epsilon_i~N(0,1)` and generate `Y_i=X_i^T beta+W_i+epsilon_i`.
5. Return only `X1,...,Xp,W,Y`. Do not return latent `C`, `Z`, `epsilon`, potential outcomes, beta, delta, or the ATE as learner input columns.

The reverse factorization at steps 1–2 preserves the source joint law: with `P(W=1)=0.5`, `P(C=0)=0.5`, and conditional treatment probabilities 0.2/0.8, Bayes' rule gives exactly the source's `P(C=0|W=0)=0.8` and `P(C=0|W=1)=0.2`. This is a distribution-preserving implementation adaptation, not a claim to reproduce the original random-number sequence. `delta` uses the generator's `n` as specified in the source scaling rule. The published Table 1 reference setting is `n=500`; the required `--run --n 128` is only a smoke test with that same scaling rule evaluated at `n=128`.

The original paragraph lists the distributions of `Z` and `epsilon`, but does not separately state every cross-variable independence relation. This implementation samples `Z`, `epsilon` independently and assumes independent individuals. Those operational choices are explicit here and remain for maintainer/scientific confirmation rather than being silently presented as a verbatim sentence from the source. The row unit is one individual. Coordinates of `Z_i` are independent, but coordinates of `X_i` are marginally dependent via the shared cluster indicator. No interference or repeated-measure structure is added.

## Target, identification, and truth

The intervention contrast is from `W=0` to `W=1`, holding pretreatment `X` fixed. The structural potential-outcome representation used for the target is

\[
Y_i(w)=X_i^Teta+w+\epsilon_i,\quad w\in\{0,1\}.
\]

Therefore

\[
ATE=E[Y_i(1)-Y_i(0)]=E[1]=1.
\]

This is an analytical result (numerical error `0`), not an estimate from generated rows. The estimator's paper discusses unconfoundedness and overlap in Section 2; in this simulation, the Gaussian-mixture feature distributions overlap pointwise, but a uniform bound away from 0 and 1 for every feature vector is not claimed. The causal interpretation also relies on the implementation's independent outcome noise. No-interference and consistency are assumed.

`verify.py` independently recalculates the Bayes-equivalent joint probabilities, reconstructs each beta profile and its norm/active count, subtracts the structural potential-outcome terms, and checks the analytic zero-effect special case. It necessarily shares the declared equations/config with `truth.py`; this is not independent-person scientific replication.

## Diversity and scope

- Total dimension: `p=2000`; the published Table 1 sample size is `n=500`, so `p>n`.
- Effective dimension depends on beta scenario: 2000 nonzero coefficients for dense/harmonic, 100 for moderately sparse, 10 for very sparse. The manifest records the family maximum as 2000.
- `interactions=false`, `nonlinear=false`: the outcome surface is linear and contains no interaction term. The mixture cluster construction induces covariate dependence without introducing a nonlinear outcome link.
- The eight configurations vary only the source's beta shape and delta shape. They are scenarios in one source family. No PFN training, large bootstrap, coverage study or reproduction of 400 simulation repetitions is included.

## Rights, adaptations, and unresolved review items

This is an independently written mathematical reconstruction. It does not package the article PDF, the authors' source code, personal data, or model weights. The paper remains under the publisher's copyright model. Please confirm scientific fidelity and attribution/redistribution expectations with the maintainer.

Open items for scientific review:

1. Confirm that independently sampling `Z` and `epsilon` and assuming independent rows matches the intended two-cluster simulation interpretation; the paragraph gives distributions but does not enumerate all independence clauses explicitly.
2. Confirm the Bayes-equivalent `C`-then-`W` factorization is the desired causal implementation of the stated joint law.
3. Confirm all eight beta/delta combinations are registered as scenarios within one family, aligned with Table 1.
4. The publisher supplementary PDF was not accessible (HTTP 403); provide the PDF or an accessible copy if its proofs must be audited.
5. Confirm the source locator/page numbering against the version used by the project maintainer and run independent human reproduction.

AI assistance was used to extract the source equations, draft the metadata, and implement local checks. No named scientific reviewer or independent person has approved this contribution. Status remains `awaiting_scientific_review` after machine PASS.
