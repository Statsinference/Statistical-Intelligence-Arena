"""Algebraic and source-probability checks independent of truth.py."""
import math
import numpy as np


def _raw_beta(profile, p):
    j = np.arange(1, p + 1, dtype=float)
    if profile == "dense":
        return 1.0 / np.sqrt(j)
    if profile == "harmonic":
        return 1.0 / (j + 9.0)
    if profile == "moderately_sparse":
        v = np.zeros(p, dtype=float)
        v[:min(10, p)] = 10.0
        v[10:min(100, p)] = 1.0
        return v
    if profile == "very_sparse":
        v = np.zeros(p, dtype=float)
        v[:min(10, p)] = 1.0
        return v
    raise ValueError("unknown beta profile")


def verify(config):
    checks = []
    p = int(config["p"])
    tau = float(config["treatment_effect"])

    # Reconstruct the source's joint probabilities using an independent
    # probability calculation, rather than calling truth() or generator().
    q0 = float(config["cluster_zero_probability"])
    w_if_zero = float(config["treatment_probability_if_cluster_zero"])
    w_if_delta = float(config["treatment_probability_if_cluster_delta"])
    p_w1 = q0 * w_if_zero + (1.0 - q0) * w_if_delta
    p_c0_w0 = q0 * (1.0 - w_if_zero) / (1.0 - p_w1)
    p_c0_w1 = q0 * w_if_zero / p_w1
    joint_ok = (
        abs(p_w1 - float(config["source_treatment_marginal_probability"])) < 1e-12
        and abs(p_c0_w0 - float(config["source_cluster_zero_given_control"])) < 1e-12
        and abs(p_c0_w1 - float(config["source_cluster_zero_given_treated"])) < 1e-12
    )
    checks.append({
        "name": "bayes_equivalent_cluster_treatment_joint_law",
        "passed": bool(joint_ok),
        "details": f"Derived P(W=1)={p_w1:.12g}, P(C=0|W=0)={p_c0_w0:.12g}, P(C=0|W=1)={p_c0_w1:.12g}; compared with source probabilities .5, .8, .2."
    })

    raw = _raw_beta(config["beta_profile"], p)
    beta = float(config["beta_l2_norm"]) * raw / np.linalg.norm(raw)
    active = int(np.count_nonzero(beta))
    expected_active = {"dense": p, "harmonic": p, "moderately_sparse": min(p, 100), "very_sparse": min(p, 10)}[config["beta_profile"]]
    beta_ok = abs(float(np.linalg.norm(beta)) - float(config["beta_l2_norm"])) < 1e-12 and active == expected_active
    checks.append({
        "name": "beta_profile_and_l2_signal_normalization",
        "passed": bool(beta_ok),
        "details": f"Independent reconstruction gives ||beta||_2={np.linalg.norm(beta):.12g}; active coefficients={active}, expected={expected_active}."
    })

    # Independently reconstruct the delta profile at the paper's reference
    # n=500, including the j=1 (mod 10) indexing convention.
    n_ref = int(config["n_reference"])
    if config["delta_profile"] == "delta_dense":
        delta_ref = np.full(p, float(config["delta_dense_multiplier"]) / math.sqrt(n_ref))
        expected_delta_active = p
        expected_delta_value = float(config["delta_dense_multiplier"]) / math.sqrt(n_ref)
        delta_shape_ok = (np.count_nonzero(delta_ref) == expected_delta_active
                          and np.allclose(delta_ref, expected_delta_value, rtol=0.0, atol=1e-14))
    elif config["delta_profile"] == "delta_sparse":
        delta_ref = np.zeros(p, dtype=float)
        delta_ref[np.arange(p) % int(config["delta_sparse_period"]) == 0] = (
            float(config["delta_sparse_multiplier"]) / math.sqrt(n_ref)
        )
        expected_delta_active = int(np.count_nonzero(np.arange(p) % int(config["delta_sparse_period"]) == 0))
        expected_delta_value = float(config["delta_sparse_multiplier"]) / math.sqrt(n_ref)
        active_positions = np.flatnonzero(delta_ref)
        expected_positions = np.arange(0, p, int(config["delta_sparse_period"]))
        delta_shape_ok = (len(active_positions) == expected_delta_active
                          and np.array_equal(active_positions, expected_positions)
                          and np.allclose(delta_ref[active_positions], expected_delta_value, rtol=0.0, atol=1e-14))
    else:
        delta_ref = np.array([], dtype=float)
        expected_delta_active = -1
        expected_delta_value = float("nan")
        delta_shape_ok = False
    checks.append({
        "name": "delta_profile_and_reference_n_scaling",
        "passed": bool(delta_shape_ok),
        "details": f"At source n_reference={n_ref}, profile={config['delta_profile']}, nonzero coordinates={np.count_nonzero(delta_ref)}, expected={expected_delta_active}, nonzero value={expected_delta_value:.12g}."
    })

    # Potential-outcome contrast obtained by subtracting the two structural
    # response means; this calculation does not invoke truth.py.
    y1_treatment_term = tau * 1.0
    y0_treatment_term = tau * 0.0
    contrast = (y1_treatment_term - y0_treatment_term)
    checks.append({
        "name": "direct_structural_potential_outcome_contrast",
        "passed": abs(contrast - tau) < 1e-14 and abs(contrast - float(config["treatment_effect"])) < 1e-14,
        "details": f"Y(1)-Y(0)=(X^T beta+tau+epsilon)-(X^T beta+epsilon)=tau={contrast:.12g}."
    })

    # Analytic zero-effect special case: changing only the treatment coefficient
    # to zero gives identical potential-outcome surfaces, hence ATE=0.
    tau_zero = 0.0
    zero_contrast = (tau_zero * 1.0) - (tau_zero * 0.0)
    checks.append({
        "name": "zero_treatment_path_special_case",
        "passed": abs(zero_contrast) < 1e-14,
        "details": "Analytic fixture only (not a declared source scenario): when the W coefficient is set to zero, Y(1)=Y(0) and ATE=0."
    })

    checks.append({
        "name": "source_setting_and_noise_scales",
        "passed": int(config["p"]) == 2000 and int(config["n_reference"]) == 500 and abs(float(config["z_sd"])-1.0)<1e-12 and abs(float(config["epsilon_sd"])-1.0)<1e-12 and abs(float(config["beta_l2_norm"])-2.0)<1e-12 and abs(tau-1.0)<1e-12,
        "details": "Checks the paper's Table 1 setting p=2000, n=500, ||beta||_2=2, Z coordinate SD=1, error SD=1, and treatment coefficient 1."
    })

    return {
        "passed": all(item["passed"] for item in checks),
        "checks": checks,
        "shared_components": "Verification shares the declared source equations and config with truth.py, but independently reconstructs the joint probability law, beta normalization and potential-outcome contrast; it does not merely call truth(). No independent-human reproduction has been performed.",
        "limitations": "The source's two-cluster paragraph does not separately spell out all cross-variable independence clauses. The generator samples Z and epsilon independently and assumes iid rows; scientific review must confirm that interpretation."
    }
