"""Analytical population ATE for the two-cluster linear outcome DGP."""


def truth(config):
    """Return the population E[Y(1)-Y(0)] and exact analytical error audit.

    Under the declared intervention, Y(w)=X^T beta + tau*w + epsilon.
    The shared X and additive error cancel in the contrast, leaving tau.
    """
    tau = float(config["treatment_effect"])
    return {
        "value": tau,
        "estimated_error": 0.0,
        "method": "Exact algebraic potential-outcome contrast; no Monte Carlo integration.",
        "error_interpretation": "Zero numerical error conditional on the declared structural equation; source-independence interpretation remains for scientific review.",
        "target": "ATE = E[Y(1)-Y(0)] for intervention W: 0 -> 1, holding pretreatment X fixed."
    }
