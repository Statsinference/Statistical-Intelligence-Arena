"""Derivative integration, CDF inversion and analytic special cases.

Thresholds fixed before execution. Independent routes, not an independent person.
"""
from copy import deepcopy
import math
import random

from generator import generate, quantile
from truth import truth


def _q_reference(u, x):
    # Expanded polynomial and log(product), independently transcribed.
    polynomial = 4 * x * u * u + (3 - 4 * x) * u + x - 1.5
    return polynomial * math.log(1 / (u * (1 - u)))


def _derivative(u, x):
    # Analytically differentiated in t=u-1/2, independent of truth/generator.
    t = u - 0.5
    return ((3 + 8 * x * t) * math.log(1 / (u * (1 - u)))
            + (3 * t + 4 * x * t * t) * (2 * u - 1) / (u * (1 - u)))


def _simpson_from_median(u, x, steps):
    # Q(0.5|x)=0 exactly. Integrate Q' from 0.5 to the query.
    h = (u - 0.5) / steps
    terms = []
    for j in range(steps + 1):
        weight = 1 if j in (0, steps) else (4 if j % 2 else 2)
        terms.append(weight * _derivative(0.5 + j * h, x))
    return h * math.fsum(terms) / 3


def _cdf(y, x):
    # Monotone inversion; endpoints are limiting brackets, never evaluated.
    lower, upper = 0.0, 1.0
    for _ in range(80):
        middle = (lower + upper) / 2
        if middle == lower or middle == upper:
            break
        if _q_reference(middle, x) < y:
            lower = middle
        else:
            upper = middle
    return (lower + upper) / 2, upper - lower


def verify(config):
    fixture = {"x_distribution": "uniform", "x_lower": -1.0, "x_upper": 1.0,
               "intercept_coefficient": 3.0, "slope_coefficient": 4.0,
               "quantile_center": 0.5, "query_x": 0.5, "quantile_level": 0.9}
    original = deepcopy(config)
    oracle = truth(config)
    u, x = config["quantile_level"], config["query_x"]
    coarse = _simpson_from_median(u, x, 2048)
    fine = _simpson_from_median(u, x, 4096)
    cdf, cdf_width = _cdf(oracle["value"], x)
    density = 1 / _derivative(u, x)
    checks = []

    def add(name, passed, **details):
        checks.append({"name": name, "passed": bool(passed), "details": details})

    add("source_constants_and_declared_query", config == fixture,
        provenance="Source: arXiv v1 p.12 Sec.5.2; query (0.5,0.9) is collection adaptation.")
    add("independent_derivative_integration", abs(oracle["value"] - fine) < 1e-10,
        analytic=oracle["value"], simpson_4096=fine,
        absolute_difference=abs(oracle["value"] - fine), tolerance=1e-10)
    add("numerical_refinement", abs(fine - coarse) / 15 < 1e-10
        and oracle["estimated_error"] < 1e-12,
        simpson_2048=coarse, simpson_4096=fine,
        simpson_error_diagnostic=abs(fine - coarse) / 15,
        oracle_error_diagnostic=oracle["estimated_error"],
        limitation="Simpson order refinement is diagnostic, not a certified integration bound.")
    add("cdf_at_target", abs(cdf - u) < 2e-14 and cdf_width < 2e-14,
        cdf=cdf, tau=u, bracket_width=cdf_width)
    add("local_density_regular", math.isfinite(density) and density > 0,
        density_at_target=density, quantile_derivative=_derivative(u, x))

    medians = []
    for xx in (-1, -0.5, 0, 0.5, 1):
        test_config = {**config, "query_x": xx, "quantile_level": 0.5}
        medians.extend([truth(test_config)["value"], quantile(0.5, xx), _q_reference(0.5, xx)])
    add("analytic_zero_median", all(v == 0 for v in medians),
        max_absolute_value=max(map(abs, medians)),
        scope="Analytic checks within the same law; no extra registered scenarios.")
    anchors = [0.1, 0.25, 0.5, 0.75, 0.9]
    reflection_error = max(abs(quantile(t, xx) + quantile(1-t, -xx))
                           for xx in (-1, -0.5, 0, 0.5, 1) for t in anchors)
    center_error = max(abs(quantile(t, 0) - 3 * (t - 0.5) * math.log(1/(t*(1-t))))
                       for t in anchors)
    add("analytic_reflection_and_zero_predictor", reflection_error < 1e-12 and center_error < 1e-12,
        reflection_max_error=reflection_error, zero_predictor_max_error=center_error,
        identities="Q(t,x)=-Q(1-t,-x); Q(t,0)=3(t-1/2)log(1/[t(1-t)]).")

    grid = sorted(set([j / 4096 for j in range(1,4096)]
                      + [10.0**(-k) for k in range(2,13)]
                      + [1-10.0**(-k) for k in range(2,13)]))
    # Q' is affine in x, so both endpoints bound every interior x.
    minimum_derivative = min(_derivative(t, xx) for xx in (-1,1) for t in grid)
    ordered = all(all(a < b for a,b in zip(values,values[1:]))
                  for values in ([quantile(t,xx) for t in grid] for xx in (-1,1)))
    add("noncrossing_endpoint_grid", minimum_derivative > 0 and ordered,
        min_derivative_on_grid=minimum_derivative, tau_points=len(grid),
        domain_proof="See card for an analytic positive bound over the full domain; grid is supplementary.")
    extreme_values = [quantile(t, xx) for xx in (-1,1)
                      for t in (2.0**-53, 1-2.0**-53)]
    add("finite_rng_extremes", all(math.isfinite(v) for v in extreme_values),
        values=extreme_values, endpoint_policy="Reject u=0; no epsilon clipping or added noise.")

    state = random.getstate()
    data = generate(config, 128, 1729)
    unchanged = random.getstate() == state
    replay = random.Random(1729)
    max_error, same_x = 0.0, True
    for xx, yy in zip(data["X"], data["Y"]):
        expected_x = 2 * replay.random() - 1
        uu = replay.random()
        while uu == 0:
            uu = replay.random()
        same_x = same_x and xx == expected_x
        max_error = max(max_error, abs(yy - _q_reference(uu, expected_x)))
    add("generated_rows_vs_expanded_source_law", same_x and max_error < 1e-12,
        rows=128, seed=1729, max_y_difference=max_error,
        shared="Same Python PRNG algorithm and draw order; quantile algebra independently transcribed.")
    changed_query = {**config, "query_x": 0, "quantile_level": 0.5}
    query_invariant = generate(changed_query,128,1729) == data
    add("observed_only_local_rng_and_query_invariance",
        unchanged and config == original and set(data) == {"X","Y"}
        and query_invariant and generate(config,0,1729) == {"X":[],"Y":[]},
        global_random_state_unchanged=unchanged, query_does_not_change_data=query_invariant)
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "shared_components": "All routes share the transcribed scientific law and query. The Simpson derivative integrand and expanded-polynomial CDF are separate from generator/truth math; special-case tests call submitted functions. PRNG replay shares RNG implementation. No independent-person or named scientific review is claimed.",
            "scope": "Scalar numerical and generator checks only; no estimator fitting, confidence interval coverage, or simultaneous-band verification."}
