"""Analytic population quantile, computed independently of generated rows.

Declared query: (3*0.4+4*0.4**2*0.5)*ln(100/9)=(38/25)*ln(100/9).
Decimal(str(value)) interprets the declared decimal query. No generator import.
"""
from decimal import Decimal, localcontext
import math


def _validate(config):
    fixed = {"x_lower": -1, "x_upper": 1, "intercept_coefficient": 3,
             "slope_coefficient": 4, "quantile_center": 0.5}
    if config.get("x_distribution") != "uniform":
        raise ValueError("Unsupported predictor distribution")
    for key, expected in fixed.items():
        v = config.get(key)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v != expected:
            raise ValueError(f"Unsupported change of source parameter {key}")
    for key in ("query_x", "quantile_level"):
        v = config.get(key)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            raise ValueError(f"Invalid {key}")
    if not -1 <= config["query_x"] <= 1 or not 0 < config["quantile_level"] < 1:
        raise ValueError("Query is outside source support")


def _decimal_value(config, precision):
    with localcontext() as ctx:
        ctx.prec = precision
        u, x = Decimal(str(config["quantile_level"])), Decimal(str(config["query_x"]))
        t = u - Decimal("0.5")
        return (3 * t + 4 * t**2 * x) * (1 / (u * (1 - u))).ln()


def truth(config):
    _validate(config)
    low, high = _decimal_value(config, 50), _decimal_value(config, 80)
    value = float(high)
    with localcontext() as ctx:
        ctx.prec = 90
        rounding = abs(Decimal.from_float(value) - high)
        refinement = abs(high - low)
        error = float(rounding + refinement) + 4 * math.ulp(value)
    return {"value": value, "estimated_error": error,
            "target": "inf{y: F_Y(y | X=query_x) >= quantile_level}",
            "query": {"x": config["query_x"], "tau": config["quantile_level"]},
            "method": "Analytic source quantile; Decimal precision 50/80, then float conversion",
            "decimal_value_80_digits": str(high),
            "decimal_refinement_difference": float(refinement),
            "float_rounding_difference": float(rounding),
            "error_interpretation": "Refinement + measured float rounding + 4 ULP allowance; numerical diagnostic for this fixed query, not a formal uniform error bound or sampling uncertainty."}
