"""Closed-form pointwise conditional mean for the declared regression law."""
import math


def _beta_density_lgamma(z, a, b):
    if z <= 0.0 or z >= 1.0:
        return 0.0
    return math.exp(
        math.lgamma(a + b)
        - math.lgamma(a)
        - math.lgamma(b)
        + (a - 1.0) * math.log(z)
        + (b - 1.0) * math.log1p(-z)
    )


def truth(config):
    z0 = float(config["query_z"])
    if not math.isfinite(z0) or not 0.0 <= z0 <= 1.0:
        raise ValueError("query_z must lie in [0,1]")
    weights = config["mixture_weights"]
    shapes = config["beta_shapes"]
    value = sum(
        float(weight) * _beta_density_lgamma(z0, float(shape[0]), float(shape[1]))
        for weight, shape in zip(weights, shapes)
    )
    return {
        "value": value,
        "estimated_error": 1e-12,
        "method": "Closed-form Beta densities evaluated in log space with math.lgamma",
        "target": "g0(query_z) = E[Y | Z=query_z]",
    }
