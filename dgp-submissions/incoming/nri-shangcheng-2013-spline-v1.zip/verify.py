"""Source fixtures, independent gamma route, normalization, and MC mechanism audit."""
import importlib.util
import math
from pathlib import Path
import random


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("shang_cheng_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _beta_density_gamma(z, a, b):
    if z <= 0.0 or z >= 1.0:
        return 0.0
    normalizer = math.gamma(a + b) / (math.gamma(a) * math.gamma(b))
    return normalizer * z ** (a - 1.0) * (1.0 - z) ** (b - 1.0)


def _mean_gamma(config, z):
    return sum(
        float(weight) * _beta_density_gamma(z, float(shape[0]), float(shape[1]))
        for weight, shape in zip(config["mixture_weights"], config["beta_shapes"])
    )


def _simpson_normalization(config, steps=200000):
    if steps % 2:
        raise ValueError("Simpson steps must be even")
    h = 1.0 / steps
    total = _mean_gamma(config, 0.0) + _mean_gamma(config, 1.0)
    for index in range(1, steps):
        total += (4.0 if index % 2 else 2.0) * _mean_gamma(config, index * h)
    return total * h / 3.0


def _window_mean_simpson(config, z0, half_width, steps=2001):
    """Analytic window mean A(z0,w); independent of Monte Carlo sampling."""
    if steps < 3 or steps % 2 == 0:
        raise ValueError("Simpson node count must be odd and at least 3")
    left = max(0.0, z0 - half_width)
    right = min(1.0, z0 + half_width)
    h = (right - left) / (steps - 1)
    total = _mean_gamma(config, left) + _mean_gamma(config, right)
    for index in range(1, steps - 1):
        total += (4.0 if index % 2 else 2.0) * _mean_gamma(config, left + index * h)
    return total * h / 3.0 / (right - left)


def _mc_window(config, proposals=2000000, half_width=0.01):
    z0 = float(config["query_z"])
    sigma = float(config["sigma"])
    analytic_window = _window_mean_simpson(config, z0, half_width)
    refined_window = _window_mean_simpson(config, z0, half_width, steps=4001)
    seed = 20130000 + int(round(z0 * 1000.0))
    rng = random.Random(seed)
    total = 0.0
    selected = 0
    for _ in range(proposals):
        z = rng.random()
        if abs(z - z0) < half_width:
            total += _mean_gamma(config, z) + rng.gauss(0.0, sigma)
            selected += 1
    if selected == 0:
        raise RuntimeError("Monte Carlo window selected no observations")
    estimate = total / selected
    threshold = 6.0 * sigma / math.sqrt(selected)
    return estimate, analytic_window, refined_window, selected, threshold


def verify(config):
    oracle = _module("truth.py")
    reference = oracle.truth(config)
    independent = _mean_gamma(config, float(config["query_z"]))
    normalization = _simpson_normalization(config)
    left = _mean_gamma(config, 0.0)
    right = _mean_gamma(config, 1.0)
    mc_estimate, analytic_window, refined_window, window_n, mc_threshold = _mc_window(config)
    quadrature_gap = abs(analytic_window - refined_window)

    constants_match = (
        float(config["sigma"]) == 0.05
        and [float(v) for v in config["mixture_weights"]] == [0.6, 0.4]
        and [[float(v) for v in pair] for pair in config["beta_shapes"]]
        == [[30.0, 17.0], [3.0, 11.0]]
    )
    checks = [
        {
            "name": "source_constants_original",
            "passed": constants_match,
            "details": "Hard-coded Case (I) fixture: sigma=0.05, weights 0.6/0.4, and Beta shapes (30,17)/(3,11); query_z is a declared interface adaptation.",
        },
        {
            "name": "independent_beta_implementation",
            "passed": abs(reference["value"] - independent) < 1e-9,
            "details": f"lgamma truth={reference['value']:.16g}; direct-gamma value={independent:.16g}; difference={abs(reference['value']-independent):.3g}.",
        },
        {
            "name": "interpretable_anchor",
            "passed": abs(normalization - 1.0) < 1e-6 and left == 0.0 and right == 0.0,
            "details": f"Composite Simpson integral={normalization:.16g} with 200000 subintervals; endpoint values=({left:.3g},{right:.3g}); expected integral=0.6+0.4=1.",
        },
        {
            "name": "mc_window_mean",
            "passed": abs(mc_estimate - analytic_window) < mc_threshold and quadrature_gap < 1e-10,
            "details": f"Two million uniform proposals; |Z-query_z|<0.01 selected {window_n}; MC window mean={mc_estimate:.16g}; analytic window mean A(z0,w) by composite Simpson (2001 nodes)={analytic_window:.16g}; 4001-node refinement gap={quadrature_gap:.3g}; difference={abs(mc_estimate-analytic_window):.3g}; 6*sigma/sqrt(N_window)={mc_threshold:.3g}. The raw window mean differs from the point value g(z0) by a deterministic smoothing bias with leading term g''(z0)w^2/6 for a symmetric interior uniform window (measured +0.0045 at z0=0.5 and -0.0109 at z0=0.64), so the audit target is the analytic window mean, not the point value.",
        },
    ]
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": "The lgamma and direct-gamma routes share the declared scientific equations but not the normalizing-constant implementation. Named source review and independent-person reproduction remain pending.",
    }
