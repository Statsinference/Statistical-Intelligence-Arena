# N06 Beta 混合回归函数的点态条件均值

Contribution: `nri-shangcheng-2013-spline-v1` · `synthetic_dgp` · `nonparametric_regression` · **v1**

## Source and reconstruction

Shang, Z. and Cheng, G. (2013). Local and global asymptotic inference in smoothing spline models. The Annals of Statistics 41(5), 2608–2638. DOI: 10.1214/13-AOS1164.

[DOI](https://doi.org/10.1214/13-AOS1164) · [固定阅读版本 1212.6788v3](https://arxiv.org/pdf/1212.6788v3)

实读 PDF SHA-256：`770a47793a31013c406325a92f813aadf5f2906e82426899a4a9b4b9803008e6`。IMS electronic reprint of the published article; the actual first-page declaration says pagination and typographic detail differ from the original.

Formula bodies: (6.1) on PDF p.24, (6.2) on PDF p.24, (6.4) on PDF p.25. Section starts: Section 6 on PDF p.24. Unnumbered paragraph on PDF p.25: "To examine the pointwise asymptotic CI" (unnumbered Beta-density mixture and experiment parameters). All PDF pages are 1-based pages of the fixed reading file 1212.6788v3. No printed journal page is inferred by adding an offset.

**原文参数逐页登记**

- PDF p.24：Y=g0(Z)+epsilon, epsilon~N(0,sigma^2); Z uniform[0,1]。
- PDF p.25：g0=.6*BetaDensity(30,17)+.4*BetaDensity(3,11); sigma=.05; spline m2; 30 equidistant evaluation points; 1000 replications。

**按实际执行顺序的生成步骤**

1. **Observed design** — Z_i iid Uniform(0,1). Source interval [0,1].
2. **Regression function** — B_(a,b)(z)=Gamma(a+b)/(Gamma(a)*Gamma(b))*z^(a-1)*(1-z)^(b-1); g0(z)=0.6*B_(30,17)(z)+0.4*B_(3,11)(z). Deterministic source Beta densities; all declared shapes exceed 1, so both endpoint limits are 0.
3. **Gaussian error** — epsilon_i iid N(0,0.05^2), independent of Z. Noise sd=0.05; variance=0.0025.
4. **Observed response** — Y_i=g0(Z_i)+epsilon_i; return Z,Y. No additional noise or oracle column. Both z0=.5 and .64 are contribution query choices.

**抽样单位与依赖**：independent observed pair (Z,Y)；iid across pairs; within a pair, Y depends on Z through g0(Z)

**边界与尺度**：Log-space Beta evaluation avoids overflow in normalizing constants for these shapes. The near-peak query .64 is not called the exact mixture mode or the steepest point. Window-mean checks compare with a separately integrated window mean; leading symmetric-window bias is g0_second_derivative*w^2/6.

**与来源的改动及理由**

1. Keep the Case (I) Gaussian regression DGP and its Beta mixture unchanged.
2. Replace interval/curve-level inference by scalar g0(z0); both z0=0.5 and z0=0.64 are contribution choices. A 30-point evaluation grid does not establish an original fixed query at 0.5.
3. Use the requested n and CPU checks; do not fit periodic splines or assess coverage.

固定点目标由已声明条件响应律识别：高斯模型使用零条件均值的误差/随机效应，广义回归直接用指定分布的链接均值。接口 n 和查询为适配；未把 n=128 说成论文原实验样本量。

**版本关系**：The actual fixed reading PDF is an IMS electronic reprint of the published article, not a separate author-preprint draft merely because it is hosted on arXiv. The first-page declaration explicitly notes pagination and typographic differences. We use only verified section/equation/1-based PDF locators and do not claim identical publisher typesetting, exact printed-page offsets or entire-text identity. No separate author-preprint-to-formal substitution is involved for this reading source; that conditional comparison is N/A.

## Target and identification

`g0(z0) = E[Y | Z = z0]`

The scalar conditional mean at the scenario's fixed query point z0. This is a pointwise target, not a simultaneous confidence-band target.

**登记场景与查询**

| Scenario | Parameters / query |
|:--|:--|
| `peak-mode` | `{"sigma": 0.05, "query_z": 0.64, "mixture_weights": [0.6, 0.4], "beta_shapes": [[30, 17], [3, 11]]}` |
| `query-z0-050`（默认） | `{"sigma": 0.05, "query_z": 0.5, "mixture_weights": [0.6, 0.4], "beta_shapes": [[30, 17], [3, 11]]}` |

场景中的 original-* 表示保留的来源生成参数，不代表新增查询和接口样本量属于原文实验。本包另设 peak-mode、query-z0-050 作为原模型参数下的自选查询；不复制同义场景充数。

**抽样、设计与支持条件**

- Observed pairs (Z,Y) are independent and identically distributed across sampling units
- Z is Uniform(0,1) and the Gaussian regression error is independent of Z
- The declared two-component Beta-density mixture is the conditional mean function
- The query point is fixed in the interior of [0,1]; machine checks do not establish smoothing-spline confidence-interval or simultaneous-band coverage

固定点条件均值正确，不等于点态区间或同时置信带覆盖率达标。非因果任务不套用干预/无混杂假设。

## Truth and independent verification

Closed-form evaluation of the two Beta densities using math.lgamma at the fixed query point.

`truth.tolerance=1e-08`。estimated_error 是浮点/数值路线诊断，不是严格统一误差界或统计标准误；其非负且不大于 tolerance。

**不同路线与解析特例**：真值用 lgamma；独立路线用整数阶乘/多项式 Beta 归一化及局部窗口 Monte Carlo；混合权重之和为 1，故积分为 1；两端密度为 0，是解析归一化与边界锚点。

**实际共享函数与独立边界**：verify 仅读取 truth.truth 的值作比较；direct-gamma、Simpson 归一化/窗口积分和随机采样均在 verify 重新实现。它们仍共享同一论文数学公式；外部 70 位/整数阶乘复核为额外路线。

外部另按论文公式用 mpmath 70 位重算全部登记查询；另对各场景 generate(n=4096, seed=7312026) 实际观察列独立重构残差，不导入私有均值助手或 verify 作外部参照。N08 的源数学参照取精确 1/sqrt(3)，与配置中最短十进制权重的浮点差计入比较；阈值仍逐包取 tolerance，不靠放宽阈值通过。

## Diversity and scope

`dimension=1`，`effective_dimension=1`。The only covariate Z is active. Nonlinearity is the bimodal mixture g0(z)=0.6 beta_30,17(z)+0.4 beta_3,11(z); there are no covariate interactions.

No treatment/label/missingness mechanism applies. The source evaluation grid has 30 equally spaced points; it does not make a standalone .5 query an original source setting. Pointwise means are not curve-wide confidence-band verification.

处理分配、标注、缺失与真实数据分支均不适用。未执行论文估计器、bootstrap、点态/同时覆盖率、PFN 训练、大规模压力测试或第二人独立人工复现。

## Rights and assistance

Source equations are cited and independently implemented. Paper copyright is not transferred; no paper PDF, author software, original participant data or model weights are redistributed. No external author code was used. The contributor must confirm the release licence for the independently implemented code before publication; pending review is not a grant of rights. AI assisted equation extraction, implementation, numerical checks and drafting; named human scientific review and independent-person reproduction are not claimed.

**未使用作者原始代码或补充材料代码**；因此作者软件 commit 追溯项 N/A。本包依赖以 requirements.txt 为准：标准库或 NumPy 的使用不等于移植作者代码。论文全文、页图、作者软件、权重、数据银行、凭据不随贡献包分发。

**missing / 尚待确认**

- 当前已声明生成律不存在未给定的必要数值参数；这不等于作者算法、许可或科学接收已获确认。
- 本人须审核 AI 协助的来源提取、代码、数值和文本，并确认独立实现代码的发布许可；pending 不是授权。
- 具名科学审核、第二人独立人工复现：未执行。
- GitHub Fork/Sync/SUBMIT DGP/Actions/PR/收录确认：本次未执行。本地 submit 不等于网络提交或项目收件。

**状态**：以最终 checks/report.json 记录本地 runnable_dgp；归档仅 awaiting_scientific_review、scientific_acceptance=false。
