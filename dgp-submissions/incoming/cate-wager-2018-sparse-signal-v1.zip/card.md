# Wager–Athey (2018) appendix design: effect spread over q signal coordinates

**Contribution `cate-wager-2018-sparse-signal-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `wager-athey-2018-sparse-signal`

## Source and reconstruction

- Citation: Wager, S. and Athey, S. (2018). Estimation and Inference of Heterogeneous Treatment Effects using Random Forests. Journal of the American Statistical Association 113(523), 1228-1242. DOI: 10.1080/01621459.2017.1319839.
- Venue / year: Journal of the American Statistical Association, 2018
- Link: https://arxiv.org/abs/1510.04342
- **Exact locator**: Appendix A 'Additional Simulations', arXiv:1510.04342v2 PDF p.30, equation (30) for tau(x) and Table 5 (p.30) for the (q, d) grid; the preceding paragraph states 'we generate data with a treatment effect function (30)'.
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **X1-X6**: `Xj ~ Uniform(0,1) independently, j = 1..6`
2. **Treatment**: `P(A=1|X) = 0.5`
3. **Baseline**: `m(X) = 0`
4. **Heterogeneity**: `tau(X) = (4/q) sum_{j=1..q} [1/(1+exp(-12 (Xj - 1/2))) - 1/2], q = 4`
5. **Outcome**: `Y = m(X) + A tau(X) + eps, eps ~ Normal(0,1)`

Sampling unit: individual · dependence: independent and identically distributed

Fixed parameters: q = 4 signal coordinates, d = 6 ambient, sigmoid steepness 12, centre 1/2, centring constant 1/2 per coordinate; noise variance 1.

### Adaptations relative to the source

- The source varies q in {2,4,6} and d in {6,12}; this package fixes the (q, d) = (4, 6) cell so that the surface has an exact closed form with 4/q = 1.
- The source keeps m(x) = 0 and e(x) = 0.5 from the Section 5.1 framework; the same values are used here and stated explicitly.
- The source writes (W - 0.5) tau(X); this package uses A tau(X) with A in {0,1}. The CATE is unchanged.
- The source reports Table 5 over 20 replications; no replication experiment is run here.

## Target and identification

- Symbol: `tau(x0) = E[Y(1) - Y(0) | X = x0]`
- Definition: Conditional average treatment effect when the signal is spread additively over q = 4 of the 6 coordinates; the estimand at a query point is the sum of four sigmoid contributions minus 2.
- Query points (part of the estimand): `primary`: (X1 = 0.9, X2 = 0.9, X3 = 0.5, X4 = 0.5, X5 = 0.5, X6 = 0.5); `secondary`: (X1 = 0.1, X2 = 0.1, X3 = 0.5, X4 = 0.5, X5 = 0.5, X6 = 0.5)

Identification assumptions:

- SUTVA: one version of treatment, no interference
- Randomised assignment: e(x) = 0.5, so unconfoundedness holds by design
- Overlap: e(x) = 0.5 with margin 0.5
- Homoscedastic Gaussian noise with unit variance

This is the sparse-signal counterpart of the sigmoid-product design: no single coordinate explains much of the effect, which is exactly the regime where local methods lose their edge.

## Truth and independent verification

With m = 0, the contrast equals the sum of the four sigmoid terms minus 4 x (1/2) = 2. At the primary query point two sigmoids are evaluated at 0.9 (each 1.98367) and two at 0.5 (each 1.0), giving 3.96735.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and confirms end-to-end that the realised
outcome column of `generator.py` carries the declared surface (arm-contrast shift
equals the mean of tau over treated rows, at identical seed). Both routes share the
declared mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 6 (effective 4) · high dimensional: False · interactions: False · nonlinear: True
- No confounding; the difficulty is signal dispersion, not overlap. Additive structure means an additive model can in principle be oracle-efficient, so this mechanism is deliberately unfriendly to purely local smoothers.

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| X1 | covariate | float | 0.0 | 1.0 | true |
| X2 | covariate | float | 0.0 | 1.0 | true |
| X3 | covariate | float | 0.0 | 1.0 | true |
| X4 | covariate | float | 0.0 | 1.0 | true |
| X5 | covariate | float | 0.0 | 1.0 | true |
| X6 | covariate | float | 0.0 | 1.0 | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by Taylor & Francis for the American Statistical Association. No PDF or author code is redistributed.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: Only the (q, d) = (4, 6) cell is implemented; q = 2 and q = 6 are left as scenarios for later.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
