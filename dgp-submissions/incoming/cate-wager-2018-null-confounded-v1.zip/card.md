# Wager–Athey (2018) simulation 1: zero treatment effect with a beta-density propensity

**Contribution `cate-wager-2018-null-confounded-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `wager-athey-2018-null-confounding`

## Source and reconstruction

- Citation: Wager, S. and Athey, S. (2018). Estimation and Inference of Heterogeneous Treatment Effects using Random Forests. Journal of the American Statistical Association 113(523), 1228-1242. DOI: 10.1080/01621459.2017.1319839.
- Venue / year: Journal of the American Statistical Association, 2018
- Link: https://arxiv.org/abs/1510.04342
- **Exact locator**: Section 5.1 'Experimental Setup', arXiv:1510.04342v2 PDF p.20, equation (27); the sentence 'We used n = 500 samples and varied d between 2 and 30' follows the equation on the same page.
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **X1-X5**: `Xj ~ Uniform(0,1) independently, j = 1..5`
2. **Treatment**: `P(A=1|X) = 0.25 * (1 + 20 X1 (1-X1)^3)`
3. **Baseline**: `m(X) = 2 X1 - 1`
4. **Heterogeneity**: `tau(X) = 0`
5. **Outcome**: `Y = m(X) + A tau(X) + eps, eps ~ Normal(0,1)`

Sampling unit: individual · dependence: independent and identically distributed

Fixed parameters: propensity scale 1/4 with beta density shape (2,4); baseline slope 2 and intercept -1; noise variance 1. Nothing is estimated in this package.

### Adaptations relative to the source

- Dimension is fixed at d = 5 instead of the source's d in {2,...,30}; only X1 enters the propensity and the baseline, X2-X5 are irrelevant coordinates kept so the design still has ambient dimension.
- The source writes Y = m(X) + (W - 0.5) tau(X) + eps; this package uses the equivalent contrast form Y = m(X) + A tau(X) + eps with A in {0,1}. The CATE is unchanged, the marginal outcome law differs by the constant 0.5 tau(X) = 0.
- The source reports MSE and coverage over 500 replications at n = 500; this package fixes one scenario and is checked at n = 128 for interface purposes only. No estimator is re-run.
- beta_{2,4} is the Beta(2,4) *density* in the source; it is implemented as 20 u (1-u)^3 so that e(X) = 0.25 (1 + 20 X1 (1-X1)^3).

## Target and identification

- Symbol: `tau(x0) = E[Y(1) - Y(0) | X = x0]`
- Definition: Conditional average treatment effect at the declared query point; in this design it is identically zero for every x, which makes it a null-effect control for bias and interval coverage under confounding.
- Query points (part of the estimand): `primary`: (X1 = 0.5, X2 = 0.5, X3 = 0.5, X4 = 0.5, X5 = 0.5); `secondary`: (X1 = 0.25, X2 = 0.1, X3 = 0.9, X4 = 0.5, X5 = 0.5)

Identification assumptions:

- SUTVA: one version of treatment, no interference between individuals
- Unconfoundedness: {Y(0), Y(1)} independent of A given X. In the source this is enforced by construction because the outcome depends on X only through m(X) and the effect is constant
- Overlap: 0.25 <= e(X) <= 0.777 on the whole support of X, since 20 u (1-u)^3 attains its maximum 2.109 at u = 0.25
- Homoscedastic Gaussian noise with unit variance, as in the source

Because tau is identically zero, this contribution works as a null-effect control: any method that reports a non-zero CATE here is biased by the A-X-m interaction that the source designed for. It is not a heterogeneity mechanism and is labelled as such.

## Truth and independent verification

E[Y | A=1, X=x] - E[Y | A=0, X=x] = (m(x) + 0) - (m(x) + 0) = 0 for every x. The value 0 is exact, not numerical; the reported estimated_error 1e-12 only records floating-point round-off.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and confirms end-to-end that the realised
outcome column of `generator.py` carries the declared surface (arm-contrast shift
equals the mean of tau over treated rows, at identical seed). Both routes share the
declared mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 5 (effective 1) · high dimensional: False · interactions: False · nonlinear: True
- Null-effect design: no CATE heterogeneity by construction. The difficulty is entirely in the nuisance structure (beta-density propensity interacting with a linear baseline). Unsupported settings: nothing here speaks to effect heterogeneity, and no uniform overlap constant is claimed beyond the analytic range [0.25, 0.777].

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| X1 | covariate | float | 0.0 | 1.0 | true |
| X2 | covariate | float | 0.0 | 1.0 | true |
| X3 | covariate | float | 0.0 | 1.0 | true |
| X4 | covariate | float | 0.0 | 1.0 | true |
| X5 | covariate | float | 0.0 | 1.0 | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by Taylor & Francis for the American Statistical Association. No PDF or author code is redistributed; the equations are cited and independently implemented.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: d is fixed at 5 rather than varied over {2,...,30}; the source's coverage experiment is not reproduced.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
