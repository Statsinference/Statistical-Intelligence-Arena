# Yang-He (2012)：Section 4.2 Models 1–4 的固定点条件分位数

贡献 ID：`qdi-yang-he-2012-conditional-quantile-v1`。类型 `synthetic_dgp`；QDI 对应 `family=quantile_distribution`；`mechanism_family_id=yang-he-2012-section42-location-scale`。

状态：**awaiting_scientific_review**，`scientific_acceptance=false`。这是一套机制、四个 scenario。本轮没有认领真实数据。尚未向维护人提交或完成全库查重；AI 协助不构成具名科学审核或独立人员复现。

## 来源核对与认领信息

Yang, Yunwen and He, Xuming (2012). *Bayesian Empirical Likelihood for Quantile Regression*. **The Annals of Statistics 40(2), 1102–1131**. [论文 DOI](https://doi.org/10.1214/12-AOS1005)。使用用户提供的正式发表版 30 页 PDF，首页印刷页码 1102，目标页印刷页码 1114；不使用 arXiv 重排版本代替正式版。

补充材料：同作者 (2012), *Supplement to “Bayesian Empirical Likelihood for Quantile Regression”*，[补充材料 DOI](https://doi.org/10.1214/12-AOS1005SUPP)，用户提供的 PDF 共 6 页。

| 项目 | 精确定位、内容与出处类别 |
|---|---|
| 收集章节 | §4.2 *Efficiency of BEL under various priors*，论文 PDF p.13／期刊 p.1114，Models 1–4；四条方程没有 equation 编号。 |
| 共同 X 分布 | p.1114 Models 1、3：X ~ χ²(2)；Models 2、4 继承。自由度 2。 |
| 共同 Z 分布 | 同页：Z/2 ~ Bernoulli(0.5)。概率 0.5，Z=0 或 2，不能改为 0/1。 |
| 独立性 | 同页明确 X、Z、e 相互独立；§2（主文 PDF p.4／期刊 p.1105） Eq.(2.1) 前采用 random sample 框架，本贡献使用 iid 行。 |
| Model 1 | p.1114：Y=X+Z+e，e~N(0,4)，均值 0、方差 4（标准差 2）；位置截距 0，X、Z 系数均为 1，误差乘数 1。 |
| Model 2 | p.1114：同 Model 1，改为 log(e)~N(0,1)，对数均值 0、对数标准差 1；不中心化 e。 |
| Model 3 | p.1114：Y=X+Z+(X/2+1)e，e~N(0,4)，位置参数与 Model 1 相同；scale_intercept=1、scale_x=0.5。 |
| Model 4 | p.1114：同 Model 3，改为 log(e)~N(0,1)，不中心化。 |
| 原推断对象 | p.1114：比较斜率 bx(τ)、bz(τ)，以及在 **(样本均值 X,0)** 处的 adjusted intercept a(τ)。 |
| 原实验设计 | p.1114：τ=0.9,0.925,0.95，n=100；主文 PDF p.15／期刊 p.1116 Table 3：500 个样本的 MSE，主文 PDF p.16／期刊 p.1117 Table 4 沿用说明。Tables 3–4 不是本贡献固定查询点的真值表。 |
| 先验与补充材料 | 主文 PDF pp.13–14／期刊 pp.1114–1115 说明 BEL 先验；补充 PDF pp.1–4 Eq.(0.1)、Tables 1–2 说明 MCMC 提议与链长。这些是估计方法设置，不是生成噪声分布。补充 PDF pp.5–6 涉及 §5 真实数据应用，未认领或获取该数据。 |
| 本次 estimand | 用户指定适配：θ_m=Q_0.95(Y\|X=2,Z=0)。τ=0.95 选自原文，固定查询 X=2=E[X] 是本贡献定义；不是样本均值查询。 |
| 识别与正则性 | §2（主文 PDF p.4／期刊 p.1105）；§3.1（主文 PDF p.7／期刊 p.1108） Assumptions 3.1–3.5。具体适用范围与有界支持差异见下文。 |
| 真值 | 从上述位置尺度模型推导，使用单调性求条件分位数；数值由本贡献计算，不冒称论文报告值。 |
| 作者代码／commit／seed | **missing**：已读论文与补充材料未提供作者生成程序、commit 或随机种子。若要求逐随机流复现，需要作者仓库／归档及固定版本、种子。当前方程重建所需参数没有缺项。 |
| 来源读取 | 主文相关章节及全部补充材料已亲自读取；主文 PDF p.13／期刊 p.1114 模型、主文 PDF p.7／期刊 p.1108 假设及补充首页另做视觉核对。在线 DOI 打开失败；本地原始来源可读，不构成公式读取缺口。 |

### 统一页码对应（主文与补充分别计数）

下表的 PDF 页码均从各自文件首页起按 1 计数；主文期刊页码 = PDF 页码 + 1101。主文与补充不能共用这个偏移。

| 引用内容 | 文件及 PDF 页码 | 期刊页码／定位 |
|---|---|---|
| 条件分位数定义 | 正式主文 PDF p.1 | p.1102，§1 Eq.(1.1) |
| random sample、随机设计与有界支持 | 正式主文 PDF p.4 | p.1105，§2 Eq.(2.1) 前后 |
| MELE 可行性、支持、光滑性、密度与正定性条件 | 正式主文 PDF p.7 | p.1108，§3.1 Assumptions 3.1–3.5；有界支持为 3.2 |
| 四个 DGP、X/Z/e 独立性、原 adjusted intercept、τ 与 n | 正式主文 PDF p.13 | p.1114，§4.2 未编号 Models 1–4 及其后正文 |
| BEL 先验（仅原估计方法背景） | 正式主文 PDF pp.13–14 | pp.1114–1115，§4.2 先验项目列表 |
| n=100、500 个样本、Models 1–2 的 MSE | 正式主文 PDF p.15 | p.1116，Table 3 标题及表注 |
| Models 3–4 的 MSE、沿用 Table 3 说明 | 正式主文 PDF p.16 | p.1117，Table 4 标题及表注 |
| 官方补充 DOI 与文件类型 | 正式主文 PDF p.27 | p.1128，Supplementary material 段 |
| MCMC 算法 | 补充 PDF pp.1–2（独立计数） | Eq.(0.1) 在补充 p.1；算法说明延续至 p.2 |
| 提议尺度与链长 | 补充 PDF pp.3–4（独立计数） | Table 1 在补充 p.3，Table 2 在补充 p.4；不是数据生成参数 |
| §5 温度应用的补充计算说明 | 补充 PDF pp.5–6（独立计数） | 补充自身页码 5–6；本贡献未认领真实数据 |

来源文件 SHA-256（仅记录指纹，不打包 PDF）：

- 正式论文：`cfa24c0e17defec588274efd38bee0bfd0107ca1014d78ac5c8ad90a4391197f`。
- 补充材料：`61500708be716a0cc21ba0ad2d7d68b5d3d6aa07704bdc208ae4f5f98f956f53`。

维护人查重范围应为“Yang & He 2012、§4.2、Models 1–4、共同 χ²／二水平协变量位置尺度机制”，不应只按 ID 或种子查重。认领和全库去重尚未执行。

## 原始机制、固定场景及适配

每行独立生成 X~χ²(2)、B~Bernoulli(0.5)、Z=2B 和独立误差 e。位置 μ(x,z)=x+z。

| scenario | s(x) | e 的分布 | 观察响应 |
|---|---|---|---|
| model1_normal_homoscedastic | 1 | N(0,4) | Y=X+Z+e |
| model2_lognormal_homoscedastic | 1 | log(e)~N(0,1) | Y=X+Z+e |
| model3_normal_heteroscedastic | 1+X/2 | N(0,4) | Y=X+Z+(1+X/2)e |
| model4_lognormal_heteroscedastic | 1+X/2 | log(e)~N(0,1) | Y=X+Z+(1+X/2)e |

`generate(config,n,seed)` 接收单个 scenario 参数对象，使用 `random.Random(seed)` 局部 RNG；χ²(2) 通过数学等价的 Gamma(shape=1,scale=2) 抽样。正态标准差是 2，不是 4；对数正态由 exp(G)、G~N(0,1) 生成，不减 exp(1/2)。相同 Python 环境、配置和 seed 可重现；不宣称与作者 RNG 或跨 Python 版本逐位相同。

输出仅含 `X,Z,Y` 三列数值列表，各长 n。`schema.csv` 中 Z 为整数范围 [0,2]，额外核验实际支持为 {0,2}；不能使用强制 0/1 的 binary dtype。X≥0，Y 在共享 schema 中不设统一下界。潜在标准正态、e、条件尺度、分位数和 oracle 标签不作为模型输入列。配置和 truth 是收集／核验资产，应由后续维护端与仅供学习器的观察表区分。

适配逐条为：

1. 保留四个原始数据律，合并为一个 mechanism family 的四个 scenarios；不新增交互、噪声参数或依赖。
2. 原文多分位回归系数目标改为单个 τ=0.95 的条件分位数标量。
3. 随机查询 (X̄,0) 改成预先固定的 (2,0)，2=E[χ²(2)]。
4. 仅做指定小样本本地核验（n=128、seed=1729），不重跑 n=100、500 次重复的 BEL/RQ/CQR 效率比较、先验或 MCMC。n 是接口入参，不改变单行数据律。

τ=0.5 的解析特例只用于 `verify`，不是第五个登记场景，也不是新的 family。

## 统计目标、抽样与假设

按每个模型 m 的总体条件分布，定义 θ_m=inf{y:F_m(y|X=2,Z=0)≥0.95}。这是条件分位数，不是边际分位数或贝叶斯参数后验的 95% 分位数。它不依赖 n 或生成样本。标量真值核验不等于区间覆盖率或同时置信带核验。

一行一个合成观察 (X,Z,Y)，行间 iid。行内 X、Z、e 相互独立，构造的 Y 与协变量相关。完整观察三列，无缺失、标注子样本、时间、聚类、网络或 interference 结构。非因果目标不需要干预方向、无混杂或中介 cross-world 假设。

X=2 在连续支持内部，f_X(2)=exp(-1)/2>0，P(Z=0)=1/2。虽然 P(X=2)=0，模型给定的连续条件分布版本确定此点的值；一般非参数估计仍需要相应连续性／平滑性条件。s(x)>0，条件 CDF 在目标附近连续严格递增，故分位数唯一。令 v=(1,X,Z)，由源分布推得 E[vvᵀ]=[[1,2,1],[2,8,2],[1,2,2]]，行列式 4>0，设计不退化。

必须保留的理论适用差异：§2（主文 PDF p.4／期刊 p.1105） 和 Assumption 3.2（主文 PDF p.7／期刊 p.1108）采用有界协变量支持，而 §4.2 的 χ²(2) 支持无界。本贡献保留模拟机制，不截断 X，也不宣称验证了主文全部 BEL 渐近定理前提。Assumption 3.1 的经验似然可行性、先验与优化／后验条件属于具体估计方法，本轮没有运行或证明。条件密度与光滑性可在当前查询直接检查，但异方差模型随 X→∞ 没有统一的正尾部密度下界。

## 真值推导与精度

e 独立于协变量且 s(x)>0，因此

F_m(y|x,z)=F_e((y−x−z)/s(x))，Q_τ(Y|x,z)=x+z+s(x)q_e(τ)。

正态 q_e(τ)=2Φ⁻¹(τ)；对数正态 q_e(τ)=exp(Φ⁻¹(τ))。设 r=Φ⁻¹(0.95)：

| 模型 | 固定查询真值公式 | 约值（机器输出见 checks/report.json） |
|---|---|---|
| 1 | 2+2r | 5.289707253903 |
| 2 | 2+exp(r) | 7.180251602233 |
| 3 | 2+4r | 8.579414507806 |
| 4 | 2+2exp(r) | 12.360503204466 |

默认 Model 1 的 `truth.reference_value` 仅用于默认场景锚点，其余场景各有独立 CDF 求根核验。查询点尾部密度为正态 φ(r)/(2s(2))、对数正态 φ(r)/(s(2)exp(r))，均严格为正，数值随 truth 返回。正态 Var(e)=4；对数正态 Var(e)=exp(2)−exp(1)；条件方差是 s(x)²Var(e)。

`truth.py` 用 `NormalDist.inv_cdf` 与 exp 的解析变换。`estimated_error` 为 CDF 回代残差除以局部密度，加上 32 倍机器 epsilon 的尺度相关舍入诊断；不是严格认证界，也不是 Monte Carlo 标准误。登记绝对容差 **1e-10**，执行前固定。

`verify.py` 直接按模型编号另写原文条件 CDF，使用 70 位 Decimal 算术，以标准正态密度幂级数积分计算 Φ，再对 Y 的条件 CDF 二分求根；不调用 NormalDist、truth 的数学 helper 或生成器公式。初始区间对应标准正态 [-2.5,2.5]，适用于本轮 0.95 和特例 0.5，不是任意极端 τ 的通用求根器。最终 bracket width <1e-45，级数停止项 <1e-60；这些是高精度数值诊断，不是严格区间算术证明。核验内容包括：

- 原文参数与固定查询；解析真值和独立求根差异 <1e-10。
- 独立条件 CDF 在返回真值处与精确十进制 0.95 的差 <1e-13；实际真值差异不超过 reported estimated_error。
- 中位数特例：Models 1、3 为 2，Model 2 为 3，Model 4 为 4；两条路线均核验。
- 受控基础抽样检查 Gamma 参数、正态／对数正态参数、Z 编码与响应方程。
- 真实局部抽样不改变全局 RNG 或 config，支持约束正确；收集器另查所有场景的列名、长度、有限值、重复 seed、不同 seed 和接口。

共享部分必须承认：两条数值路线共享本次对来源公式的解读、同一来源和模型编号；受控生成方程测试两边均用 `math.exp`。所有代码由同一次 AI 协助工作编写，没有独立具名人员复现。算法独立不能证明来源解释绝无错误。

## 维数、标签和范围

`dimension=2`、`effective_dimension=2` 指 X、Z 两个活跃观察协变量；截距不计输入维数，Y 是响应。原文 n=100、本轮 n=128，`high_dimensional=false`。

Q_τ=x+z+s(x)q_e(τ) 在固定 τ 下对 X、Z 是仿射函数，没有 XZ 项，所以 `interactions=false`、`nonlinear=false` 指观察协变量的条件分位数面。Models 3–4 的 Xe/2 使噪声尺度依赖 X，不冒称观察协变量间交互；Models 2、4 的 exp(G) 非线性噪声变换，以及 s(x)² 条件方差，均明确记录。没有无关填充列或因果混杂标签。

本轮不训练／微调 PFN，不生成超分布，不跑 bootstrap／coverage，不改 checkpoint 或原实验。没有收件回执、远端 CI、PR 或外部发送；最终 ZIP 由用户交维护人。

## 权利、协助与未决问题

论文版权归 Institute of Mathematical Statistics (2012)。本贡献引用方程并独立编写程序；ZIP 不含论文 PDF、作者原始代码、真实数据、凭据、数据银行或权重。贡献代码许可和最终归档归属由贡献者／维护人确认，没有替作者或用户授予未取得的权利。

AI 用于来源读取、推导、代码编写和代码审阅。工具来自用户提供的 2026-10-27 学生参考包；初次收集任务（2026-10-31）的目录为空，因此当时使用工作区副本运行 collect.py。本轮（2026-11-01）在新的独立修订目录使用原学生包工具，未改参考包或其他任务。

未决项目：作者代码／commit／随机种子 **missing**；有界支持假设与 χ² 模拟的差异；维护人全库查重与认领；代码许可确认；具名科学审核和另一人独立复现。不得通过放宽容差或删除场景消除这些问题。生成参数齐全，不需要补造；如果要求作者代码级复现，请提供作者原始代码与固定版本。本包只声称方程重建及明确声明的目标适配。

检查状态 `runnable_dgp` 仅表示本地格式／运行就绪；包状态仍为 **awaiting_scientific_review**。科学接收须由维护人根据原文核对、独立复现和具名审核决定。

## 2026-11-01 来源完整性复查修订

本修订仅从用户指定的四场景旧 ZIP 开始，基准 SHA-256 为 `e2c8383c061f6575fb4f2e327588bc3d48d91bbf87ffb3d40d178d1703d68fb8`。先前仅 Model 1、τ=0.9 的包被排除，未用作本轮基准。新的独立目录保留全部四场景、τ=0.95、查询点 (2,0)、机制参数和真值容差；三个 Python 入口、config、schema、requirements 均与选定基准逐字节相同。

已重新读取项目中文 PDF、第一次任务 DOCX、学生包指南和 task-family 对照。工作区中文 PDF 是 2026-10-21 的早期六类因果草稿；后续 2026-10-27 指南、DOCX 与本次用户任务明确扩展到 QDI，故采用 `quantile_distribution`。文档中的外部提交／联系步骤未获本轮授权，本轮没有执行。

### 生成顺序、全部内部变量与边界

| 次序 | 分布／变换、参数 | 独立性／观察情况／边界 | 来源性质 |
|---|---|---|---|
| 1 | X_i~χ²(2)=Gamma(shape=1,scale=2) | 行间独立；X≥0，连续理论下 X=0 概率为零；X 可见 | §4.2 PDF13／期刊1114 Models1、3，2、4继承；Gamma 是等价实现 |
| 2 | B_i~Bernoulli(0.5)，Z_i=2B_i | B 独立于 X；Z∈{0,2}，仅输出 Z | 原文写 Z/2~Bernoulli(0.5)；B 是本包解释性别名 |
| 2 的计算辅助 | U_Z∈[0,1) 的局部均匀伪随机数；B=1[U_Z<0.5] | 不输出 U_Z 或 B；不是新增协变量 | Bernoulli 的数值实现选择，不冒称原文指定 RNG 算法 |
| 3，Models1、3 | e_i~N(0,4)，标准差2 | 原始 e 独立于 X、Z，支持 R；不输出 e | 同页原始模型 |
| 3，Models2、4 | G_i=log(e_i)~N(0,1)，标准差1；e_i=exp(G_i) | 原始 e 独立于 X、Z；e>0；不中心化；G、e 均不输出 | 同页改动条目；G 是实现别名 |
| 4 | Models1、2：s=1；Models3、4：s(X)=1+X/2 | s≥1；异方差的总噪声 ε=s(X)e 依赖 X，不应把 ε 与原始 e 的独立性混淆 | 同页原始方程 |
| 5 | Y_i=0+1X_i+1Z_i+s(X_i)e_i | 条件正态模型 Y∈R；条件对数正态模型 Y∈(X+Z,∞)；观察 Y | 同页原始方程 |

一行是一个合成观察 (X,Z,Y)，各行 iid，无单位共享随机效应、面板、聚类或网络。Z 是协变量，不是处理；处理分配机制不适用。标签划分、缺失、删失、选择与有限占位值机制均不适用，三列全可见。最终仅输出 X、Z、Y。

边界处理：保留完整 χ² 和误差支持；不截断 X、不中心化对数正态、不裁剪／winsorize、不重抽超界样本。n 为正整数、seed 为整数，配置必须满足代码中的数值与正尺度约束。数值溢出或非有限响应导致错误，不默默替换或重抽。正常浮点实现不是实数分布的逐比特精确采样，也不声称无限尾部的任意极端配置都可有限表示。

### 对原作者脚本与随机种子的有范围调查

完整逐项记录、查询文本、URL、访问结果在包内 `source_audit.json`，调查日期为 2026-11-01。调查的对象是这篇 **2012 AoS** 论文，而不是同名作者、后续空间分位论文或其他 Bayesian QR 软件。

| 调查范围 | 实际结果 | 数学生成律完整性影响 |
|---|---|---|
| 正式主文30页文本关键词扫描；§4.2、参考来源／补充声明细读；补充6页全文细读 | 主文 PDF27／期刊1128 的 Supplementary material 段明确 DOI `10.1214/12-AOS1005SUPP` 及 .pdf。补充给 MCMC 算法／提议尺度／链长，所读文件中未发现生成脚本、仓库／commit 或原始 RNG seed | 所有四模型的分布与数值参数均已明确，数学机制完整；补充中的计算参数不误作数据噪声参数 |
| [Project Euclid 正式条目](https://projecteuclid.org/journals/annals-of-statistics/volume-40/issue-2/Bayesian-empirical-likelihood-for-quantile-regression/10.1214/12-AOS1005.full)、主文／补充 DOI；IMS 与 e-publications 可能的补充归档地址 | DOI／归档读取失败；Euclid 仅返回 iframe，继续打开为 service notice。未能验证页面背后的全部补充附件清单；归档尝试地址不写成已确认下载地址 | 不影响本地正式方程核对；限制在线附件穷尽性，不能据此声称不存在代码 |
| [WashU 作者机构论文记录](https://profiles.wustl.edu/en/publications/bayesian-empirical-likelihood-for-quantile-regression/) | 确认作者、题名、2012年4月、40(2)、1102–1131与DOI；其 Access／Other links 为 DOI、Scopus，当前页面未显示代码仓库 | 补齐线上官方机构元数据交叉核对 |
| [Xuming He 官方机构页](https://artsci.washu.edu/faculty-staff/xuming-he)及其 Personal Website | 确认统计学作者身份和主页链接；`sites.washu.edu/xuminghe/` 跳转 `sites.wustl.edu/xuminghe/` 后无法抓取。Michigan 历史地址尝试也无法读取 | 主页的软件／论文附件清单仍未核实；不冒充已查遍作者网站 |
| [Columbia 2014 官方讲座记录](https://www.publichealth.columbia.edu/academics/departments/biostatistics/news-events/past-lectures/2014)指向的 Yunwen Yang 旧 Drexel 教师页 | 教师页 `publichealth.drexel.edu/academics/faculty/Yunwen%20Yang/` 现跳转到 Dornsife 总首页；未获得针对本文的代码链接 | 留作访问／历史页面缺口，无数学参数缺口 |
| 官方机构库 IDEALS 题名记录；[arXiv版本记录](https://arxiv.org/abs/1207.5378) | IDEALS 访问403，论文／附件未据此采用；arXiv元数据可读，v1为2012-07-23，期刊与DOI吻合。本轮仅用该记录说明版本，不把重排版本改作主来源，也不声称逐字比对过两版本 | 正式期刊版继续唯一主来源；通用 code-finder 开关不是作者仓库证据 |
| 精确题名／DOI＋code、software、seed；GitHub域限定题名／DOI／作者查询 | 返回的公开搜索结果中未识别出可验证的本文作者生成仓库，无法给出固定 commit、文件、函数或行号。排除同名计算机视觉作者及其他 QR 软件结果 | 原作者随机流复现未解决，不否决已完整的数学生成律 |

结论是“**在已记录范围内仍未找到可验证的原作者生成脚本、固定 commit 或原始随机种子；部分官方页面访问未完成**”，不是“这些资产不存在”。本包 `seed=1729` 来自用户指定的小样本检查，绝不是论文报告种子。如后续要求作者随机流／原 MSE 或 MCMC 逐次结果复现，需可验证的作者代码归档／仓库固定版本及 RNG 设置；本轮未联系作者或维护人。

### 本包代码追溯与未决事项处置

`code_provenance.json` 记录 `generator.py`、`truth.py`、`verify.py` 的 SHA-256、函数／类名和实际行号。这些是本次独立编写实现，未取得、复制或执行外部作者程序，因此“外部仓库／固定 commit”对本地实现标为不适用，而原作者对应字段保持“经有范围调查仍未找到”。本包自身没有虚构 Git commit；封存版本由 ZIP、MANIFEST 和各文件 SHA-256 确定。

| 原缺项／待确认 | 本轮处置 | 是否仍影响数学机制完整 |
|---|---|---|
| 正式版本与章节定位 | 已解决：正式版仍为主来源；PDF13／1114未编号Models1–4；补充声明精确到PDF27／1128 | 否 |
| 所有变量、方差／尺度、依赖与边界是否完整写入包 | 已解决：上表及 collection.json 的 generation_order、observation_mechanisms 补全 | 否 |
| 作者脚本／commit／函数行号／seed | 仍未找到，具体查找范围与访问失败已落地 source_audit.json；本地实现另有哈希和行号 | 不影响数学机制；影响作者代码与随机流级复现 |
| 原作者代码许可 | 没有定位到可验证代码资产及许可；本包未复用它，不假定许可 | 否 |
| 本包自写代码再分发许可 | 仍待贡献者／维护人选择，无法通过原论文推定，本轮不替用户授予 | 否；属于归档／分发决定 |
| 有界X理论条件与χ²模拟差异 | 已精确记录并保留原机制；没有截断X或宣称全理论适用 | 不影响生成律定义；限制估计方法定理适用宣称 |
| 认领、全库查重、具名科学审核、另一人复现 | 非公开来源可自行补齐事项；维护人认领／查重、具名科学审核及另一人复现仍未完成 | 不影响本地数学定义；不代表科学接收 |
