"""Analytic conditional quantile, evaluated with standard-library binary64 math."""
import math
from statistics import NormalDist
import sys


def truth(config):
    """Scalar Q_tau(Y | X=x, Z=z), never fitted to simulated data."""
    tau = config["tau"]
    x, z = config["query"]["X"], config["query"]["Z"]
    a, bx, bz = config["location_coefficients"]
    mu, sd = config["error_normal_mean"], config["error_normal_sd"]
    values = (tau, x, z, a, bx, bz, mu, sd, config["scale_intercept"], config["scale_x"])
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)
               for v in values):
        raise ValueError("Target parameters must be finite numeric values")
    if not 0 < tau < 1 or sd <= 0 or x < 0 or z not in (0, config["z_multiplier"]):
        raise ValueError("Invalid quantile level, noise SD or query support")
    location = a + bx * x + bz * z
    scale = config["scale_intercept"] + config["scale_x"] * x
    if scale <= 0:
        raise ValueError("Positive error scale is required for this quantile formula")
    normal_q = NormalDist().inv_cdf(tau)
    if config["error_distribution"] == "normal":
        error_q = mu + sd * normal_q
        density = math.exp(-normal_q * normal_q / 2) / (sd * math.sqrt(2 * math.pi))
    elif config["error_distribution"] == "lognormal":
        error_q = math.exp(mu + sd * normal_q)
        density = math.exp(-normal_q * normal_q / 2) / (sd * error_q * math.sqrt(2 * math.pi))
    else:
        raise ValueError("Unsupported error distribution")
    value = location + scale * error_q
    conditional_density = density / scale
    if not math.isfinite(value) or conditional_density <= 0:
        raise ValueError("Unsupported numerical range")
    # Local roundoff/CDF residual diagnostic, NOT a rigorous error guarantee.
    residual = abs(NormalDist().cdf(normal_q) - tau)
    estimated_error = residual / conditional_density + 32 * sys.float_info.epsilon * (
        1.0 + abs(location) + abs(scale * error_q))
    return {
        "value": value, "estimated_error": estimated_error,
        "target": "inf{y: P(Y<=y | X=query.X,Z=query.Z)>=tau}",
        "tau": tau, "query": dict(config["query"]),
        "method": "Positive location-scale quantile transform; NormalDist.inv_cdf; exp for lognormal noise",
        "derivation": "Q_tau = a+bx*x+bz*z + (scale_intercept+scale_x*x)*F_e^{-1}(tau)",
        "conditional_density_at_quantile": conditional_density,
        "error_interpretation": "Binary64 CDF residual/density plus 32-epsilon roundoff diagnostic; not a certified bound. Decimal CDF inversion is implemented separately in verify.py. No Monte Carlo error."
    }
