"""Separate source CDF inversion + analytic median + deterministic equation checks.

No scipy, NormalDist or generator/truth helper is used in the reference solver.
The source equations and their interpretation are shared, not independently audited.
"""
from copy import deepcopy
from decimal import Decimal as D, localcontext
import importlib.util
import math
from pathlib import Path
import random
from unittest.mock import patch


PI = D("3.14159265358979323846264338327950288419716939937510582097494459230781640628620899")
VALUE_TOL = 1e-10  # Fixed before execution; same as collection.json.
CDF_TOL = D("1e-13")


def _load(name):
    path = Path(__file__).with_name(name + ".py")
    spec = importlib.util.spec_from_file_location("yang_he_verify_" + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _phi(t):
    """Integrate exp(-u^2/2) by its power series, in 70-digit arithmetic.

    Phi(t) = 1/2 + sum_k (-1)^k t^(2k+1)/(2^k k! (2k+1))/sqrt(2*pi).
    At |t|<=3 the terms decrease after the first few terms. Stop once a
    decreasing term is below 1e-60; this is a numerical truncation diagnostic.
    """
    if abs(t) > 3:
        raise ValueError("Independent normal CDF implemented only on [-3,3]")
    term, total = t, t
    for k in range(1, 300):
        term *= -t * t * D(2 * k - 1) / (D(2 * k) * D(2 * k + 1))
        total += term
        if k > 5 and abs(term) < D("1e-60"):
            return D("0.5") + total / (2 * PI).sqrt()
    raise ArithmeticError("Normal CDF series did not converge")


def _source_cdf(model, x, z, y):
    """Hard-code the four published laws separately from production config math."""
    scale = D(1) if model in (1, 2) else 1 + x / 2
    residual = (y - x - z) / scale
    if model in (1, 3):
        return _phi(residual / 2)
    if residual <= 0:
        return D(0)
    return _phi(residual.ln())


def _source_root(model, x, z, tau):
    with localcontext() as ctx:
        ctx.prec = 70
        x, z, tau = D(str(x)), D(str(z)), D(str(tau))
        scale = D(1) if model in (1, 2) else 1 + x / 2
        if model in (1, 3):
            lo, hi = x + z - 5 * scale, x + z + 5 * scale
        else:
            lo, hi = x + z + scale * D("-2.5").exp(), x + z + scale * D("2.5").exp()
        flo, fhi = _source_cdf(model, x, z, lo), _source_cdf(model, x, z, hi)
        if not flo < tau < fhi:
            raise ValueError("Target outside the independent reference bracket")
        for _ in range(200):
            mid = (lo + hi) / 2
            if _source_cdf(model, x, z, mid) < tau:
                lo = mid
            else:
                hi = mid
            if hi - lo < D("1e-45"):
                break
        return (lo + hi) / 2, hi - lo


class _ScriptedRNG:
    """Known primitive draws test the exact generator transformation, not sampling."""
    def __init__(self):
        self.x = iter((2.0, 4.0, 6.0))
        self.u = iter((0.25, 0.75, 0.1))
        self.standard = iter((-1.0, 0.0, 1.0))
        self.gamma_calls, self.normal_calls = [], []

    def gammavariate(self, shape, scale):
        self.gamma_calls.append((shape, scale))
        return next(self.x)

    def random(self):
        return next(self.u)

    def gauss(self, mean, sd):
        self.normal_calls.append((mean, sd))
        return mean + sd * next(self.standard)


def verify(config):
    model = config["model"]
    if model not in (1, 2, 3, 4):
        return {"passed": False, "checks": [{"name": "source_model", "passed": False,
                "details": "Only published Models 1--4 are declared"}]}
    normal = model in (1, 3)
    fixture = {
        "x_df": 2, "z_probability": 0.5, "z_multiplier": 2,
        "location_coefficients": [0, 1, 1], "error_normal_mean": 0,
        "error_normal_sd": 2 if normal else 1,
        "error_distribution": "normal" if normal else "lognormal",
        "scale_intercept": 1, "scale_x": 0 if model in (1, 2) else 0.5,
        "tau": 0.95, "query": {"X": 2, "Z": 0}
    }
    checks = [{"name": "published_constants_and_declared_adaptation",
               "passed": all(config.get(k) == v for k, v in fixture.items()),
               "details": "Published p.1114; Z in {0,2}, normal variance 4, uncentered lognormal, fixed tau=.95 and query=(2,0) adaptation."}]
    oracle, gen = _load("truth"), _load("generator")
    reference = oracle.truth(deepcopy(config))
    root, width = _source_root(model, 2, 0, 0.95)
    with localcontext() as ctx:
        ctx.prec = 70
        absolute_error = abs(D.from_float(reference["value"]) - root)
        cdf_residual = abs(_source_cdf(model, D(2), D(0), D.from_float(reference["value"])) - D("0.95"))
    checks.extend([
        {"name": "independent_decimal_conditional_cdf_inversion",
         "passed": absolute_error < D(str(VALUE_TOL)),
         "details": f"70-digit Decimal CDF series plus Y-scale bisection: root={root}; float absolute difference={absolute_error}; tolerance={VALUE_TOL}."},
        {"name": "reference_solver_precision",
         "passed": width < D("1e-45"),
         "details": f"Final numerical bracket width={width}; CDF series stopping term<1e-60. Diagnostic, not interval-arithmetic certification."},
        {"name": "independent_cdf_at_reported_quantile",
         "passed": cdf_residual < CDF_TOL,
         "details": f"Absolute conditional-CDF residual against exact decimal .95={cdf_residual}; tolerance={CDF_TOL}."},
        {"name": "reported_error_covers_observed_difference",
         "passed": absolute_error <= D.from_float(reference["estimated_error"]),
         "details": "Compare the production roundoff diagnostic with the observed independent root discrepancy; this is not a general error bound."}
    ])
    # Temporary analytic special case; it does not add a declared benchmark scenario.
    median_config = deepcopy(config)
    median_config["tau"] = 0.5
    source_scale = 1 if model in (1, 2) else 2
    exact_median = 2 if normal else 2 + source_scale
    median = oracle.truth(median_config)["value"]
    median_root, _ = _source_root(model, 2, 0, 0.5)
    checks.append({"name": "analytic_median_special_case", "passed":
                   abs(median - exact_median) < 1e-12 and abs(median_root - D(exact_median)) < D("1e-40"),
                   "details": f"Normal error median=0; lognormal error median=1; exact conditional median={exact_median}; oracle={median}. tau=.5 is a verification-only special case."})
    scripted = _ScriptedRNG()
    with patch.object(gen.random, "Random", return_value=scripted):
        actual = gen.generate(deepcopy(config), 3, 1729)
    noise = (-2.0, 0.0, 2.0) if normal else (math.exp(-1), 1.0, math.exp(1))
    expected_y = [x + z + (1 if model in (1, 2) else 1 + x / 2) * e
                  for x, z, e in zip((2, 4, 6), (2, 0, 2), noise)]
    transformation_ok = (set(actual) == {"X", "Z", "Y"}
                         and actual["X"] == [2.0, 4.0, 6.0] and actual["Z"] == [2, 0, 2]
                         and len(actual["Y"]) == 3
                         and all(abs(y - target) < 1e-12 for y, target in zip(actual["Y"], expected_y))
                         and scripted.gamma_calls == [(1.0, 2.0)] * 3
                         and scripted.normal_calls == [(0, 2 if normal else 1)] * 3)
    checks.append({"name": "generator_source_equations_and_noise_scale", "passed": transformation_ok,
                   "details": "Scripted Gamma/uniform/normal draws verify source parameters, Z coding, all response transformations and observed-only output. Uses math.exp in both sides for this check only; does not test RNG distribution statistically."})
    before_config, before_random = deepcopy(config), random.getstate()
    data = gen.generate(config, 128, 1729)
    checks.append({"name": "local_rng_and_input_immutability", "passed":
                   before_config == config and before_random == random.getstate(),
                   "details": "A real 128-row draw leaves the Python global RNG state and selected config unchanged."})
    residuals = [(y - x - z) / (1 if model in (1, 2) else 1 + x / 2)
                 for x, z, y in zip(data["X"], data["Z"], data["Y"])]
    checks.append({"name": "observed_support_and_lognormal_positivity", "passed":
                   all(x >= 0 for x in data["X"]) and set(data["Z"]) == {0, 2}
                   and (normal or all(e > 0 for e in residuals)),
                   "details": "For seed 1729, both Z support points are observed; X is nonnegative and lognormal standardized residuals are strictly positive."})
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "independent_value_decimal": str(root), "absolute_difference": float(absolute_error),
            "shared_components": "Both routes share the published equations and author interpretation. The reference uses separately hard-coded source laws, Decimal power-series CDF and bisection; production uses NormalDist.inv_cdf and math.exp. Scripted generator checks share math.exp. All code was written in this contribution with AI assistance, not by an independent named reproducer. Scalar truth checks do not assess CI coverage or simultaneous bands."}
