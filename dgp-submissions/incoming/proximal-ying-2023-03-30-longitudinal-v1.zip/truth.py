def truth(config):
    y=config['y'];a0_effect=y[2]+y[3]*config['x1'][1]+y[4]*config['u1'][1]
    if abs(a0_effect-y[1])>1e-12:raise ValueError("Common-coefficient MSM is not valid for this configuration")
    intercept=y[0]+y[3]*(config['x1'][0]+config['x1'][2]*config['x0_mean'])+y[4]*(config['u1'][0]+config['u1'][2]*config['u0_mean'])+y[5]*config['x0_mean']+y[6]*config['u0_mean']
    return {"value":float(y[1]),"estimated_error":0.,"method":"Analytic structural marginalization; coefficient on both a0 and a1","target":"MSM beta1","auxiliary":{"beta0":float(intercept),"joint_11_minus_00":float(a0_effect+y[1])},"error_interpretation":"The primary value is analytic; no numerical integration or simulation error is involved."}
