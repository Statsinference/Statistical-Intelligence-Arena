import itertools
import numpy as np
from numpy.polynomial.hermite import hermgauss
from numpy.polynomial.legendre import leggauss
from generator import generate, _draw
from truth import truth


def verify(config):
    checks=[]
    def equal(name,observed,expected,tol=1e-10):
        error=float(np.max(np.abs(np.asarray(observed)-np.asarray(expected))))
        checks.append({"name":name,"passed":bool(np.isfinite(error) and error<=tol),"details":{"max_absolute_error":error,"tolerance":float(tol)}})
    def mc(name,values,expected):
        v=np.asarray(values);se=float(v.std(ddof=1)/np.sqrt(v.size))
        equal(name,v.mean(),expected,max(1e-12,6*se))
    c=config
    expected=dict(SOURCE_ANCHOR)
    if 'beta' in expected:expected['beta']=c['beta']
    checks.append({"name":"fixed_source_parameter_anchor","passed":c==expected,"details":"Config matches the fixed parameter transcription. This catches later edits but cannot detect an error in the original transcription."})
    # Integrate the four exogenous normals without calling the generator.
    q,w=hermgauss(5);w=w/np.sqrt(np.pi);z=np.sqrt(2)*.5*q
    means={}
    for a0,a1 in itertools.product([0,1],repeat=2):
        total=0.
        for i,j,k,l in itertools.product(range(5),repeat=4):
            x0=-.35+z[i];u0=.35+z[j]
            x1=.2+.7*a0+.7*x0+z[k];u1=.2+.7*a0+.7*u0+z[l]
            ey=-1.3+a1+1.14*a0+.5*x1-.7*u1+.2*x0-.7*u0
            total+=w[i]*w[j]*w[k]*w[l]*ey
        means[(a0,a1)]=total
        equal('quadrature_regime_'+str(a0)+str(a1),total,-1.949+a0+a1)
    equal('MSM_beta1_first_time',means[(1,0)]-means[(0,0)],truth(c)['value'])
    equal('MSM_beta1_second_time',means[(0,1)]-means[(0,0)],truth(c)['value'])
    equal('joint_regime_effect',means[(1,1)]-means[(0,0)],2)
    # Set the direct A0 coefficient to .14 to check a zero total A0 effect.
    equal('zero_A0_total_path_special_case',.14+.5*.7-.7*.7,0)
    k=14/17;r=119/95;errors=[]
    for x0,u0,a0,a1 in itertools.product([-.5,.2],[.1,.8],[0,1],[0,1]):
        x1=.2+.7*a0+.7*x0;u1=.2+.7*a0+.7*u0
        ew1=.35+.45*(x0+x1)-.85*(u0+u1)
        h1=-1.3-.35*k+a1+1.14*a0+(.5-.45*k)*x1+(.2-.45*k)*x0+k*ew1
        ey=-1.3+a1+1.14*a0+.5*x1-.7*u1+.2*x0-.7*u0
        ew0=.2+.5*x0-.95*u0
        h0=-1.34-.2*r+a0+a1+(.55-.5*r)*x0+r*ew0
        errors.extend([h1-ey,h0-ey])
    equal('sequential_outcome_bridge_identities',errors,0)
    d=_draw(c,65536,np.random.default_rng(314160))
    p0=1/(1+np.exp(.5-.35*d['X0']+.35*d['U0']))
    p1=1/(1+np.exp(.5-.5*d['A0']-.35*(d['X0']+d['X1'])-.35*(d['U0']+d['U1'])))
    for name,p,a in [('A0',p0,d['A0']),('A1',p1,d['A1'])]:
        for covname,cov in [('intercept',np.ones(len(a))),('X0',d['X0']),('U0',d['U0'])]:
            mc('source_probability_score_'+name+'_'+covname,(a-p)*cov,0)
    mc('X1_transition_mean',d['X1']-.2-.7*d['A0']-.7*d['X0'],0)
    mc('U1_transition_mean',d['U1']-.2-.7*d['A0']-.7*d['U0'],0)
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'shared_components':'Every check uses the same transcribed source model. The structural, enumeration and quadrature calculations run separately from the generator; sample-moment tests call it. Independent review of the source transcription is still required.',
            'limits':'Finite grids and simulation checks cannot establish identification, behavior in the tails, or estimator coverage. Tolerances were set in advance. Null-path tests are diagnostic cases, not new scenarios.'}

SOURCE_ANCHOR = {'x0_mean': -0.35, 'u0_mean': 0.35, 'noise_sd': 0.5, 'a0_logit': [-0.5, 0.35, -0.35], 'z0': [0.2, 0.5, 0.5, 0.75], 'w0': [0.2, 0.5, -0.95], 'x1': [0.2, 0.7, 0.7], 'u1': [0.2, 0.7, 0.7], 'a1_logit': [-0.5, 0.5, 0.35, 0.35], 'z1': [0.2, 0.5, 0.5, -0.75], 'w1': [0.35, 0.45, -0.85], 'y': [-1.3, 1, 1.14, 0.5, -0.7, 0.2, -0.7]}
