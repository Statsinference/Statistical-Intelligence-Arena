"""Separate coupled-potential construction and null tests."""
import math,random,importlib.util
from copy import deepcopy
from pathlib import Path
def _t(c):
    s=importlib.util.spec_from_file_location('xia_t',Path(__file__).with_name('truth.py')); m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m.truth(c)['value']
def verify(c):
    # Three-point Gauss-Hermite rule for N(0,1) is exact for cubic polynomials.
    # Enumerating coupled potential outcomes at 3^3 nodes gives a deterministic,
    # high-precision check without copying truth.py's closed-form expression.
    nodes=((-math.sqrt(3),1/6),(0.,2/3),(math.sqrt(3),1/6))
    est=0.
    for zx,wx in nodes:
      for zm,wm in nodes:
        for zc,wc in nodes:
          x=c['x_sd']*zx
          em=zm
          ec=c['copula_rho']*zm+math.sqrt(1-c['copula_rho']**2)*zc
          m0=c['m_intercept']+c['m_x']*x+c['m_sd']*em
          c0=c['c_intercept']+c['c_x']*x+c['c_sd']*ec
          c1=c['c_intercept']+c['c_a']+c['c_x']*x+c['c_sd']*ec
          def y(a,cc):return c['y_intercept']+c['y_a']*a+c['y_m']*m0+c['y_c']*cc+c['y_x']*x+c['y_ac']*a*cc+c['y_am']*a*m0
          est+=wx*wm*wc*(y(1,c1)-y(0,c0))
    z=_t(c);null=deepcopy(c);null['y_a']=null['c_a']=null['y_ac']=null['y_am']=0.
    checks=[{'name':'independent_coupled_potential_quadrature','passed':abs(est-z)<1e-10,'details':f'27-node deterministic paired-potential quadrature={est:.12g}; analytic={z:.12g}; tolerance 1e-10.'},{'name':'zero_direct_paths','passed':abs(_t(null))<1e-12,'details':'All A->Y and A->C->Y direct paths removed.'},{'name':'source_constants','passed':c['copula_rho']==.2 and c['m_sd']==5 and c['c_sd']==4 and c['y_ac']==4 and c['y_am']==2,'details':'Section 4.1 constants.'}]
    return {'passed':all(t['passed'] for t in checks),'checks':checks,'shared_components':'Independent 27-node deterministic coupled-potential quadrature versus analytic expression; paper source PDF checked separately.'}
