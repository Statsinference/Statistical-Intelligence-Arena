# Continuous treatment-induced confounding (Xia & Chan, 2023)

**Status:** local candidate; named human scientific review pending.

## 1. Source and source version

Source: https://doi.org/10.1080/01621459.2021.1990765; author manuscript https://par.nsf.gov/servlets/purl/10300663 §4.1 continuous C and M.

## 2. Generating mechanism

X~N(0,1), A|X~Bern(expit(-0.4+0.6X)); conditional Gaussian copula for M,C has correlation 0.2, with M=3+2A+4X+5E_M, C=1+2A+2X+4E_C. Y=1+2A+2M+3C+5X+4AC+2AM+epsilon, epsilon~N(0,4²).

## 3. Causal target and population truth

Under the specified coupled structural errors, NDE=E[Y(1,M(0))-Y(0,M(0))]=2+3(2)+4(1+2)+2(3)=26 exactly. The manuscript reports **26.01**. Its statement at this location does not establish why the reported number differs by 0.01; Monte Carlo rounding is possible but unconfirmed. This package labels 26 as a value **derived from the displayed structural equations**, not as the paper's quoted truth. A deterministic 27-node coupled-potential quadrature independently reproduces 26 to `1e-10`.

## 4. Changes, checks and limits

Changes: mathematically equivalent correlated-normal implementation of the Gaussian copula; sample size is an interface input; estimation-model misspecification experiments omitted. No manuscript PDF redistributed. AI-assisted transcription requires human scientific review.

## 5. Rights and AI assistance

This ZIP contains an independent Python implementation and source references. The paper PDF and author code are not redistributed. Codex assisted with source transcription, derivation, implementation and this card. `collect.py check --run` verifies the local interface and contributor-supplied mathematical checks; it does not confer scientific acceptance. A named human reviewer must compare all equations, parameters, estimand interpretation, and stated changes against the cited original before submission.
