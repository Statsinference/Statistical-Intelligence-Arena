"""Analytic natural direct effect from coupled Gaussian potentials."""
def truth(c):
    ec1=c['c_intercept']+c['c_a']
    em0=c['m_intercept']
    val=c['y_a']+c['y_c']*c['c_a']+c['y_ac']*ec1+c['y_am']*em0
    return {'value':float(val),'estimated_error':0.0,'method':'Exact potential-outcome expectation; mean X and errors are zero.','target':'NDE=E[Y(1,M(0))-Y(0,M(0))]'}
