Candidate T06 contribution; scientific review pending.
