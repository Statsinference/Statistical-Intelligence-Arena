# 相关高维正态特征与稀疏线性结果

Contributor: 张佳怡. Task family: ate. Status: runnable candidate pending named scientific review and independent-person reproduction.

## Source and version

Yang Ning, Sida Peng and Kosuke Imai (2020). Robust estimation of causal effects via a high-dimensional covariate balancing propensity score. Biometrika 107(3):533–554. DOI: https://doi.org/10.1093/biomet/asaa020.
Actual reading version: Published typeset article, DOI asaa020, 22-page author-hosted copy.
Source URL: https://imai.fas.harvard.edu/research/files/hdCBPS.pdf
Exact location: Section 5, PDF pp.17–18; journal pp.549–550; unnumbered covariate, propensity and two linear potential-outcome equations; scenario (A), Table 1
Locators use one-based PDF page numbers. Journal page numbers are separately labeled; supplement pages are not main-paper pages.
Local verification source SHA-256: 1311f084288118755cd97366d456deb32ce5a65573eaee2915d02a008286a62e. The source PDF is retained outside the submission ZIP.
Version and scope differences: Published typeset copy used directly; arXiv draft was not used for implementation. Only original linear scenario (A) is collected; scenarios (B)–(D) and binary outcomes are not included.
No author software is copied or used to fill parameters. Repository/file/function/commit citations are therefore not applicable; all implementations are independently written from the cited equations.

## Original generation order and fixed parameters

1. X ~ N_d(0,Sigma), Sigma[j,k]=rho**abs(j-k), rho=0.5.
2. s=-X1+X2/2-X3/4-X4/10-X5/10+X6/10; p=1-1/(1+exp(s))=expit(s); A|X~Bernoulli(p).
3. Y(1)=2+0.137*(X5+X6+X7+X8)+epsilon1; Y(0)=1+0.291*(X5+X6+X7+X8+X9+X10)+epsilon0.
4. epsilon0,epsilon1 iid N(0,1), independent of X and treatment randomization; Y=A*Y(1)+(1-A)*Y(0).

Fixed configuration: `{"dimension": 1000, "rho": 0.5, "propensity_coefficients": [-1, 0.5, -0.25, -0.1, -0.1, 0.1], "intercept_control": 1.0, "intercept_treated": 2.0, "coefficient_control": 0.291, "coefficient_treated": 0.137, "noise_sd": 1.0}`.
Original source sample size is recorded in collection.json as context. The generate interface deliberately accepts n and seed, and the required smoke check uses n=128; this is not a recreation of the paper's estimator performance experiments.
Sampling units are independent individuals, with no interference, clusters, panels, or shared random coefficients. Random draws for treatment and noise are independent conditional on the generated covariates. Within-person covariate dependence follows the equations above. Potential-outcome residual coupling that is not specified by a source is not inferred: the generator implements its observed conditional law without claiming a unique joint counterfactual law.
AR(1) innovations are an exact O(n*d) factorization of the stated covariance, avoiding a dense d-by-d Cholesky. The submitted fixed schema uses original d=1000. Table 1 also contains d=2000, but that is not exported as an incompatible second-schema scenario and is not counted as another mechanism.

## Target and identification

Population ATE = E[Y(1)-Y(0)] under the declared full covariate distribution, with treatment levels 1 versus 0. This is not ATT, a trimmed/overlap population, a sample-average realized effect, or a fixed-point CATE. No outcome-dependent sample selection or missingness is introduced.
Identification requires consistency, no interference, conditional exchangeability of treatment and potential outcomes given observed X, and positivity. These are part of the synthetic scientific model, not inferred from machine PASS. For Gaussian logistic mechanisms positivity holds pointwise but there is no uniform overlap bound over unbounded support. No propensity clipping is added unless it is part of the cited original equation.

## Population truth and independent verification

E[Xj]=0 and E[epsilon_a]=0. Therefore E[Y(1)]=2 and E[Y(0)]=1, so ATE=1. Correlation changes efficiency, not these marginal means.
truth.py returns value, estimated_error and method separately from generated rows. verify.py uses independent scalar source fixtures and a separate analytic/numerical integration route, integrates the implemented arm contrast, and checks assignment, covariate and noise distributions. Statistical diagnostics use fixed seeds and explicit broad six-standard-error criteria; they are not coverage tests or mathematical proofs. Gaussian-tail truncation and order-refinement estimates are numerical diagnostics, not uniform error bounds.
The verifier shares the declared scientific equations, configuration, NumPy and the same AI author with the generator. Independent numerical routes reduce implementation risk but do not constitute independent-person reproduction. No named human scientific review is claimed.

## Mechanism identity and properties

d=1000 or 2000 against source n=500 is high-dimensional. The conditional laws directly use X1–X10 only; other coordinates are correlated, not independent noise padding. AR(1) dependence is within each person; people are independent. Logistic assignment is nonlinear; combining arm-specific means gives A*X5–X10 interactions.
Canonical mechanism family: ning_linear. It is distinguished by its covariate law and/or functional treatment/outcome/noise structure, not by seed, sample size or a mere coefficient change. Source scenarios with the same functional structure are grouped. The final family count is subject to the maintainer's scientific interpretation, with full equations provided for review.

## Adaptations and boundaries

- Source treatment indicator is named A in the observed output; no scientific change.
- Independently implemented Python/NumPy sampler; source estimator fitting and large simulation replications are outside this collection task.

RNG is local numpy.random.default_rng(seed); identical seeds reproduce under the recorded Python/NumPy environment. Exact bitwise reproducibility across arbitrary dependency upgrades is not promised. Stable expit/logaddexp implementations are algebraic evaluations, not scientific changes. No clipping of Gaussian covariates, deletion of extreme rows, winsorization or silent finite-value replacement is used. Nonfinite outputs raise errors. Binary treatment is generated without forcing a fixed group size or resampling a missing arm.

## Rights, AI assistance and unresolved review

The scientific equations are attributed to their authors; paper copyrights remain with their respective rights holders. Paper PDFs, author software and original personal records are not redistributed in the ZIP. Implementation licensing is reserved for contributor/maintainer confirmation; no third-party code license is presumed from public accessibility.
AI assistance: literature discovery, source extraction and visual equation review, implementation, analytic derivation, numerical cross-checking, packaging and report drafting. Contributor review is still required before upload. Scientific acceptance, a separate human reproducer, project-wide deduplication and PR checks remain external steps. The local package does not assert any of those outcomes.


## Final source audit
AI source audit completed against the exact local source version and source_map.json. Human scientific acceptance and independent-person reproduction are not claimed. Dependencies are pinned to NumPy 2.3.5; only the original source scenario is registered.
