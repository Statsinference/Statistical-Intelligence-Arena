"""Authoritative independent G01 checks; testing-only primitive trace, no latent export."""
import copy
import hashlib
import json
import math
from pathlib import Path
import random
import statistics as st
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import generator
from truth import truth
from verify import verify
CONFIG = json.loads((ROOT / "config.json").read_text())["scenarios"]["section6_main"]
BASE_RANDOM = random.Random
DIAGNOSTICS = []
TRACE_CHECK = {}

class Trace:
    def __init__(self, seed):
        self.base = BASE_RANDOM(seed)
        self.calls = []
    def gauss(self, a, b):
        v = self.base.gauss(a,b)
        self.calls.append(("g",v))
        return v
    def random(self):
        v = self.base.random()
        self.calls.append(("r",v))
        return v

def mean(x):
    return math.fsum(x)/len(x)

def cov(x,y):
    mx,my=mean(x),mean(y)
    return math.fsum((a-mx)*(b-my) for a,b in zip(x,y))/len(x)

def judge(name,value,target,tolerance):
    d={"name":name,"value":value,"target":target,"absolute_tolerance":tolerance,"passed":abs(value-target)<=tolerance}
    DIAGNOSTICS.append(d)
    if not d["passed"]:
        raise AssertionError(str(d))

def independent_rows(calls):
    # Different inverse-CDF expression and logistic parameterization from generator.
    rows=[];latent=[]
    for i in range(0,len(calls),10):
        block=calls[i:i+10]
        if [x[0] for x in block] != ["g","g","r","r","r","r","r","r","g","g"]:
            raise AssertionError("unexpected primitive draw schedule")
        x1,x2,vz,vt,vu0,vu1,va0,va1,e0,e1=[x[1] for x in block]
        z=int(vz<.5);t=int(vt<.5)
        u0=2*math.asinh(math.tan(math.pi*(vu0-.5)))
        u1=2*math.asinh(math.tan(math.pi*(vu1-.5)))
        p0=(1+math.tanh((2-7*z+.2*u0+2*x1)/2))/2
        p1=(1+math.tanh((-1.5+5*z-.15*u1+1.5*x2)/2))/2
        a0=int(va0<p0);a1=int(va1<p1)
        ys=[200+5*u0+20*z+15*x1+20*x2+a0*(-5+15*x1+20*x2)+e0,
            240+5*u1+20*z+20*x1+15*x2+a1*(-5+15*x1+20*x2)+e1]
        rows.append((x1,x2,z,t,[a0,a1][t],ys[t]))
        latent.append((x1,x2,u0,u1,e0,e1,z,t,a0-p0,a1-p1,-5+15*x1+20*x2))
    return rows,latent

class G01Tests(unittest.TestCase):
    def test_01_interface_seed_and_observed(self):
        for n in [1,32,5000]:
            a=generator.generate(copy.deepcopy(CONFIG),n,1729)
            self.assertEqual(list(a),["X1","X2","Z","T","A","Y"])
            self.assertTrue(all(len(v)==n and all(math.isfinite(x) for x in v) for v in a.values()))
            self.assertTrue(all(x in (0,1) for k in ["Z","T","A"] for x in a[k]))
            self.assertEqual(a,generator.generate(copy.deepcopy(CONFIG),n,1729))
            self.assertNotEqual(a,generator.generate(copy.deepcopy(CONFIG),n,1730))
        before=random.getstate()
        generator.generate(CONFIG,32,99)
        self.assertEqual(before,random.getstate())

    def test_02_invalid_input_and_no_config_mutation(self):
        frozen=copy.deepcopy(CONFIG)
        for n in [0,-1,True,2.5,"32"]:
            with self.assertRaises(ValueError): generator.generate(CONFIG,n,1)
        for seed in [None,False,1.2]:
            with self.assertRaises(ValueError): generator.generate(CONFIG,32,seed)
        for key,new in [("bridge_phi",.4),("a0_coefficients",[0,0,0,0]),("outcome_error_sd",2),("estimand","ATT")]:
            changed=copy.deepcopy(CONFIG);changed[key]=new
            with self.assertRaises(ValueError):generator.generate(changed,32,1)
        self.assertEqual(CONFIG,frozen)

    def test_03_inverse_CDF_density_and_moments(self):
        # Derivative of independently written CDF compared with source density.
        for v in [.0001,.01,.1,.25,.5,.75,.9,.99,.9999]:
            u=2*math.log(math.sin(math.pi*v/2)/math.sin(math.pi*(1-v)/2))
            p=2/math.pi*math.atan(math.exp(u/2))
            self.assertAlmostEqual(p,v,places=13)
            h=1e-5
            diff=(2/math.pi*math.atan(math.exp((u+h)/2))-2/math.pi*math.atan(math.exp((u-h)/2)))/(2*h)
            self.assertAlmostEqual(diff,1/(2*math.pi*math.cosh(u/2)),places=9)
        self.assertAlmostEqual(math.pi**2*((.5)**-2-1)/3,math.pi**2)

    def test_04_primitive_reconstruction_and_statistics(self):
        n=65536; trace=Trace(381902)
        with patch.object(generator.random,"Random",return_value=trace):
            out=generator.generate(CONFIG,n,381902)
        rows, latent=independent_rows(trace.calls)
        maxerr=0.0
        for i,row in enumerate(rows):
            for k,x in zip(out,row):
                self.assertAlmostEqual(out[k][i],x,delta=2e-8)
                maxerr=max(maxerr,abs(out[k][i]-x))
        TRACE_CHECK.update({"rows":n,"primitive_draws":len(trace.calls),"max_observed_reconstruction_error":maxerr,"tolerance":2e-8,"passed":maxerr<2e-8})
        vectors=list(zip(*latent));names=["X1","X2","U0","U1","e0","e1","Z","T","A0_score","A1_score","conditional_tau"]
        for j,name in enumerate(names[:6]):
            judge(name+" mean",mean(vectors[j]),0,.06 if j in (2,3) else .025)
            judge(name+" variance",cov(vectors[j],vectors[j]),math.pi**2 if j in (2,3) else 1,.5 if j in (2,3) else .04)
        for a,b in [(0,1),(2,3),(4,5),(0,4),(1,4),(2,4),(3,5),(2,0),(3,1)]:
            judge(names[a]+"/"+names[b]+" covariance",cov(vectors[a],vectors[b]),0,.13 if a in(2,3) or b in(2,3) else .035)
        for j in [6,7]:judge(names[j]+" fraction",mean(vectors[j]),.5,.012)
        judge("Z/T covariance",cov(vectors[6],vectors[7]),0,.008)
        for j in [8,9]:
            judge(names[j]+" mean",mean(vectors[j]),0,.012)
            for k in [0,1,2,3]:judge(names[j]+"/"+names[k]+" moment",mean([a*b for a,b in zip(vectors[j],vectors[k])]),0,.04)
        judge("finite mean conditional effect (not fixed truth)",mean(vectors[10]),-5,.4)
        judge("heterogeneous conditional effect variance",cov(vectors[10],vectors[10]),625,22)
        self.assertNotEqual(mean(vectors[10]),-5)
        self.assertEqual(truth(CONFIG)["value"],-5)

    def test_05_independent_analytic_truth(self):
        self.assertTrue(verify(CONFIG)["passed"])
        # Independently integrate intervention mean differences by symmetric Gaussian law.
        for t in [0,1]:
            for x1,x2,z,u in [(0,0,0,0),(1,-2,1,3),(-3,2,1,-1)]:
                baseline=[200+15*x1+20*x2,240+20*x1+15*x2][t]+20*z+5*u
                mu1=baseline-5+15*x1+20*x2
                self.assertEqual(mu1-baseline,15*x1+20*x2-5)
        self.assertEqual(sum([-5+15*x+20*y for x,y in [(1,1),(1,-1),(-1,1),(-1,-1)]])/4,-5)
        self.assertNotIn("generator",Path(ROOT/"verify.py").read_text().split("from fractions")[1])

if __name__=="__main__":
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(G01Tests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        files=["collection.json","card.md","config.json","schema.csv","generator.py","truth.py","verify.py","requirements.txt","tests/test_g01.py"]
        audit={"passed":True,"tests_run":result.testsRun,"failures":0,"errors":0,"scope":"independent specification, interface, finite statistical diagnostics; no estimator/PFN training, no author code execution", "scenario":"section6_main","source_sha256":{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files},"primitive_trace_reconstruction":TRACE_CHECK,"diagnostics":DIAGNOSTICS,"statistical_judgments":len(DIAGNOSTICS),"analytic_population_ATE":-5,"interface_sample_sizes_actually_executed":[1,32,5000],"finite_mean_conditional_effect_is_random":True}
        (ROOT/"checks"/"independent_audit.json").write_text(json.dumps(audit,indent=2)+"\n",encoding="utf8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
