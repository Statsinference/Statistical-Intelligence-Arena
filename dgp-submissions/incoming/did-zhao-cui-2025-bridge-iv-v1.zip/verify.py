"""Independent symbolic conditional-mean contrast; no generator/truth imports."""
from fractions import Fraction as Q
import math

def verify(config):
    # Separate coefficient tables [constant,X1,X2,U,Z] for intervention means.
    m00 = [Q(200), Q(15), Q(20), Q(5), Q(20)]
    m01 = [Q(195), Q(30), Q(40), Q(5), Q(20)]
    m10 = [Q(240), Q(20), Q(15), Q(5), Q(20)]
    m11 = [Q(235), Q(35), Q(35), Q(5), Q(20)]
    d0 = [a-b for a,b in zip(m01,m00)]
    d1 = [a-b for a,b in zip(m11,m10)]
    expected = [Q(-5), Q(15), Q(20), Q(0), Q(0)]
    checks = [
      {"name":"period0 rational intervention-mean contrast", "passed": d0 == expected, "coefficients":[str(v) for v in d0]},
      {"name":"period1 rational intervention-mean contrast and stable CATE", "passed": d1 == expected},
      {"name":"population integration by normal symmetry", "passed": d0[0] == -5 and d0[3:] == [0,0], "value":float(d0[0]),"details":"Both Gaussian covariate means are zero; no independence of treatment is needed for population integration."},
      {"name":"bridge analytic CDF identity and median (not numerical derivative)", "passed": math.isclose(2/math.pi*math.atan(math.exp(0)),.5),"details":"F(u)=2/pi atan(exp(u/2)); derivative1/(2pi cosh(u/2)); limits0,1. Symmetry gives mean0 and variance pi^2."},
      {"name":"declared baseline scalar target", "passed": config.get("estimand")=="population_ATE" and config.get("bridge_phi")==.5 and config.get("cate_coefficients")==[-.5,1.5,2] and config.get("outcome_scale")==10}
    ]
    return {"passed":all(x["passed"] for x in checks),"checks":checks,"scope":"Mathematical mean truth only; does not inspect generated rows, sample pairing or empirical moments"}
