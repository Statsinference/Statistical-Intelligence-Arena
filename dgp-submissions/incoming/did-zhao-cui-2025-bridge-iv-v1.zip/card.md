# G01: repeated-cross-sectional instrumented DiD with bridge confounding

## Source and scope
Pan Zhao and Yifan Cui (2025), *A semiparametric instrumented difference-in-differences approach to policy learning*, Biometrika112(4),asaf043, DOI https://doi.org/10.1093/biomet/asaf043.
Formal published PDF pp11-12, Section6 has unnumbered DGP displays. Section2 pp4-5 defines the time-stable CATE; Section4 p8 uses the population E[deltaY(X)/deltaA(X)] building block. Supplement2.pdf SectionL pp21-22 retains the same DGP. No new calibrations or initial conditions are needed.
Formal PDF mirror: https://api.repository.cam.ac.uk/server/api/core/bitstreams/f53daf21-4f51-4cd4-8ca7-197da497310e/content
Author main.R6-28: https://github.com/panzhaooo/policy-learning-instrumented-DiD/blob/11f92f2c29316810531935985a981b567b8abab5/simulation/main.R . Its driver sets n=5000 for parametric estimators, n=10000 for machine learning. main.R function default1000 is not the paper main baseline. Source code and formal paper agree on the generation parameters. The repository predates publication; a full editorial-history diff is not claimed.

## Complete observed-data law
Independently across rows draw X1,X2 iid N(0,1), Z,T iid Bernoulli(.5), U0,U1 iid bridge(phi=.5). The bridge density is f(u)=1/[2*pi*cosh(u/2)], CDF F(u)=2/pi*atan(exp(u/2)), mean0, variance pi^2. Independent uniform draws V generate U=2log(tan(pi*V/2)). Exclude exact machine endpoint0 by redraw, no clipping/truncation of tails.
```
p0=expit(2-7Z+0.2U0+2X1)
p1=expit(-1.5+5Z-0.15U1+1.5X2)
A0~Bernoulli(p0), A1~Bernoulli(p1)
s(X)=1.5X1+2X2-0.5
Y0=200+10[A0*s(X)+0.5U0+2Z+1.5X1+2X2]+e0
Y1=240+10[A1*s(X)+0.5U1+2Z+2X1+1.5X2]+e1
e0,e1 iid N(0,1)
A=T*A1+(1-T)*A0; Y=T*Y1+(1-T)*Y0
```
All baseline/exogenous draws and Bernoulli/normal innovations are independent except for dependence shown in equations. Only X1,X2,Z,T,A,Y are returned; U,errors,A0,A1,Y0,Y1,CATE and policies are not exported. T is an observation-period indicator, not treatment. Z is a random instrument, not the exposure. No donor, panel pairing, time series initialization or burn-in exists.
The cross-time joint coupling is supplied by independent R RNG calls; the observed-data law is one cross-section per individual. We do not infer a unique cross-world distribution of individual potential-outcome errors from marginal normals.

## Scalar estimand and independent truth
Target population: the Section6 Gaussian baseline population, averaging over its natural U and Z; either t=0 or1. Define tau_t(x)=E[Y_t(1)-Y_t(0)|X=x]=10*s(x). The scalar contribution target is ATE=E[tau_t(X)]=-5. This is the article Section4 population-average causal building block, not the article performance metric PCD or an estimated policy value. Conditional intervention mean subtraction cancels intercept,U,Z and baseline-X terms; Gaussian symmetry integrates both X means to0. `truth` reports value-5,error0. `verify` separately subtracts rational coefficient tables; it never calls generator/truth.
This is **not ATT**: treatment depends on X and U, so effects among observed treated units are selected. A finite-sample mean of conditional effects is random and need not equal-5. Source provides conditional intervention means; we make no claim that an unspecified individual cross-world effect is pointwise deterministic. ATE truth does not depend on such coupling.
Identification is instrumented DiD: consistency/random sampling, randomized Z/T, stable CATE, Z has no direct effect on untreated outcome *trend*, and no shared latent effect modifier. Z directly affects levels, so ordinary-IV exclusion is not asserted; U confounds treatment-outcome and ordinary unconfoundedness is not asserted. Trend treatment contrast deltaA(x) is positive because Z reduces A0 propensity and raises A1 propensity, giving a nonzero denominator. Untreated Z-level effect is20 in both periods and cancels from deltaY. Thus deltaY/deltaA=10*s(X), as in the source.

## Interface and scenarios
`generate(config,n,seed)` uses local random.Random, returns six numeric list columns each exactly n. n means **total independent cross-sectional individuals**, not observations per time or paired units. T/Z groups are random, never forced equal. `section6_main` is the sole family scenario; n5000 corresponds to the main parametric source setting. Other n (including32 smoke checks) are sample-size extensions, not the paper baseline and not separate families. No copying, truncation or padding. Config freezes all generation parameters and rejects changes. One row has only its T-specific actual A,Y.
The observed six-column schema uses covariate(X1,X2), instrument(Z), time(T), treatment(A), outcome(Y), all observed=true. No IDs or hidden outputs.

## Independent evidence and limitations
The sole authoritative independent source is tests/test_g01.py. It checks deterministic primitive-draw replay through a separately expressed inverse-CDF and logistic formula; all columns, seed replay/change, invalid inputs/config, distribution moments and covariance, conditional Bernoulli score residuals, zero-mean independent normal outcome residuals, and analytic CATE/ATE. Statistical thresholds are fixed in code and recorded with actual statistics in checks/independent_audit.json; finite numerical PASS is evidence, not a proof of universal independence/identification. verify(config) does not see generated tables. Official report/sample are generated by the unchanged toolkit, not hand-written. No author code is executed.

## Family fingerprint and deduplication
Repeated cross-section, two random observation periods, binary randomized IV, bridge latent confounding, opposing time-specific logit treatment responses, Gaussian outcomes with heterogenous A-by-X effects. Distinct from M01 fixed group/two paired periods/nonlinear baseline null, M11 shared AR factors, M12 donor-noise inheritance. n/seed/estimators are not new families. This is one family and one scenario.

## Rights and provenance
Published PDF p1: Copyright2025 Biometrika Trust, CC BY-NC-ND4.0. Author repo fixed commit contains no LICENSE, GitHub metadata license=null; no permissive license is invented. bridgedist0.1.2 CRAN archive provides explicit defaultphi.5 and inverse formula, GPL(>=2); author code does not pin a package version, so its actual installed version is not claimed. Paper explicitphi is the principal source. No R/PDF/package code redistributed in formal ZIP. `source.license` records these source rights only, not a release license for independently written Python.

## Official smoke-size limitation
The unmodified tool rejects `--n 5000` before hook execution because its allowed smoke n is2 through2048. This is an interface limit, not a generator/scientific failure. Independent test01 actually executes n5000 for observed structure, same-seed replay and different-seed change; test04 additionally executes65536 rows for moment/reconstruction evidence. Official `--n 32` is therefore a clearly labelled non-paper sample-size extension; the pack report/sample must be read as n32 evidence, not n5000. The official n5000 rejection is recorded in checks/official_n5000_rejection_record.json; it is a factual execution record, not a reconstructed official report.
