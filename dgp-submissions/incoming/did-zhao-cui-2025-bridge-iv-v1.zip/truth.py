"""Population ATE, not a sample effect or a policy value."""
def truth(config):
    if config.get("estimand") != "population_ATE" or config.get("cate_coefficients") != [-.5,1.5,2] or config.get("outcome_scale") != 10 or config.get("x_sd") != 1:
        raise ValueError("Unsupported truth specification")
    return {"value": -5.0, "estimated_error": 0.0, "method": "E[15X1+20X2-5] with EX1=EX2=0", "scope": "population_ATE_both_periods_not_ATT_not_SATT"}
