# 随机处理与阈值跳跃异质效应

Contributor: 张佳怡. Task family: ate. Status: runnable candidate pending named scientific review and independent-person reproduction.

## Source and version

Xinkun Nie and Stefan Wager (2021). Quasi-oracle estimation of heterogeneous treatment effects. Biometrika 108(2):299–319. DOI: https://doi.org/10.1093/biomet/asaa076.
Actual reading version: Published typeset article deposited in NSF PAR, 21 PDF pages; issue year 2021; publisher first-online metadata 2020-09-24.
Source URL: https://par.nsf.gov/servlets/purl/10311702
Exact location: Section 4.2, PDF p.9 / journal p.307, equation (9) and following discontinuous effect definition; Figure 2 PDF p.10 / journal p.308, sigma=1 noise setting
Locators use one-based PDF page numbers. Journal page numbers are separately labeled; supplement pages are not main-paper pages.
Local verification source SHA-256: e99abbe90a4d5baa0373827b022cede4266e721a3fe3473540fb72032858d8af. The source PDF is retained outside the submission ZIP.
Version and scope differences: Published typeset copy used directly. The printed advance-access date differs from the publisher metadata; filenames use the verified first-online date and source.year uses issue year 2021. The source evaluates conditional effects; this contribution integrates the same effect function over the original covariate population to define population ATE.
No author software is copied or used to fill parameters. Repository/file/function/commit citations are therefore not applicable; all implementations are independently written from the cited equations.

## Original generation order and fixed parameters

1. X~N_10(0,I); independent coordinates and individuals.
2. A~Bernoulli(0.5), independent of X.
3. b(X)=3/(1+exp(X3-X2)); tau(X)=1{X1>0}/(1+exp(-X2)).
4. Y|X,A~N(b(X)+(A-0.5)*tau(X),sigma**2), sigma=1, selected from Figure 2 noise levels.

Fixed configuration: `{"dimension": 10, "noise_sd": 1.0, "treatment_probability": 0.5}`.
Original source sample size is recorded in collection.json as context. The generate interface deliberately accepts n and seed, and the required smoke check uses n=128; this is not a recreation of the paper's estimator performance experiments.
Sampling units are independent individuals, with no interference, clusters, panels, or shared random coefficients. Random draws for treatment and noise are independent conditional on the generated covariates. Within-person covariate dependence follows the equations above. Potential-outcome residual coupling that is not specified by a source is not inferred: the generator implements its observed conditional law without claiming a unique joint counterfactual law.


## Target and identification

Population ATE = E[Y(1)-Y(0)] under the declared full covariate distribution, with treatment levels 1 versus 0. This is not ATT, a trimmed/overlap population, a sample-average realized effect, or a fixed-point CATE. No outcome-dependent sample selection or missingness is introduced.
Identification requires consistency, no interference, conditional exchangeability of treatment and potential outcomes given observed X, and positivity. These are part of the synthetic scientific model, not inferred from machine PASS. For Gaussian logistic mechanisms positivity holds pointwise but there is no uniform overlap bound over unbounded support. No propensity clipping is added unless it is part of the cited original equation.

## Population truth and independent verification

Independence gives E[1{X1>0}*expit(X2)]=P(X1>0)*E[expit(X2)]=(1/2)*(1/2)=1/4. The strict >0 boundary is retained.
truth.py returns value, estimated_error and method separately from generated rows. verify.py uses independent scalar source fixtures and a separate analytic/numerical integration route, integrates the implemented arm contrast, and checks assignment, covariate and noise distributions. Statistical diagnostics use fixed seeds and explicit broad six-standard-error criteria; they are not coverage tests or mathematical proofs. Gaussian-tail truncation and order-refinement estimates are numerical diagnostics, not uniform error bounds.
The verifier shares the declared scientific equations, configuration, NumPy and the same AI author with the generator. Independent numerical routes reduce implementation risk but do not constitute independent-person reproduction. No named human scientific review is claimed.

## Mechanism identity and properties

Three active covariates. The threshold indicator creates a discontinuity at X1=0, multiplied by a second-covariate sigmoid; it cannot be obtained by merely changing a coefficient in the smooth equation (9) design. Baseline is smooth but effect is discontinuous.
Canonical mechanism family: nie_stacking_discontinuous. It is distinguished by its covariate law and/or functional treatment/outcome/noise structure, not by seed, sample size or a mere coefficient change. Source scenarios with the same functional structure are grouped. The final family count is subject to the maintainer's scientific interpretation, with full equations provided for review.

## Adaptations and boundaries

- Explicit target adaptation: integrate source conditional effect over the original covariate distribution to obtain population ATE; data-generating equations unchanged.
- Rename source treatment D or W to A; observed conditional law unchanged.
- Independent Python/NumPy implementation; no source estimator fitting or reported performance tables are reproduced.

RNG is local numpy.random.default_rng(seed); identical seeds reproduce under the recorded Python/NumPy environment. Exact bitwise reproducibility across arbitrary dependency upgrades is not promised. Stable expit/logaddexp implementations are algebraic evaluations, not scientific changes. No clipping of Gaussian covariates, deletion of extreme rows, winsorization or silent finite-value replacement is used. Nonfinite outputs raise errors. Binary treatment is generated without forcing a fixed group size or resampling a missing arm.

## Rights, AI assistance and unresolved review

The scientific equations are attributed to their authors; paper copyrights remain with their respective rights holders. Paper PDFs, author software and original personal records are not redistributed in the ZIP. Implementation licensing is reserved for contributor/maintainer confirmation; no third-party code license is presumed from public accessibility.
AI assistance: literature discovery, source extraction and visual equation review, implementation, analytic derivation, numerical cross-checking, packaging and report drafting. Contributor review is still required before upload. Scientific acceptance, a separate human reproducer, project-wide deduplication and PR checks remain external steps. The local package does not assert any of those outcomes.


## Final source audit
AI source audit completed against the exact local source version and source_map.json. Human scientific acceptance and independent-person reproduction are not claimed. Dependencies are pinned to NumPy 2.3.5; only the original source scenario is registered.
