"""Analytic population ATE of the source mechanism."""

def truth(config):
    return {'value': 0.25, 'estimated_error': 1e-14, 'method': 'Independence gives E[1{X1>0}*expit(X2)]=P(X1>0)*E[expit(X2)]=(1/2)*(1/2)=1/4. The strict >0 boundary is retained.', 'error_interpretation': 'Analytic identity with floating-point allowance, not Monte Carlo uncertainty.'}
