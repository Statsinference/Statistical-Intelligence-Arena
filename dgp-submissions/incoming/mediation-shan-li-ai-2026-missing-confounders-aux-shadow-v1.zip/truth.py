"""Population mediation functional theta = E[Y(1, M(0))]; integrates the law.

The population law is integrated analytically, never estimated from generated rows.
Two facts make the integral elementary:

  * X1 = Phi(eps1) and X2 = Phi(eps2) with eps_j standard normal, so the probability
    integral transform gives X1, X2 ~ Uniform(0, 1) independently.  Hence
    E[Xj] = 1/2, E[Xj^2] = 1/3 and E[sin Xj] = 1 - cos(1) exactly;
  * X3 ~ Bernoulli(x3_probability), so E[X3] = x3_probability.

The mediator equation is additive in (T, X1^2, sin X2, X3, eps3) and the outcome
equation is additive in (T, T*M, M, T*X1, sin X1, X2^2, X3, eps4) with both noises
mean zero, so an intervention that fixes T = t turns every expectation into a sum of
the moments above.  No quadrature and no Monte Carlo is used, so the registered value
carries no statistical error.

The missingness mechanism plays no part here: theta is a FULL-DATA functional of
(T, M, Y, X), identical in the source's DGP1 and DGP2.  What the two settings change
is whether theta is identifiable from the observed data, which is the source's subject
and not something this file asserts.
"""
import math

HALF = 0.5                      # E[Xj]   for Xj ~ Uniform(0, 1)
SECOND_MOMENT = 1.0 / 3.0       # E[Xj^2] for Xj ~ Uniform(0, 1)
SINE_MEAN = 1.0 - math.cos(1.0)  # E[sin Xj] = integral of sin over (0, 1)


def expected_mediator(config, t):
    """E[M(t)] under the source's mediator equation."""
    return (config["mediator_intercept"]
            + config["mediator_treatment"] * t
            + config["mediator_treatment_x1_squared"] * t * SECOND_MOMENT
            + config["mediator_x1_squared"] * SECOND_MOMENT
            + config["mediator_sin_x2"] * SINE_MEAN
            + config["mediator_x3"] * config["x3_probability"])


def mediation_functional(config, t, t_prime):
    """E[Y(t, M(t'))], the quantity the source calls a mediation functional."""
    mediator_slope = config["outcome_treatment_mediator"] * t + config["outcome_mediator"]
    return (config["outcome_intercept"]
            + config["outcome_treatment"] * t
            + mediator_slope * expected_mediator(config, t_prime)
            + config["outcome_treatment_x1"] * t * HALF
            + config["outcome_sin_x1"] * SINE_MEAN
            + config["outcome_x2_squared"] * SECOND_MOMENT
            + config["outcome_x3"] * config["x3_probability"])


def natural_indirect_effect(config, t=1):
    """xi(t) = E[Y(t, M(1)) - Y(t, M(0))]; the source reports xi(1)."""
    return mediation_functional(config, t, 1) - mediation_functional(config, t, 0)


def natural_direct_effect(config, t_prime=0):
    """zeta(t') = E[Y(1, M(t')) - Y(0, M(t'))]; the source reports zeta(0)."""
    return mediation_functional(config, 1, t_prime) - mediation_functional(config, 0, t_prime)


def average_treatment_effect(config):
    """tau = E[Y(1) - Y(0)] with Y(t) = Y(t, M(t))."""
    return mediation_functional(config, 1, 1) - mediation_functional(config, 0, 0)


def truth(config):
    value = mediation_functional(config, 1, 0)
    return {
        "value": value,
        "estimated_error": 0.0,
        "method": ("Closed form.  X1, X2 ~ Uniform(0,1) by the probability integral "
                   "transform and X3 is Bernoulli, so the additive mediator and outcome "
                   "equations reduce the mediation functional to the exact moments "
                   "E[Xj] = 1/2, E[Xj^2] = 1/3, E[sin Xj] = 1 - cos(1) and E[X3]. "
                   "No quadrature and no Monte Carlo."),
        "error_interpretation": ("Exact up to IEEE-754 double rounding of the registered "
                                 "coefficients and of cos(1); not a statistical error bar."),
        "target": "MF theta = E[Y(1, M(0))]",
        "companions": {
            "NIE xi(1)": natural_indirect_effect(config, 1),
            "NDE zeta(0)": natural_direct_effect(config, 0),
            "ATE tau": average_treatment_effect(config),
        },
    }
