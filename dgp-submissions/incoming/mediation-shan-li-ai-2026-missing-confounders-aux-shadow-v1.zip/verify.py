"""Independent verification of the registered mediation functional theta = E[Y(1, M(0))].

Routes that do not share code with truth.py:

  * two-dimensional Gauss-Legendre quadrature over (X1, X2) in [0, 1]^2 with an exact
    sum over X3, integrating the structural equations as written.  It never uses the
    closed-form moments E[Xj] = 1/2, E[Xj^2] = 1/3, E[sin Xj] = 1 - cos(1) that
    truth.py relies on;
  * a from-scratch structural simulation of the nested counterfactual Y(1, M(0)) under
    common random numbers, which also checks the exact per-unit identity
    Y(1, M(1)) - Y(1, M(0)) = (3 - 1.5) (M(1) - M(0)) through the full equations;
  * independent recomputation of all four estimands the source reports, with the
    source's own decomposition tau = xi(1) + zeta(0).

Plus source-constant, source-reported-missingness, multinomial-identity, figure-axis,
full-data-invariance, masking-integrity, zero-path and observed-column checks.
The shared element is the registered mechanism itself; see shared_components below.
"""
from copy import deepcopy
import importlib.util
import math
from pathlib import Path

import numpy as np

STRUCTURAL = {
    "x3_probability": 0.5,
    "propensity_intercept": 0.1,
    "propensity_x1_squared": 1.0,
    "propensity_x2": -1.0,
    "propensity_x3": 0.2,
    "mediator_intercept": -1.0,
    "mediator_treatment": 1.0,
    "mediator_treatment_x1_squared": -1.0,
    "mediator_x1_squared": 4.0,
    "mediator_sin_x2": -1.0,
    "mediator_x3": 1.0,
    "mediator_noise_sd": 1.0,
    "outcome_intercept": -1.0,
    "outcome_treatment": 1.0,
    "outcome_treatment_mediator": 3.0,
    "outcome_mediator": -1.5,
    "outcome_treatment_x1": 1.0,
    "outcome_sin_x1": 5.0,
    "outcome_x2_squared": -2.0,
    "outcome_x3": 1.0,
    "outcome_noise_sd": 1.0,
    "incomplete_pattern_count": 3,
    "missing_fill_value": 0.0,
}

MISSINGNESS = {
    "dgp1_residual_dependent": {
        "missingness_x1": 3.0,
        "missingness_x2": 1.0,
        "missingness_x3": -1.0,
        "missingness_treatment_times_mediator_noise": 0.5,
        "missingness_outcome_noise": 0.1,
        "shadow_variables": "auxiliary",
        "shadow_correlation": 0.6,
    },
    "dgp2_covariate_treatment_dependent": {
        "missingness_intercept": 1.2,
        "missingness_x1": 1.0,
        "missingness_x2_squared": 1.0,
        "missingness_x3": -1.0,
        "missingness_treatment": -0.5,
        "missingness_treatment_x1_squared": 1.0,
        "shadow_variables": "internal_mediator_outcome",
    },
}

# Vertical axis ranges printed on the panels of the source's Figure 2.
FIGURE_AXES = {
    "dgp1_residual_dependent": {"MF": (2.5, 4.0), "NIE": (0.6, 1.8),
                                "NDE": (1.5, 4.0), "ATE": (3.0, 5.0)},
    "dgp2_covariate_treatment_dependent": {"MF": (2.5, 4.0), "NIE": (0.5, 1.5),
                                           "NDE": (1.5, 4.0), "ATE": (3.0, 4.5)},
}

# The source states the average missingness pattern percentages are about
# 58%, 14%, 14%, 14% in BOTH data-generating processes.
REPORTED_COMPLETE_SHARE = 0.58
REPORTED_INCOMPLETE_SHARE = 0.14


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("shan_collection_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _quadrature_functional(config, t, t_prime, order=200):
    """E[Y(t, M(t'))] by product Gauss-Legendre over (X1, X2) and an exact X3 sum.

    The structural equations are integrated as written; no moment identity is used.
    """
    nodes, weights = np.polynomial.legendre.leggauss(order)
    grid = 0.5 * (nodes + 1.0)
    weight = 0.5 * weights
    x1 = grid[:, None]
    x2 = grid[None, :]
    plane = weight[:, None] * weight[None, :]
    probability = float(config["x3_probability"])
    total = 0.0
    for x3, mass in ((0.0, 1.0 - probability), (1.0, probability)):
        mediator = (config["mediator_intercept"]
                    + config["mediator_treatment"] * t_prime
                    + config["mediator_treatment_x1_squared"] * t_prime * x1 ** 2
                    + config["mediator_x1_squared"] * x1 ** 2
                    + config["mediator_sin_x2"] * np.sin(x2)
                    + config["mediator_x3"] * x3)
        outcome = (config["outcome_intercept"]
                   + config["outcome_treatment"] * t
                   + config["outcome_treatment_mediator"] * t * mediator
                   + config["outcome_mediator"] * mediator
                   + config["outcome_treatment_x1"] * t * x1
                   + config["outcome_sin_x1"] * np.sin(x1)
                   + config["outcome_x2_squared"] * x2 ** 2
                   + config["outcome_x3"] * x3)
        total += mass * float((plane * outcome).sum())
    return total


def _structural_nested_simulation(config, n, seed):
    """Simulate Y(1, M(0)) and the per-unit NIE identity from the equations directly."""
    rng = np.random.Generator(np.random.PCG64(seed))
    eps1 = rng.standard_normal(n)
    eps2 = rng.standard_normal(n)
    eps3 = rng.standard_normal(n)
    eps4 = rng.standard_normal(n)
    erf = np.vectorize(math.erf, otypes=[float])
    x1 = 0.5 * (1.0 + erf(eps1 / math.sqrt(2.0)))
    x2 = 0.5 * (1.0 + erf(eps2 / math.sqrt(2.0)))
    x3 = (rng.random(n) < float(config["x3_probability"])).astype(float)

    def mediator(t):
        return (config["mediator_intercept"]
                + config["mediator_treatment"] * t
                + config["mediator_treatment_x1_squared"] * t * x1 ** 2
                + config["mediator_x1_squared"] * x1 ** 2
                + config["mediator_sin_x2"] * np.sin(x2)
                + config["mediator_x3"] * x3
                + float(config["mediator_noise_sd"]) * eps3)

    def outcome(t, mediator_values):
        return (config["outcome_intercept"]
                + config["outcome_treatment"] * t
                + config["outcome_treatment_mediator"] * t * mediator_values
                + config["outcome_mediator"] * mediator_values
                + config["outcome_treatment_x1"] * t * x1
                + config["outcome_sin_x1"] * np.sin(x1)
                + config["outcome_x2_squared"] * x2 ** 2
                + config["outcome_x3"] * x3
                + float(config["outcome_noise_sd"]) * eps4)

    m0 = mediator(0)
    m1 = mediator(1)
    nested = outcome(1, m0)
    slope = config["outcome_treatment_mediator"] * 1 + config["outcome_mediator"]
    identity_gap = float(np.max(np.abs((outcome(1, m1) - nested) - slope * (m1 - m0))))
    return float(nested.mean()), identity_gap


def _pattern_shares(config, n, seed):
    """Average pattern probabilities under the registered missingness mechanism."""
    rng = np.random.Generator(np.random.PCG64(seed))
    eps1 = rng.standard_normal(n)
    eps2 = rng.standard_normal(n)
    eps3 = rng.standard_normal(n)
    eps4 = rng.standard_normal(n)
    erf = np.vectorize(math.erf, otypes=[float])
    x1 = 0.5 * (1.0 + erf(eps1 / math.sqrt(2.0)))
    x2 = 0.5 * (1.0 + erf(eps2 / math.sqrt(2.0)))
    x3 = (rng.random(n) < float(config["x3_probability"])).astype(float)
    logit = (config["propensity_intercept"]
             + config["propensity_x1_squared"] * x1 ** 2
             + config["propensity_x2"] * x2
             + config["propensity_x3"] * x3)
    treatment = (rng.random(n) < 1.0 / (1.0 + np.exp(-logit))).astype(float)
    if config["missingness_form"] == "dgp1_residual_dependent":
        index = (config["missingness_x1"] * x1
                 + config["missingness_x2"] * x2
                 + config["missingness_x3"] * x3
                 + config["missingness_treatment_times_mediator_noise"] * treatment * eps3
                 + config["missingness_outcome_noise"] * eps4)
    else:
        index = (config["missingness_intercept"]
                 + config["missingness_x1"] * x1
                 + config["missingness_x2_squared"] * x2 ** 2
                 + config["missingness_x3"] * x3
                 + config["missingness_treatment"] * treatment
                 + config["missingness_treatment_x1_squared"] * treatment * x1 ** 2)
    count = float(config["incomplete_pattern_count"])
    complete = 1.0 / (1.0 + count * np.exp(-index))
    incomplete = 1.0 / (np.exp(index) + count)
    simplex_gap = float(np.max(np.abs(complete + count * incomplete - 1.0)))
    odds_gap = float(np.max(np.abs(complete / incomplete - np.exp(index))
                            / np.maximum(np.exp(index), 1.0)))
    return float(complete.mean()), float(incomplete.mean()), simplex_gap, odds_gap


def verify(config):
    oracle = _module("truth.py")
    producer = _module("generator.py")
    form = config["missingness_form"]

    expected = dict(STRUCTURAL)
    expected.update(MISSINGNESS[form])

    def _matches(key, value):
        if isinstance(value, str):
            return config[key] == value
        return abs(float(config[key]) - float(value)) <= 1e-12

    constant_mismatch = [key for key, value in expected.items() if not _matches(key, value)]

    registered = oracle.truth(config)
    reference = float(registered["value"])

    quad = {"MF": _quadrature_functional(config, 1, 0),
            "Y1": _quadrature_functional(config, 1, 1),
            "Y0": _quadrature_functional(config, 0, 0)}
    quad_estimands = {"MF": quad["MF"],
                      "NIE": quad["Y1"] - quad["MF"],
                      "NDE": quad["MF"] - quad["Y0"],
                      "ATE": quad["Y1"] - quad["Y0"]}
    closed_estimands = {"MF": reference,
                        "NIE": oracle.natural_indirect_effect(config, 1),
                        "NDE": oracle.natural_direct_effect(config, 0),
                        "ATE": oracle.average_treatment_effect(config)}
    quad_gap = max(abs(quad_estimands[k] - closed_estimands[k]) for k in quad_estimands)
    decomposition_gap = abs(closed_estimands["ATE"]
                            - (closed_estimands["NIE"] + closed_estimands["NDE"]))

    simulated, identity_gap = _structural_nested_simulation(config, 400_000, 24_601)
    simulation_gap = abs(simulated - reference)

    complete_share, incomplete_share, simplex_gap, odds_gap = _pattern_shares(
        config, 400_000, 7_919)

    axes = FIGURE_AXES[form]
    outside = [name for name, (low, high) in axes.items()
               if not low <= closed_estimands[name] <= high]

    # The registered target is a full-data functional: perturbing every missingness
    # coefficient must leave it bit-identical.
    perturbed = deepcopy(config)
    for key in list(perturbed):
        if key.startswith("missingness_") and isinstance(perturbed[key], (int, float)):
            perturbed[key] = float(perturbed[key]) + 7.0
    invariance_gap = abs(float(oracle.truth(perturbed)["value"]) - reference)

    no_treatment_to_mediator = deepcopy(config)
    no_treatment_to_mediator["mediator_treatment"] = 0.0
    no_treatment_to_mediator["mediator_treatment_x1_squared"] = 0.0
    no_mediator_to_outcome = deepcopy(config)
    no_mediator_to_outcome["outcome_treatment_mediator"] = 0.0
    no_mediator_to_outcome["outcome_mediator"] = 0.0

    sample = producer.generate(config, 4096, 104_729)
    declared = ["R1", "R2", "X1_obs0", "X2_obs0", "X3"]
    if form == "dgp1_residual_dependent":
        declared += ["Z1", "Z2"]
    declared += ["T", "M", "Y"]
    columns_exact = list(sample) == declared

    fill = float(config["missing_fill_value"])
    masking_problems = []
    for indicator, masked in (("R1", "X1_obs0"), ("R2", "X2_obs0")):
        flags = np.asarray(sample[indicator], dtype=float)
        values = np.asarray(sample[masked], dtype=float)
        if not np.all(values[flags < 0.5] == fill):
            masking_problems.append(masked + " carries a value where the indicator is 0")
        shown = values[flags > 0.5]
        if shown.size and not np.all((shown > 0.0) & (shown < 1.0)):
            masking_problems.append(masked + " leaves the Uniform(0,1) support where observed")
    observed_rate = float(np.mean(np.asarray(sample["R1"], dtype=float)
                                  * np.asarray(sample["R2"], dtype=float)))

    if form == "dgp1_residual_dependent":
        alpha = float(config["shadow_correlation"])
        shadow_ok = (abs(config["missingness_treatment_times_mediator_noise"]) > 0.0
                     and abs(config["missingness_outcome_noise"]) > 0.0)
        shadow_detail = (
            "The DGP1 missingness index carries %.3g * T * eps3 and %.3g * eps4, the very "
            "noises that drive M and Y, so M and Y are NOT valid shadow variables here and "
            "the source supplies external auxiliary Z1, Z2 built as Phi(%.2g eps_j + "
            "%.6g eps_j'), a Gaussian copula of correlation %.2g with X_j. Both Z columns "
            "are exported."
            % (config["missingness_treatment_times_mediator_noise"],
               config["missingness_outcome_noise"], alpha,
               math.sqrt(1.0 - alpha * alpha), alpha))
    else:
        shadow_ok = not any(key in config for key in
                            ("missingness_treatment_times_mediator_noise",
                             "missingness_outcome_noise"))
        shadow_detail = (
            "The DGP2 missingness index is a function of (X1, X2, X3, T) only and carries no "
            "eps3 or eps4 term, which is exactly what lets the source use the already "
            "observed (M, Y) as shadow variables; no external Z column is generated.")

    checks = [
        {"name": "source_constants_section_5",
         "passed": not constant_mismatch,
         "details": ("Every structural and missingness coefficient matches the displayed "
                     "data-generating process of Section 5 and the %s branch; mismatches: %s."
                     % (form, constant_mismatch or "none"))},
        {"name": "independent_gauss_legendre_quadrature",
         "passed": quad_gap < 1e-9,
         "details": ("Product Gauss-Legendre of order 200 over (X1, X2) with an exact sum "
                     "over X3 reproduces all four estimands to within %.3g. This route "
                     "integrates the equations as written and never touches the moment "
                     "identities E[Xj] = 1/2, E[Xj^2] = 1/3, E[sin Xj] = 1 - cos(1) that "
                     "truth.py uses." % quad_gap)},
        {"name": "independent_structural_nested_simulation",
         "passed": simulation_gap < 0.02 and identity_gap < 1e-9,
         "details": ("400000 units simulated from the structural equations give "
                     "mean Y(1, M(0)) = %.6f against the registered %.6f, a gap of %.3g "
                     "(Monte Carlo). Under common random numbers the per-unit identity "
                     "Y(1, M(1)) - Y(1, M(0)) = (outcome_treatment_mediator + "
                     "outcome_mediator) (M(1) - M(0)) holds to %.3g, so any slip in the "
                     "mediator or outcome equation would surface here."
                     % (simulated, reference, simulation_gap, identity_gap))},
        {"name": "four_estimands_and_source_decomposition",
         "passed": decomposition_gap < 1e-12,
         "details": ("MF = %.15g, NIE xi(1) = %.15g, NDE zeta(0) = %.15g, ATE tau = %.15g. "
                     "The source's decomposition tau = xi(1) + zeta(0) holds to %.3g. All "
                     "four are registered here so the target cannot be confused with the "
                     "indirect, direct or total effect."
                     % (closed_estimands["MF"], closed_estimands["NIE"],
                        closed_estimands["NDE"], closed_estimands["ATE"],
                        decomposition_gap))},
        {"name": "source_reported_missingness_percentages",
         "passed": (abs(complete_share - REPORTED_COMPLETE_SHARE) < 0.01
                    and abs(incomplete_share - REPORTED_INCOMPLETE_SHARE) < 0.01),
         "details": ("Average pattern probabilities are %.4f for the complete pattern and "
                     "%.4f for each of the three incomplete ones. The source states these "
                     "are about 58%%, 14%%, 14%%, 14%% in both of its data-generating "
                     "processes, so this is an anchor the source itself prints and it pins "
                     "down the transcription of the index U."
                     % (complete_share, incomplete_share))},
        {"name": "multinomial_pattern_identities",
         "passed": simplex_gap < 1e-12 and odds_gap < 1e-9,
         "details": ("p11 + 3 p_kl = 1 to %.3g and p11 / p_kl = exp(U) to %.3g relative. "
                     "The constant 3 in the source's formulas is therefore the NUMBER of "
                     "incomplete patterns, not a free parameter, which is why "
                     "incomplete_pattern_count is pinned to 3."
                     % (simplex_gap, odds_gap))},
        {"name": "figure_2_axis_containment",
         "passed": not outside,
         "details": ("Each registered value lies inside the vertical axis range printed on "
                     "the corresponding panel of the source's Figure 2 (MF %s, NIE %s, "
                     "NDE %s, ATE %s); panels outside range: %s. The source draws the true "
                     "value as a solid line inside these panels but prints no table of "
                     "truths, so this is a consistency check, not a quoted number."
                     % (axes["MF"], axes["NIE"], axes["NDE"], axes["ATE"],
                        outside or "none"))},
        {"name": "target_is_a_full_data_functional",
         "passed": invariance_gap == 0.0,
         "details": ("Adding 7.0 to every missingness coefficient leaves the registered "
                     "value changed by %.3g. theta is a functional of the full-data law of "
                     "(T, M, Y, X) alone, which is why the source's DGP1 and DGP2 share it; "
                     "what the missingness mechanism changes is identifiability from the "
                     "observed data, not the target." % invariance_gap)},
        {"name": "masking_encoding_is_lossless",
         "passed": not masking_problems and columns_exact,
         "details": ("Xj_obs0 equals the declared fill value %.1f exactly on every row with "
                     "Rj = 0 and lies strictly inside (0, 1) on every row with Rj = 1, so "
                     "the indicator recovers the pattern without ambiguity and no latent "
                     "covariate value reaches a learner. Complete-case share in the 4096-row "
                     "probe: %.4f. Problems: %s."
                     % (fill, observed_rate, masking_problems or "none"))},
        {"name": "zero_treatment_to_mediator_path",
         "passed": abs(oracle.natural_indirect_effect(no_treatment_to_mediator, 1)) < 1e-14,
         "details": ("Removing both treatment terms from the mediator equation makes "
                     "M(1) = M(0) and the natural indirect effect exactly 0.")},
        {"name": "zero_mediator_to_outcome_path",
         "passed": abs(oracle.natural_indirect_effect(no_mediator_to_outcome, 1)) < 1e-14,
         "details": ("Removing both mediator terms from the outcome equation makes the "
                     "natural indirect effect exactly 0.")},
        {"name": "shadow_variable_structure",
         "passed": bool(shadow_ok),
         "details": shadow_detail},
        {"name": "observed_columns_only",
         "passed": columns_exact,
         "details": ("The generator returns exactly %d columns in the declared order %s and "
                     "no exogenous noise, no complete X1 or X2, and no counterfactual or "
                     "oracle column; eps1, eps1', eps2, eps2', eps3, eps4 and the unmasked "
                     "X1, X2 stay internal." % (len(declared), declared))},
    ]
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": ("All routes necessarily share the registered structural "
                              "equations and coefficients. They do not share code: truth.py "
                              "reduces the functional to closed-form Uniform(0,1) and "
                              "Bernoulli moments, the quadrature route integrates the "
                              "equations numerically over the covariate cube, the simulation "
                              "route draws the nested counterfactual unit by unit, and the "
                              "pattern-share route reconstructs the missingness index "
                              "independently of generator.py. Transcription from the paper "
                              "and independent-person reproduction remain separate review "
                              "tasks."),
        "limits": ("Numerical diagnostics only. They do not establish the source's "
                   "sequential ignorability or positivity assumptions, do not establish that "
                   "the shadow-variable condition identifies theta from the observed data, "
                   "and do not verify the source's sieve estimator. Positivity of the "
                   "complete-case pattern is not claimed to be bounded away from 0 "
                   "uniformly."),
    }
