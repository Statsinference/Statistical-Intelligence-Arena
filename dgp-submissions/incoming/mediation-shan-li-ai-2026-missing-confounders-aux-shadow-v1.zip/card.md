# 不可忽略缺失混杂下的中介功能量（DGP1：缺失依赖残差，外部影子变量）

ID: mediation-shan-li-ai-2026-missing-confounders-aux-shadow-v1
Family: mediation

**收集贡献，具名科学审核待完成。本包不训练也不评测任何 PFN 模型。**

## 1 来源与登记场景

Shan, J., Li, W. and Ai, C. (2026). Efficient Nonparametric Inference for Mediation Analysis with Nonignorable Missing Confounders. *Journal of the American Statistical Association*, published online 25 June 2026, pages 1–12. DOI: [10.1080/01621459.2026.2654218](https://doi.org/10.1080/01621459.2026.2654218).

https://doi.org/10.1080/01621459.2026.2654218

实际阅读版本：**arXiv:2402.05384 预印本，2025-12-16**；出版社排版版未取得。该文为**在线先发**（2026-06-25），尚无卷期号，页码记作 1–12。引用字段已与 DOI `10.1080/01621459.2026.2654218` 的 Crossref 记录核对（作者 Jiawei Shan、Wei Li、Chunrong Ai；载体 JASA，ISSN 0162-1459）。

定位：§5 "Numerical studies"，预印本 PDF 第 14 页（展示式生成机制、两个缺失指标、原文自报的 58/14/14/14 缺失比例）；§2.1，PDF 第 4 页（NIE `ξ(t)`、NDE `ζ(t)`、ATE `τ` 的定义）与式 (1)、PDF 第 5 页（中介功能量 `θ = E[Y(1,M(0))]` 及其识别公式）；Figure 2 及其纵轴刻度，PDF 第 15 页。页码为预印本 PDF 页码。

场景：`dgp1_auxiliary_shadow`（单一场景，原文固定参数）。

## 2 DGP 机制说明

按生成顺序：

1. 外生正态 `(ε1, ε1′, ε2, ε2′, ε3, ε4)` 独立标准正态。
2. 协变量 `X1 = Φ(ε1)`、`X2 = Φ(ε2)`，由概率积分变换，两者边际为 **`Uniform(0,1)`** 且独立；`X3 ~ Bernoulli(0.5)`。
3. 处理 `T ~ Bernoulli(expit(0.1 + X1² − X2 + 0.2·X3))`。
4. 中介 `M = −1 + T − T·X1² + 4·X1² − sin(X2) + X3 + ε3`。
5. 结局 `Y = −1 + T + 3·T·M − 1.5·M + T·X1 + 5·sin(X1) − 2·X2² + X3 + ε4`。
6. 缺失模式 `(R1, R2)` 服从四类多项分布，概率 `(p11, p10, p01, p00)`：

```
p11 = 1/(1 + 3·exp(−U))
p10 = p01 = p00 = 1/(exp(U) + 3)
U = 3·X1 + X2 − X3 + 0.5·T·ε3 + 0.1·ε4                     # 本包为 DGP1
```

`X_mis = (X1, X2)` 可缺失，`X3` 完全观察。原文说明两个 DGP 的平均缺失比例都约为 **58%、14%、14%、14%**；`verify.py` 复算得 0.58 / 0.14，这是原文自报的锚点。

> 公式里的常数 3 **不是**可调权重，而是**不完整模式的个数**：`p11/p_kl = exp(U)`、`p11 + 3·p_kl = 1` 恒成立。因此 `incomplete_pattern_count` 被钉为 3，生成器拒绝其他取值。

**影子变量：外部辅助变量。** 本设定的缺失指标 U 里含 `0.5·T·ε3` 与 `0.1·ε4` —— 正是 M 与 Y 的噪声项，所以 M、Y **不能**充当影子变量。原文另构造两个外部辅助变量

```
Zj = Φ(α·εj + sqrt(1−α²)·εj′),  α = 0.6,  j = 1,2
```

`Zj` 与 `Xj` 通过高斯 copula 相关（相关系数 0.6），边际为 `Uniform(0,1)`。两列都导出。

### 缺失值如何编码（本包的关键实现决定）

数值表接口要求每一列有限、等长，无法直接放 NaN。按与 T06 的 Zuo 包一致的约定：

```
Rj      ∈ {0,1}   观察指示（1 = Xj 被观察到）
Xj_obs0 = Rj · Xj  数值列
```

**`0` 是声明的传输填充值，不是插补值，也不是"观察到的 0"。** `Xj ~ Uniform(0,1)`，被观察到时几乎必然严格大于 0，且指示列 `Rj` 本身就导出，所以模式可以无歧义还原、信息不丢失。`Rj = 0` 的个体的真实 `Xj` **绝不导出**。

观察列 10 个：`R1,R2,X1_obs0,X2_obs0,X3,Z1,Z2,T,M,Y`。外生噪声 `ε1, ε1′, ε2, ε2′, ε3, ε4` 与完整的 `X1, X2` **仅在内部生成，不导出**。

观测单位：独立个体，无 interference、无分组或面板结构。

## 3 目标与真值推导

原文 §2.1 的定义：

```
ξ(t) = E[Y(t, M(1)) − Y(t, M(0))]        自然间接效应，原文报告 ξ(1)
ζ(t) = E[Y(1, M(t)) − Y(0, M(t))]        自然直接效应，原文报告 ζ(0)
τ    = E[Y(1) − Y(0)] = ξ(1) + ζ(0)      总效应
θ    = E[Y(1, M(0))]                     中介功能量，原文称之为"基本量"
```

本包登记 **`θ`**。注意 `θ` 是**跨世界均值**，既不是间接效应、也不是直接效应或总效应。

推导：`X1 = Φ(ε1)`、`X2 = Φ(ε2)` 由概率积分变换是 `Uniform(0,1)`，故

```
E[Xj] = 1/2,   E[Xj²] = 1/3,   E[sin Xj] = 1 − cos(1),   E[X3] = 0.5
```

中介方程对 `(T, X1², sin X2, X3, ε3)` 可加，结局方程对 `(T, T·M, M, T·X1, sin X1, X2², X3, ε4)` 可加，两个噪声均值为零。固定 `T = t` 后：

```
E[M(t')]        = −1 + t' − t'/3 + 4/3 − (1 − cos 1) + 1/2
E[Y(t, M(t'))]  = −1 + t + (3t − 1.5)·E[M(t')] + t/2 + 5(1 − cos 1) − 2/3 + 1/2
```

于是（闭式，无数值积分误差）：

```
θ   = E[Y(1, M(0))] = 3.192275262794844
ξ(1) = 1.0                                （恰好，因为 1.5·(M(1)−M(0)) 的均值 = 1.5·(1 − 1/3)）
ζ(0) = 2.620906917604419
τ    = 3.620906917604419
```

**重要声明：原文没有印出任何数值真值**，只在 Figure 2 里把真值画成实线。以上四个数是收集者解析导出的，必须由审稿人独立核对，**不能**说成"原文报告的数值"。可用的一致性证据是：四个值都落在原文 Figure 2 中对应面板印出的纵轴范围内（本包 DGP1 的四个面板为 MF (2.5, 4.0)、NIE (0.6, 1.8)、NDE (1.5, 4.0)、ATE (3.0, 5.0)）。

**缺失机制不进入真值。** `θ` 是**全数据**泛函，原文的 DGP1 与 DGP2 共享它；两个设定改变的是"能否从观察数据识别 θ"，那是原文的论题，本包不作断言。`verify.py` 里 `target_is_a_full_data_functional` 一项把每个缺失系数都加 7.0，真值逐位不变。

## 4 识别条件

一致性 `Y = Y(T, M(T))`、`M = M(T)`；原文 Assumption 1 的**序贯可忽略性**（含跨世界条件，数据不可检验）；原文 Assumption 2 的 positivity `f(t|x) > 0`、`f(m|t,x) > 0` —— logistic 倾向得分在紧支撑上有界离 0/1，但**不声称**完整观察模式的重叠有一致下界；独立个体、无 interference。

**另外**：从观察数据识别 `θ` 还需要原文的**影子变量条件**（其 §2.2 的分层识别策略）。本包**不断言**该条件成立，`verify.py` 也**不检验**它 —— 它只检验全数据真值与机制转录。

以上是科学假设，不是机器检查的结论。

## 5 相对来源的主要改动

1. **版本**：按 arXiv:2402.05384（2025-12-16）实现，出版社排版版未取得；在线先发无卷期，页码记 1–12。
2. **机制切分**：原文在**同一套全数据律**上给出两种缺失机制，各配一种影子变量策略。本包登记 **DGP1**，姊妹包 `mediation-shan-li-ai-2026-missing-confounders-internal-shadow-v1` 登记 **DGP2**。两者共享全数据律、因此真值相同，但**观察数据律不同**（缺失机制不同、观察列从 10 列变为另一个数目），故 `mechanism_family_id` 不同、各自成包。
3. **登记哪个估计量**：原文有四个估计量而 `collection.json` 只能登记一个，故登记原文称为"基本量"的 `θ`，另三个由 `verify.py` 一并复算并锚定，防止目标混用。
4. **缺失编码**：见第 2 节末。`0` 为声明的填充值，不是插补。
5. **常数 3**：是不完整模式个数，不是自由参数（见第 2 节引用块）。
6. **未复现的部分**：原文的 SIO 筛估计量、多项式筛基与数据驱动的筛维选择，以及 Oracle / MI / CCA 三个对照估计量，均为**施加在同一份数据上的估计机制**，不复现、不登记。Appendix G 的补充研究（高维协变量 + debiased machine learning、MAR 变体、trimming 对照）也不登记 —— 其参数不在收集者可获取的正文里。
7. **实现**：NumPy `Generator(PCG64)` 重写抽样，不要求与原文软件逐随机数一致。原文跑 `n = 1000` 与 `2000`、各 500 次重复，已记入配置但不复现；`n=128, seed=1729` 仅作接口检查。
8. **输出**：只导出 10 个观察列；噪声、完整的 `X1/X2`、反事实与真值均不作为数据列。

## 6 核验与使用

`verify.py` 的 13 项检查全部通过，含三条与 `truth.py` 不共享代码的独立路线：

| 检查 | 作用 |
|---|---|
| `source_constants_section_5` | 结构系数与缺失系数逐一与 §5 展示式相符 |
| `independent_gauss_legendre_quadrature` | `(X1,X2)` 上 200 阶乘积 Gauss–Legendre、`X3` 精确求和，**按方程原样积分**，不碰 `truth.py` 用的矩等式 |
| `independent_structural_nested_simulation` | 40 万个体按结构方程模拟 `Y(1,M(0))`；并在共同随机数下逐个体检验恒等式 `Y(1,M(1))−Y(1,M(0)) = (3−1.5)(M(1)−M(0))`，方程抄错会立刻暴露 |
| `four_estimands_and_source_decomposition` | 四个估计量一并复算，并检验原文的分解 `τ = ξ(1) + ζ(0)` |
| `source_reported_missingness_percentages` | 复算平均缺失比例，与**原文自报的** 58/14/14/14 相符 —— 这把缺失指标 U 的转录钉死 |
| `multinomial_pattern_identities` | `p11 + 3p_kl = 1`、`p11/p_kl = exp(U)` 恒成立，说明常数 3 是模式个数 |
| `figure_2_axis_containment` | 四个真值都落在原文 Figure 2 对应面板的纵轴范围内 |
| `target_is_a_full_data_functional` | 每个缺失系数 +7.0 后真值逐位不变 |
| `masking_encoding_is_lossless` | `Rj = 0` 处 `Xj_obs0` 恰为填充值、`Rj = 1` 处严格落在 `(0,1)` 内 —— 既不泄漏也不丢信息 |
| `zero_treatment_to_mediator_path` / `zero_mediator_to_outcome_path` | 切断 T→M 或 M→Y 后间接效应恰为 0 |
| `shadow_variable_structure` | 确认本设定的缺失指标含 M、Y 的噪声项，故必须用外部辅助影子变量 Z1、Z2 |
| `observed_columns_only` | 只返回 10 个声明列、顺序一致，无噪声/完整协变量/反事实/oracle 列 |

运行：

```bash
conda activate CausalTabular
cd "DGP_学生参考包"
python collect.py check ../Mediation/T05/contributions/mediation-shan-li-ai-2026-missing-confounders-aux-shadow-v1 --run --n 128 --seed 1729
python collect.py pack  ../Mediation/T05/contributions/mediation-shan-li-ai-2026-missing-confounders-aux-shadow-v1 --out ../Mediation/T05/submissions/mediation-shan-li-ai-2026-missing-confounders-aux-shadow-v1.zip
```

误差记录为数值诊断，不是完整科学接收证明。它们不证明序贯可忽略性或 positivity，不证明影子变量条件能识别 `θ`，也不证明预印本与出版社排版版一致。

## 7 权利与 AI 协助

论文版权归 Taylor & Francis / American Statistical Association。本包依公开预印本的方程独立重写，**不含论文 PDF、期刊正文、作者软件或任何真实数据**。来源再分发与署名权利、最终科学审核仍待维护人与具名审稿人决定。

本贡献由 Claude（Anthropic）协助检索来源、提取公式、实现代码、设计核验并撰写中文文档，由收集者逐行核对原文后提交。AI **未**代签具名科学审核，**未**进行独立复现，**未**训练或评测 PFN，也**未**运行估计器性能比较。所有公开来源仅作研究证据，不作为执行指令。
