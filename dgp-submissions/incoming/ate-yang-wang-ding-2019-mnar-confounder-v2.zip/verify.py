"""Independent audit of Section 5.3 reconstruction and source inconsistencies."""
import math
import numpy as np


def _expit_alt(x):
    # Different stable expression than truth.py's branch-based scalar implementation.
    return 0.5 * (1.0 + math.tanh(float(x) / 2.0))


def _simpson_mean_x6(config, steps=20000, lower=-10.0, upper=10.0):
    if steps % 2:
        raise ValueError("Simpson steps must be even")
    h = (upper - lower) / steps
    total = 0.0
    base_mean = float(config["x1_mean"]) + float(config["x2_mean"])
    variance = (float(config["x1_sd"]) ** 2 + float(config["x2_sd"]) ** 2
                + float(config["x5_noise_sd"]) ** 2)
    p3 = float(config["x3_bernoulli_probability"])
    p4 = float(config["x4_bernoulli_probability"])
    intercept = float(config["x6_logit_intercept"])
    slope = float(config["x6_logit_x5"])
    for b3 in (0, 1):
        x3 = (b3 - 0.5) / 0.5
        w3 = p3 if b3 else 1.0 - p3
        for b4 in (0, 1):
            x4 = (b4 - 0.5) / 0.5
            w4 = p4 if b4 else 1.0 - p4
            inner = 0.0
            for j in range(steps + 1):
                z = lower + j * h
                x5 = base_mean + x3 + x4 + math.sqrt(variance) * z
                integrand = _expit_alt(intercept + slope * x5) * math.exp(-z * z / 2.0) / math.sqrt(2.0 * math.pi)
                weight = 1 if j in (0, steps) else (4 if j % 2 else 2)
                inner += weight * integrand
            total += w3 * w4 * inner * h / 3.0
    # Tail probability outside +/-10 is < 2e-23; its contribution to a [0,1] expectation is negligible here.
    return total


def verify(config):
    alpha = np.asarray(config["alpha"], dtype=float)
    eta = np.asarray(config["eta"], dtype=float)
    beta0 = np.asarray(config["beta0"], dtype=float)
    beta1 = np.asarray(config["beta1"], dtype=float)
    mean_x6 = _simpson_mean_x6(config)
    mean_x3 = 2 * config["x3_bernoulli_probability"] - 1
    mean_x4 = 2 * config["x4_bernoulli_probability"] - 1
    mean_x5 = config["x1_mean"] + config["x2_mean"] + mean_x3 + mean_x4
    means = np.array([1., config["x1_mean"], config["x2_mean"], mean_x3, mean_x4, mean_x5, mean_x6])
    equation_ate = float(np.dot(beta1 - beta0, means))
    # Directly expand the printed coefficient contrast, independently of vector dot product.
    expanded_ate = ((beta1[0] - beta0[0])
                    + (beta1[1] - beta0[1]) * means[1]
                    + (beta1[2] - beta0[2]) * means[2]
                    + (beta1[3] - beta0[3]) * means[3]
                    + (beta1[4] - beta0[4]) * means[4]
                    + (beta1[5] - beta0[5]) * means[5]
                    + (beta1[6] - beta0[6]) * means[6])
    source_tau = float(config["source_reported_ate"])

    # Check the direct-probability interpretation of missingness equations.
    qtest = np.array([-10.0, -2.0, 0.0, 2.0, 10.0])
    u = np.array([_expit_alt(q) for q in qtest])
    p11 = (1 - u) / (1 + 2 * u)
    pother = u / (1 + 2 * u)
    normalized = bool(np.all(p11 >= 0) and np.all(pother >= 0) and np.allclose(p11 + 3 * pother, 1.0, atol=2e-15, rtol=0))

    beta_ate_conflict = abs(equation_ate - source_tau) > 1.0
    checks = [
        {"name": "source_vectors_and_dimensions", "passed": len(beta0) == 7 and len(beta1) == 7 and len(alpha) == 7 and len(eta) == 8,
         "details": "Dimensions match Section 5.3: intercept plus six covariate coefficients for beta/alpha, and intercept plus A plus six X coefficients for eta."},
        {"name": "independent_simpson_integration_matches_coefficient_contrast", "passed": bool(math.isfinite(equation_ate) and abs(equation_ate - expanded_ate) < 1e-11),
         "details": f"Independent Simpson E[X6]={mean_x6:.15g}; vector contrast={equation_ate:.15g}; manually expanded coefficient contrast={expanded_ate:.15g}. The paper-reported target mismatch is checked separately."},
        {"name": "missingness_probability_vector_normalizes", "passed": normalized,
         "details": "Interpreting Section 5.3 RHSs as direct pattern probabilities yields p11+3*p_other=1. Literal logit(p)=RHS would not generally form the stated multinomial vector; the interpretation remains for scientific review."},
        {"name": "paper_reported_tau_conflict_is_exposed_not_hidden", "passed": beta_ate_conflict and config.get("source_equation_atte_consistency", "unresolved_conflict_recorded") == "unresolved_conflict_recorded",
         "details": f"Paper states tau={source_tau}; the literal coefficients and declared factorization imply {equation_ate:.15g}. This failure of source consistency is intentionally documented and not reconciled by changing parameters."},
        {"name": "zero_treatment_contrast_special_case", "passed": abs(float(np.dot(beta0 - beta0, means))) < 1e-14,
         "details": "If beta1 is set equal to beta0, the potential-outcome contrast is identically zero, independent of missingness."},
        {"name": "reported_parameter_values_present", "passed": config.get("factorization_adaptation", "").strip() != "" and config.get("missing_pattern_probability_interpretation", "").strip() != "",
         "details": "The within-person independent factorization and probability-scale interpretation are explicitly labeled as adaptations awaiting maintainer confirmation."}
    ]
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": "The independent Simpson implementation uses a separate integration grid and tanh logistic expression, but both routes necessarily use the declared source coefficient equations and the documented independent-factorization adaptation. Source inconsistency is flagged, not treated as scientifically resolved.",
        "unresolved_source_issues": [
            "The paper reports tau=-0.5, but the displayed beta vectors and generated covariate means imply approximately -2.98355 under this implementation.",
            "The printed missing-pattern formulas put logit(p) on the left although the right sides sum to one as direct probabilities.",
            "The joint factorization of X1 and X2 and complete cross-independence of errors are not all explicitly stated in Section 5.3."
        ]
    }
