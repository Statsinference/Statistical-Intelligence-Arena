# Source-grounded DGP contribution

Status: candidate; not scientifically accepted. The source-equation/target mismatch documented below is material and requires maintainer review before treating this as a source-faithful accepted DGP.

## Source and reconstruction

**Primary source.** S. Yang, L. Wang and P. Ding (2019), “Causal inference with confounders missing not at random,” *Biometrika*, 106(4), 875–888, DOI: https://doi.org/10.1093/biomet/asz048. Actual version read: author-hosted electronic reprint of the final 2019 journal article, 27 PDF pages: https://shuyang.wordpress.ncsu.edu/files/2022/11/Yang-et-al-2019-Biometrika-Causal-inference-with-confounders-missing-not-at-random.pdf. Section 5.3 is on printed page 886, author PDF page P11 (PDF page 12 if counted starting at 1). The DGP equations are unnumbered prose under “5.3. Multiple confounders subject to missingness.” Simulation sizes n=400, 800, 1600 and 2000 Monte Carlo samples per sample size are described in the paragraph preceding Section 5.2 (printed page 884, PDF page P9); they are experiment settings, not parameters of the generator interface. Supplementary material for the article has 13 pages and covers proofs/additional discussions/estimator details; it does not appear to add a separate DGP specification. The author PDF could be text-read, but the screenshot endpoint returned cache-miss, so visual screenshot verification was not completed. No author-code commit was used.

### Equations in generation order

The paper defines six confounders `X=(X1,...,X6)`:

1. `X1, X2 ~ Normal(1,1)` (the article does not explicitly state their joint dependence in this sentence). **Adaptation:** generate them independently, pending confirmation.
2. For `j=3,4`, `Xj=(Bj-0.5)/0.5`, `Bj~Bernoulli(0.5)`, giving values -1 and +1. **Adaptation:** draw B3 and B4 independently, pending confirmation.
3. `X5=X1+X2+X3+X4+epsilon5`, where `epsilon5~Normal(0,1)`. **Adaptation:** generate epsilon5 independently of earlier variables.
4. `X6|X5~Bernoulli(p6)`, with `logit(p6)=-X5`.
5. Potential outcomes: `Y(0)=(1,X^T) beta0+epsilon0`; `Y(1)=(1,X^T) beta1+epsilon1`, where `beta0=(-1.5,1,-1,1,-1,1,1)^T`, `beta1=(0,-1,1,-1,1,-1,-1)^T`, `epsilon0,epsilon1~Normal(0,1)`. **Adaptation:** independently draw the two outcome errors and take them independent of X, pending confirmation; the paper gives marginal error laws but not all cross-independences in this paragraph.
6. Treatment: `A|X~Bernoulli(expit((1,X^T) alpha))`, `alpha=0.5*(2,1,1,1,1,-2,-2)^T`.
7. Missing pattern for X5/X6: `R=(R5,R6)` takes values `(11),(10),(01),(00)` with four multinomial pattern probabilities. Let `q=(1,A,X^T) eta`, `eta=0.25*(-4,1,1,1,1,1,-1,-1)^T`. The printed text places `logit(p_11)` and `logit(p_kl)` on the left, while the four right-hand sides are `1/(1+3 exp(q))` and `1/(exp(-q)+3)` (for each `kl` in `10,01,00`). The right-hand-side quantities form a valid probability vector when read as the probabilities themselves, summing exactly to one; applying an inverse-logit interpretation would not give a multinomial probability vector. **Adaptation and unresolved issue:** this candidate uses the right-hand sides as direct probabilities and requests maintainer confirmation on the published notation.
8. Observed outcome `Y=A Y(1)+(1-A)Y(0)`. Only observed variables are returned. `Y(0)`, `Y(1)`, errors, propensity, q, and all probabilities remain internal.

Units are individuals. The implementation generates individuals independently. Within an individual, `X5` is a function of `X1`–`X4` and noise; `X6` depends on `X5`; treatment depends on all X; and missingness depends on A and all X. Thus the mechanism is MNAR because the missingness probability depends on the possibly missing values `X5` and `X6`, but is outcome-independent conditional on `(A,X)` by construction. No interference is added.

### Material source inconsistency: reported ATE

The article explicitly reports `tau=-0.5` in Section 5.3. However, under the printed coefficient vectors and the above declared independent factorization, the coefficient contrast gives:

`E[Y(1)-Y(0)] = 1.5 - 2 E[X1] + 2 E[X2] - 2 E[X3] + 2 E[X4] - 2 E[X5] - 2 E[X6]`.

Since `E[X1]=E[X2]=1`, `E[X3]=E[X4]=0`, and `E[X5]=2`, this becomes `ATE=-2.5-2 E[X6]`. Under `X5|S ~ Normal(2+S,3)`, `S=X3+X4` takes `-2,0,2` with probabilities `1/4,1/2,1/4`; numerical integration gives `E[X6]=E[expit(-X5)]≈0.2417754075740287`, hence **equation-implied ATE ≈ -2.983550815148057**, not -0.5. This contribution computes and validates the truth of the runnable equation-based adaptation; it does not change coefficients or claim that this value agrees with the paper's sentence. Maintainer/source clarification is required before accepting the contribution as a faithful reproduction.

## Target and identification

Target: population ATE `E[Y(1)-Y(0)]`, intervention A=1 versus A=0. Consistency holds by construction. Treatment assignment is random conditional on X and potential errors under the implementation's independence assumptions. Missingness is generated conditional on `(A,X)` and does not use Y, so `R ⟂ Y | (A,X)` holds by construction. However, Section 2's uniform propensity lower/upper bound (Assumption 2) is not guaranteed under unbounded Gaussian covariates and a logistic treatment mechanism. Similarly, if the printed direct multinomial probabilities are used, the fully observed pattern probability can approach zero on an unbounded support, so the uniform lower bound in Assumption 7 is not guaranteed. These limitations are documented, not hidden by machine PASS.

## Truth and independent verification

The truth is calculated from the coefficient contrast. Under the explicit factorization adaptation, the only nontrivial expectation is `E[X6]=E[expit(-X5)]`, evaluated from a three-component Gaussian mixture with Gauss-Hermite quadrature (orders 64, 128, 256). `truth.py` returns an order-difference convergence diagnostic, not a rigorous global error bound. `verify.py` independently integrates the mixture using composite Simpson quadrature on standard-normal support [-10,10] and a tanh logistic expression, checks the probability simplex, and checks the zero-treatment-contrast special case. Both routes share the source coefficient equations and declared factorization; this is not an independent human reproduction. The independent value is about -2.983550815148, whereas the source reports -0.5; this unresolved disagreement is a blocking scientific-review item.

## Diversity and scope

Six total/effective baseline covariates; not high-dimensional. Nonlinearity comes from `expit(-X5)` for X6, logistic treatment assignment and the missing-pattern probability transformation. There are no explicit interaction product terms in the supplied equations. X5 and X6 are sometimes missing. The numeric table contract represents missing values by sentinel 0.0 and exports `R5`,`R6`; users must apply the masks and must not interpret masked zero as an observed value. This is an interface adaptation, not imputation.

## Rights and assistance

AI assistance was used for source extraction, equation transcription, code writing and testing. No paper PDF, raw sensitive data, author source code, credentials, model weights or data bank is included. This package is a candidate for maintainer review only. Required maintainer decisions: (i) resolve reported `tau=-0.5` versus equation-implied ATE; (ii) confirm missing-pattern RHS probability interpretation; (iii) confirm joint factorization/cross-independence assumptions; (iv) assess overlap and the uniform positivity conditions. No named scientific reviewer or independent replicator has approved it.
