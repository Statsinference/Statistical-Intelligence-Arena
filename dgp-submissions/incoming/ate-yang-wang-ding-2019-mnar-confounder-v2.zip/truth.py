"""Equation-implied population ATE, conditional on the stated factorization adaptation."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss


def _expit_scalar(x):
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    e = math.exp(x)
    return e / (1.0 + e)


def _mean_x6(config, order):
    # X5 = X1 + X2 + X3 + X4 + epsilon5. Under the declared independent
    # factorization, X1+X2+epsilon5 is normal with variance sd1^2+sd2^2+sd5^2;
    # enumerate the four discrete X3/X4 combinations exactly.
    nodes, weights = hermgauss(order)
    weights = weights / math.sqrt(math.pi)
    base_mean = float(config["x1_mean"]) + float(config["x2_mean"])
    variance = (float(config["x1_sd"]) ** 2 + float(config["x2_sd"]) ** 2
                + float(config["x5_noise_sd"]) ** 2)
    total = 0.0
    p3 = float(config["x3_bernoulli_probability"])
    p4 = float(config["x4_bernoulli_probability"])
    slope = float(config["x6_logit_x5"])
    intercept = float(config["x6_logit_intercept"])
    for b3 in (0, 1):
        x3 = (b3 - 0.5) / 0.5
        w3 = p3 if b3 else 1.0 - p3
        for b4 in (0, 1):
            x4 = (b4 - 0.5) / 0.5
            w4 = p4 if b4 else 1.0 - p4
            x5 = base_mean + x3 + x4 + math.sqrt(2.0 * variance) * nodes
            values = np.array([_expit_scalar(intercept + slope * float(v)) for v in x5])
            total += w3 * w4 * float(np.dot(weights, values))
    return total


def truth(config):
    mean_x6_64 = _mean_x6(config, 64)
    mean_x6_128 = _mean_x6(config, 128)
    mean_x6_256 = _mean_x6(config, 256)
    beta0 = np.asarray(config["beta0"], dtype=float)
    beta1 = np.asarray(config["beta1"], dtype=float)
    means = np.array([
        1.0,
        float(config["x1_mean"]),
        float(config["x2_mean"]),
        2.0 * float(config["x3_bernoulli_probability"]) - 1.0,
        2.0 * float(config["x4_bernoulli_probability"]) - 1.0,
        float(config["x1_mean"]) + float(config["x2_mean"])
        + 2.0 * float(config["x3_bernoulli_probability"]) - 1.0
        + 2.0 * float(config["x4_bernoulli_probability"]) - 1.0,
        mean_x6_128
    ])
    # E[Y(1)-Y(0)] = (beta1-beta0)' E[(1,X)]; error means are zero.
    value = float(np.dot(beta1 - beta0, means))
    error = abs(mean_x6_128 - mean_x6_64) * 2.0 + abs(mean_x6_256 - mean_x6_128) * 2.0 + 1e-14
    return {
        "value": value,
        "estimated_error": float(error),
        "method": "Coefficient contrast plus three-order Gauss-Hermite integration of E[X6]=E[expit(-X5)] under the declared independent factorization.",
        "error_interpretation": "Order-difference convergence diagnostic, not a rigorous uniform error bound.",
        "target": "ATE = E[Y(1)-Y(0)] for intervention A=1 versus A=0; this equation-implied value is not the paper's reported tau=-0.5, which conflicts with the printed coefficients under this factorization."
    }
