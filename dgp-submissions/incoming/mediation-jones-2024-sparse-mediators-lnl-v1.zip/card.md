# 稀疏多中介的自然间接效应 · 场景 LNL

ID: mediation-jones-2024-sparse-mediators-lnl-v1
Family: mediation
Mechanism family: `jones-2024-robinson-additive-sparse-mediator-selection`（本家族共 8 个场景包）

**收集贡献，具名科学审核待完成。本包不训练也不评测任何 PFN 模型。**

## 1 来源与登记场景

Jones, J., Ertefaie, A. and Strawderman, R. L. (2025). Causal mediation analysis: selection with asymptotically valid inference. *Journal of the Royal Statistical Society Series B: Statistical Methodology* 87(3), 678–700. DOI: [10.1093/jrsssb/qkae109](https://doi.org/10.1093/jrsssb/qkae109).

实际阅读版本：**arXiv:2110.06127v2 预印本**；期刊正式版未取得。

定位：§5 "Simulation Studies"，预印本 PDF 第 **15** 页（`mu_D0`、`psi_M`、`psi_Y` 各两种形式与三字母场景命名）；**Appendix A，第 26 页**（全部方差、维数、`alpha_0`、`beta_0`、`gamma_0`，以及原文印出的 `NIE = 2.4`）；结构模型式 **(1)**，第 4 页；**Proposition 2.1**，第 6 页。以上为**预印本 PDF 页码**，不是期刊页码 678–700。

场景：**`LNL`** —— 倾向得分 线性、中介混杂 非线性、结局混杂 线性。

### 为什么按三字母组合切分，以及为什么只交三个（切分依据）

原文为三个 nuisance 函数**各给出线性与非线性两种形式**，并按 `mu_D0, psi_M, psi_Y` 的顺序用**三字母命名场景**（文中明确举例 LNN），因此理论上有八种组合。函数形式的改变是**机制的改变**，不是参数的改变 —— 李桫的 proximal 范例即把 Qi et al. (2024) 一篇里的线性、三角、二次三种形式各立为独立 ZIP —— 所以一个三字母组合是一个**贡献**，不是同一包里的一个 scenario。

**但本家族只提交三个，是刻意的选择，不是穷举。** 三个包构成“一个参考点 + 两个单因子邻居”：

| 包 | 三字母 | 与 LNN 的差别 | `interactions` |
|---|---|---|---|
| 参考点 | `LNN` | —— 原文**唯一点名**的组合 | false |
| 邻居一 | `NNN` | 只换 **`mu_D0`**（倾向得分形式）；三包中**唯一**带原文 `X1·X2` 乘积项 | **true** |
| 邻居二 | `LNL` | 只换 **`psi_Y`**（结局混杂函数形式） | false |

每一对都只隔离**一个** nuisance 函数。剩下五个组合**不提交** —— 它们只会给同一家族添加换标签的重复，抬高机制计数而不增加一套不同的数据律。原文 Appendix B 的 `p = 60` 维数变体也**不提交**：它与 `p = 10` 的 LNN 函数形式完全相同、只差一个维数参数，按同一把尺子量属于参数扫描而非新机制。

三个包**共享同一 `mechanism_family_id`**；若审稿人认为应按家族计为一个 DGP，可据此合并。原文未逐一说明实际跑过哪些组合，本包也**不发明**原文之外的任何函数形式。


## 2 DGP 机制说明（场景 LNL）

按生成顺序：

1. `X_l ~ N(0, 1/4)` 独立，`l = 1,2,3`（原文明确说小方差是为减少无意的 positivity 违背）
2. `D | X ~ Bernoulli(mu_D0(X))`，本场景 `mu_D0(X) = expit{0.8(X1 + X2)}`
3. `M = alpha_0·D + psi_M(X)·1_p + eta`，`eta_j ~ N(0,1)` 独立，`p = 10`，本场景 `psi_M(X) = X1² + X2 − X3`
   `alpha_0 = (1, 2, 2, 0, …, 0)`。`psi_M` 是**标量值函数**，原文写作 `psi_M(·) ≡ 1·psi_M(·)`，即同一个值加到 10 个中介坐标上。
4. `Y = gamma_0·D + beta_0ᵀM + psi_Y(X) + epsilon`，`epsilon ~ N(0,1)`，本场景 `psi_Y(X) = 2(X1 − 0.5) + X2 + 2X3`
   `gamma_0 = 2`，`beta_0 = (0.8, 0.4, 0.4, 0, …, 0)`

**稀疏结构**：10 个候选中介里只有前 3 个同时有非零 `alpha_0` 与 `beta_0`；第 4–10 个两个系数**都为 0**（真正无效，不是"弱中介"）。

标签依据：`interactions` = false（本场景三条结构方程均无乘积项；家族中其他场景的非线性形式是幂次，不是交互）；`nonlinear` = true，对应 logistic 链接、`psi_M` 的平方项 `X1²`；结局均值在 `(D, M, X)` 上其余部分是线性的。

观测单位：独立个体，无 interference。观察列 15 个：`X1,X2,X3,D,M1…M10,Y`。无潜变量（`latent_variables: []`）；`psi_M(X)`、`psi_Y(X)`、`M(1)`、`M(0)` 均只在内部存在。

## 3 目标与真值

由原文式 (1) 与 **Proposition 2.1**：

```
E[M(d)] = alpha_0·d + E[psi_M(X)]·1_p
NIE = beta_0ᵀ(E[M(1)] − E[M(0)]) = beta_0ᵀ·alpha_0
NDE = gamma_0
```

**`NIE = 1×0.8 + 2×0.4 + 2×0.4 = 2.4`**，`NDE = gamma_0 = 2`

混杂函数 `psi_M`、`psi_Y` 在对比中**完全相消**，故真值与本场景的函数形式无关 —— verify 中以 Gauss–Hermite 算出两者期望非零、同时确认切换混杂形式真值不变，说明是**真的相消**而非被悄悄丢掉。这也是本家族三个场景包共享同一真值的原因。

**真值出处（与本批其他机制不同）**：`NIE = 2.4` 是**原文 Appendix A 直接印出的数值**，`NDE = gamma_0 = 2` 由原文 Proposition 2.1 给出。本包登记原文自报值并由收集者独立复算确认，不是仅有收集者推导的数。

## 4 识别条件

一致性与对处理、中介向量的联合干预良定义；独立个体、无 interference；给定 `X` 的处理可交换性与给定 `(X, D)` 的中介–结局可交换性（原文 Assumptions 2.1、2.2）；原文的**稀疏性假设**——前 3 个中介构成"好"中介集 `S*`，且 `S*` 之外的中介与 `S*` 内任何变量无关；条件零均值误差 `E(eta|X,D)=0`、`E(epsilon|X,D,M)=0`；处理 positivity——原文刻意把协变量方差取 1/4 以减少无意的违背，expit 对有限 X 严格在 (0,1) 内，但**不声称**无界高斯支撑上的一致重叠界。

原文 Remark 2.2 还指出：在略宽的假设下其估计量也可作 **interventional effect** 解释；本包按原文采用的**自然效应**读法登记。

以上是科学假设，不是机器检查的结论。

## 5 相对来源的主要改动

1. **版本**：按 arXiv:2110.06127v2 预印本实现，期刊正式版未取得。
2. **场景切分**：见第 1 节末。原文设计允许八个三字母组合，本批只提交三个（LNN 参考点、NNN 只换倾向得分、LNL 只换结局混杂），三包共享 `mechanism_family_id`，可按家族合并计数。
3. **只登记 "Large" 设定**：原文 "Small" 设定让 `alpha_0`、`beta_0` 随 `n` 变化（贡献为 `4n^{-1/2}` 量级），属**局部漂移参数序列**而非固定机制，不登记。
4. **只登记 p = 10**：原文 Appendix B 的 p = 60 设定不登记。
5. **未复现的部分**：原文 10 折交叉拟合、指数权重 perturbation bootstrap、以及 product / adaptive / full / oracle / parametric-linear 五个估计量，都是**施加在同一份数据上的估计机制**，不复现、不登记为新机制。
6. **实现**：NumPy `Generator(PCG64)` 重写抽样；`n=128, seed=1729` 仅作接口检查。

## 6 核验与使用

`verify.py` 的 9 项检查全部通过：

| 检查 | 作用 |
|---|---|
| `source_constants_appendix_a` | 全部参数与 Appendix A 的 "Large" 设定及 §5 的混杂形式逐一相符，场景名与原文三字母记法一致 |
| `independent_common_random_number_contrast` | 512 个个体按完整方程模拟 `Y(1,M(1)) − Y(1,M(0))`；共同随机数下该对比**退化为常数**，故对 `alpha_0`、`beta_0` 的每个分量与两条方程的可加结构都是锐利检查（偏差 < 1e-12） |
| `confounding_functions_cancel` | Gauss–Hermite（阶 24）算出 `E[psi_M]`、`E[psi_Y]` 非零，而切换混杂形式真值不变 → 混杂是**真的相消** |
| `source_published_truth` | `NIE = 2.4` 与**原文印出的数值**一致，`NDE = 2` 与 Proposition 2.1 一致 |
| `sparse_mediator_set` | 10 个候选中介中恰好 3 个有效（索引 1,2,3），第 4–10 个两系数都为 0 |
| `zero_treatment_to_mediator_path` / `zero_mediator_to_outcome_path` | `alpha_0 = 0` 或 `beta_0 = 0` 时 NIE 恰为 0 |
| `propensity_inside_unit_interval` | 在跨 6 个标准差的协变量探针上倾向得分始终在 (0,1) 内 |
| `observed_columns_only` | 生成器只返回 15 个声明列、顺序一致，不含任何反事实/oracle/混杂函数列 |

运行：

```bash
conda activate CausalTabular
cd "DGP_学生参考包"
python collect.py check ../Mediation/T05/contributions/mediation-jones-2024-sparse-mediators-lnl-v1 --run --n 128 --seed 1729
python collect.py pack  ../Mediation/T05/contributions/mediation-jones-2024-sparse-mediators-lnl-v1 --out ../Mediation/T05/submissions/mediation-jones-2024-sparse-mediators-lnl-v1.zip
```

误差记录为数值诊断，不是完整科学接收证明。它们不证明原文的稀疏性与可交换性假设，不覆盖 "Small" 与 p=60 设定，也不能证明预印本与期刊正式版一致。

## 7 权利与 AI 协助

论文版权归 Royal Statistical Society / Oxford University Press。本包依公开预印本的方程独立重写，**不含论文 PDF、期刊正文、作者软件或任何真实数据**。来源再分发与署名权利、最终科学审核仍待维护人与具名审稿人决定。

本贡献由 Claude（Anthropic）协助检索来源、提取公式、实现代码、设计核验并撰写中文文档，由收集者逐行核对原文后提交。AI **未**代签具名科学审核，**未**进行独立复现，**未**训练或评测 PFN，也**未**运行估计器性能比较。所有公开来源仅作研究证据，不作为执行指令。
