# QDI：有界单调三次分位数机制

状态：**awaiting_scientific_review**。贡献 ID：`qdi-fong-yiu-2026-cubic-quantile-v1`。

本贡献为 `synthetic_dgp`，任务 family 为 `quantile_distribution`，机制标识为 `fong-yiu-qkaf080-bounded-cubic-quantile`。这是一个非因果、无条件分位数任务；不是 real_data_claim。两个样本量属于同一机制，不按参数或种子重复计数。未向维护人认领、查重或发送文件。

## Source and reconstruction / 来源核对与认领

认领用 citation：Fong, Edwin and Yiu, Andrew (2026). *Bayesian quantile estimation and regression with martingale posteriors*. Journal of the Royal Statistical Society Series B: Statistical Methodology, **88(4), 1130-1159**. DOI: [10.1093/jrsssb/qkaf080](https://doi.org/10.1093/jrsssb/qkaf080)。参考版本：[arXiv:2406.03358v1，2024-06-05](https://arxiv.org/abs/2406.03358v1)。拟认领 Section 7.1 / Figure 4 的有界三次机制，另据出版社补充材料 E.3.1。

初次核对日期：2026-10-31；正式版来源补全：2026-11-01，修订 formal-source-r2；固定代码来源补全为 fixed-commit-source-r3。文档用于提供来源证据；行动范围以用户请求为准。

| 核对项目 | 亲读来源、定位及结论 |
|---|---|
| 期刊/卷期年、版本 | 用户补充的正式排版 PDF 共 30 页。首页显示 JRSS-B, 2026,88,1130-1159，作者 Edwin Fong / Andrew Yiu，DOI qkaf080；p.24 页眉显示 Vol.88,No.4。它是本贡献主来源，预印本保留为对照。 |
| 在线发表日期 | 正式 PDF 首页直接标注 Advance access publication 16 December 2025；不同于卷期年 2026，ID 保持不变。 |
| section/page/equation | 正式版 Section 7.1 (Simulations)：PDF 第 23 页、期刊 p.1152，首段未编号分位数式；Figure 4 和后续讨论：PDF 第 24 页、期刊 p.1153。以上页眉经过渲染亲读，不靠偏移计算。 |
| 参考预印本 | arXiv:2406.03358v1（2024-06-05），84 页；§7.1 PDF/印刷 p.25 首段同一公式和 Figure 4，讨论续至 p.26。p.25 不是正式版页码。 |
| 出版社补充材料 | qkaf080_supplementary_data.pdf 共 54 页；E.3.1 (Bounded support)，PDF/印刷 pp.47-48 已读并渲染检查；p.48 重述公式、端点及总体均值。无需重复补件。 |
| iid 与 sampling unit | 正式 §7.1 p.1152 明确 Y_1:n iid 来自 P*；每行是一个完整观察的独立标量响应 Y。 |
| U 的分布 | 主文用总体分位数函数指定 P*；U_i iid Uniform(0,1)、Y_i=Q*(U_i) 是等价逆变换实现，由此推导，不能冒称首段逐字给出 U 的生成式。 |
| 每个分布/参数 | 正式 p.1152：Q*(u)=4(u-0.4)^3+0.2u；4、0.4、3、0.2 全来自该式，补充 p.48 一致。没有另设噪声分布/尺度；原仿真无指定物理单位，本贡献保留原数值尺度。 |
| 样本量 | 正式 p.1152 与 p.1153 Figure 4：n=50、n=500，分别为 original_n50/original_n500，属于同一 DGP。 |
| estimand | 原文展示整个分位数函数和 E[Y]；本贡献固定边际 tau=.9，theta=inf{y:F_Y(y)>=.9}。固定查询是 adaptation，Q(.9)=.68 由方程推出，不伪称原文报告此标量。 |
| 抽样/观测/正则性/识别 | iid 为原文；仅完整 Y、无协变量/缺失/删失为此次忠实实现；导数 Q'(u)=12(u-.4)^2+.2>=.2 推出唯一内部目标和正密度。theta 是观察边际分布泛函，无需因果干预/无混杂/中介假设。 |
| 真值求法 | 严格单调逆变换给 Q_Y(.9)=4(.5)^3+.2(.9)=17/25；Fraction 精确运算，另用展开多项式的 Decimal CDF 双重反演核验。详见下文。 |
| 原文估计器配置 | 正式 p.1152 的 Q0、c、10 次排列、200 点网格、B=5000、N=n+5000 属于估计/后验计算，不是 P* 生成参数；本轮不运行这些实验。 |
| 作者代码及 commit | 正式 p.1157 指向作者仓库。用户给定 [commit a779aef7ce40d6403e006c65b5177603cebd4758](https://github.com/edfong/qmp/commit/a779aef7ce40d6403e006c65b5177603cebd4758)；本地 qmp-main.zip 的 ZIP 注释完全匹配。亲读 run_scripts/7.1_sim_qmp.py：L14-22 网格/三次函数，L25-29 sim，L31-36 seed与嵌套样本；qmp/qmp_functions.py L45-49 为 Q0。LICENSE 和依赖模块已读；详见 author_code_audit.json。 |
| 来源核对范围 | 正式版首页、§7.1、Figure 4/相关讨论和 Data availability 均提取文本并渲染亲读，确认本 DGP 与预印本/补充一致；不宣称逐章审核所有算法。固定文件来自用户，未声称与重新从出版社下载的文件逐字节相同。 |

来源文件 SHA-256（仅保留指纹，不打包 PDF）：

- 正式主文：`6da6d30a201ae059652d34de99c85002eb618e2302b234b81366184e50ad0138`；1,463,611 字节、30 页。
- arXiv v1：`1a7b1a41a73a462a7786cb095cabd8f6d42ea0e53feddb4b750945c32c7093ce`。
- 补充材料：`82f48a69abb254834d5883a084625d0148d299e65f4736c3eeb95fd9608f6b6f`。

版本边界：arXiv v1 p.25 将额外实验指向 Appendix E.1；正式 §7.1 指向 online supplement E.3，补充中对应 E.3.1。三份来源在此生成律与样本量上一致，不代表其余章节/算法完全相同。补充 E.3.2 高斯混合和主文 §7.2 气旋真实数据不属于本贡献。旧 r1 的“缺固定正式 PDF/页码映射”已由本轮用户提供的文件解决，不再列为未决。

## 固定作者代码对照（2026-11-01 新增）

来源 ZIP：qmp-main.zip，SHA-256 `751a9907dd907227acb2e74e8a3602cd19511c219cf8ed66c79d6610eb1ea4e8`，1,676,307 字节。ZIP 注释等于用户提供的完整 commit `a779aef7ce40d6403e006c65b5177603cebd4758`；远程网页仍 cache miss，未声称独立 Git 对象认证。归档只作为本地阅读证据，不放入贡献 ZIP。

| 对照项 | 固定作者代码 | 本贡献及判断 |
|---|---|---|
| 生成式 | L21 在网格上计算相同三次函数；L28 实际通过 np.interp 生成 y | 保留论文解析式直接求值；不宣称作者代码分布逐位相同 |
| 网格与边界 | L15-16：步长 .005，内部网格 .005 至 .995（理想十进制网格199点）；np.interp 在网格外返回首尾值 | 作者插值机制有平坦尾部，连续 U 下端点带点质量；本贡献是支持 [-.256,1.064] 的连续三次分布 |
| 数据 RNG/seed | L26-27 使用全局 np.random.seed / np.random.rand，L32 的 seed=2024 | 使用局部 random.Random(seed)；1729 是本地检查种子 |
| 样本关联 | L32-36 一次生成500，50取前缀 | 两场景同机制；相同seed、不同n也形成前缀，不能称跨场景独立 |
| Q0 | qmp/qmp_functions.py L45-49：min(y)+ptp(y)*u | 证实按样本极值初始化，不是固定中心 .66；不进入本DGP/truth |
| 方法配置 | fit_Q_perm L67 默认10次排列、seed=100；主脚本 L73-77 后验seed=1706、B=T=5000；L44 的c网格19点 | 正式文写200个分位点/20个c值，与代码199/19有差异；这里只记录，不运行或验证估计器 |
| 许可文本 | LICENSE L1-21 是 MIT、copyright 2024 Edwin Fong；setup.py L9 标为 BSD 3-Clause | 文本缺口已解决，但元数据冲突保留；没有复制或再分发作者软件 |

按理想精确十进制网格推导，插值支持为 [Q(.005),Q(.995)]=[-.2455195,1.0415795]，左右端点质量各 .005；实际 JAX 浮点网格可能略有变化。tau=.9 在理想网格上恰好是节点，值仍 .68，但这不证明作者实际运行环境的插值分位数满足本贡献的数值 tolerance。author_code_audit.json 附 Fraction 独立计算的端点/内部例子，不调用作者代码。本次按用户指定保留论文机制，不新增插值 scenario。NumPy 默认边界行为据 [1.26 官方 interp 文档](https://numpy.org/doc/1.26/reference/generated/numpy.interp.html)核对。

## 原始方程、场景及明确适配

对 i=1,...,n：

```text
U_i iid ~ Uniform(0,1)
Y_i = 4(U_i - 0.4)^3 + 0.2 U_i
n in {50,500}
```

观察列仅为 Y。U 是内部随机变量，不输出给模型；没有 X、处理、中介、个体效应、oracle nuisance 或真值列，也没有外加噪声。

| scenario | 原文名义 n | 系数 (a,b,c) | 登记查询 | 机制与适配 |
|---|---:|---|---|---|
| original_n50 | 50 | (4,.4,.2) | tau=.9 | 原文生成律；固定标量目标为 adaptation |
| original_n500 | 500 | (4,.4,.2) | tau=.9 | 同一原文生成律；固定标量目标为 adaptation |

`generate(config,n,seed)` 中 `config` 是单个 scenario 参数对象。显式参数 n 决定实际返回行数；`paper_n` 记录原文设计，绝不覆盖调用者请求。标准命令 `--n 128` 会对两个场景各检查 128 行；`verify` 另按各自 paper_n 实际生成 50 或 500 行并核对。相同 seed、相同调用 n 的两个 scenario 会给出相同样本，因为其概率律相同，这是预期行为。

独立实现采用局部 `random.Random(seed)`，不修改全局 RNG 或 config。其实现网格范围为 [0,1)，包含 0。2026-11-01 修复只在 u==0 时按 Fraction(str(a)) 和 Fraction(str(b)) 计算精确十进制参数端点再转 float；其余 u 保留原式，不裁剪样本、不放宽 schema。旧版该路径为 -0.25600000000000006，低于 schema 的 -.256；修正后为 -.256。这是确定性注入路径复现，不是自然 seed=1729 失败。Python 的有限精度伪随机均匀数是连续分布的计算实现，不声称与作者 NumPy 数据 RNG、JAX 数值计算 或 Figure 4 样本逐位一致。作者固定脚本的数据 seed 已确认为2024；1729不是作者脚本种子；该值是本地检查种子。

`source_relation=adapted_from_source` 的原因是固定查询目标、实现随机数方法及有限检查范围；原文 DGP 的系数、噪声结构、iid 抽样和两个样本量均保留。a=0 的线性特例和 tau=.4 的消项特例仅在 verify 内部用于验证，不新增 declared scenario，也不作为第二个 DGP。

## Target and identification / 统计目标与假设

边际总体目标：theta=Q_Y(.9)=inf{y:F_Y(y)>=.9}。没有条件查询点、干预方向或因果对比。只返回一个标量真值。

适用条件与来源分开记录：

1. 抽样：独立同分布 Y 来自指定 P*，正式主文 p.1152（PDF p.23）明确给出。没有面板、聚类、序列依赖或干扰结构。
2. 观测：每个 Y 完全观察，未引入缺失、删失、选择或测量误差。不需要观测指示列、占位值、预测器或样本划分。
3. 正则性（由式子推导）：Q 连续可微，Q'(u)=12(u-.4)^2+.2>=.2；因此在 [0,1] 上严格递增，分位数唯一，内部支持上密度连续且为正。
4. 识别：theta 是完整观测边际分布 F_Y 的统计泛函；不附加因果一致性、无混杂、跨世界或中介假设。该可识别性不证明任何估计器的有限样本性能。

支持闭包为 [Q(0),Q(1)]=[-.256,1.064]，两个端点的定义使用连续延拓；连续总体在端点的质量为零。若 y 在内部，令 u_y 为 Q(u_y)=y 的唯一根，则 F_Y(y)=u_y；支持外分别为 0 或 1。密度 f_Y(y)=1/[12(u_y-.4)^2+.2]，在 theta=.68 处 u_y=.9，因此 f_Y(theta)=.3125。尾部不为零，但本贡献不对区间覆盖率作保证。

## Truth and independent verification / 真值推导和核验

严格递增性给出 F_Y(Q(tau))=tau，故：

```text
theta = Q(.9)
      = 4(.9-.4)^3 + .2*.9
      = 4*(1/2)^3 + (1/5)*(9/10)
      = 1/2 + 9/50 = 17/25 = .68.
```

`truth.py` 使用 Fraction 将配置的十进制数按其文本解释为精确有理数，再计算并转换为 float。总体真值是精确 17/25；最终二进制转换误差约 4.885e-17，`estimated_error` 为该转换绝对误差向上舍入后的值。它不包括抽样误差、科学重构错误或模型估计误差。登记 tolerance=1e-12，在执行前确定；没有为通过检查放宽。

另一条计算路线将 Q 展开为 `4u^3-4.8u^2+2.12u-.256`，用 Decimal（65 位有效数字）和 Horner 形式求值。对每个 y，以 180 次二分求逆得到 F_Y(y)，再在 y 支持区间上进行 100 次二分，求 F_Y(y)=.9 的解，与 truth 比较；另直接检查 F_Y(truth.value) 接近 .9。内部 u 区间宽度 2^-180，外部 y 区间宽度 1.32*2^-100；Decimal 舍入仍存在，区间宽度不是整个求解器的严格统一误差界。两条路线差异阈值 1e-13，CDF 残差阈值 1e-14。

逐项核验包括（保留原 13 项，新增 5 项，每场景共 18 项）：

- 注入真实 RNG 网格值 0、2^-53、1-2^-53：只替换新加载的 generator 模块的 random 绑定，在上下文退出时恢复，不修改全局 random.Random；每项调用宿主原版 collection.worker.validate_observed 并读取提交 schema。两个场景共 6 个边界检查。
- 单独确认注入后模块绑定、全局 RNG 状态及配置保持原状。
- seed=1729/n=128 样本 SHA-256 与旧版报告一致：`47e9c0278e5721ea1331edf300c543b4c7a9c4af8ae117c238ebb27234e15129`。另在包外审计中实际逐值比较原版与新版在 128/50/500 行下的样本。

其余原有核验：

- 原文参数和两个原文样本量；登记 tau=.9 的来源适配。
- 有理数真值与独立 CDF 反演一致，且等于导出的 17/25。
- 支持端点、支持外 CDF 边界、严格单调性和目标处密度。
- 三次函数上的单面板 Simpson 积分精确给出 E[Y]=.204，与补充材料一致；这是辅助校验而非把目标改为均值。
- 解析特例 a=0：Y=.2U，直接使用 F(y)=y/.2 验证 Q(.9)=.18。
- 解析消项点 tau=.4：Q(.4)=.08。
- 每个场景在其原文 paper_n 下生成数据，核查仅 Y、长度、有限值、支持和复现；不同 seed 应改变样本；全局 RNG 和 config 保持不变。
- 用独立反演的 CDF 将实际生成的 Y 还原为内部均匀概率，核查计算实现。

独立性限制：解析真值与数值 CDF 共用同一来源重构、参数及单调性论证；数值路线不调用 truth/generator 的计算辅助函数。生成数据的 CDF 还原检查共用 Python RNG 算法和 seed。参数 fixture 是同一次 AI 阅读后的转录。边界检查依赖宿主学生工具包原版 collection.core/worker；从工具包运行 collect.py 即可，不另 pip 安装同名包。检查器和 schema 的哈希留存且未修改。上述均不等于另一位研究者的独立复现，不能替代具名科学审核。标量真值和实现 PASS 不等于置信区间、更不等于同时置信带的覆盖验证。

## Diversity and scope / 标签与适用范围

`dimension=0`、`effective_dimension=0` 均指输入协变量数；观察响应列数为 1，内部随机变量数为 1。没有高维混杂，`high_dimensional=false`。`nonlinear=true` 明确来自 `4(U-.4)^3`；单变量三次幂不是多变量交互，`interactions=false`。机制为连续有界分布，没有新增依赖或干扰。

仅登记上述固定两场景。接口内部支持线性退化特例是为核验服务，其他系数不是已经收集或科学接受的场景。原文指出 QMP 在接近 0/1 的尾部分位数处可能给出偏窄区间（正式 p.1153 / PDF p.24，v1 p.26）；本轮不拟合 QMP，也没有验证 tau=.9 的 coverage。未训练或微调 PFN，未构建超分布，未运行大型 bootstrap/coverage，未修改 checkpoint 或原实验。

## Rights and assistance / 权利、协助与未决问题

本贡献代码由 AI 按已阅读方程重新实现；不是作者软件拷贝。只打包源码、配置、卡片、小样本检查证据及哈希清单，不打包原文 PDF、原图、原始数据、凭据、模型权重或数据银行。正式版首页明确声明 CC BY 4.0，文件已取得且记录哈希。作者固定代码 LICENSE 全文已读，为 MIT（2024 Edwin Fong）；setup.py L9 却填写 BSD 3-Clause，两者不一致，保留为许可元数据疑点。没有作者软件再分发；本贡献的许可选择由维护人决定。

未决事项：

1. **论文/代码实现差异已明确。** 本贡献保留论文解析三次律，作者 sim 是内部网格线性插值并在两端恒定延拓。分位网格199/文中200、c网格19/文中20也有差异。维护人应据此评估；不冒称精确复现作者实验。
2. **原文 .66 算术疑点。** 正式 p.1153 与补充 p.48 的表述仍待作者解释。论文理论端点中点 .404、半宽 .66；固定代码证实 Q0 用样本极值，其均值是 (sample_min+sample_max)/2。代码不能自动构成作者勘误；本DGP/truth不使用Q0。
3. **许可元数据冲突。** LICENSE MIT 与 setup.py 的 BSD 3-Clause 都已取得并记录；不把此冲突写成缺文件，也不替作者决定意图。
4. 维护人认领/查重、新贡献许可选择、具名审核、独立人员复现及科学接收待完成，仍 awaiting_scientific_review。固定 commit、脚本、必要调用文件和 LICENSE 的材料缺口已经解决，无需再补这些文件。远程 Git 对象独立验证未完成，归档链接证据为用户提供的 commit 和匹配 ZIP 注释。

本轮只更新来源元数据/card，新增 author_code_audit.json；generator.py、truth.py、verify.py、config.json、schema.csv、requirements.txt 与 r2 字节一致，端点修复、两个场景和36项检查保留。上一版 r2 ZIP SHA-256 `b4c86fb5a5cd613826245680a13679fe6191bdef565f7b6ce93f999771318463`，与更早版本一并保留在 archive 中。请提交本轮 r3 ZIP。


AI 协助内容：文档提取、相关 PDF 页面视觉核对、元数据和代码撰写、代码自审、有限本地核验与打包。没有冒充具名科学审核或独立人员复现。本包不包含对外发送、PR 或消息操作。
