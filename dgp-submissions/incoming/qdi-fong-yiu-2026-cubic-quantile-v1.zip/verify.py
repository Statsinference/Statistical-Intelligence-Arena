"""Expanded-polynomial CDF inversion and analytic special cases.

Only hooks under test are imported; the CDF route reuses no computational helper
from generator.py or truth.py. All routes share the reconstructed equation.
"""
from copy import deepcopy
from decimal import Decimal, localcontext
import importlib.util
import math
from pathlib import Path
import random
from types import SimpleNamespace
from unittest.mock import patch


def _load(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("qdi_check_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _polynomial(config):
    a = Decimal(str(config["cubic_coefficient"]))
    b = Decimal(str(config["shift"]))
    c = Decimal(str(config["linear_coefficient"]))
    coefficients = (a, -3 * a * b, 3 * a * b * b + c, -a * b * b * b)

    def polynomial(u):
        aa, bb, cc, dd = coefficients
        return ((aa * u + bb) * u + cc) * u + dd

    return polynomial


def _cdf(y, polynomial):
    """F_Y(y) = measure of {u in [0,1]: polynomial(u) <= y}."""
    lo, hi = Decimal(0), Decimal(1)
    if y <= polynomial(lo):
        return lo
    if y >= polynomial(hi):
        return hi
    for _ in range(180):
        mid = (lo + hi) / 2
        if polynomial(mid) <= y:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def verify(config):
    oracle = _load("truth.py")
    generator = _load("generator.py")
    checks = []

    def record(name, passed, details):
        checks.append({"name": name, "passed": bool(passed), "details": details})

    # Use the unchanged host collection checker and actual submitted schema.
    # Replace only this fresh generator module's random binding, never random.Random.
    from collection.core import read_schema
    from collection.worker import digest, validate_observed
    rows = read_schema(Path(__file__).parent)
    original_random_binding = generator.random
    global_state = random.getstate()
    edge_config = deepcopy(config)
    for label, u in (("zero", 0.0), ("next_after_zero", 2.0 ** -53),
                     ("largest_random_grid_value", 1.0 - 2.0 ** -53)):
        injected_random = SimpleNamespace(Random=lambda seed, fixed=u:
                                          SimpleNamespace(random=lambda: fixed))
        with patch.object(generator, "random", injected_random):
            edge_data = generator.generate(config, 1, 1729)
        accepted, failure = True, None
        try:
            validate_observed(edge_data, rows, 1)
        except ValueError as exc:
            accepted, failure = False, str(exc)
        value = edge_data["Y"][0]
        expected = -.256 if u == 0.0 else 4 * (u - .4) ** 3 + .2 * u
        record("rng_grid_boundary_" + label, accepted and value == expected,
               {"u": u, "y": value, "original_validate_observed_passed": accepted,
                "error": failure, "injection": "isolated generator module binding"})
    record("boundary_injection_isolated",
           generator.random is original_random_binding and random.getstate() == global_state
           and config == edge_config,
           "Restored generator.random; global RNG, random.Random and config unchanged.")
    smoke = generator.generate(config, 128, 1729)
    old_digest = "47e9c0278e5721ea1331edf300c543b4c7a9c4af8ae117c238ebb27234e15129"
    record("unchanged_20261031_smoke_sample", digest(smoke) == old_digest,
           {"n": 128, "seed": 1729, "sha256": digest(smoke),
            "baseline": "2026-10-31 checks/report.json in retained ZIP 636a2915..."})

    fixture = {"cubic_coefficient": 4.0, "shift": 0.4,
               "linear_coefficient": 0.2, "quantile_level": 0.9}
    record("source_constants_and_registered_target",
           all(config.get(k) == v for k, v in fixture.items()) and config.get("paper_n") in (50, 500),
           "Paper mechanism a=4,b=.4,c=.2,n=50/500; tau=.9 is a declared target adaptation.")
    reference = oracle.truth(config)
    with localcontext() as context:
        context.prec = 65
        polynomial = _polynomial(config)
        tau = Decimal(str(config["quantile_level"]))
        candidate = Decimal.from_float(reference["value"])
        f_at_candidate = _cdf(candidate, polynomial)
        # Outer inversion solves F(y)=tau without calling the direct quantile formula.
        lo, hi = polynomial(Decimal(0)), polynomial(Decimal(1))
        for _ in range(100):
            mid = (lo + hi) / 2
            if _cdf(mid, polynomial) < tau:
                lo = mid
            else:
                hi = mid
        inverse = (lo + hi) / 2
        error = abs(candidate - inverse)
        record("independent_cdf_inversion", error < Decimal("1e-13"),
               {"cdf_inverted_quantile": str(inverse), "absolute_difference": str(error),
                "y_bracket_width": str(hi - lo), "u_bracket_width": str(Decimal(2) ** -180),
                "precision_decimal_digits": 65, "tolerance": "1e-13"})
        record("cdf_at_registered_quantile", abs(f_at_candidate - tau) < Decimal("1e-14"),
               {"cdf": str(f_at_candidate), "target": str(tau), "tolerance": "1e-14"})
        record("derived_exact_anchor", reference["exact_value"] == "17/25"
               and abs(candidate - Decimal("0.68")) < Decimal("1e-15"),
               "17/25 is derived here, not a separately reported paper result.")
        record("truth_conversion_precision", reference["estimated_error"] <= 1e-15,
               {"estimated_error": reference["estimated_error"], "tolerance": 1e-15})
        left, right = polynomial(Decimal(0)), polynomial(Decimal(1))
        record("support_endpoints_and_cdf_limits",
               left == Decimal("-0.256") and right == Decimal("1.064")
               and _cdf(left - 1, polynomial) == 0 and _cdf(right + 1, polynomial) == 1,
               "Support closure [-.256,1.064]; supplementary E.3.1 p.48 agrees.")
        derivative = 12 * (tau - Decimal("0.4")) ** 2 + Decimal("0.2")
        record("strict_monotonicity_and_tail_density", derivative == Decimal("3.2"),
               "Q'(u)>=.2 for all u; Q'(.9)=3.2, f_Y(.68)=.3125.")
        mean = (left + 4 * polynomial(Decimal("0.5")) + right) / 6
        record("cubic_exact_simpson_mean", mean == Decimal("0.204"),
               "One Simpson panel integrates a cubic exactly: E[Y]=.204, matching supplement p.48.")
        linear = deepcopy(config)
        linear["cubic_coefficient"] = 0.0
        linear_truth = oracle.truth(linear)
        linear_cdf = Decimal.from_float(linear_truth["value"]) / Decimal("0.2")
        record("analytic_uniform_special_case", linear_truth["exact_value"] == "9/50"
               and abs(linear_cdf - tau) < Decimal("1e-14"),
               "Auxiliary test only, not a declared paper scenario: a=0 implies Uniform(0,.2), Q(.9)=.18.")
        center = deepcopy(config)
        center["quantile_level"] = 0.4
        record("analytic_cubic_center_special_case", oracle.truth(center)["exact_value"] == "2/25",
               "Auxiliary query only: Q(.4)=.08 because the cubic term vanishes.")
        n = config["paper_n"]
        saved_state = random.getstate()
        original_config = deepcopy(config)
        data = generator.generate(config, n, 1729)
        repeat = generator.generate(config, n, 1729)
        changed = generator.generate(config, n, 1730)
        values = data.get("Y", [])
        record("nominal_sample_size_observed_only",
               set(data) == {"Y"} and len(values) == n
               and all(isinstance(v, float) and math.isfinite(v) and -.256 <= v <= 1.064 for v in values),
               {"paper_n_actually_generated": n, "observed_columns": list(data)})
        record("nominal_replay_rng_and_config_isolation",
               data == repeat and data != changed and random.getstate() == saved_state and config == original_config,
               "Seeds 1729/1730; no global random-state or scenario-config mutation.")
        rng = random.Random(1729)
        pit_error = max(abs(_cdf(Decimal.from_float(y), polynomial) - Decimal.from_float(rng.random())) for y in values)
        record("generated_data_cdf_transform", pit_error < Decimal("1e-13"),
               {"max_absolute_u_recovery_error": str(pit_error), "tolerance": "1e-13",
                "note": "Uses independently inverted CDF but shares Python RNG algorithm and seed with generator."})
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "shared_components": "Same scientific equation, decimal parameters and monotonicity argument. CDF route uses separate Decimal/Horner/bisection code, not Fraction/direct quantile evaluation. RNG-transform check shares random.Random. This is not independent-person reproduction.",
            "limits": "Scalar functional and finite implementation checks only; no confidence-interval or simultaneous-band coverage assessment."}
