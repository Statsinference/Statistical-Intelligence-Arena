"""Exact rational population quantile, separate from observed sample generation."""
from fractions import Fraction
import math


def truth(config):
    """Decimal config literals denote exact rational scientific parameters."""
    parameters = []
    for name in ("cubic_coefficient", "shift", "linear_coefficient", "quantile_level"):
        value = config[name]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(name + " must be a finite number")
        parameters.append(Fraction(str(value)))
    a, b, c, tau = parameters
    if a < 0 or c <= 0 or not 0 <= b <= 1 or not 0 < tau < 1:
        raise ValueError("Strict monotonicity and an interior quantile are required")
    exact = a * (tau - b) ** 3 + c * tau
    value = float(exact)
    conversion_error = abs(Fraction.from_float(value) - exact)
    # Round upward so the diagnostic does not understate binary conversion error.
    error = math.nextafter(float(conversion_error), math.inf) if conversion_error else 0.0
    return {
        "value": value,
        "estimated_error": error,
        "exact_value": str(exact),
        "target": "inf{y: F_Y(y) >= tau}, marginal population quantile",
        "quantile_level": float(tau),
        "method": "Exact Fraction evaluation of a*(tau-b)^3+c*tau; Q'(u)>0",
        "error_interpretation": "Exact rational arithmetic before float conversion; estimated_error bounds only the final binary-float conversion. It is not sampling error or source uncertainty.",
    }
