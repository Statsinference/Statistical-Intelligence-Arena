"""Population CATE at the declared query points.

The target is never estimated from generated rows: it is evaluated from the
declared mechanism.  The query points are part of the estimand definition and are
repeated in card.md and collection.json.
"""
import math

QUERY_POINTS = {
    "primary": {
        "X1": 0.5,
        "X2": 0.5,
        "X3": 0.0,
        "X4": 0.0,
        "X5": 0.0
    },
    "secondary": {
        "X1": -0.5,
        "X2": 0.0,
        "X3": 0.0,
        "X4": 0.0,
        "X5": 0.0
    }
}


def tau_at(x):
    """CATE surface of the mechanism, evaluated at one query point."""
    return (
        (x["X1"] + math.log(1.0 + math.exp(x["X2"])))
    )


def truth(config):
    scale = float(config["tau_scale"])
    primary = tau_at(QUERY_POINTS["primary"]) * scale
    secondary = tau_at(QUERY_POINTS["secondary"]) * scale
    return {
        "value": primary,
        "estimated_error": 1e-12,
        "method": "Closed form: tau(x0) = x1 + log(1 + e^{x2}); the second typing uses log1p(exp(.)) directly. Checked end-to-end against the realised outcome column.",
        "target": "tau(x0) at QUERY_POINTS['primary'], evaluated from the declared mechanism",
        "value_at_secondary_query": secondary,
        "scale_used": scale,
    }
