# Nie–Wager (2021) Setup B: randomised trial with a logarithmic treatment effect

**Contribution `cate-nie-2021-setup-b-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `nie-wager-2021-setup-b`

## Source and reconstruction

- Citation: Nie, X. and Wager, S. (2021). Quasi-oracle estimation of heterogeneous treatment effects. Biometrika 108(2), 299-319. DOI: 10.1093/biomet/asaa076.
- Venue / year: Biometrika, 2021
- Link: https://arxiv.org/abs/1712.04912
- **Exact locator**: Section 6.1, arXiv:1712.04912v4 (6 Aug 2020) PDF p.16, unnumbered Setup B paragraph (no equation number in the source): 'Here, e*(x) = 1/2 for all x ... Xi ~ N(0, I_{d x d}), tau*(Xi) = Xi1 + log(1 + e^{Xi2}), and b*(Xi) = max{Xi1 + Xi2, Xi3, 0} + max{Xi4 + Xi5, 0}'.
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **X1-X5**: `Xj ~ Normal(0,1) independently, j = 1..5`
2. **Treatment**: `e(X) = 1/2`
3. **Baseline**: `b(X) = max{X1 + X2, X3, 0} + max{X4 + X5, 0}`
4. **Heterogeneity**: `tau(X) = X1 + log(1 + exp(X2))`
5. **Outcome**: `Y = b(X) + A tau(X) + sigma eps, eps ~ Normal(0,1), sigma = 1`

Sampling unit: individual · dependence: independent and identically distributed

Fixed parameters: standard normal covariates, noise sigma = 1, no trimming (randomised assignment).

### Adaptations relative to the source

- Dimension fixed at d = 5, the smallest dimension for which b(x) is fully defined; the source varies d in {6, 12}.
- The source writes Y = b(X) + (W - 0.5) tau(X) + sigma eps; this package uses A in {0,1} and the same b, tau. The CATE is unchanged.
- sigma is fixed at 1 (the source also reports 0.5, 2, 3).

## Target and identification

- Symbol: `tau(x0) = E[Y(1) - Y(0) | X = x0]`
- Definition: Conditional average treatment effect at the declared query points; linear in X1 plus a log-sum-exp transform of X2.
- Query points (part of the estimand): `primary`: (X1 = 0.5, X2 = 0.5, X3 = 0.0, X4 = 0.0, X5 = 0.0); `secondary`: (X1 = -0.5, X2 = 0.0, X3 = 0.0, X4 = 0.0, X5 = 0.0)

Identification assumptions:

- SUTVA: one version of treatment, no interference
- Randomised assignment: e(x) = 1/2, so unconfoundedness holds by design and no propensity adjustment is needed
- Overlap: e(x) = 1/2 with margin 0.5
- Homoscedastic Gaussian noise with sigma = 1

Setup B isolates the case where confounding is absent, so any remaining error is due to the baseline's non-additivity, not to propensity adjustment. The effect surface ranges roughly over [-1, 4] on the bulk of the support.

## Truth and independent verification

Additive outcome: E[Y|A=1,X=x] - E[Y|A=0,X=x] = tau(x). At (0.5, 0.5) this is 0.5 + log(1+e^{0.5}) = 1.4740769842.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and confirms end-to-end that the realised
outcome column of `generator.py` carries the declared surface (arm-contrast shift
equals the mean of tau over treated rows, at identical seed). Both routes share the
declared mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 5 (effective 5) · high dimensional: False · interactions: True · nonlinear: True
- Gaussian covariates have unbounded support, so no uniform overlap constant is claimed; with e = 1/2 the issue is moot. No weak-identification region, but the log-sum-exp term is nearly linear for large X2 and nearly exponential for negative X2.

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| X1 | covariate | float | · | · | true |
| X2 | covariate | float | · | · | true |
| X3 | covariate | float | · | · | true |
| X4 | covariate | float | · | · | true |
| X5 | covariate | float | · | · | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by Oxford University Press for Biometrika. No PDF or author code is redistributed.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: d fixed at 5, sigma fixed at 1.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
