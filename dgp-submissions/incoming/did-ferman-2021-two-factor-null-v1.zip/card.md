# M11: Ferman (2021), fixed two-type common-AR-factor null

## Source and scientific scope
Bruno Ferman (2021), *On the Properties of the Synthetic Control Estimator with Many Periods and Many Controls*, JASA116(536),1764–1772. DOI https://doi.org/10.1080/01621459.2021.1965613 .
Official publication-linked supplementary archive https://doi.org/10.6084/m9.figshare.15135426.v3 ,
file31887422, MD5 5d0337c0f1da966466b54a2e35362456.
Codes/Readme.rtf line10 links main.R and aux.R to Table1.
Source main.R: K30; fixed loadings34–37 and77–86; Gaussian AR1 and parameters40–50; error variance53; T1/effect57–60; J/T0 grid66–71; factors75; errors89; outcomes91; response shift94.
aux.R12–19 gives stationary initialization, recursion and initial-draw removal.
Auxiliary arXiv1906.06665v5 Section5 PDF17–18 and Table1 PDF46 provide source design context. These are not formal journal page numbers. Full published-main-text version comparison remains incomplete; no unverified locator is claimed.
The formal archive, not third-party estimators, supplies the complete current mechanism.
The project authorizes DiD / synthetic control as did_sc. This is a synthetic-control-source panel null, not a claim that estimator labels define DGP families.

## Frozen source baseline
J=10, N=11; T0=20=2J; T1=1; two factors.
R experiment seed47 and nreps5000 concern evaluation, not a required Python random stream or separate families.
Only one declared scenario, table1_j10_t020_null.
No source parameter extensions; external n must equal11. Default toolkit n32 is deliberately rejected, rather than changing scientific donor counts.

## Generative law and ordering
For k=1,2 draw independent F_k0~N(0,1).
For s=1,...,21 set F_ks=.5 F_k,s-1+eta_ks, eta iidN(0,.75), independent of all initial values.
Drop only the initial draw; no extra burn-in.
Treatment unit i=0 and donors i=1,...,5 have loading(1,0); donors i=6,...,10 have loading(0,1).
Draw epsilon_is iidN(0,1), independent of factors.
Observed Y_is=mu_i'F_s+epsilon_is; only i=0,s=21 receives post_effect=0.
The two public latent factors are drawn once for the whole panel, not once per row.
No missingness, attrition or calibration-data assets.

Scientific time t=s-20: pre t=-19,...,0; sole post t=1.
Internal initialization s0 corresponds to scientific t=-20. It is not exported.
One wide observed row is one unit; order is treated first, then donors1–10.

## Observed schema and exposure
Exactly22 columns: G,Y_pre_01,...,Y_pre_20,Y_post_01.
G is treatment/binary 0 or1; outcome columns are finite float without finite support bounds. All columns observed=true.
Exposure is A_pre=0,A_post=G. No ID, donor-type, factor, loading, error, potential-outcome or truth-label column is exported.
Twenty-one outcomes are not baseline covariates: dimension=effective_dimension=0.
generate returns a column-to-list dictionary, all lists length11. It never copies/truncates rows to accept another n.

## Estimand and exact truth
Target tau_01=Y_01(1)-Y_01(0), the specified treated unit in its only post period.
Both intervention states share identical common factors and the same post disturbance; their response difference is post_effect=0 pointwise.
Thus finite single-treated SATT and design-population average both equal0, regardless of sample means or estimator success.
Observed post-minus-pre need not vanish.
Consistency/no interference/no anticipation define the intervention. Factor-model identification and quality of fitted SC weights do not establish oracle truth.

## Mathematical and independent data verification
Var(F_ks)=1 and Cov(F_ks,F_kr)=.5^abs(s-r), with cross-factor covariance0.
Cov(Y_is,Y_jr)=mu_i'mu_j*.5^abs(s-r)+1{i=j,s=r}.
Unit variance2; same-type different-unit same-period covariance1; different-type covariance0.
After removing shared factors, treated/donor idiosyncratic covariance is0. This contrasts with M12 donor-noise inheritance.

truth.py independently derives pointwise response cancellation.
verify.py imports neither generator nor truth and uses exact-rational closed-form impulse expansion for all441 factor covariance entries and pointwise treatment polynomial.
verify(config) does not receive actual data or n and cannot validate realized counts/seed/pairing.
tests/test_m11.py is the only authoritative independent test source:
structural/schema checks; seed/local-RNG checks; illegal-input rejection; independent closed-form reconstruction from traced primitive normal draws; empirical process/observed covariance checks.
A test-only Random subclass records primitive Gaussian draws in memory, never exports hidden columns. The independent reconstruction uses impulse sums, not the generator recursion.
Audit JSON saves actual statistics, thresholds and decisions; finite tests do not prove distributional independence in general.
Only summary evidence is persisted; no latent sample bank or original R/PDF is included.

## Family distinction and adaptation
M01 has independent units with shared within-unit observed nonlinear X signal.
M11 has common serial factors with independent iid unit noise.
M12 instead uses donor AR errors and directly passes their weighted noise into the treated response.
Do not count changed J/T0, seed, estimator or parameter scenarios as new M11 mechanisms.
Adaptations are numerical unit-wide format and Python local RNG; scientific source baseline is preserved.
This contribution is AI-assisted independent Python code and requires scientific review even after machine checks.

## Source rights
source.license records origin rights only.
Official Figshare15135426.v3 metadata records CC BY4.0 for its supplementary item; no extension to the formal article or this Python implementation is inferred.
The formal main article full-text copyright/open-license statement was not verified; no open permission is claimed.
No article PDF or author R source is redistributed. This field selects no release license for independently written contribution code.
