"""Structural response oracle; independent of generator implementation."""
import math


def truth(config):
    expected = {
        "J": 10, "N": 11, "T0": 20, "T1": 1, "K": 2, "rho": 0.5,
        "alpha": 0, "factor_innovation_variance": 0.75,
        "factor_initial_variance": 1, "error_variance": 1,
        "donors_type1": 5, "donors_type2": 5, "post_effect": 0, "burn_in": 0,
        "representation": "unit_wide_22_observed_columns",
        "sample_size_policy": "strict_n_equals_11",
    }
    if not isinstance(config, dict) or set(config) != set(expected):
        raise ValueError("Oracle requires the registered complete fixed M11 configuration")
    for key, value in expected.items():
        actual = config[key]
        valid = actual == value if isinstance(value, str) else (
            isinstance(actual, (int, float)) and not isinstance(actual, bool)
            and math.isfinite(actual) and actual == value)
        if not valid:
            raise ValueError(f"Unapproved oracle parameter {key}")
    return {
        "value": 0.0, "estimated_error": 0.0,
        "method": "Exact pointwise response cancellation",
        "definition": "Y_01(1)-Y_01(0), not an observed pre/post difference",
        "derivation": "Both states use identical common factors and the same treated post disturbance. "
                      "Their difference is post_effect=0 for every realization. "
                      "Thus single-treated SATT and the design-population expectation are zero.",
    }
