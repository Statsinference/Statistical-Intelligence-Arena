"""Independent exact-rational mathematical check; receives no generated table."""
from fractions import Fraction as Q
import math


def verify(config):
    expected = {
        "J": 10, "N": 11, "T0": 20, "T1": 1, "K": 2, "rho": 0.5,
        "alpha": 0, "factor_innovation_variance": 0.75,
        "factor_initial_variance": 1, "error_variance": 1,
        "donors_type1": 5, "donors_type2": 5, "post_effect": 0, "burn_in": 0,
        "representation": "unit_wide_22_observed_columns",
        "sample_size_policy": "strict_n_equals_11",
    }
    checks = []
    def record(name, passed, details):
        checks.append({"name": name, "passed": bool(passed), "details": details})
    valid = isinstance(config, dict) and set(config) == set(expected)
    if valid:
        for key, expected_value in expected.items():
            v = config[key]
            if isinstance(expected_value, str):
                valid = valid and v == expected_value
            else:
                valid = valid and (isinstance(v, (int, float)) and not isinstance(v, bool)
                                   and math.isfinite(v) and v == expected_value)
    record("registered_fixed_parameters", valid, "Exact approved Table1 cell and interface")
    if not valid:
        return {"passed": False, "checks": checks}

    # Closed-form impulse coefficients; unlike the generator's state recursion.
    rho, innovation = Q(1, 2), Q(3, 4)
    def factor_cov(s, t):
        common = min(s, t)
        return rho ** (s+t) + innovation * sum(
            (rho ** (s-r)) * (rho ** (t-r)) for r in range(1, common+1))
    variance_checks = [factor_cov(s, s) == 1 for s in range(1, 22)]
    covariance_checks = [factor_cov(s, t) == rho ** abs(s-t)
                         for s in range(1, 22) for t in range(1, 22)]
    record("stationary_first_and_all_observed_variances", all(variance_checks),
           {"innovation_variance": "3/4", "initial_variance": 1, "observed_periods": 21})
    record("full_ar_covariance_by_impulse_expansion", all(covariance_checks),
           {"entries_checked": 441, "covariance": "(1/2)^abs(s-t)",
            "independent_factor_cross_covariance": 0})
    # Source fixed deterministic loading design, separate from generator branching.
    loadings = [(1, 0)] * 6 + [(0, 1)] * 5
    record("source_donor_loading_allocation", loadings[1:].count((1, 0)) == 5
           and loadings[1:].count((0, 1)) == 5 and loadings[0] == (1, 0),
           {"treated_type": 1, "donors_each_type": 5})
    record("observed_covariance_identity",
           factor_cov(1, 1)+1 == 2 and factor_cov(1, 2) == Q(1, 2),
           {"unit_variance": 2, "same_type_pair_same_time": 1,
            "different_type_pair": 0, "idiosyncratic_cross_unit_covariance": 0})
    # Difference two potential responses expressed as coefficients on common
    # post factors, treated disturbance, and a constant treatment shift.
    contrast_coefficients = [Q(0), Q(0), Q(0), Q(str(config["post_effect"]))]
    record("pointwise_post_response_polynomial",
           all(v == 0 for v in contrast_coefficients),
           {"contrast_coefficients": [str(v) for v in contrast_coefficients],
            "satt": 0, "design_population_average": 0})
    record("time_index_mapping", list(range(1-20, 1))[-1] == 0
           and 21-20 == 1 and 0-20 == -20,
           "Internal initial s=0 is scientific t=-20, not last pre t=0")
    return {
        "passed": all(c["passed"] for c in checks), "checks": checks,
        "scope": "Mathematical source/config identities only; no actual table or external n received.",
        "independence": "No imports of generator.py or truth.py; exact-rational impulse expansion.",
        "limits": "Sample counts, seed behavior and realized latent/observed relationships require separate tests.",
    }
