"""Authoritative independent M11 tests; standard library, no latent output files."""
import copy
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import random
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import generator
import truth
import verify

DOC = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
CONFIG = DOC["scenarios"][DOC["default_scenario"]]
EVIDENCE = {}


class TraceRandom(random.Random):
    """Test-only primitive tracing; discarded after extracting aggregate evidence."""
    latest = None
    def __init__(self, seed):
        super().__init__(seed)
        self.draws = []
        TraceRandom.latest = self
    def gauss(self, mu=0.0, sigma=1.0):
        value = super().gauss(mu, sigma)
        self.draws.append((mu, sigma, value))
        return value


def traced_world(seed):
    with patch.object(generator, "Random", TraceRandom):
        observed = generator.generate(CONFIG, 11, seed)
    draws = TraceRandom.latest.draws
    if len(draws) != 275:
        raise AssertionError("Expected two initial states, 42 factor innovations and 231 unit errors")
    # Independent closed-form AR impulse sum instead of generator's state recursion.
    factors = []
    initial = []
    innovations = []
    for offset in (0, 22):
        mean, sd, z0 = draws[offset]
        if mean != 0 or sd != 1:
            raise AssertionError("Initial-state primitive must be standard normal")
        initial.append(z0)
        eta = [row[2] for row in draws[offset+1:offset+22]]
        if any(row[0] != 0 or row[1] != math.sqrt(0.75)
               for row in draws[offset+1:offset+22]):
            raise AssertionError("Factor innovation primitive must have variance .75")
        innovations.append(eta)
        factors.append([
            0.5 ** s * z0 + math.fsum(0.5 ** (s-r) * eta[r-1] for r in range(1, s+1))
            for s in range(1, 22)])
    errors = [[draws[44+i*21+s][2] for s in range(21)] for i in range(11)]
    if any(mu != 0 or sd != 1 for mu, sd, _ in draws[44:]):
        raise AssertionError("Unit disturbances must be standard normal")
    return observed, factors, errors, initial, innovations


def average(values):
    return math.fsum(values)/len(values)


class M11Tests(unittest.TestCase):
    def test_structure_and_closed_form_mapping(self):
        actual, factors, errors, _, _ = traced_world(1729)
        names = ["G"]+[f"Y_pre_{k:02d}" for k in range(1, 21)]+["Y_post_01"]
        self.assertEqual(list(actual), names)
        self.assertEqual(actual["G"], [1]+[0]*10)
        self.assertTrue(all(len(v)==11 for v in actual.values()))
        loadings = [(1, 0)]*6+[(0, 1)]*5  # source design, includes treated row
        self.assertEqual(loadings[1:].count((1, 0)), 5)
        self.assertEqual(loadings[1:].count((0, 1)), 5)
        for i, loading in enumerate(loadings):
            for s, name in enumerate(names[1:]):
                expected = loading[0]*factors[0][s]+loading[1]*factors[1][s]+errors[i][s]
                self.assertAlmostEqual(actual[name][i], expected, places=12)
                self.assertIsInstance(actual[name][i], float)
                self.assertTrue(math.isfinite(actual[name][i]))
        EVIDENCE["structure"] = {
            "rows": 11, "columns": names, "treated": 1, "donors": 10,
            "donor_type_counts": [5, 5], "pre_periods": 20, "post_periods": 1,
            "scientific_pre_times": list(range(-19, 1)), "scientific_post_time": 1,
            "closed_form_mapping_comparisons": 231,
            "primitive_normal_draw_count": 275,
            "test_trace_limits": "Hidden primitives remain in memory only; no exported latent columns.",
        }

    def test_seed_and_no_global_mutation(self):
        state = random.getstate()
        config = copy.deepcopy(CONFIG)
        a = generator.generate(config, 11, 1729)
        self.assertEqual(a, generator.generate(config, 11, 1729))
        b = generator.generate(config, 11, 1730)
        for name in a:
            if name != "G":
                self.assertNotEqual(a[name], b[name])
        self.assertEqual(random.getstate(), state)
        self.assertEqual(config, CONFIG)
        EVIDENCE["randomness"] = {"same_seed_equal": True, "different_seed_changes_all_outcomes": True,
                                  "global_rng_unchanged": True, "config_unchanged": True}

    def test_reject_unapproved_inputs(self):
        for n in (0, 1, 10, 12, 21, 32, True, 11.0):
            with self.assertRaises(ValueError):
                generator.generate(CONFIG, n, 1729)
        for seed in (True, "1729", 1.5):
            with self.assertRaises(ValueError):
                generator.generate(CONFIG, 11, seed)
        for key, wrong in (("J", 12), ("T0", 19), ("rho", 0.6),
                            ("factor_innovation_variance", 0.5),
                            ("factor_initial_variance", 0), ("error_variance", 2),
                            ("donors_type1", 6), ("post_effect", 1),
                            ("burn_in", 100), ("rho", True), ("rho", float("nan"))):
            altered = dict(CONFIG, **{key: wrong})
            with self.assertRaises(ValueError):
                generator.generate(altered, 11, 1729)
            with self.assertRaises(ValueError):
                truth.truth(altered)
            self.assertFalse(verify.verify(altered)["passed"])
        for altered in (dict(CONFIG, extra_parameter=1), {k:v for k,v in CONFIG.items() if k!="K"}):
            with self.assertRaises(ValueError):
                generator.generate(altered, 11, 1729)
            with self.assertRaises(ValueError):
                truth.truth(altered)
            self.assertFalse(verify.verify(altered)["passed"])
        EVIDENCE["invalid_inputs"] = {"strict_n_policy": True, "unapproved_parameters_rejected": True}

    def test_independent_mathematics_and_truth(self):
        verification = verify.verify(CONFIG)
        self.assertTrue(verification["passed"])
        self.assertEqual(truth.truth(CONFIG)["value"], 0)
        self.assertEqual(truth.truth(CONFIG)["estimated_error"], 0)
        # Analytic independent potential-response comparison with shared exogenous
        # coefficients; no generated oracle/latent outcomes are exported.
        rho = Fraction(1, 2)
        for s in (1, 2, 21):
            variance = rho**(2*s)+Fraction(3,4)*sum(rho**(2*r) for r in range(s))
            self.assertEqual(variance, 1)
        EVIDENCE["mathematics"] = verification

    def test_distribution_and_covariances(self):
        reps = 4096
        # Primitive arrays are test memory only; evidence stores summaries.
        initial = [[], []]
        factors = [[[] for _ in range(21)] for _ in range(2)]
        innovations = [[], []]
        errors = [[[] for _ in range(21)] for _ in range(11)]
        outcomes = [[[] for _ in range(21)] for _ in range(11)]
        for seed in range(20000, 20000+reps):
            data, fs, es, starts, etas = traced_world(seed)
            for k in range(2):
                initial[k].append(starts[k])
                innovations[k].extend(etas[k])
                for s in range(21):
                    factors[k][s].append(fs[k][s])
            for i in range(11):
                for s, name in enumerate(list(data)[1:]):
                    errors[i][s].append(es[i][s])
                    outcomes[i][s].append(data[name][i])

        checks = {}
        EVIDENCE["statistical_audit"] = {
            "replications": reps, "seed_range": [20000, 20000+reps-1],
            "panels": reps, "units": reps*11, "observations": reps*11*21,
            "checks": checks,
            "policy": "Strict absolute deviations against predeclared conservative Gaussian moment bounds; eight-scale diagnostic thresholds, not simultaneous confidence guarantees.",
            "limits": "Empirical evidence, not a universal proof of independence. Covariances use independent panel replications; hidden primitive tracing is test-only.",
        }
        def record(name, statistic, target, bound):
            passed = abs(statistic-target) < bound
            checks[name] = {"statistic": statistic, "target": target,
                            "absolute_deviation": abs(statistic-target), "threshold": bound,
                            "comparison": "absolute_deviation < threshold", "passed": passed}
            self.assertTrue(passed, name)
        def moment(name, values, target_second):
            count = len(values)
            record(name+"_mean", average(values), 0, 8*math.sqrt(target_second/count))
            record(name+"_second", average([v*v for v in values]), target_second,
                   8*target_second*math.sqrt(2/count))
        def covariance(name, x, y, target, var_x=1, var_y=1):
            # Record empirical covariance rather than uncentered cross-product.
            estimate = average([a*b for a,b in zip(x,y)])-average(x)*average(y)
            record(name, estimate, target, 8*math.sqrt((var_x*var_y+target*target)/reps))
        for k in range(2):
            moment(f"factor{k+1}_initial", initial[k], 1)
            moment(f"factor{k+1}_innovations", innovations[k], .75)
            for s in range(21):
                moment(f"factor{k+1}_s{s+1}", factors[k][s], 1)
            for lag in (1, 2, 5, 20):
                covariance(f"factor{k+1}_lag{lag}", factors[k][0], factors[k][lag], .5**lag)
        for s,t in ((0,0),(0,20),(20,0),(20,20)):
            covariance(f"cross_factor_s{s+1}_s{t+1}",factors[0][s],factors[1][t],0)
        for i in range(11):
            moment(f"unit{i}_first_error", errors[i][0], 1)
            covariance(f"unit{i}_error_lag1", errors[i][0], errors[i][1], 0)
        for j in range(1, 11):
            covariance(f"treated_donor{j}_error", errors[0][0], errors[j][0], 0)
        for k in range(2):
            covariance(f"factor{k+1}_unit0_error", factors[k][0], errors[0][0], 0)
        for i in (0, 1, 5, 6, 10):
            moment(f"unit{i}_observed_first", outcomes[i][0], 2)
        covariance("same_type_observed_pair", outcomes[0][0], outcomes[1][0], 1, 2, 2)
        covariance("different_type_observed_pair", outcomes[0][0], outcomes[6][0], 0, 2, 2)
        covariance("same_type_cross_time_pair", outcomes[0][0], outcomes[1][1], .5, 2, 2)
        covariance("single_unit_observed_lag1", outcomes[0][0], outcomes[0][1], .5, 2, 2)
        EVIDENCE["statistical_audit"]["passed"] = all(c["passed"] for c in checks.values())


if __name__ == "__main__":
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(M11Tests))
    EVIDENCE.update({
        "passed": result.wasSuccessful(), "tests_run": result.testsRun,
        "failures": len(result.failures), "errors": len(result.errors),
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "authoritative_test_source": "tests/test_m11.py",
        "source_sha256": {
            p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(ROOT.rglob("*")) if p.is_file()
            and "checks" not in p.relative_to(ROOT).parts
            and "__pycache__" not in p.relative_to(ROOT).parts
        },
    })
    checks = ROOT / "checks"
    checks.mkdir(exist_ok=True)
    (checks/"independent_audit.json").write_text(
        json.dumps(EVIDENCE, ensure_ascii=False, indent=2, allow_nan=False)+"\n",encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
