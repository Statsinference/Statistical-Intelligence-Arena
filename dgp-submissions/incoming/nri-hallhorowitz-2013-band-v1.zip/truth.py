"""Analytic population target m(x0) = g_j(x0); no rows, integration or simulation involved."""
import math

_FUNCTIONS = ("g1", "g2", "g3")


def sign(x):
    """sgn(x) = 1 if x > 0, 0 if x = 0, -1 if x < 0."""
    if x > 0.0:
        return 1.0
    if x < 0.0:
        return -1.0
    return 0.0


def normal_density(t):
    """phi(t) = exp(-t^2/2)/sqrt(2*pi). For t = 10*x this gives phi(10x) = exp(-50x^2)/sqrt(2*pi)."""
    return math.exp(-t * t / 2.0) / math.sqrt(2.0 * math.pi)


def mean_function(name, x):
    """Closed-form evaluation of the Section 3 regression function named in the scenario."""
    if name == "g1":
        return x + 5.0 * normal_density(10.0 * x)
    if name == "g2":
        return math.sin(3.0 * math.pi * x / 2.0) / (1.0 + 18.0 * x * x * (sign(x) + 1.0))
    if name == "g3":
        return math.sin(math.pi * x / 2.0) / (1.0 + 2.0 * x * x * (sign(x) + 1.0))
    raise ValueError("unknown mean function: " + repr(name))


def truth(config):
    name = config["function"]
    if name not in _FUNCTIONS:
        raise ValueError("function must be one of g1, g2, g3")
    query = float(config["query_x"])
    low = float(config["support_min"])
    high = float(config["support_max"])
    if not math.isfinite(query) or not low < query < high:
        raise ValueError("query_x must be finite and strictly inside the declared support")
    return {
        "value": mean_function(name, query),
        "estimated_error": 1e-12,
        "method": "Direct substitution of the query point into the closed form g_j, with phi(10x) = exp(-50x^2)/sqrt(2*pi); one elementary function evaluation, so the reported error is a floating-point rounding allowance rather than a quadrature or Monte Carlo error estimate.",
        "error_interpretation": "Declared rounding allowance for a single closed-form evaluation; it is not a rigorous bound and it does not account for how a finite-sample estimator, bandwidth or bootstrap calibration behaves.",
        "target": "m(x0) = E[Y | X = x0] = g_j(x0)",
    }
