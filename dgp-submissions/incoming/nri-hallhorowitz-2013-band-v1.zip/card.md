# N05 一元光滑回归的窄峰与分段有理函数

Contribution: `nri-hallhorowitz-2013-band-v1` · `synthetic_dgp` · `nonparametric_regression` · **v1**

## Source and reconstruction

Hall, P. and Horowitz, J. L. (2013). A simple bootstrap method for constructing nonparametric confidence bands for functions. The Annals of Statistics 41(4), 1892-1921. DOI: 10.1214/13-AOS1137.

[DOI](https://doi.org/10.1214/13-AOS1137) · [固定阅读版本 1309.4864v1](https://arxiv.org/pdf/1309.4864v1)

实读 PDF SHA-256：`c9570bebb37844060c411f44807674308e61ade3fd5e4349ff5709c67f271531`。IMS electronic reprint of the published article; the actual first-page declaration says pagination and typographic detail differ from the original.

Formula bodies: (2.1) on PDF p.4. Section starts: Section 2.1 on PDF p.4, Section 3 on PDF p.13, Section 3.1 on PDF p.13, Section 3.2 on PDF p.14. Unnumbered paragraph on PDF p.13: "For n = 100, 200 or 400" (three g functions, n, sigma, distribution and repetition parameters). Unnumbered paragraph on PDF p.14: "a proportion of values" (evaluation interval [-0.9,0.9]). All PDF pages are 1-based pages of the fixed reading file 1309.4864v1. No printed journal page is inferred by adding an offset.

**原文参数逐页登记**

- PDF p.13：X~Uniform[-1,1]; epsilon~N(0,sigma^2); n=100,200,400; sigma=1,0.5,0.2; 1000 simulations; g1 coefficient5 and normal-density argument10x; g2 frequency3*pi/2 and denominator coefficient18; g3 frequencypi/2 and denominator coefficient2; sgn(0)=0。
- PDF p.14：evaluation interval[-0.9,0.9]。

**按实际执行顺序的生成步骤**

1. **Observed design** — X_i iid Uniform(-1,1). Source support -1..1; one scalar covariate per row.
2. **Mean function** — g1(x)=x+5*exp(-50*x^2)/sqrt(2*pi); g2(x)=sin(3*pi*x/2)/(1+18*x^2*(sgn(x)+1)); g3(x)=sin(pi*x/2)/(1+2*x^2*(sgn(x)+1)). Deterministic; sgn(x)=-1/0/1 for x<0/=0/>0. All coefficients are from the source unnumbered functions.
3. **Regression error** — epsilon_i iid N(0,sigma^2), independent of X; registered pairs are (g1,sigma=1),(g2,0.5),(g3,0.2). sigma is a standard deviation, not a variance; the source has a full 3-by-3 design.
4. **Observed response** — Y_i=g_j(X_i)+epsilon_i; return X,Y. No extra noise, latent mean or oracle column.

**抽样单位与依赖**：One scalar covariate/outcome pair (X_i, Y_i), one observation per independent unit；iid across i with no within-cluster correlation; X_i is drawn independently of epsilon_i, so observations share nothing beyond the fixed DGP parameters

**边界与尺度**：For x<0, sgn(x)+1=0. At x=0 the factor is 1, but x^2=0 so both rational denominators are still 1. All three queries are interior to [-1,1].

**与来源的改动及理由**

1. Select three cells of the source's 3-by-3 g_j by sigma design: (g1,1), (g2,0.5), (g3,0.2).
2. Replace the source pointwise confidence-band/coverage study over an interval by the scalar response mean m(x0); add x0=0,.3,.5. The source is not described as a conventional all-points simultaneous-coverage experiment.
3. Use the interface's requested n and CPU checks, without fitting estimators or reproducing coverage.

固定点目标由已声明条件响应律识别：高斯模型使用零条件均值的误差/随机效应，广义回归直接用指定分布的链接均值。接口 n 和查询为适配；未把 n=128 说成论文原实验样本量。

**版本关系**：The actual fixed reading PDF is an IMS electronic reprint of the published article, not a separate author-preprint draft merely because it is hosted on arXiv. The first-page declaration explicitly notes pagination and typographic differences. We use only verified section/equation/1-based PDF locators and do not claim identical publisher typesetting, exact printed-page offsets or entire-text identity. No separate author-preprint-to-formal substitution is involved for this reading source; that conditional comparison is N/A. Its first-page header and declaration print issue No.1, while DOI metadata and the journal issue list give 41(4):1892-1921. The citation follows the authoritative publication metadata; the PDF is not altered.

## Target and identification

`m(x0) = E[Y | X = x0] = g_j(x0)`

The value of the conditional mean function at one fixed interior design point x0 specified per scenario, in the superpopulation defined by the declared regression model with X uniform on [-1,1] and additive N(0, sigma^2) noise. This is a pointwise scalar query, not a simultaneous confidence band and not a coverage claim over any interval.

**登记场景与查询**

| Scenario | Parameters / query |
|:--|:--|
| `g1-sigma1`（默认） | `{"source_case": "g1-sigma1", "function": "g1", "sigma": 1.0, "support_min": -1.0, "support_max": 1.0, "query_x": 0.0}` |
| `g2-sigma05` | `{"source_case": "g2-sigma05", "function": "g2", "sigma": 0.5, "support_min": -1.0, "support_max": 1.0, "query_x": 0.3}` |
| `g3-sigma02` | `{"source_case": "g3-sigma02", "function": "g3", "sigma": 0.2, "support_min": -1.0, "support_max": 1.0, "query_x": 0.5}` |

场景中的 original-* 表示保留的来源生成参数，不代表新增查询和接口样本量属于原文实验。本包三场景为原文三个回归函数在各自 sigma 下的自选查询，命名为 g1-sigma1、g2-sigma05、g3-sigma02；不复制同义场景充数。

**抽样、设计与支持条件**

- Independent and identically distributed pairs (X_i, Y_i); no clustering, serial dependence, spatial or network interference is present.
- X_i is drawn uniformly on [-1,1], so its density is bounded away from zero at every interior query point used here and local smoothing has design points on both sides of x0.
- epsilon_i ~ N(0, sigma^2) is independent of X_i and additive, so no correction for heteroskedasticity, measurement error or endogenous regressors is required to identify E[Y | X = x0].
- g_j is bounded on [-1,1] and smooth enough for the local-polynomial regularity assumed in Section 2 of the source; g2 and g3 are continuous at x = 0 where the sign convention switches.
- The query point x0 is fixed interior to the support and chosen before seeing data; pointwise verification at one or several x0 does not establish simultaneous coverage over the source evaluation interval [-0.9, 0.9].
- This is a non-causal regression target: no intervention, exposure, exchangeability or counterfactual consistency assumption is claimed.

固定点条件均值正确，不等于点态区间或同时置信带覆盖率达标。非因果任务不套用干预/无混杂假设。

## Truth and independent verification

Closed-form substitution of the scenario query point into g_j, with phi(10x) = exp(-50x^2)/sqrt(2*pi) evaluated directly and sgn(x) applied branch-wise; a single elementary evaluation, so the reported error is a floating-point rounding allowance rather than a quadrature or Monte Carlo error estimate. Reported estimated_error is 1e-12.

`truth.tolerance=1e-08`。estimated_error 是浮点/数值路线诊断，不是严格统一误差界或统计标准误；其非负且不大于 tolerance。

**不同路线与解析特例**：独立指数/三角函数求值与另一随机数路线的局部窗口 Monte Carlo；g1(0)=5/sqrt(2*pi)，g2(0)=g3(0)=0 是解析锚点。

**实际共享函数与独立边界**：verify 的 interpretable_anchor 调用 truth.mean_function，属于共享闭式的解释/一致性检查，不能称为独立实现；generator.generate 用于实际设计诊断。真正不同路线为 local_sin 的 Taylor 级数、statistics.NormalDist 密度、分支分母及 NumPy 单独生成的 Monte Carlo。

外部另按论文公式用 mpmath 70 位重算全部登记查询；另对各场景 generate(n=4096, seed=7312026) 实际观察列独立重构残差，不导入私有均值助手或 verify 作外部参照。N08 的源数学参照取精确 1/sqrt(3)，与配置中最短十进制权重的浮点差计入比较；阈值仍逐包取 tolerance，不靠放宽阈值通过。

## Diversity and scope

`dimension=1`，`effective_dimension=1`。The single covariate X is the only input, so dimension = effective_dimension = 1 and high_dimensional is false relative to the source sample sizes n = 100, 200, 400. interactions is false: the mean depends on X through one univariate function with no product term between covariates. nonlinear is true for two explicit reasons: g1 adds a narrow Gaussian spike 5*phi(10x) = 5*exp(-50x^2)/sqrt(2*pi) (effective bandwidth 0.1) to a linear trend, and g2/g3 are sign-split rational sine functions whose denominator is 1 for x<0 (sgn(x)+1=0); at x=0 that factor equals 1 but x^2=0, so the denominator remains 1. For x > 0 the denominator is 1 + 2*a*x^2 with a = 18 (g2) and a = 2 (g3). The observed columns are only X and Y; the noise draw is not exported.

The source develops pointwise confidence bands with a calibrated proportion of locations having pointwise coverage, not the usual all-points simultaneous-coverage guarantee. This contribution computes only a scalar conditional mean and executes no interval or coverage experiment. No treatment/label/missingness mechanism applies.

处理分配、标注、缺失与真实数据分支均不适用。未执行论文估计器、bootstrap、点态/同时覆盖率、PFN 训练、大规模压力测试或第二人独立人工复现。

## Rights and assistance

Source equations are cited and independently implemented. Paper copyright is not transferred; no paper PDF, author software, original participant data or model weights are redistributed. No external author code was used. The contributor must confirm the release licence for the independently implemented code before publication; pending review is not a grant of rights. AI assisted equation extraction, implementation, numerical checks and drafting; named human scientific review and independent-person reproduction are not claimed.

**未使用作者原始代码或补充材料代码**；因此作者软件 commit 追溯项 N/A。本包依赖以 requirements.txt 为准：标准库或 NumPy 的使用不等于移植作者代码。论文全文、页图、作者软件、权重、数据银行、凭据不随贡献包分发。

**missing / 尚待确认**

- 当前已声明生成律不存在未给定的必要数值参数；这不等于作者算法、许可或科学接收已获确认。
- 本人须审核 AI 协助的来源提取、代码、数值和文本，并确认独立实现代码的发布许可；pending 不是授权。
- 具名科学审核、第二人独立人工复现：未执行。
- GitHub Fork/Sync/SUBMIT DGP/Actions/PR/收录确认：本次未执行。本地 submit 不等于网络提交或项目收件。

**状态**：以最终 checks/report.json 记录本地 runnable_dgp；归档仅 awaiting_scientific_review、scientific_acceptance=false。
