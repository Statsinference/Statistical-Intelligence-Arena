"""Independent re-derivation, exact anchors, a Monte Carlo window check and a design check.

The re-derivation here deliberately shares neither the math.sin / normal_density helpers of
truth.py nor the mean-function code of generator.py: it uses a locally coded Taylor sine with
quadrant reduction, the standard-library statistics.NormalDist density, and branch-wise algebra
for the sign-split denominators. All numerical tolerances below are engineering tolerances for a
fixed machine seed; none of them is a coverage or identification proof.
"""
import importlib.util
import json
import math
import statistics
from pathlib import Path

import numpy as np

_HALF_PI = math.pi / 2.0
_SOURCE_ROOT_2PI = math.sqrt(2.0 * math.pi)

# Section 3 fixtures: three of the nine cells of the Section 3 full factorial design (sigma in
# {1, 0.5, 0.2} crossed with g1, g2, g3), plus the query point added by this contribution. Keys
# must match config.json scenario fields; the names carry no `original-` prefix because the query
# point, not the source, fixes part of each scenario.
_FIXTURES = {
    "g1-sigma1": {"source_case": "g1-sigma1", "function": "g1", "sigma": 1.0,
                           "support_min": -1.0, "support_max": 1.0, "query_x": 0.0},
    "g2-sigma05": {"source_case": "g2-sigma05", "function": "g2", "sigma": 0.5,
                            "support_min": -1.0, "support_max": 1.0, "query_x": 0.3},
    "g3-sigma02": {"source_case": "g3-sigma02", "function": "g3", "sigma": 0.2,
                            "support_min": -1.0, "support_max": 1.0, "query_x": 0.5},
}
# Sample sizes and replication count declared in Section 3 for the estimator comparison; they are
# properties of the bootstrap study, not of the data-generating mechanism, so no adaptation or
# invention is involved.
_SOURCE_DESIGN_CONSTANTS = {"paper_sample_sizes": [100, 200, 400], "paper_monte_carlo_replications": 1000,
                            "paper_evaluation_grid": [-0.9, 0.9],
                            "citation_authority": "Crossref DOI 10.1214/13-AOS1137 gives volume 41, issue 4, pages 1892-1921; the arXiv reprint header and its LaTeX source declare issue 1, a metadata discrepancy; the citation follows the DOI and journal issue record without altering the reading PDF."}
_MC_DRAWS = 2_000_000
_MC_WINDOW = 0.01
_MC_SEED = 20130921
_DESIGN_N = 50_000
_DESIGN_SEED = 1729


def _module(filename, stem):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location(stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _series_sum(radius, start_term, start_index):
    """Alternating Taylor partial sums for sin/cos on |radius| <= pi/4."""
    total = 0.0
    term = start_term
    index = start_index
    while True:
        total += term
        index += 2
        term = -term * radius * radius / ((index - 1) * index)
        if index > 4 and abs(term) < 1e-24:
            break
    return total


def local_sin(x):
    """Sine from a locally coded Taylor series after quadrant reduction; not math.sin."""
    steps = round(x / _HALF_PI)
    radius = x - steps * _HALF_PI
    quadrant = steps % 4
    sin_r = _series_sum(radius, radius, 1)
    cos_r = _series_sum(radius, 1.0, 0)
    if quadrant == 0:
        return sin_r
    if quadrant == 1:
        return cos_r
    if quadrant == 2:
        return -sin_r
    return -cos_r


def local_density(t):
    """Standard normal density from the standard library, independent of the shared helper."""
    return statistics.NormalDist().pdf(t)


def _denominator(x, amplitude):
    """Equivalent denominator: 1 for x<=0 and 1+2*amplitude*x^2 for x>0. At zero the sign factor itself is 1, but x^2 is 0."""
    if x > 0.0:
        return 1.0 + 2.0 * amplitude * x * x
    return 1.0


def independent_mean(name, x):
    """Second implementation of g_j using different primitives and different algebra."""
    if name == "g1":
        return x + 5.0 * local_density(10.0 * x)
    if name == "g2":
        return local_sin(3.0 * math.pi * x / 2.0) / _denominator(x, 18.0)
    if name == "g3":
        return local_sin(math.pi * x / 2.0) / _denominator(x, 2.0)
    raise ValueError("unknown mean function: " + repr(name))


def vectorised_mean(name, x):
    """Vectorised g_j for the Monte Carlo checks; the sign split is expressed with np.where."""
    if name == "g1":
        return x + 5.0 * np.exp(-50.0 * x * x) / _SOURCE_ROOT_2PI
    if name == "g2":
        return np.sin(3.0 * math.pi * x / 2.0) / np.where(x > 0.0, 1.0 + 36.0 * x * x, 1.0)
    if name == "g3":
        return np.sin(math.pi * x / 2.0) / np.where(x > 0.0, 1.0 + 4.0 * x * x, 1.0)
    raise ValueError("unknown mean function: " + repr(name))


def _window_mean(config):
    """Mean of Y over |X - x0| < w with a fixed seed, 2e6 draws, and the number of window hits."""
    rng = np.random.default_rng(_MC_SEED)
    name = config["function"]
    sigma = float(config["sigma"])
    low = float(config["support_min"])
    high = float(config["support_max"])
    query = float(config["query_x"])
    x = rng.uniform(low, high, size=_MC_DRAWS)
    noise = rng.normal(0.0, sigma, size=_MC_DRAWS)
    y = vectorised_mean(name, x) + noise
    keep = np.abs(x - query) < _MC_WINDOW
    return float(y[keep].mean()), int(keep.sum())


def _design_diagnostics(generator, config):
    """Residual scale and design uniformity from a generated table (independent seeded draw)."""
    data = generator.generate(json.loads(json.dumps(config)), _DESIGN_N, _DESIGN_SEED)
    x = np.asarray(data["X"], dtype=float)
    y = np.asarray(data["Y"], dtype=float)
    low = float(config["support_min"])
    high = float(config["support_max"])
    uniforms = np.sort((x - low) / (high - low))
    ranks = np.arange(1, _DESIGN_N + 1, dtype=float) / _DESIGN_N
    kolmogorov = float(max(np.abs(uniforms - ranks).max(), np.abs(uniforms - (ranks - 1.0 / _DESIGN_N)).max()))
    residual = y - vectorised_mean(config["function"], x)
    return {"kolmogorov_statistic": kolmogorov, "residual_mean": float(residual.mean()),
            "residual_variance": float(residual.var(ddof=1))}


def verify(config):
    oracle = _module("truth.py", "nri_hh_self_truth")
    generator = _module("generator.py", "nri_hh_self_generator")
    name = config["function"]
    sigma = float(config["sigma"])
    query = float(config["query_x"])
    case = config["source_case"]

    reference = oracle.truth(config)["value"]
    second = independent_mean(name, query)

    g1_at_zero = oracle.mean_function("g1", 0.0)
    g2_at_zero = oracle.mean_function("g2", 0.0)
    g3_at_zero = oracle.mean_function("g3", 0.0)
    negative_probe = -0.4
    anchor_conditions = [
        abs(g1_at_zero - 5.0 * local_density(0.0)) < 1e-9,
        abs(g2_at_zero) < 1e-12 and abs(g3_at_zero) < 1e-12,
        abs(oracle.mean_function("g2", negative_probe) - local_sin(3.0 * math.pi * negative_probe / 2.0)) < 1e-12,
        abs(oracle.mean_function("g3", negative_probe) - local_sin(math.pi * negative_probe / 2.0)) < 1e-12,
        abs((oracle.mean_function("g1", query) - oracle.mean_function("g1", -query)) - 2.0 * query) < 1e-12,
    ]

    window_mean, window_count = _window_mean(config)
    window_tolerance = 6.0 * sigma / math.sqrt(window_count)
    design = _design_diagnostics(generator, config)
    design_tolerance_kolmogorov = 3.0 / math.sqrt(_DESIGN_N)
    design_tolerance_variance = 5.0 * sigma * sigma * math.sqrt(2.0 / _DESIGN_N)
    design_tolerance_mean = 6.0 * sigma / math.sqrt(_DESIGN_N)

    checks = [
        {"name": "source_constants_original",
         "passed": case in _FIXTURES and config == _FIXTURES[case],
         "details": "Scenario parameters match the Section 3 fixture for " + str(case)
                    + ": mean function " + name + ", sigma=" + repr(sigma)
                    + ", X uniform on [" + repr(config["support_min"]) + ", " + repr(config["support_max"])
                    + "]. The paper's estimator-side constants n in "
                    + str(_SOURCE_DESIGN_CONSTANTS["paper_sample_sizes"])
                    + ", " + str(_SOURCE_DESIGN_CONSTANTS["paper_monte_carlo_replications"])
                    + " replications and the evaluation interval "
                    + str(_SOURCE_DESIGN_CONSTANTS["paper_evaluation_grid"])
                    + " are fixture constants of the bootstrap study, not DGP parameters, and are not used to "
                      "generate rows. Citation metadata follows " + _SOURCE_DESIGN_CONSTANTS["citation_authority"]
                    + ". The query point x0=" + repr(query) + " is added by this contribution."},
        {"name": "independent_function_evaluation",
         "passed": abs(reference - second) < 1e-9,
         "details": "truth.py closed form=" + format(reference, ".14g")
                    + "; independent route (locally coded Taylor sine with quadrant reduction, "
                      "statistics.NormalDist density, branch-wise sign-split denominator)=" + format(second, ".14g")
                    + "; difference=" + format(abs(reference - second), ".3g") + "."},
        {"name": "interpretable_anchor",
         "passed": all(anchor_conditions),
         "details": "g1(0)=5*phi(0)=" + format(g1_at_zero, ".12g") + "; g2(0)=g3(0)=0 exactly because the "
                    + "numerator is sin(0)=0 and the denominator is 1; for x<0 the factor sgn(x)+1 vanishes so "
                    + "g2(x)=sin(3*pi*x/2) and g3(x)=sin(pi*x/2), checked at x=" + str(negative_probe)
                    + "; g1(x0)-g1(-x0)=2*x0=" + format(2.0 * query, ".12g")
                    + ". Anchors other than x0 use the shared closed form, so they test interpretation, not "
                      "independent coding."},
        {"name": "mc_window_mean",
         "passed": abs(window_mean - reference) < window_tolerance and window_count > 5000,
         "details": "Fixed seed " + str(_MC_SEED) + ", " + format(_MC_DRAWS, ",") + " draws, |X-x0|<"
                    + str(_MC_WINDOW) + ": window count=" + format(window_count, ",") + ", window mean="
                    + format(window_mean, ".10g") + ", truth=" + format(reference, ".10g") + ", |difference|="
                    + format(abs(window_mean - reference), ".3g") + " versus a 6*sigma/sqrt(count) tolerance of "
                    + format(window_tolerance, ".3g") + ". This checks the direction of the generating mechanism, "
                    + "not the coverage of any band or interval."},
        {"name": "generator_design_consistency",
         "passed": design["kolmogorov_statistic"] < design_tolerance_kolmogorov
                   and abs(design["residual_variance"] - sigma * sigma) < design_tolerance_variance
                   and abs(design["residual_mean"]) < design_tolerance_mean,
         "details": "From a " + format(_DESIGN_N, ",") + "-row generated table (seed " + str(_DESIGN_SEED)
                    + "): Kolmogorov statistic of X against Uniform[" + repr(config["support_min"]) + ", "
                    + repr(config["support_max"]) + "]=" + format(design["kolmogorov_statistic"], ".3g")
                    + " < " + format(design_tolerance_kolmogorov, ".3g") + "; residual variance="
                    + format(design["residual_variance"], ".6g") + " against sigma^2="
                    + format(sigma * sigma, ".6g") + " within " + format(design_tolerance_variance, ".3g")
                    + "; residual mean=" + format(design["residual_mean"], ".3g") + " within "
                    + format(design_tolerance_mean, ".3g")
                    + ". Residuals use this module's own g_j, so a disagreement between generator.py and the "
                      "declared mean function would show up here and in the window check."},
    ]
    return {"passed": all(check["passed"] for check in checks), "checks": checks,
            "shared_components": "Both-verification routes share the documented Section 3 equations and the scenario config; they share no helper, no random generator and no trigonometry implementation. Retranscription against the source PDF and reproduction by an independent person are still required.",
            "shared_components_extra": {"mc_draws": _MC_DRAWS, "mc_window_half_width": _MC_WINDOW,
                                        "design_rows": _DESIGN_N}}
