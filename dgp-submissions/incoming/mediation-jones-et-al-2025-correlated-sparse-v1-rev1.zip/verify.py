"""Independent path enumeration plus covariance and null-case checks."""
import importlib.util
from pathlib import Path
from copy import deepcopy
import numpy as np

def verify(c):
    spec=importlib.util.spec_from_file_location('jones_truth',Path(__file__).with_name('truth.py'))
    t=importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
    a=np.zeros(c['p']); b=np.zeros(c['p'])
    a[np.array(c['a_to_m_indices'])-1]=c['a_to_m_coefficient']
    b[np.array(c['m_to_y_indices'])-1]=c['m_to_y_coefficient']
    direct=float(a@b); claimed=t.truth(c)['value']
    s=np.zeros((c['p'],c['p'])); r=c['rho_within']; q=c['rho_bridge']
    s[:2,:2]=r; s[2:,2:]=r; np.fill_diagonal(s,1)
    s[:2,2:]=q; s[2:,:2]=q
    null=deepcopy(c); null['a_to_m_indices']=[3]
    # Paired potential outcomes use the same correlated latent mediator and outcome errors.
    # This structural substitution is separate from the path-product formula in truth.py.
    rng=np.random.default_rng(20251031)
    latent_m=rng.multivariate_normal(np.zeros(c['p']),s,size=17,method='cholesky')
    latent_y=rng.normal(size=17)
    alpha=np.zeros(c['p']); beta=np.zeros(c['p'])
    alpha[np.array(c['a_to_m_indices'])-1]=c['a_to_m_coefficient']
    beta[np.array(c['m_to_y_indices'])-1]=c['m_to_y_coefficient']
    m0=latent_m
    m1=latent_m+alpha
    y_1_m0=c['direct_effect']+m0@beta+latent_y
    y_1_m1=c['direct_effect']+m1@beta+latent_y
    paired_effect=float(np.mean(y_1_m1-y_1_m0))
    checks=[
      {'name':'independent_vector_path_sum','passed':abs(direct-claimed)<1e-12,'details':f'alpha dot beta={direct:g}; truth={claimed:g}'},
      {'name':'paired_counterfactual_structural_substitution','passed':abs(paired_effect-claimed)<1e-12,'details':f'17 fixed latent-error pairs: mean Y(1,M(1))-Y(1,M(0))={paired_effect:.12g}; truth={claimed:.12g}'},
      {'name':'source_covariance_positive_definite','passed':bool(np.linalg.eigvalsh(s)[0]>0),'details':'Final-paper-prose covariance; smallest eigenvalue '+str(np.linalg.eigvalsh(s)[0])},
      {'name':'exposure_only_mediator_zero_path','passed':t.truth(null)['value']==0,'details':'M3 has exposure path only, no outcome path.'},
      {'name':'source_sparse_indices','passed':c['p']==100 and c['a_to_m_indices']==[1,2,3] and c['m_to_y_indices']==[1,2,4,5,6],'details':'Index sets checked against final article §5 Simulation B.'}
    ]
    return {'passed':all(x['passed'] for x in checks),'checks':checks,'shared_components':'Truth and path check use common source coefficients but separate scalar and vector implementations; scientific review pending.'}
