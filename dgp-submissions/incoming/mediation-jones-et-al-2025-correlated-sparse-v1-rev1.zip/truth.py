"""Joint mediator natural indirect effect in a linear additive SEM."""
def truth(config):
    overlap=set(config['a_to_m_indices']) & set(config['m_to_y_indices'])
    value=len(overlap)*config['a_to_m_coefficient']*config['m_to_y_coefficient']
    return {'value':float(value),'estimated_error':0.0,'method':'Exact alpha dot beta for the joint mediator intervention under additive linear structural equations.','target':'E[Y(1,M(1))-Y(1,M(0))] over the complete mediator vector'}
