# Correlated sparse Gaussian mediation (Jones et al., 2025)

**Status:** local candidate; named human scientific review pending.

## 1. Source and source version

Source: https://doi.org/10.1093/jrsssb/qkae109, final article §5 Simulation B. Author code for cross-check: https://github.com/jmiahjones/mediation-selection-paper-2024/blob/7617776b1a6415a185e18d336a5709c4d38f0555/mediation-new-sims/R/sim_conf.R , function do_sim_paths, lines 84–117. This contribution follows final article prose where article and code differ; the discrepancy is detailed in source_audit.json.

## 2. Generating mechanism

Generate A~Bern(.5), E~N_100(0,Sigma) with unit diagonal, 0.5 correlation in first-two and remaining-98 blocks, plus 0.25 cross-correlation between M1/M2 and all M3–M100. M_j=alpha_j A+E_j, alpha=1 for j=1,2,3. Y=2A+M1+M2+M4+M5+M6+epsilon, epsilon~N(0,1).

## 3. Causal target and population truth

Full-vector NIE_1=E[Y(1,M(1))-Y(1,M(0))]=alpha^T beta=2. This is derived, not a quoted paper number. The article studies sparse selection and deliberate correlated-error misspecification. We use the full-vector effect, so no subset-specific identification claim is made.

## 4. Changes, checks and limits

Changes: independent NumPy implementation of final article §5 prose; output excludes latent E; n=200 from source is recorded while the interface n remains variable; article versus author-code discrepancy is documented. Rights: no paper PDF or R file is redistributed. AI-assisted transcription and code require human scientific review.

| Structural item | Final article §5 Simulation B | Fixed author `do_sim_paths` | This package |
| --- | --- | --- | --- |
| Exposure paths | `M1,M2,M3` | `M1,M2,M6` | `M1,M2,M3` |
| Outcome paths | `M1,M2,M4,M5,M6` | `M1` through `M5` | `M1,M2,M4,M5,M6` |
| Cross-block noise correlation 0.25 | `M1,M2` with nonmediators `M3` through `M100` | `M1,M2` with `M3` through `M7` | All `M3` through `M100` |

Within the first-two and remaining-98 blocks the correlation is 0.5. This is an explicit choice of the final article's **prose specification**. The code is a different realized DGP; it is not silently combined with this one. `verify.py` also uses paired potential outcomes with fixed latent errors, separately from `truth.py`'s coefficient product.

## 5. Rights and AI assistance

This ZIP contains an independent Python implementation and source references. The paper PDF and author code are not redistributed. Codex assisted with source transcription, derivation, implementation and this card. `collect.py check --run` verifies the local interface and contributor-supplied mathematical checks; it does not confer scientific acceptance. A named human reviewer must compare all equations, parameters, estimand interpretation, and stated changes against the cited original before submission.
