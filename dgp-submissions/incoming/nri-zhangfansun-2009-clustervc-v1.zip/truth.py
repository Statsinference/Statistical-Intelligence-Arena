"""Conditional mean given all six observed covariates; random effect integrated out."""
import math


def truth(config):
    u = float(config["query_u"])
    x, z = config["query_x"], config["query_z"]
    if not math.isfinite(u) or not 0<=u<=1 or len(x)!=3 or len(z)!=2:
        raise ValueError("query requires u in [0,1], three x and two z coordinates")
    if not all(math.isfinite(float(v)) for v in list(x)+list(z)):
        raise ValueError("query coordinates must be finite")
    s, c, h = math.sin(2*math.pi*u), math.cos(2*math.pi*u), math.sin(math.pi*u)
    value = s*(1+float(z[0])+float(z[1])) + math.fsum(float(v) for v in x)*(s+c*float(z[0])+h*float(z[1]))
    return {"value": value, "estimated_error": 1e-12,
            "method": "Evaluate beta0 + x'*(alpha0 + A*z) + z'*beta; E[e|X,Z,U]=0, so random effects integrate out.",
            "target": "E[Y|U=query_u,X=query_x,Z=query_z]",
            "error_interpretation": "Floating-point rounding allowance at the registered query; no coverage or uniform bound."}
