# N04 簇相关变系数模型的完整条件均值

Contribution: `nri-zhangfansun-2009-clustervc-v1` · `synthetic_dgp` · `nonparametric_regression` · **v1**

## Source and reconstruction

Zhang, W., Fan, J. and Sun, Y. (2009). A semiparametric model for cluster data. The Annals of Statistics 37(5A), 2377-2408. DOI: 10.1214/08-AOS662.

[DOI](https://doi.org/10.1214/08-AOS662) · [固定阅读版本 0908.3382v1](https://arxiv.org/pdf/0908.3382v1)

实读 PDF SHA-256：`25002d0808f8e53aa13627c0d8c154711f9a38845fdade4a72f26e53f797a3e8`。IMS electronic reprint of the published article; the actual first-page declaration says pagination and typographic detail differ from the original.

Formula bodies: (1.4) on PDF p.4. Section starts: Section 5 on PDF p.13. Unnumbered paragraph on PDF p.13: "In model (1.4), we take" (dimensions, cluster sizes, all distributions and coefficient functions). All PDF pages are 1-based pages of the fixed reading file 0908.3382v1. No printed journal page is inferred by adding an offset.

**原文参数逐页登记**

- PDF p.13：p3,q2,m100; cluster size floor(abs(2*xi)+6),xi~N01; X~N(0,I3); Z~N(0,I2); U~Uniform(0,1); e~N(0,.5^2*I3); measurement noise sd.5; beta0=sin(2*pi*u); alpha0 allsin(2*pi*u); alpha1 allcos(2*pi*u); alpha2 allsin(pi*u); beta allsin(2*pi*u)。
- PDF p.14：100 replications; method-only bandwidth.15; method-only Epanechnikov factor.75。

**按实际执行顺序的生成步骤**

1. **Cluster size and row budget** — For each cluster draw xi_i~N(0,1) and source candidate size floor(2*abs(xi_i)+6); apply the declared fixed-n terminal-budget rule. Source base=6, scale=2; when remaining<12, the terminal cluster takes the remaining rows. Other oversized draws also absorb the remaining budget.
2. **Cluster covariates** — Z_i~N(0,I_2), one two-vector shared by all rows of cluster i. Mean zero, each sd=1, independent components and independent cluster draws.
3. **Random coefficients** — e_i~N(0,0.25*I_3), shared within cluster and independent of Z_i. Each random-effect sd=0.5; not observed/exported.
4. **Individual index** — U_ij~Uniform(0,1), newly drawn for each individual. Independent of cluster variables and other individual draws.
5. **Individual covariates** — X_ij~N(0,I_3), newly drawn for each individual. Each sd=1; independent coordinates and independent of U,Z,e.
6. **Coefficient functions** — beta0(u)=sin(2*pi*u); beta(u)=ones(2)*sin(2*pi*u); alpha0(u)=ones(3)*sin(2*pi*u); alpha1(u)=ones(3)*cos(2*pi*u); alpha2(u)=ones(3)*sin(pi*u); a_i(u)=alpha0(u)+alpha1(u)*Z_i1+alpha2(u)*Z_i2+e_i. Deterministic functions of current u and shared Z/e. Follow the source simulation paragraph including beta0.
7. **Measurement error** — epsilon_ij~N(0,0.5^2), independent of all previous variables and errors. Measurement-error sd=0.5.
8. **Outcome and observed columns** — Y_ij=beta0(U_ij)+X_ij^T*a_i(U_ij)+Z_i^T*beta(U_ij)+epsilon_ij; return cluster,U,X1,X2,X3,Z1,Z2,Y. Independent cluster-level Z/e draws induce shared within-cluster effects; sizes are coupled by the n-row budget.

**抽样单位与依赖**：A numeric row for one individual, retaining its cluster identifier. The interface fixes n individuals rather than the source m=100 clusters. The terminal cluster absorbs the row budget; all clusters have at least 6 rows when n>=6, while n<6 produces one smaller budget cluster.；Shared Z_i and random effect e_i induce within-cluster dependence. Independent per-cluster Z/e draws; fixed total n couples cluster sizes and determines the terminal budget cluster. Preserve cluster identifiers in analysis.

**边界与尺度**：For n>=6 each reported cluster has at least 6 rows; for n<6 the sole budget cluster is smaller than the source support. The final size is budget-constrained, so this is not the source fixed-m=100 iid-size sampling plan.

**与来源的改动及理由**

1. Follow the Section 5 simulation paragraph, which explicitly includes beta0(u)=sin(2*pi*u); disclose that general display (1.4) omits it.
2. Preserve cluster identifiers and shared Z/e in a numeric table. The interface fixes n individuals rather than m=100 clusters; the terminal cluster size is budget-constrained, so cluster sizes are not iid under this interface. For n<6 the sole budget cluster is smaller than the source support. This is an adaptation, not an exact source design.
3. Replace the source coefficient-function target alpha01(u0) by the full conditional mean m(u0,x0,z0)=E[Y|U=u0,X=x0,Z=z0], integrating the unobserved random effect. Fix u0=0.25 and x0=z0=0; truth remains 1 by coincidence of these chosen values.
4. Cluster-table acceptance by the maintainer is not proven by the open schema role vocabulary. The numeric contract runs, but the guide's request to confirm multilayer data remains an external review step.
5. Use CPU mechanism checks, not the paper's estimator, MISE or confidence-band experiment.

固定点目标由已声明条件响应律识别：高斯模型使用零条件均值的误差/随机效应，广义回归直接用指定分布的链接均值。接口 n 和查询为适配；未把 n=128 说成论文原实验样本量。

**版本关系**：The actual fixed reading PDF is an IMS electronic reprint of the published article, not a separate author-preprint draft merely because it is hosted on arXiv. The first-page declaration explicitly notes pagination and typographic differences. We use only verified section/equation/1-based PDF locators and do not claim identical publisher typesetting, exact printed-page offsets or entire-text identity. No separate author-preprint-to-formal substitution is involved for this reading source; that conditional comparison is N/A.

## Target and identification

`m(u0,x0,z0)=E[Y|U=u0,X=x0,Z=z0]`

Integrate the mean-zero random effect from the Section 5 simulation model: sin(2*pi*u)*(1+z1+z2)+sum(x)*(sin(2*pi*u)+z1*cos(2*pi*u)+z2*sin(pi*u)). The fixed query is u=.25, x=(0,0,0), z=(0,0), yielding 1. The source coefficient alpha01 is a different estimand, though it happens to equal 1 here.

**登记场景与查询**

| Scenario | Parameters / query |
|:--|:--|
| `original-sigma05`（默认） | `{"sigma": 0.5, "random_effect_var": 0.25, "query_u": 0.25, "cluster_size_base": 6.0, "cluster_size_scale": 2.0, "query_x": [0.0, 0.0, 0.0], "query_z": [0.0, 0.0]}` |

场景中的 original-* 表示保留的来源生成参数，不代表新增查询和接口样本量属于原文实验。本包仅保留原文生成设定 original-sigma05，未另设自选查询；不复制同义场景充数。

**抽样、设计与支持条件**

- Random effect e~N(0,0.25*I3) is independent of X,Z,U and has mean zero.
- Errors are independent N(0,0.5^2). Individual covariates are independent N(0,I3), cluster covariates N(0,I2), and U is Uniform(0,1).
- Different clusters use independent Z/e draws, while their sizes are coupled by the fixed row budget. Individuals in the same cluster are dependent and cannot be treated as independent rows.
- The interface adaptation constrains the terminal cluster size. Cluster-table acceptance requires maintainer confirmation under the student guide; executable schema compliance is not that confirmation.
- The whole conditional query is specified before generation and does not condition on unobserved random effects.

固定点条件均值正确，不等于点态区间或同时置信带覆盖率达标。非因果任务不套用干预/无混杂假设。

## Truth and independent verification

Evaluate the full conditional-mean equation after integrating the mean-zero random effect; independent closed form and Monte Carlo verify.py checks.

`truth.tolerance=1e-08`。estimated_error 是浮点/数值路线诊断，不是严格统一误差界或统计标准误；其非负且不大于 tolerance。

**不同路线与解析特例**：完整均值的独立展开、对零均值簇随机效应及测量误差作条件 Monte Carlo；x=z=0 时退化为 sin(2*pi*u)。另在非零 x/z 查询处检验，避免默认值 1 掩盖斜率与均值混淆。

**实际共享函数与独立边界**：verify 调用 generator.intercept/alpha_population/alpha_first_loading/alpha_second_loading/cluster_coefficient 与独立固定式比较，并调用 generator.generate 检查簇结构；这些是被测函数。完整均值展开与条件随机效应 Monte Carlo 不复用这些助手。

外部另按论文公式用 mpmath 70 位重算全部登记查询；另对各场景 generate(n=4096, seed=7312026) 实际观察列独立重构残差，不导入私有均值助手或 verify 作外部参照。N08 的源数学参照取精确 1/sqrt(3)，与配置中最短十进制权重的浮点差计入比较；阈值仍逐包取 tolerance，不靠放宽阈值通过。

## Diversity and scope

`dimension=6`，`effective_dimension=6`。Six covariates U, X1..X3, Z1..Z2 all affect the full conditional mean. X_j*Z_k terms are genuine interactions. At fixed U the mean is affine in X for fixed Z, and affine in Z for fixed X, but is not jointly linear in (X,Z). Sine/cosine coefficients are nonlinear in U. Six inputs with the source cluster sizes are not a sparse high-dimensional design. The cluster identifier is an observed index and is excluded from dimension.

The target conditions on U, all three X and both Z, and integrates the unobserved mean-zero e. It is not the source slope alpha01. No raw person data are used. The cluster index is observed but is not counted as a covariate dimension.

处理分配、标注、缺失与真实数据分支均不适用。未执行论文估计器、bootstrap、点态/同时覆盖率、PFN 训练、大规模压力测试或第二人独立人工复现。

## Rights and assistance

Source equations are cited and independently implemented. Paper copyright is not transferred; no paper PDF, author software, original participant data or model weights are redistributed. No external author code was used. The contributor must confirm the release licence for the independently implemented code before publication; pending review is not a grant of rights. AI assisted equation extraction, implementation, numerical checks and drafting; named human scientific review and independent-person reproduction are not claimed.

**未使用作者原始代码或补充材料代码**；因此作者软件 commit 追溯项 N/A。本包依赖以 requirements.txt 为准：标准库或 NumPy 的使用不等于移植作者代码。论文全文、页图、作者软件、权重、数据银行、凭据不随贡献包分发。

**missing / 尚待确认**

- missing(maintainer_multilevel_interface_confirmation): the student guide asks for prior confirmation of multilayer or panel interfaces. A numeric cluster_id is executable under the supplied schema, but no maintainer approval record was supplied. Keep this item pending.
- 本人须审核 AI 协助的来源提取、代码、数值和文本，并确认独立实现代码的发布许可；pending 不是授权。
- 具名科学审核、第二人独立人工复现：未执行。
- GitHub Fork/Sync/SUBMIT DGP/Actions/PR/收录确认：本次未执行。本地 submit 不等于网络提交或项目收件。

**状态**：以最终 checks/report.json 记录本地 runnable_dgp；归档仅 awaiting_scientific_review、scientific_acceptance=false。
