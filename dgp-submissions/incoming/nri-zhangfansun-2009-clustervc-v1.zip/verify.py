"""Independent re-derivation of the declared mechanism: fixtures, closed forms, CPU Monte Carlo."""
import importlib.util
import math
from pathlib import Path

import numpy as np

MC_SIZE = 1_000_000
MC_TOLERANCE = 6.0 * math.sqrt(0.5) / math.sqrt(MC_SIZE)
SCALE_SIZE = 500_000
SCALE_TOLERANCE = 0.01
STRUCTURE_N = 128
STRUCTURE_SEED = 1729

SOURCE_FIXTURE = {"sigma": 0.5, "random_effect_var": 0.25, "query_u": 0.25,
                  "cluster_size_base": 6.0, "cluster_size_scale": 2.0,
                  "query_x": [0.0,0.0,0.0], "query_z": [0.0,0.0]}


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("zfs09_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _literal_coefficients(u):
    """Coefficient functions typed out again from Section 5, not imported."""
    sine, cosine, half = math.sin(2 * math.pi * u), math.cos(2 * math.pi * u), math.sin(math.pi * u)
    return {"intercept": sine, "alpha_0": (sine, sine, sine),
            "alpha_1": (cosine, cosine, cosine), "alpha_2": (half, half, half),
            "beta": (sine, sine)}


def _mc_conditional_mean(x, z, u0, sigma, effect_var, size, rng):
    """Monte Carlo mean of y at fixed covariates; re-implements the outcome equation."""
    effect = rng.normal(0.0, math.sqrt(effect_var), size=(size, len(x)))
    noise = rng.normal(0.0, sigma, size=size)
    shared = math.sin(2 * math.pi * u0) + math.cos(2 * math.pi * u0) * z[0] \
        + math.sin(math.pi * u0) * z[1]
    individual = (shared + effect) @ np.asarray(x, dtype=float)
    # Intercept plus the Z-part of the mean both equal sin(2*pi*u0) times their loading.
    remainder = math.sin(2 * math.pi * u0) * (1.0 + z[0] + z[1])
    draws = individual + remainder + noise
    return float(draws.mean()), float(draws.std(ddof=1) / math.sqrt(size))


def verify(config):
    generator, oracle = _module("generator.py"), _module("truth.py")

    same_source = config == SOURCE_FIXTURE
    functional_form = True
    for u in (0.0, 0.25, 0.5, 0.75):
        expected = _literal_coefficients(u)
        functional_form &= generator.intercept(u) == expected["intercept"]
        functional_form &= generator.alpha_population(u) == expected["alpha_0"]
        functional_form &= generator.alpha_first_loading(u) == expected["alpha_1"]
        functional_form &= generator.alpha_second_loading(u) == expected["alpha_2"]
        functional_form &= generator.cluster_coefficient(u) == expected["beta"]
    size_rule_offset = generator.generate({**SOURCE_FIXTURE, "cluster_size_scale": 0.0},
                                          60, 1729)["cluster"][-1]

    reference = oracle.truth(config)
    alternate = 2.0 * math.sin(math.pi * config["query_u"]) \
        * math.cos(math.pi * config["query_u"])
    anchor = abs(reference["value"] - 1.0) if config["query_u"] == 0.25 else None

    mean_unit, se_unit = _mc_conditional_mean(
        (1.0, 0.0, 0.0), (0.0, 0.0), config["query_u"], config["sigma"],
        config["random_effect_var"], MC_SIZE, np.random.default_rng(20240917))
    mean_null, se_null = _mc_conditional_mean(
        (0.0, 0.0, 0.0), (0.0, 0.0), config["query_u"], config["sigma"],
        config["random_effect_var"], MC_SIZE, np.random.default_rng(20240918))

    effect = np.random.default_rng(20240919).normal(
        0.0, math.sqrt(config["random_effect_var"]), size=(SCALE_SIZE, 3))
    effect_average = float((np.square(effect).sum(axis=1) / 3.0).mean())

    rows = generator.generate(dict(config), STRUCTURE_N, STRUCTURE_SEED)
    ids, sizes, shared = rows["cluster"], {}, True
    for position in range(len(ids)):
        level = ids[position]
        sizes.setdefault(level, 0)
        sizes[level] += 1
    for level in sorted(sizes):
        block = [k for k in range(len(ids)) if ids[k] == level]
        z_pairs = {(rows["Z1"][k], rows["Z2"][k]) for k in block}
        shared &= len(z_pairs) == 1
    levels = sorted(sizes)
    structure_ok = shared and levels == list(range(1, len(levels) + 1)) and len(levels) >= 2
    structure_ok &= all(sizes[level] >= float(config["cluster_size_base"])
                        for level in levels)
    structure_ok &= len(rows["Y"]) == STRUCTURE_N
    structure_ok &= sum(sizes.values()) == STRUCTURE_N

    query_x, query_z = config["query_x"], config["query_z"]
    u = config["query_u"]
    literal = _literal_coefficients(u)
    full_mean = literal["intercept"] + sum(
        query_x[j] * (literal["alpha_0"][j] + literal["alpha_1"][j]*query_z[0]
                      + literal["alpha_2"][j]*query_z[1]) for j in range(3)
    ) + sum(query_z[j]*literal["beta"][j] for j in range(2))
    query_mc, query_se = _mc_conditional_mean(query_x, query_z, u, config["sigma"],
        config["random_effect_var"], MC_SIZE, np.random.default_rng(20261031))
    result = {
        "passed": False,
        "checks": [
            {"name": "full_conditional_query",
             "passed": bool(abs(reference["value"]-full_mean)<1e-10 and abs(query_mc-full_mean)<6*query_se),
             "details": f"Complete fixed query U={u}, X={query_x}, Z={query_z}; independent full equation={full_mean:.16g}, truth={reference['value']:.16g}; conditional MC mean={query_mc:.8g}, SE={query_se:.3g}. The slope coefficient is not substituted for the response mean."},
            {"name": "source_constants_original",
             "passed": bool(same_source and functional_form and size_rule_offset == 10),
             "details": "Scenario equals the Section 5 fixture sigma=0.5, "
                        "Sigma=0.5^2*I_3=0.25*I_3 (superscript reading confirmed by PDF "
                        "glyph coordinates on reprint page 13), U~U(0,1), "
                        "X~N(0,I_3), Z~N(0,I_2), n_i=floor(|2*xi|+6), and the four "
                        "sin/cos coefficient families agree with hand-typed literals at "
                        "u in {0,0.25,0.5,0.75}. With the random size switched off, 60 "
                        "rows give exactly 10 clusters, confirming base=6."},
            {"name": "independent_closed_form",
             "passed": abs(reference["value"] - alternate) < 1e-12,
             "details": f"math.sin route={reference['value']:.16g}; double-angle "
                        f"route={alternate:.16g}; gap={abs(reference['value']-alternate):.3g}; "
                        f"anchor gap to 1 at u0=0.25={anchor:.3g}; declared numerical "
                        f"error={reference['estimated_error']:.3g}."},
            {"name": "conditional_mean_mc",
             "passed": bool(abs(mean_unit - 2.0) < MC_TOLERANCE
                            and abs(mean_null - 1.0) < MC_TOLERANCE),
             "details": f"{MC_SIZE} draws each. X=(1,0,0),Z=(0,0),u0={config['query_u']}: "
                        f"mean={mean_unit:.6f} against 2, se={se_unit:.2e}, tol={MC_TOLERANCE:.2e}. "
                        f"X=(0,0,0),Z=(0,0): mean={mean_null:.6f} against 1, se={se_null:.2e}. "
                        "Together they pin down beta_0(u0)=1 and alpha_01(u0)=1 in one equation."},
            {"name": "random_effect_scale_check",
             "passed": abs(effect_average - config["random_effect_var"]) < SCALE_TOLERANCE,
             "details": f"E[e'e]/3={effect_average:.6f} against random_effect_var="
                        f"{config['random_effect_var']} over {SCALE_SIZE} draws, "
                        f"tolerance {SCALE_TOLERANCE}."},
            {"name": "cluster_structure_check",
             "passed": bool(structure_ok),
             "details": f"n={STRUCTURE_N}, seed={STRUCTURE_SEED}: {len(levels)} clusters with "
                        f"ids 1..{len(levels)}, one shared (Z1,Z2) pair per cluster, every "
                        f"cluster including the final one holding at least "
                        f"{config['cluster_size_base']:.0f} rows, and the cluster sizes summing "
                        f"to exactly n, so no row is discarded (sizes="
                        f"{[sizes[k] for k in levels]})."},
        ],
        "shared_components": "Both routes use the declared Section 5 equations and config; "
                             "the Monte Carlo mean, the cluster rendering and the algebraic "
                             "cross-check are separate code paths. Source fixtures are "
                             "reconstructed and still need named scientific review.",
        "coverage_note": "The Monte Carlo window checks the stated mechanism at a fixed seed; "
                         "it is not a simultaneous-band or coverage claim.",
    }

    result["passed"] = all(c["passed"] for c in result["checks"])
    return result
