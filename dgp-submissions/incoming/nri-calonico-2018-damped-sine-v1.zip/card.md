# NRI collection: CCF2018 Models 5 and 6 — damped-sine regression (Hall-Horowitz g2/g3 family)

**Status: candidate; not scientifically accepted.**

Primary source: Calonico, S., Cattaneo, M. D., and Farrell, M. H. (2018). On the Effect of Bias Estimation on Coverage Accuracy in Nonparametric Inference. *Journal of the American Statistical Association* 113(522), 767–779. DOI [10.1080/01621459.2017.1285776](https://doi.org/10.1080/01621459.2017.1285776). Supplement dated December 16, 2017.

Original family: Hall, P. G. and Horowitz, J. L. (2013). A simple bootstrap method for constructing nonparametric confidence bands for functions. *Annals of Statistics* 41(4), 1892–1921. Models M5/M6 of CCF2018 are g2/g3 of Hall-Horowitz (2013); some functions originally studied in Berry, Carroll, and Ruppert (2002).

## Source and reconstruction

**Supplement §S.II.7** ("Complete Simulation Results", printed p. 80, PDF p. 81): all six regression DGP models.

**Main text §4** (printed p. 776, PDF p. 10): M5 representative simulation with the five-point evaluation grid x ∈ {−2/3, −1/3, 0, 1/3, 2/3}.

Attribution (supplement p. 81): "Models 4 to 6 are from Hall and Horowitz (2013), with some originally studied by Berry et al. (2002)."

### Shared DGP structure (§S.II.7)

```
Y_i = m(X_i) + eps_i,    i = 1, ..., n
X_i ~ U[-1, 1]           (iid)
eps_i ~ N(0, 1)          (iid, independent of X_i)
```

Paper simulation: n = 500, 5000 replications. This collection uses population equations only.

### Model 5 — g2 of Hall-Horowitz (§S.II.7 / §4)

```
m(x) = sin(3*pi*x/2) / (1 + 18*x^2*(sgn(x)+1))
```

`sgn(x) ∈ {-1, 0, +1}`. For x < 0: `sgn(x)+1 = 0` → denominator = 1 → `m(x) = sin(3*pi*x/2)`.  
For x > 0: `sgn(x)+1 = 2` → denominator = 1 + 36x² (heavy damping).  
At x = 0: `x² = 0` → denominator = 1, `m(0) = sin(0) = 0`.

### Model 6 — g3 = g2(x/3) of Hall-Horowitz (§S.II.7)

```
m(x) = sin(pi*x/2) / (1 + 2*x^2*(sgn(x)+1))
```

Same structural form with gentler damping (`2` vs `18`). Equivalent to g2(x/3): substitute u = x/3 in g2(u) = sin(3*pi*u/2)/(1+18u²(sgn(u)+1)).

### Evaluation grid (§4 / §S.II.7)

x ∈ {−2/3, −1/3, 0, 1/3, 2/3}. Each (model, query point) pair is a separate `config.json` scenario targeting one fixed scalar `m(x0)`.

## Target and identification

**Estimand:** `m(x0) = E[Y | X = x0]` at each fixed query point x0.

Since `eps ~ N(0,1)` with `E[eps] = 0`, `E[Y|X=x0] = m(x0)`. No causal interpretation. This is an NRI (nonparametric regression inference) task; the target is the conditional mean.

**Applicable assumptions:**

- X and eps independent; E[eps] = 0 (directly from DGP specification).
- m(x) is smooth on (−1,0) and (0,1); at x = 0 both m5 and m6 are continuous with m(0) = 0 (x² factor removes sgn discontinuity).
- Inference is pointwise at each fixed query point; the five-point grid is **not** a simultaneous confidence band.
- No treatment, mediator, instrumental variable, or interference.

**Cross-paper family note:** M5 = g2, M6 = g3 in Hall-Horowitz (2013); per project rules these are registered as scenarios of the `hall-horowitz-2013-damped-sine` mechanism family, not as an independent new family. They are included in CCF2018 as a comparison benchmark.

## Truth and independent verification

### M5 five-point exact rational derivation

| x0 | sin argument | sin value | denom formula | denom | m5(x0) |
|---|---|---|---|---|---|
| −2/3 | sin(−π) | 0 | 1 + 18·(4/9)·0 | 1 | **0** |
| −1/3 | sin(−π/2) | −1 | 1 + 18·(1/9)·0 | 1 | **−1** |
| 0 | sin(0) | 0 | 1 + 0 | 1 | **0** |
| 1/3 | sin(π/2) | 1 | 1 + 18·(1/9)·2 | 5 | **1/5 = 0.2** |
| 2/3 | sin(π) | 0 | 1 + 18·(4/9)·2 | 17 | **0** |

At x0 ∈ {−2/3, −1/3, 0, 2/3} the values 0, −1, 0, 0 are exactly representable in IEEE 754.  
At x0 = 1/3, m5 = 1/5 = 0.2; 0.2 is not exactly representable (binary fraction) but matches the IEEE 754 rounded value to 1 ULP, estimated_error = 1e-14.

### M6 values at five points (computed, not integer-exact for all)

| x0 | m6(x0) |
|---|---|
| −2/3 | sin(−π/3) / 1 = −√3/2 ≈ −0.8660254 |
| −1/3 | sin(−π/6) / 1 = −0.5 |
| 0 | 0 |
| 1/3 | sin(π/6) / (1 + 2·(1/9)·2) = 0.5 / (13/9) = 9/26 ≈ 0.3461538 |
| 2/3 | sin(π/3) / (1 + 2·(4/9)·2) = (√3/2) / (25/9) = 9√3/50 ≈ 0.3117691 |

### Independent verification routes (verify.py)

1. **Independent arithmetic path:** truth.py uses `if x>0: return 1` for sgn; verify.py uses `(x>0)-(x<0)` (boolean subtraction). Denominator is grouped as `1 + (coeff*(s+1)) * x^2` vs `1 + coeff*x^2*(s+1)`. Agreement to < 1e-12.
2. **Zero-numerator special case:** at x0 ∈ {0, −2/3, 2/3} for M5 (and x0=0 for M6), `sin = 0` → `m = 0` regardless of denominator. Checked independently.
3. **M5 exact rational anchor:** five hard-coded rational values derived without invoking truth.py; each checked to < 1e-12.
4. **Denominator strictly positive:** `1 + coeff·x0²·(sgn(x0)+1) ≥ 1` always (the product `(sgn+1)·x² ≥ 0`). Confirms no division-by-zero.

**Shared components:** both truth.py and verify.py use the declared DGP equations. Code paths differ in sgn implementation and denominator factoring. Named scientific review and independent-person reproduction remain pending.

## Diversity and scope

- **dimension = 1, effective_dimension = 1.** Single covariate X.
- **nonlinear = true.** Damped-sine: strong nonlinearity from oscillation and asymmetric polynomial denominator. The denominator creates sharper decay for x > 0 (M5) or both sides (M6), making the function notably asymmetric.
- **interactions = false.** Single-covariate model.
- **high_dimensional = false.**

The function is hardest to estimate near x = 0 (rapid oscillation before the damping kicks in) and at x = 1/3 (maximum of sin-half with moderate damping, giving m5 = 0.2). Coverage distortions at x = 0 and x = ±1/3 are the main finding in CCF2018 Table 1 / Figure 1.

## Scenario structure

Ten scenarios are registered: (M5, M6) × (x0 ∈ {−2/3, −1/3, 0, 1/3, 2/3}). Default is `m5_x0_0`. Each scenario's `reference_value` in `collection.json` is set to the default scenario (x0=0, M5) value of 0.0; truth() computes the correct scalar for every other scenario independently.

## Rights and assistance

Paper copyright ASA / Taylor & Francis (CCF2018); IMS (Hall-Horowitz 2013). The supplement is from the published version (December 16, 2017 date on supplement). No paper PDF or nprobust package code is distributed here. Equations are cited and independently implemented. Claude Code (AI assistant) extracted equations from the PDF and wrote the Python code; a named human reviewer must verify equation transcription and independently reproduce the result.

**Open issues:**

- The sgn(x) factor: at x = 0 the paper's formula has `sgn(0)` which could be defined as 0 (as implemented here, following the standard mathematical convention). If the paper intends a different convention (e.g., sgn(0) = +1), m(0) = sin(0)/1 = 0 regardless, so the truth at x0=0 is unaffected. But sgn(0) can affect generate() at X=0 observations — verify that the paper uses sgn(0) = 0.
- The supplement φ extraction: the supplement lists M6 as `sin(πx/2)/(1+2x²(sgn(x)+1))`; a named reviewer should confirm this is identical to g3(x) = g2(x/3) of Hall-Horowitz (2013).
- `reference_value` in collection.json is pinned to the default scenario `m5_x0_0` = 0.0 (m5 at x0=0). The checker only compares truth() against `reference_value` for the default scenario; all other scenarios are verified by truth()+verify() independently.
