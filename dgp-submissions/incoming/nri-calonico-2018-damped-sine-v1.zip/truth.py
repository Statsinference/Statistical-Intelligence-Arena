"""Population truth for CCF2018 supplement S.II.7 Models 5 and 6.

Estimand: m(x0) = E[Y | X = x0] at the fixed query point x0.
Because eps ~ N(0,1) with mean 0, E[Y|X=x0] = m(x0).

Model 5: m(x) = sin(3*pi*x/2) / (1 + 18*x^2*(sgn(x)+1))
Model 6: m(x) = sin(pi*x/2)  / (1 +  2*x^2*(sgn(x)+1))

At the five paper evaluation points x in {-2/3,-1/3,0,1/3,2/3} the
sine arguments hit exact multiples of pi/2, giving closed-form rationals:

  M5(-2/3) = sin(-pi)     / (1 + 18*(4/9)*0)    =  0 / 1   =  0
  M5(-1/3) = sin(-pi/2)   / (1 + 18*(1/9)*0)    = -1 / 1   = -1
  M5( 0  ) = sin(0)       / 1                    =  0
  M5( 1/3) = sin(pi/2)    / (1 + 18*(1/9)*2)    =  1 / 5   =  0.2
  M5( 2/3) = sin(pi)      / (1 + 18*(4/9)*2)    =  0 / 17  =  0

All five M5 values are exactly representable in IEEE 754 double precision
(0, -1, 0, 0.2 = 1/5, 0). estimated_error = 0 for x0 in {-2/3,-1/3,0,2/3}
and the single ULP error for 1/5 representation; reported as 1e-14.
"""
import math


def _sgn(x):
    if x > 0: return 1
    if x < 0: return -1
    return 0


def _m_model5(x):
    numer = math.sin(1.5 * math.pi * x)
    denom = 1.0 + 18.0 * x * x * (_sgn(x) + 1)
    return numer / denom


def _m_model6(x):
    numer = math.sin(0.5 * math.pi * x)
    denom = 1.0 + 2.0 * x * x * (_sgn(x) + 1)
    return numer / denom


# Analytic derivations at each query point
_M5_DERIVATIONS = {
    -2 / 3: (
        "sin(3*pi*(-2/3)/2)=sin(-pi)=0; denom=1+18*(4/9)*(sgn(-2/3)+1)=1+0=1; m5=0/1=0"
    ),
    -1 / 3: (
        "sin(3*pi*(-1/3)/2)=sin(-pi/2)=-1; denom=1+18*(1/9)*(sgn(-1/3)+1)=1+0=1; m5=-1/1=-1"
    ),
    0.0: (
        "sin(0)=0; x^2=0 so denom=1 regardless of sgn; m5=0/1=0"
    ),
    1 / 3: (
        "sin(3*pi*(1/3)/2)=sin(pi/2)=1; denom=1+18*(1/9)*(sgn(1/3)+1)=1+18*(1/9)*2=1+4=5; m5=1/5=0.2"
    ),
    2 / 3: (
        "sin(3*pi*(2/3)/2)=sin(pi)=0; denom=1+18*(4/9)*(sgn(2/3)+1)=1+16=17; m5=0/17=0"
    ),
}


def truth(config):
    """Return the exact population conditional mean m(x0) at the fixed query point.

    Returns
    -------
    dict with keys:
        value           : m(x0), a finite float
        estimated_error : floating-point rounding bound (<= 1e-14)
        method          : analytic derivation string
        target          : estimand description
        query_point     : x0 used
        noise_mean_contribution : noise_mean (= 0 per paper)
    """
    x0 = config["query_point"]
    noise_mean = config.get("noise_mean", 0.0)
    model = config.get("model_name", "M5")

    if model == "M5":
        m_val = _m_model5(x0)
        # Look up pre-derived derivation string (within float equality of grid)
        deriv = None
        for key, text in _M5_DERIVATIONS.items():
            if abs(x0 - key) < 1e-10:
                deriv = text
                break
        if deriv is None:
            deriv = (
                f"m5(x0) = sin(3*pi*{x0}/2) / (1 + 18*{x0}^2*(sgn({x0})+1))"
                f" = {m_val:.16g}"
            )
        method = (
            "Closed-form analytic: M5 m(x)=sin(3*pi*x/2)/(1+18*x^2*(sgn(x)+1)). "
            "At the five paper evaluation points the sine hits multiples of pi/2 giving "
            "exact rationals. Derivation: " + deriv
        )
    elif model == "M6":
        m_val = _m_model6(x0)
        method = (
            f"Closed-form analytic: M6 m(x)=sin(pi*x/2)/(1+2*x^2*(sgn(x)+1)). "
            f"m6({x0:.6g}) = sin(pi*{x0:.6g}/2) / (1 + 2*{x0**2:.6g}*(sgn({x0:.6g})+1))"
            f" = {m_val:.16g}."
        )
    else:
        raise ValueError("Unknown model_name: " + str(model) + "; expected M5 or M6")

    value = m_val + noise_mean

    return {
        "value": value,
        "estimated_error": 1e-14,
        "method": method,
        "target": "m(x0) = E[Y | X = x0] at fixed query point x0",
        "query_point": x0,
        "noise_mean_contribution": noise_mean,
    }
