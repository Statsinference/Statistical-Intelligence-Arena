"""Exact natural indirect effect of the source linear SEM."""


def truth(config):
    value = float(config["alpha_s"] * config["beta_m"])
    return {"value": value, "estimated_error": 0.0,
            "method": "Analytic product of the A-to-M and M-to-Y coefficients in equation (11).",
            "target": "NIE_1=E[Y(1,M(1))-Y(1,M(0))]"}
