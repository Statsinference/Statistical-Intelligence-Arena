# T06 mechanism claim

- Source: He, Song & Xu (2024), JRSS-B, DOI 10.1093/jrsssb/qkad129, §4 equation (11).
- Mechanism: one continuous linear mediator with mixed Gaussian/Bernoulli baseline variables.
- Four registered parameter scenarios are one family; no duplicate count is claimed.
- Compared with T05 planned Liu et al. high-dimensional sparse multi-mediator design, this is a single-mediator low-dimensional test setting. Its family distinction still requires maintainer review.
- Maintainer claim and named scientific review: pending.
