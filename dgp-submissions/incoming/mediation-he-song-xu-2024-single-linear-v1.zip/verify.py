"""Independent structural-potential-outcome substitution."""
from copy import deepcopy
import importlib.util
from pathlib import Path


def _oracle(config):
    path = Path(__file__).with_name("truth.py")
    spec = importlib.util.spec_from_file_location("he_truth", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.truth(config)["value"]


def _counterfactual_difference(c, x1, x2, em, ey):
    m1 = c["mediator_intercept"]+c["mediator_x1"]*x1+c["mediator_x2"]*x2+em+c["alpha_s"]
    m0 = c["mediator_intercept"]+c["mediator_x1"]*x1+c["mediator_x2"]*x2+em
    def y(m):
        return (c["outcome_intercept"]+c["outcome_x1"]*x1+c["outcome_x2"]*x2
                +c["outcome_direct"]+c["beta_m"]*m+ey)
    return y(m1)-y(m0)


def verify(config):
    reference = _oracle(config)
    values = [_counterfactual_difference(config, x1, x2, em, ey)
              for x1,x2,em,ey in ((0,0,0,0),(1.2,1,-0.3,0.4),(-2.1,0,0.7,-0.2))]
    no_a = deepcopy(config); no_a["alpha_s"] = 0.0
    no_m = deepcopy(config); no_m["beta_m"] = 0.0
    base = all(config[k] == v for k,v in {
        "x1_sd":1.0,"x2_probability":0.5,"treatment_probability":0.5,
        "mediator_intercept":1.0,"mediator_x1":1.0,"mediator_x2":1.0,"mediator_noise_sd":0.5,
        "outcome_intercept":1.0,"outcome_x1":1.0,"outcome_x2":1.0,"outcome_direct":1.0,"outcome_noise_sd":0.5
    }.items())
    pair = (config["alpha_s"],config["beta_m"])
    source_pair = pair in ((0.0,0.5),(0.5,0.0),(0.0,0.0),(0.2,0.2))
    checks = [
        {"name":"source_constants", "passed":base and source_pair,
         "details":"Equation 11 constants, equation 12 fixed null pairs, or section 4.2 product 0.04 at ratio 1."},
        {"name":"structural_counterfactual_substitution", "passed":all(abs(v-reference)<1e-12 for v in values),
         "details":f"analytic={reference:.15g}; substituted contrasts={values}"},
        {"name":"zero_a_to_m_path", "passed":abs(_oracle(no_a))<1e-14,
         "details":"Setting alpha_S=0 eliminates the indirect path."},
        {"name":"zero_m_to_y_path", "passed":abs(_oracle(no_m))<1e-14,
         "details":"Setting beta_M=0 eliminates the indirect path."}
    ]
    return {"passed":all(c["passed"] for c in checks),"checks":checks,
            "shared_components":"Both implementations share the cited linear SEM and configuration. The verifier constructs counterfactual M and Y values without calling the oracle product formula. Named human review remains pending."}
