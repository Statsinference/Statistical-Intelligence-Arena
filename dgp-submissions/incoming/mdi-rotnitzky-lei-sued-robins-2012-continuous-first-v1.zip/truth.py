"""Analytic full-data mean, independent of generated rows."""
import math

def truth(config):
    b=float(config["outcome_intercept"])
    slopes=[float(v) for v in config["outcome_coefficients"]]
    if len(slopes)!=4 or not all(map(math.isfinite,[b]+slopes)):
        raise ValueError("invalid scenario")
    return {"value":b,"estimated_error":0.0,"method":"Linear expectation of independent mean-zero Gaussian terms","target":"Full-data E(Y)"}
