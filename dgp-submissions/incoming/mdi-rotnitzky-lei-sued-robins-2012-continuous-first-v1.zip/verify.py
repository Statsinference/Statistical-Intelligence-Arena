"""Source constants, independent centered-normal quadrature, selection checks."""
import math

def verify(config):
    fixture={"covariate_sd":1.0,"outcome_intercept":210.0,
             "outcome_coefficients":[27.4,13.7,13.7,13.7],"outcome_noise_sd":1.0,
             "observation_logit_coefficients":[-1.0,0.5,-0.25,-0.1],
             "missing_outcome_placeholder":0.0,"paper_sample_sizes":[200,1000],
             "paper_simulation_repetitions":1000}
    b=float(config["outcome_intercept"])
    slopes=[float(v) for v in config["outcome_coefficients"]]
    z=(-1.0,1.0)
    quadrature=sum((b+sum(s*x for s,x in zip(slopes,l)))/16
                   for l in ((a,c,d,e) for a in z for c in z for d in z for e in z))
    selection=config["observation_logit_coefficients"]
    checks=[
      {"name":"source_constants","passed":config==fixture,"details":"Section 5 first experiment and Table 1."},
      {"name":"independent_gaussian_quadrature","passed":abs(quadrature-210)<1e-12,"details":f"Two-node product rule integrates linear mean exactly: {quadrature:.17g}."},
      {"name":"selection_logit_spots","passed":selection==[-1.0,0.5,-0.25,-0.1],"details":"At L=0 logit=0; at each unit vector, logits equal the listed coefficients."},
      {"name":"placeholder_finite","passed":math.isfinite(float(config["missing_outcome_placeholder"])),"details":"Unobserved full Y is never exported."}
    ]
    return {"passed":all(c["passed"] for c in checks),"checks":checks,
            "shared_components":"Quadrature uses published linear mean but not truth.py's direct mean-zero expectation."}
