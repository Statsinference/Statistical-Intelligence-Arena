# Rotnitzky et al. (2012): first continuous-response MAR experiment

**Candidate mechanism; formal claim/deduplication and scientific review pending.**

Rotnitzky, Lei, Sued and Robins (2012), “Improved double-robust estimation in missing data and causal inference models,” *Biometrika* 99(2):439–456, DOI [10.1093/biomet/ass013](https://doi.org/10.1093/biomet/ass013). [Open full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC3635709/), Section 5 first continuous-outcome experiment, journal pp. 451–452. Table 1 on p. 453 says Y is observed iff A=1. The source explicitly reuses the Kang–Schafer (2007) design, so duplicate review must be by mechanism, not just article title. The publisher PDF is [here](https://academic.oup.com/biomet/article-pdf/99/2/439/17461540/ass013.pdf); automatic local download was blocked, so no verified local PDF is claimed.

Per iid individual, (L1,L2,L3,L4,epsilon)~N(0,I5), Y=210+27.4L1+13.7(L2+L3+L4)+epsilon, and A|L~Bernoulli(expit(-L1+0.5L2-0.25L3-0.1L4)). A=1 means Y observed. Missingness is MAR given fully observed L. Selection probability is positive for each finite L but is not uniformly bounded away from zero across Gaussian support. Full-data target E(Y)=**210** by zero means of the independent Gaussian terms.

The paper computes transformed X variables to compare correctly specified and misspecified *estimator working models*. Those X variables do not alter the full-data response or observation law and are not exported here; fully observed L is exported. One call generates one sample, whereas the paper considered n=200 and 1000 with 1000 Monte Carlo datasets. Only observed columns L1–L4, A, Y_observed are returned. When A=0, Y_observed=0 is a finite interface placeholder, not a measured Y; mask using A. Full Y is never exported.

`truth.py` uses centered Gaussian expectation; `verify.py` uses an exact two-node product quadrature for the linear mean plus source-constant/selection checks. Standard library only. No paper PDF, author software, or real data enters this ZIP. AI assisted extraction and implementation; this local work is not named independent reproduction or scientific acceptance.
