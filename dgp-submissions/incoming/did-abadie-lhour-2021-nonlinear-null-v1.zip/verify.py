"""Independent mathematical verification; receives no generated table.

No imports from generator.py or truth.py. Rational quadrature checks
normalization independently of the generator's power-antiderivative formula.
"""
from fractions import Fraction as F
import math


def _simpson_moment(power, subdivisions=256):
    left, right = F(1, 10), F(9, 10)
    step = (right - left) / subdivisions
    total = left ** power + right ** power
    for j in range(1, subdivisions):
        total += (4 if j % 2 else 2) * (left + j * step) ** power
    return step * total / 3 / (right - left)


def verify(config):
    checks = []

    def record(name, passed, details):
        checks.append({"name": name, "passed": bool(passed), "details": details})

    frozen = {
        "p": 4, "r": 2, "a": 0.1, "b": 0.9, "h": 0.1,
        "error_sd": 1, "periods": 2, "treatment_effect": 0,
        "baseline_n": 500, "baseline_n1": 100, "baseline_n0": 400,
    }
    valid = all(isinstance(config.get(k), (int, float))
                and not isinstance(config[k], bool)
                and math.isfinite(config[k]) and config[k] == v
                for k, v in frozen.items())
    record("registered_source_parameters", valid, frozen)
    if not valid:
        return {"passed": False, "checks": checks}

    # Exact rational integration of x^2 and x^4; Simpson error for x^4 is known.
    m2 = _simpson_moment(2)
    m4 = _simpson_moment(4)
    exact_m2, exact_m4 = F(91, 300), F(7381, 50000)
    exact_error = F(2, 15) * (F(4, 5) / 256) ** 4
    v2_integrated = 4 * (m4 - m2 ** 2)
    v2_exact = F(6256, 28125)
    record("independent_second_moment", m2 == exact_m2,
           {"integral": str(m2), "reference": str(exact_m2)})
    record("independent_fourth_moment_with_exact_quadrature_error",
           m4 - exact_m4 == exact_error,
           {"integral": str(m4), "reference": str(exact_m4),
            "exact_simpson_error": str(exact_error)})
    record("independent_population_normalization",
           v2_integrated - v2_exact == 4 * exact_error,
           {"v_squared": str(v2_exact), "v": math.sqrt(float(v2_exact)),
            "integrated_v_squared": float(v2_integrated),
            "quadrature_error_v_squared": float(4 * exact_error)})

    # Independent response-polynomial derivation, not an oracle self-comparison.
    # Conditional mean in state d has coefficients (d*effect,1/v,...,1/v).
    # Shared disturbance cancels pointwise; integration is needed only for ATT.
    scale = math.sqrt(float(v2_exact))
    coeff0 = (0.0,) + (1 / scale,) * 4
    coeff1 = (config["treatment_effect"],) + (1 / scale,) * 4
    contrast = tuple(c1 - c0 for c1, c0 in zip(coeff1, coeff0))
    att = contrast[0] + float(exact_m2) * sum(contrast[1:])
    record("att_by_conditional_response_polynomial", att == 0,
           {"contrast_coefficients": list(contrast), "att": att})
    record("satt_by_pointwise_response_identity", all(c == 0 for c in contrast),
           "The entire response contrast polynomial vanishes for each unit; "
           "the same external post-period disturbance cancels. Any finite "
           "treated-unit average is zero, not the observed pre/post change.")
    record("population_moment_implications",
           4 * (exact_m4 - exact_m2 ** 2) == v2_exact,
           {"treated_outcome_variance": 2, "treated_pre_post_covariance": 1,
            "treated_pre_post_correlation": 0.5,
            "change_mean_each_group": 0, "change_variance_each_group": 2,
            "basis": "Shared unit signal plus independent standard-normal period errors"})
    return {
        "passed": all(c["passed"] for c in checks), "checks": checks,
        "scope": "Mathematical identities only; no generated data or external n received",
        "independence": "Rational Simpson integration and polynomial derivation; no generator/truth imports",
        "limits": "No claim about actual sample counts, pairing, or source scientific acceptance",
    }
