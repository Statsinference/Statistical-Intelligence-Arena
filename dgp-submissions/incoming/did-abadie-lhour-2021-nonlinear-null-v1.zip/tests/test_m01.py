"""Independent tests of actual M01 observations; standard library only."""
import copy
from datetime import datetime, timezone
import hashlib
from fractions import Fraction
import json
import math
from pathlib import Path
import random
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import generator
import truth
import verify

DOCUMENT = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
CONFIG = DOCUMENT["scenarios"][DOCUMENT["default_scenario"]]
EVIDENCE = {}


class M01Tests(unittest.TestCase):
    def test_structure_and_allocation(self):
        counts = {}
        for n in list(range(2, 65)) + [128, 500]:
            data = generator.generate(CONFIG, n, 1729)
            # Rational integer oracle, independent of floating point implementation.
            q = Fraction(n, 5) + Fraction(1, 2)
            n1 = min(n - 1, max(1, q.numerator // q.denominator))
            self.assertEqual(list(data), ["G", "X1", "X2", "X3", "X4", "Y_pre", "Y_post"])
            self.assertTrue(all(len(col) == n for col in data.values()))
            self.assertEqual(data["G"].count(1), n1)
            self.assertEqual(data["G"].count(0), n - n1)
            for i, g in enumerate(data["G"]):
                for j in range(1, 5):
                    self.assertIsInstance(data[f"X{j}"][i], float)
                    lo, hi = (0.1, 0.9) if g else (0, 1)
                    self.assertLessEqual(lo, data[f"X{j}"][i])
                    self.assertLessEqual(data[f"X{j}"][i], hi)
            self.assertTrue(all(math.isfinite(x) for col in data.values() for x in col))
            for key in ("Y_pre", "Y_post"):
                self.assertTrue(all(isinstance(x, float) for x in data[key]))
            if n in (32, 128, 500):
                counts[str(n)] = {"rows": n, "treated": n1, "controls": n-n1,
                                  "sample_status": "paper_table4_baseline" if n == 500 else
                                  "sample_size_extension_not_paper_table4"}
        EVIDENCE["actual_complete_table_counts"] = counts

    def test_seed_and_isolation(self):
        config_before = copy.deepcopy(CONFIG)
        state = random.getstate()
        first = generator.generate(CONFIG, 500, 1729)
        self.assertEqual(first, generator.generate(CONFIG, 500, 1729))
        other = generator.generate(CONFIG, 500, 1730)
        for name in first:
            if name != "G":
                self.assertNotEqual(first[name], other[name])
        self.assertEqual(state, random.getstate())
        self.assertEqual(CONFIG, config_before)

    def test_reject_unapproved_inputs(self):
        for n in (0, 1, -1, True, 2.5):
            with self.assertRaises(ValueError):
                generator.generate(CONFIG, n, 1729)
        for key, value in (("p", 5), ("r", 3), ("error_sd", 2),
                           ("treatment_effect", 1), ("baseline_n0", 1000)):
            altered = dict(CONFIG, **{key: value})
            with self.assertRaises(ValueError):
                generator.generate(altered, 500, 1729)
            with self.assertRaises(ValueError):
                truth.truth(altered)
            self.assertFalse(verify.verify(altered)["passed"])

    def test_independent_math(self):
        exact_v2 = Fraction(6256, 28125)
        self.assertAlmostEqual(generator._normalization(CONFIG), math.sqrt(float(exact_v2)), places=14)
        result = verify.verify(CONFIG)
        self.assertTrue(result["passed"])
        self.assertEqual(truth.truth(CONFIG)["value"], 0)
        EVIDENCE["mathematics"] = result

    def test_distribution_and_shared_unit_signal(self):
        # Predeclared 128 independent replications; 64,000 units, no retained bank.
        groups = {g: {"x": [[] for _ in range(4)], "pre": [], "post": []}
                  for g in (0, 1)}
        v_ref = math.sqrt(6256 / 28125)  # rational reference, not generator helper
        for seed in range(10000, 10128):
            data = generator.generate(CONFIG, 500, seed)
            for i, g in enumerate(data["G"]):
                xs = [data[f"X{j}"][i] for j in range(1, 5)]
                for j, x in enumerate(xs):
                    groups[g]["x"][j].append(x)
                signal = math.fsum(x*x for x in xs) / v_ref
                groups[g]["pre"].append(data["Y_pre"][i] - signal)
                groups[g]["post"].append(data["Y_post"][i] - signal)

        def average(x):
            return math.fsum(x) / len(x)

        def cross(x, y):
            return average([a*b for a, b in zip(x, y)]) - average(x)*average(y)

        summaries = {}
        EVIDENCE["statistical_audit"] = {
            "replications": 128, "seeds": [10000, 10127], "units": 64000,
            "groups": summaries,
            "covariance_definition": "Population-denominator empirical covariance: mean(x*y)-mean(x)*mean(y).",
            "threshold_policy": "Same acceptance thresholds as reviewed tests; absolute deviations use strict <. These are diagnostic bounds, not simultaneous confidence statements. Covariance bounds are conservative scale bounds, not exact 8-SE estimates.",
            "limits": "Finite-sample evidence, not proof of independence. Residuals are reconstructed using each row's shared covariates and the independent rational normalization. verify(config) receives no observed table."
        }
        for g, values in groups.items():
            size = len(values["pre"])
            summary = {"units": size, "checks": {},
                       "covariate_cross_covariances": {},
                       "residual_covariate_covariances": {}}
            summaries[str(g)] = summary

            def record(name, statistic, target, threshold):
                deviation = abs(statistic-target)
                passed = deviation < threshold
                summary["checks"][name] = {
                    "statistic": statistic, "target": target,
                    "absolute_deviation": deviation, "threshold": threshold,
                    "comparison": "absolute_deviation < threshold", "passed": passed
                }
                self.assertTrue(passed, name)

            ks = []
            for j, xs in enumerate(values["x"], 1):
                uniforms = sorted((x-.1)/.8 if g else x*x for x in xs)
                d = max(max((i+1)/size-u, u-i/size) for i, u in enumerate(uniforms))
                record(f"X{j}_uniformized_cdf", d, 0, 6/math.sqrt(size))
                ks.append(d)
            summary["covariate_cdf_distances"] = ks
            for j in range(4):
                for k in range(j):
                    label = f"X{k+1}_X{j+1}"
                    covariance = cross(values["x"][j], values["x"][k])
                    summary["covariate_cross_covariances"][label] = covariance
                    record("covariance_"+label, covariance, 0, 1/math.sqrt(size))
            residuals = {}
            summary["reconstructed_errors"] = residuals
            for period in ("pre", "post"):
                es = values[period]
                mean, second = average(es), average([e*e for e in es])
                record(period+"_residual_mean", mean, 0, 8/math.sqrt(size))
                record(period+"_residual_second_moment", second, 1, 8*math.sqrt(2/size))
                ordered = sorted(es)
                normal_ks = max(max((i+1)/size-(.5*(1+math.erf(e/math.sqrt(2)))),
                                    (.5*(1+math.erf(e/math.sqrt(2))))-i/size)
                                for i, e in enumerate(ordered))
                record(period+"_normal_cdf", normal_ks, 0, 6/math.sqrt(size))
                covariance_values = {}
                summary["residual_covariate_covariances"][period] = covariance_values
                for j, xs in enumerate(values["x"], 1):
                    covariance = cross(es, xs)
                    covariance_values[f"X{j}"] = covariance
                    record(f"{period}_residual_covariance_X{j}", covariance, 0, 8/math.sqrt(size))
                residuals[period] = {"mean": mean, "second_moment": second,
                                     "normal_cdf_distance": normal_ks}
            covariance = cross(values["pre"], values["post"])
            summary["error_pre_post_covariance"] = covariance
            record("pre_post_residual_covariance", covariance, 0, 8/math.sqrt(size))
            changes = [b-a for a, b in zip(values["pre"], values["post"])]
            summary["change_mean"] = average(changes)
            summary["change_second_moment"] = average([d*d for d in changes])
            record("change_mean", summary["change_mean"], 0, 8*math.sqrt(2/size))
            record("change_second_moment", summary["change_second_moment"], 2, 8*math.sqrt(8/size))
            summary["passed"] = all(check["passed"] for check in summary["checks"].values())


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(M01Tests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    EVIDENCE["executed_at_utc"] = datetime.now(timezone.utc).isoformat()
    EVIDENCE["authoritative_test_source"] = "tests/test_m01.py"
    EVIDENCE["source_sha256"] = {
        p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(ROOT.rglob("*"))
        if p.is_file() and "checks" not in p.relative_to(ROOT).parts
        and "__pycache__" not in p.relative_to(ROOT).parts
    }
    EVIDENCE.update({"passed": result.wasSuccessful(), "tests_run": result.testsRun,
                     "failures": len(result.failures), "errors": len(result.errors)})
    checks = ROOT / "checks"
    checks.mkdir(exist_ok=True)
    (checks / "independent_audit.json").write_text(
        json.dumps(EVIDENCE, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
