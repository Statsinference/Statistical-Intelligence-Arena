# M01: Abadie & L’Hour (2021), Section 5 nonlinear null

## Scope and provenance

正式来源：Abadie, A. and L’Hour, J. (2021), *A Penalized Synthetic Control Estimator for Disaggregated Data*, JASA 116(536), 1817–1834.
DOI: https://doi.org/10.1080/01621459.2021.1971535

正式 PDF: https://economics.mit.edu/sites/default/files/publications/A%20Penalized%20Synthetic%20Control%20Estimator%20for%20Disagg.pdf
定位：§5，PDF 第8页/期刊1824页的未编号生成方程；PDF第9页/1825页样本设置；Table 4，PDF第13页/1829页，p=4、r=2。
作者代码固定版本：
https://github.com/jeremylhour/pensynth/blob/3f2ad93a96acd558841275d07cd70576c78d451f/simulations/Main_MonteCarlo_v3.m
样本数、维数、支持与指数：33–37行；协变量：69–71行；标准化与第一期结局：73、79–81行；第二期新误差与结局：205–219行。
以固定 commit 为准，不使用移动分支。

最新版《项目第一次任务操作指南(2).docx》将 DiD 对应 did_sc，内嵌 image10.png 明列“DiD / Synthetic Control”；原版 docs/DGP_Collection_Student_Guide_ZH.md 第9行亦列 DiD / synthetic control。
因此本机制归入 did_sc，准确描述为合成控制背景的两期零效应模拟；不声称复现论文估计器或 Table 4 的估计性能。

## Baseline and source-version difference

基准：n1=100，n0=400，N=500，p=4，r=2，h=0.1。
论文 Table 4 的100/400与作者 v3 默认100/1000不同。
本实现固定论文基准，不能称为完整复现 v3 默认样本量。
Python random.Random 与 MATLAB combRecursive 不逐字节复现随机流。

## Generative order and scientific variables

每行一个单位；前 n1 行 G=1，其余 G=0。这是固定分层计数，不是随机 Bernoulli 分配。
对每一单位及 j=1,...,4 独立生成：
- G=1: X_j ~ Uniform(0.1,0.9)。
- G=0: X_j=sqrt(U_j)，U_j ~ Uniform(0,1)。
- 两期共享这些 X；独立生成 epsilon_pre、epsilon_post ~ N(0,1)，跨期、跨单位及与 X 独立。
- v=sqrt(p Var[X^r | G=1])；mu(X)=sum_j X_j^r/v。
- Y_pre=mu(X)+epsilon_pre；Y_post=mu(X)+epsilon_post。

v 是处理组平方变换后协变量之和的总体标准差，不是样本标准差。
E[X^2]=91/300，E[X^4]=7381/50000；
Var(X^2)=1564/28125，v^2=6256/28125，v=0.47163074068126176。
生成器使用均匀分布幂矩公式；verify 使用独立有理数 Simpson 积分及其精确误差核对。

七列且全部 observed：G treatment/binary；X1–X4 covariate/float；Y_pre、Y_post outcome/float。
不输出 ID、误差、潜在结果、条件均值或真值列。宽表为本项目适配格式，不是原论文数据格式。
时期 t=1 为 pre、t=2 为 post，暴露可重建为 A_pre=0、A_post=G。
没有缺失、退出或额外初始状态；两期结局都是实际观察结局。

## Estimand and identification

目标 ATT_post=E[Y_2(1)-Y_2(0)|G=1]，目标总体为处理组协变量分布，评价期为第二期。
结构方程在第二期无处理项；两种处理状态使用同一单位、同一第二期扰动，因此逐单位差严格为0。
总体 ATT=0，任意有限处理组等权 SATT=0。
这不表示观察到的 Y_post-Y_pre 为0；该变化由两次独立误差之差构成，方差2。
无干扰、一致性、无预期效应及时间不变信号/均值零误差保证这里的未处理均值平行趋势。
零效应真值来自结构方程，不是估计方法的输出。

## Sample-size interface and scenarios

generate(config,n,seed) 的 n 是单位数，也是每列长度，要求整数 n>=2。
外部 n 从不被配置中的基准计数覆盖。
分配规则严格为：
n1=min(n-1,max(1,floor(n/5+0.5)))；n0=n-n1。
n=500 恰为100/400；n=32为6/26；n=128为26/102。
其他 n 均为 sample_size_extension_not_paper_table4；整数分配使小样本比例仅近似1:4。
不复制、截断或补齐单位。

config 只登记一个固定数学场景及上述 n 规则；baseline_n/n1/n0 是来源基准元数据，不是覆盖 n 的命令。
p、r、支持、误差标准差及零效应固定；未实现其他维数或指数。
样本量、随机种子变化均不是新的 mechanism family。

## Validation scope and evidence

生成器运行时检查七列、长度、实际组别计数、组别支持、有限值和本单位两期结局构造。
truth 返回标量0及解析推导。
verify(config) 不接收 n 或观察表，只核对数学恒等式，不证明实际样本计数或配对。
独立 tests/test_m01.py 是贡献目录中唯一权威测试源，检验实际完整表、随机复现、扰动分布及跨期关系；统计检验仅提供有限样本证据，不等同于分布证明。
checks/independent_audit.json 保存实际执行的逐项统计量、数值阈值和判断，包括协变量交叉协方差、两期残差协方差以及每期残差与各协变量的协方差。阈值沿用已审核测试，不作为多重检验置信结论。
原始 M01_review.zip 内 checks/independent_tests.py 是当时审核用的字节相同副本；历史 ZIP 保留不变，不作为当前测试源。
官方检查将依次使用 --n 500、--n 32。
checks/runs/n500 与 checks/runs/n32 分别保留原始报告和样本；根 checks 保持基准500的证据。
官方 sample.json 仅含前8行；因处理组排在前面，这些行不能证明对照组计数，须结合完整表的独立审计。
本轮不打包、不上传。额外检查子目录不应被假定自动进入官方 pack，最终打包前须复核其收录规则。

## Rights and limitations

不复制或分发原文 PDF、作者 MATLAB 源文件；这里为独立 Python 实现。
作者固定 commit 的 LICENSE 为 MIT（https://github.com/jeremylhour/pensynth/blob/3f2ad93a96acd558841275d07cd70576c78d451f/LICENSE），其许可不自动替本贡献选定发布许可证。
source.license 仅记录来源许可：正式论文版权为 © 2021 American Statistical Association；在该正式 PDF 中未发现明确开放内容许可，不据此推断开放授权。作者固定 commit 的 MIT 仅适用于相应作者代码，不扩展到论文或本贡献 Python 代码。该字段不替本贡献选定发布许可证。
机器检查通过不等于科学审核通过，也不代表整个 T10 已完成。
