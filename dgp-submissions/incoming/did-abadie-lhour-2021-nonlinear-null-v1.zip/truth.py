"""Analytic ATT oracle. Does not import or call generator.py."""
import math


def truth(config):
    expected = {
        "p": 4, "r": 2, "a": 0.1, "b": 0.9, "h": 0.1,
        "error_sd": 1, "periods": 2, "treatment_effect": 0,
        "baseline_n": 500, "baseline_n1": 100, "baseline_n0": 400,
    }
    for key, value in expected.items():
        actual = config.get(key)
        if (not isinstance(actual, (int, float)) or isinstance(actual, bool)
                or not math.isfinite(actual) or actual != value):
            raise ValueError(f"Registered M01 oracle requires {key}={value}")
    return {
        "value": 0.0, "estimated_error": 0.0,
        "method": "Exact structural cancellation, not a Monte Carlo estimate",
        "definition": "E[Y_i2(1)-Y_i2(0)|G_i=1]",
        "derivation": (
            "Holding X and the post-period external error fixed, the response "
            "contains no treatment term. Each individual contrast is zero. "
            "Its population expectation and finite-sample average (SATT) "
            "are exactly zero, independently of group sample sizes. "
            "The observed change Y_post-Y_pre need not equal zero."
        ),
    }
