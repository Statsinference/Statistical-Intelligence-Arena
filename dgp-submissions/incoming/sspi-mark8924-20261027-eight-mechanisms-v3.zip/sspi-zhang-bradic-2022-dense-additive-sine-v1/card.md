# Dense additive sine mean with equicorrelated Gaussian covariates

Status: locally prepared contribution; scientific acceptance and named independent-person replication are pending.
Contributor: 马铭远 (Mark8924). Task: SSPI (T05/T06).

## Source and exact reconstruction

Zhang, Y. and Bradic, J. (2022). High-dimensional semi-supervised learning: in search of optimal inference of the mean. Biometrika 109(2), 387-403. DOI: https://doi.org/10.1093/biomet/asab042.
Reading version: Final journal PDF, downloaded copy dated 2 August 2022; not the later arXiv revision.
Download: https://par.nsf.gov/servlets/purl/10345775
SHA-256: `133540a561376c631f2fad39a24cf413442e2f4321229ff2a99af85e5d0a7cd9`.
Mechanism locator: **Section 5.1, Model 3, unnumbered covariance and outcome equations, PDF p. 12 / journal p. 398; Figure 3**. These model equations are unnumbered in the source.
Sampling/target locator: Section 1, PDF pp. 1-2 / journal pp. 387-388; Section 5.1, PDF pp. 10-13 / journal pp. 396-399.

- p=1001, d=p-1=1000, rho=1/(2*p); X~N_d(0,C).
- C_jj=1-rho and C_jk=rho for j!=k, exactly as printed (NOT unit diagonal).
- Y=sum_{j=1}^d 0.7^(j-1)*sin(X_j)+epsilon; epsilon independent of X is N(0,0.25).
- Independent units from the same population in labeled and unlabeled samples. R=1 on the first n_labeled rows and R=0 on the rest, fixed by design independently of values. Y_obs=Y when R=1 and zero placeholder when R=0.

Every variance, coefficient, distribution, and source allocation is transcribed in config.json and the equations above. The generator creates covariates first, then only the labeled outcomes using an independent RNG stream. There are no causal interventions. `source_audit.json` maps these components back to the paper. No author software was relied on, so there is no invented code commit.

## Observation contract and target

Population mean of Y in the common labeled/unlabeled population.

`generate(config,n,seed)` takes the selected scenario object. Its n is the **total combined row count**. At n=source_n_labeled+source_n_unlabeled, the paper allocation is reproduced exactly. At other n, the integer formula in collection.json preserves the ratio approximately and leaves both groups nonempty. The first L rows have R=1; the rest have R=0. Ordering is a representation choice and conveys only sample membership. All X columns are observed. Y_obs on R=0 rows is a **zero placeholder**, never a true zero response; downstream fitting and evaluation must mask by R. Hidden Y, latent Gaussian Z in the lognormal case, noise, regression function and oracle truth are not exported. Independent MCAR samples are assumed, not outcome-dependent selection or distribution shift.

The DGP supplies **no fitted predictor**. PFN or classical predictors, if later used, must be trained only on permitted labeled data; cross-fitting, validation splits and external-predictor provenance belong to the later method stage. Never use this truth routine or the complete data law as method inputs.

## Source scenarios and population truth

| Scenario | Source labeled n | Source unlabeled m | Population truth | Numerical error diagnostic |
|---|---:|---:|---:|---:|
| original | 100 | 1000 | 0 | 0 |

Every centered Gaussian marginal is symmetric and sin is odd, hence every term has mean zero, even with correlated covariates. E[Y]=0.

`truth.py` uses population calculations, not Monte Carlo over generated observations. `verify.py` uses separate real-axis Simpson integration or a discrete probability-mass recurrence, plus hand-evaluated response fixtures, source constants, finite observed-only schema and mask checks. For Gaussian integrals the real-axis cutoff is 12 standard deviations. Analytic special cases include zero/noise symmetry, product/shift identities, or one-coordinate polynomial evaluations as appropriate. Both routines share the documented equations and configuration; they do **not** constitute a second person's reproduction. The lognormal error field is an observed quadrature convergence estimate, not a proof of uniform numerical accuracy. Declared comparison tolerance is 1e-9.

## Diversity and limitations

All 1000 coefficients are nonzero, although they decay geometrically. Reported effective_dimension counts exact support, not intrinsic statistical difficulty. Model 4 changes dimension/covariance/sample ratio and is not counted separately.

Eight contributed mechanisms are distinguished by functional structure and data law, not by seeds or sample sizes. This package implements only its declared scenarios, not every simulation in the article. It does not reproduce estimator tables, confidence-interval coverage, PFN performance or training.

## Explicit adaptations and implementation choices

1. Represent the two independent samples as one numeric table with mandatory R and zero placeholder Y_obs; n in generate is total rows, unlike the source n which denotes labeled rows. No hidden labels are returned.
2. For source totals the labeled/unlabeled sizes are exact. Other requested n values use nearest-integer proportional allocation, clamped to keep both groups nonempty. Such smaller smoke samples are interface checks, not a reproduction of paper performance.
3. Original NumPy PCG64 implementation; source random-number streams and estimator fitting are not reproduced. No pretrained/external predictor is supplied; later predictors must use observed labels with their own training/evaluation separation.
4. Use source n_labeled=100 from the plotted grid and m=10*n. Other plotted n values change sample allocation, not a new mechanism. Source p includes the intercept; observed X has p-1 columns.

## Reproduce and inspect

Requires Python >=3.11 and the pinned NumPy version. From the student toolkit root, replace CONTRIBUTION with this extracted directory:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTSIDE_CONTRIBUTION.zip
```

Run all scenarios; editing any source/config/card requires rerunning check and repacking. Check evidence is in checks/report.json. Do not fit on Y_obs without R. A small-n check only validates implementation; it is not a benchmark run at the source sample size.

For the additional reproducible audit, run `python audit.py` inside this contribution directory. It prints JSON and does not write files or use the network. `extra_validation.json` records its actual run: original source sample counts, a fixed-seed distribution diagnostic, scalar-versus-vectorized equation checks, boundary cases and checks that the generator leaves global RNG state untouched. These are finite computational tests, not a general distribution proof.

## Rights and assistance

Source article copyright remains with its rights holders. PDFs/figures/author code are not redistributed. Equations are independently implemented; contributed original code is Apache-2.0, matching the destination repository. No real individual records are used.

AI assistance: Codex extracted sources, implemented equations, derived/checks truth and performed computational self-review for Mark8924. A human scientific reviewer has not signed off. No approval, acceptance, authorship allocation or independent-human replication is asserted. The paper PDFs stay outside the ZIP. Reviewers should confirm the source interpretation, scalar target, assumptions and all adaptations. The currently deployed six-category registry may put this correctly labeled semi_supervised contribution in Needs classification until maintained.
