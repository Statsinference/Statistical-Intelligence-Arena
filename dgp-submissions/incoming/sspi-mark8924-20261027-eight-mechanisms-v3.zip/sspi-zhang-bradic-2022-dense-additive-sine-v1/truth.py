"""Population functional, independent of generated observations. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss

def truth(config):
    c=config
    error=0.0
    value=0.0
    return {'value':float(value),'estimated_error':float(error),
            'method':'Analytic population moments, separately verified by real-axis integration or discrete PMF summation', 'explanation':'Every centered Gaussian marginal is symmetric and sin is odd, hence every term has mean zero, even with correlated covariates. E[Y]=0.',
            'error_interpretation':'Analytic values use floating-point arithmetic. Nonzero numerical error is a convergence diagnostic, not a rigorous uniform bound.'}
