"""Original NumPy implementation of the cited mechanism. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np

MECHANISM = 'quadratic'
DIMENSION = 10

def _validate(c):
    if c.get('mechanism') != MECHANISM or c.get('dimension') != DIMENSION:
        raise ValueError('Wrong mechanism/dimension for this fixed-schema contribution')
    for k in ('source_n_labeled','source_n_unlabeled'):
        if isinstance(c[k],bool) or not isinstance(c[k],int) or c[k]<1:
            raise ValueError(k+' must be a positive integer')
    if c['observation_rule']!='fixed_two_independent_samples' or c['placeholder']!=0.0:
        raise ValueError('Unsupported observation contract')
    if not math.isfinite(c['noise_sd']) or c['noise_sd']<0:
        raise ValueError('Invalid noise scale')

def _draw_x(c, n, rng):
    a=c['truncation_bound']
    if not math.isfinite(a) or a<=0: raise ValueError('Invalid truncation bound')
    x=rng.normal(size=(n,DIMENSION))
    bad=np.abs(x)>a
    while np.any(bad):
        x[bad]=rng.normal(size=int(bad.sum()))
        bad=np.abs(x)>a
    return x

def _mean(x, c):
    b=np.ones(DIMENSION); b[DIMENSION//2:]=int(c['coefficient_pattern']=='dense')
    u=x@b
    return u+u*u

def generate(config, n, seed):
    """n is TOTAL rows. Only R=1 rows have an observed response; zero elsewhere."""
    c=config
    _validate(c)
    if isinstance(n,bool) or not isinstance(n,int) or n<2:
        raise ValueError('n must be an integer >=2 with both sample types present')
    streams=np.random.SeedSequence(seed).spawn(2)
    rx=np.random.Generator(np.random.PCG64(streams[0]))
    ry=np.random.Generator(np.random.PCG64(streams[1]))
    x=_draw_x(c,n,rx)
    # Integer nearest allocation; exact when n is the source total. No outcome-driven selection.
    den=c['source_n_labeled']+c['source_n_unlabeled']
    labeled=max(1,min(n-1,(n*c['source_n_labeled']+den//2)//den))
    mean=_mean(x[:labeled],c)
    observed=ry.poisson(mean) if MECHANISM=='poisson' else mean+ry.normal(0,c['noise_sd'],labeled)
    y=np.zeros(n,dtype=float); y[:labeled]=observed
    r=np.zeros(n,dtype=int); r[:labeled]=1
    # Hidden responses are never generated or returned; R is mandatory for all downstream use.
    out={f'X{j+1}':x[:,j].tolist() for j in range(DIMENSION)}
    out['R']=r.tolist(); out['Y_obs']=y.tolist()
    return out
