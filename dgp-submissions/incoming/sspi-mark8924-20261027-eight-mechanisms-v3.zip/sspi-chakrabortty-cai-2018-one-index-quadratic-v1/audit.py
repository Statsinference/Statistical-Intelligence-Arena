"""Run from a contribution as audit.py: python audit.py. No file/network writes.

SPDX-License-Identifier: Apache-2.0
Numerical/self-review evidence, not independent human scientific acceptance.
Six-standard-error diagnostics were fixed before observing generated samples.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import platform
import random
import sys

import numpy as np


def load(root, name):
    spec = importlib.util.spec_from_file_location('audit_' + name, root / (name + '.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def independent_response(row, c):
    """Scalar Python equations transcribed separately from NumPy generator code."""
    k = c['mechanism']
    if k == 'linear':
        return math.fsum(row[:c['sparsity']]) / math.sqrt(c['sparsity'])
    if k == 'cosine':
        return c['amplitude'] * math.cos(math.fsum(row[:3]))
    if k == 'sine':
        return math.fsum(c['decay'] ** j * math.sin(x) for j, x in enumerate(row))
    if k == 'lognormal':
        return math.fsum(math.log1p(x) ** 2 + c['offset_per_coordinate'] for x in row[:3])
    if k == 'interaction':
        return row[0] * row[1] + c['quadratic_scale'] * (row[2] + c['shift']) ** 2
    if k == 'poisson':
        return c['response_multiplier'] * row[0]
    p = len(row)
    u = math.fsum(row if c['coefficient_pattern'] == 'dense' else row[:p // 2])
    if k == 'quadratic':
        return u + u ** 2
    v = math.fsum(row[p // 2:])
    w = math.fsum(row[j] for j in range(0, p, 2))
    return u + u * v + w ** 2


def digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def audit(root):
    g, t = load(root, 'generator'), load(root, 'truth')
    configs = json.loads((root / 'config.json').read_text())['scenarios']
    all_results = []
    for name, c in configs.items():
        checks = []
        def check(label, passed, detail):
            checks.append(dict(name=label, passed=bool(passed), details=detail))

        original = json.dumps(c, sort_keys=True)
        # Full published allocation: run the interface at the original total, not just 128 rows.
        source_total = c['source_n_labeled'] + c['source_n_unlabeled']
        full = g.generate(c, source_total, 272026)
        check('full_source_allocation', len(full['R']) == source_total and sum(full['R']) == c['source_n_labeled'],
              {'total': source_total, 'labeled': sum(full['R']), 'unlabeled': source_total - sum(full['R'])})
        full_hash = digest(full)
        del full
        small = g.generate(c, 128, 20261027)
        small_hash = digest(small)
        check('replay', small_hash == digest(g.generate(c, 128, 20261027)), small_hash)
        check('different_seed', small_hash != digest(g.generate(c, 128, 20261028)), 'Distinct fixed seeds')
        edge = g.generate(c, 2, 1729)
        check('minimal_two_sample_case', edge['R'] == [1, 0] and edge['Y_obs'][1] == 0,
              'One labeled and one unlabeled row at minimum supported n=2')
        rejected = []
        for invalid in (-1, 0, 1, True, 2.5):
            try:
                g.generate(c, invalid, 1729)
                rejected.append(False)
            except ValueError:
                rejected.append(True)
        check('invalid_n_rejected', all(rejected), 'negative/zero/one/bool/noninteger')
        random.seed(6001); py_before = random.getstate()
        np.random.seed(6001); np_before = np.random.get_state()
        g.generate(c, 16, 551)
        np_after = np.random.get_state()
        check('no_global_rng_mutation', random.getstate() == py_before and np.array_equal(np_before[1], np_after[1]) and np_before[2:] == np_after[2:], 'Local SeedSequence + PCG64 only')
        check('no_config_mutation', original == json.dumps(c, sort_keys=True), 'Input scenario unchanged')
        d = c['dimension']
        test_rng = np.random.default_rng(80312)
        probe = test_rng.uniform(-2, 2, size=(25, d))
        if c['mechanism'] == 'lognormal':
            probe = np.exp(probe)
        if c['mechanism'] == 'poisson':
            probe = test_rng.poisson(10, size=(25, d))
        scalar = np.array([independent_response(row.tolist(), c) for row in probe])
        difference = float(np.max(np.abs(scalar - g._mean(probe, c))))
        check('scalar_vectorized_equation_agreement', difference < 1e-10, {'max_abs_difference': difference, 'fixed_probe_rows': 25})

        if c['mechanism'] in ('sine', 'lognormal'):
            class BasisRng:
                def normal(self, size):
                    if size == (2, d):
                        a = np.zeros(size); a[0, 0] = 1; a[1, 1] = 1
                        return a
                    if size == (2, 1):
                        return np.array([[1.0], [-1.0]])
                    raise ValueError('Unexpected covariance draw shape')
            actual = g._draw_x(c, 2, BasisRng())
            if c['mechanism'] == 'lognormal':
                actual = np.log(actual)
            rho = 1 / (2 * c['source_p']); marginal_variance = 1 - rho
            expected = np.tile(np.array([[math.sqrt(rho)], [-math.sqrt(rho)]]), (1, d))
            expected[0, 0] += math.sqrt(marginal_variance - rho)
            expected[1, 1] += math.sqrt(marginal_variance - rho)
            check('actual_covariance_sampling_map', np.allclose(actual, expected, rtol=0, atol=1e-14),
                  'Exercises actual _draw_x; detects replacing printed diagonal 1-rho with 1')
        if c['mechanism'] in ('quadratic', 'three_component'):
            class RejectionRng:
                def normal(self, size):
                    if isinstance(size, tuple):
                        a = np.zeros(size); a[0, 0] = 6; a[1, 0] = -6
                        return a
                    return np.full(size, 0.25)
            actual = g._draw_x(c, 2, RejectionRng())
            check('actual_rejection_boundary', actual[0, 0] == 0.25 and actual[1, 0] == 0.25,
                  'Out-of-range draws are redrawn; they are not clipped to the boundary')
        if c['mechanism'] == 'poisson':
            null_config = dict(c, x_rate=0.0)
            null_data = g.generate(null_config, 128, 811)
            check('poisson_zero_rate_special_case', all(v == 0 for v in null_data['X1'] + null_data['Y_obs']),
                  'Explicit analytic null special case, not a source scenario or an additional mechanism')

        # Fixed diagnostic sample and threshold; failures must be investigated, not reseeded.
        data = g.generate(c, 8192, 20261101)
        x = np.column_stack([data[f'X{j+1}'] for j in range(d)])
        r = np.array(data['R'], dtype=bool); y = np.array(data['Y_obs'])
        mu = np.array([independent_response(row.tolist(), c) for row in x[r]])
        check('no_hidden_label_leak', set(data) == {f'X{j+1}' for j in range(d)} | {'R', 'Y_obs'} and np.all(y[~r] == 0), 'Exact observed-only column set and zero placeholder for every unavailable Y')
        check('finite_and_lengths', all(len(v) == 8192 and np.all(np.isfinite(v)) for v in data.values()), 'All columns finite numeric lists of requested length')
        k = c['mechanism']
        if k == 'poisson':
            standardized = (y[r] - mu) / np.sqrt(np.maximum(mu, 1))
            check('poisson_integer_support', np.all(x >= 0) and np.all(x == np.floor(x)) and np.all(y >= 0) and np.all(y == np.floor(y)), 'Nonnegative integer covariates and response')
            check('zero_rate_boundary', np.all(y[r][mu == 0] == 0), 'Poisson(0) returns zero; not clamped to positive rate')
            expected_var = c['x_rate']; feature = x[:, 0]; expected_mean = c['x_rate']
        else:
            standardized = (y[r] - mu) / c['noise_sd']
            feature = np.log(x[:, 0]) if k == 'lognormal' else x[:, 0]
            expected_mean = 0.0
            expected_var = 1 - 1 / (2 * c['source_p']) if k in ('sine', 'lognormal') else 1.0
            if k in ('quadratic', 'three_component'):
                a = c['truncation_bound']
                expected_var = 1 - 2 * a * math.exp(-a * a / 2) / math.sqrt(2 * math.pi) / math.erf(a / math.sqrt(2))
                check('bounded_without_clipped_atoms', np.all(np.abs(x) < a), 'Continuous conditional truncation has no atoms at +-5')
        m = len(standardized)
        z_residual = float(np.mean(standardized) * math.sqrt(m))
        # Poisson standardized fourth moment = 3 + 1/lambda, bounded by 3.1 for lambda>=10.
        var_se = math.sqrt(2.1 / max(m - 1, 1))
        residual_var = float(np.var(standardized, ddof=1))
        check('noise_location_diagnostic', abs(z_residual) < 6, {'standardized_mean_z': z_residual, 'cutoff': 6, 'labeled_draws': m})
        check('noise_variance_diagnostic', abs(residual_var - 1) < 6 * var_se, {'standardized_sample_variance': residual_var, 'absolute_tolerance': 6 * var_se})
        feature_z = float((np.mean(feature) - expected_mean) / math.sqrt(expected_var / len(feature)))
        check('feature_mean_diagnostic', abs(feature_z) < 6, {'z': feature_z, 'cutoff': 6})
        variance = float(np.var(feature, ddof=1))
        variance_se = math.sqrt((2 * expected_var ** 2 + (c['x_rate'] if k == 'poisson' else 0)) / (len(feature) - 1))
        check('feature_variance_diagnostic', abs(variance - expected_var) < 6 * variance_se, {'empirical': variance, 'target': expected_var, 'absolute_tolerance': 6 * variance_se})
        all_results.append(dict(scenario=name, passed=all(v['passed'] for v in checks), checks=checks,
                                source_sample_sha256=full_hash, diagnostic_seed=20261101, diagnostic_n=8192,
                                truth=t.truth(c)))
    return dict(passed=all(x['passed'] for x in all_results), scenarios=all_results,
                environment=dict(python=platform.python_version(), numpy=np.__version__, platform=platform.platform()),
                limitations='Finite, fixed-seed diagnostics and same-contributor equation checks. No estimator coverage, general goodness-of-fit proof, named reviewer or independent-human replication. Six-SE cutoffs were specified before diagnostic results; no seed search.')


if __name__ == '__main__':
    destination = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else Path(__file__).resolve().parent
    result = audit(destination)
    print(json.dumps(result, indent=2, allow_nan=False))
    raise SystemExit(0 if result['passed'] else 1)
