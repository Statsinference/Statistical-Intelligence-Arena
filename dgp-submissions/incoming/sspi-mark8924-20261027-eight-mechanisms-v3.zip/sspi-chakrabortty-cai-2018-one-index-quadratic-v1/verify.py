"""Different numerical routes, source fixtures and mask tests. SPDX-License-Identifier: Apache-2.0."""
import importlib.util
from pathlib import Path
import math
import numpy as np

FIXTURES = [{'observation_rule': 'fixed_two_independent_samples', 'placeholder': 0.0, 'target': 'population_mean', 'noise_sd': 1.0, 'mechanism': 'quadratic', 'dimension': 10, 'source_p': 10, 'source_n_labeled': 500, 'source_n_unlabeled': 10000, 'truncation_bound': 5.0, 'coefficient_pattern': 'sparse'}, {'observation_rule': 'fixed_two_independent_samples', 'placeholder': 0.0, 'target': 'population_mean', 'noise_sd': 1.0, 'mechanism': 'quadratic', 'dimension': 10, 'source_p': 10, 'source_n_labeled': 500, 'source_n_unlabeled': 10000, 'truncation_bound': 5.0, 'coefficient_pattern': 'dense'}]

def _load(name):
    p=Path(__file__).with_name(name+'.py')
    spec=importlib.util.spec_from_file_location('sspi_check_'+name,p)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def _simpson(f,lo,hi,steps=12000):
    x=np.linspace(lo,hi,steps+1); y=f(x)
    return float((hi-lo)/(3*steps)*(y[0]+y[-1]+4*y[1:-1:2].sum()+2*y[2:-1:2].sum()))

def _independent(c):
    """Uses real-axis Simpson integration or discrete PMF summation, not GH/closed-form moment code."""
    normal=lambda x:np.exp(-x*x/2)/math.sqrt(2*math.pi)
    k=c['mechanism']
    if k=='linear':
        return math.sqrt(c['sparsity'])*_simpson(lambda x:x*normal(x),-12,12)
    if k=='sine':
        sd=math.sqrt(1-1/(2*c['source_p']))
        return sum(c['decay']**j for j in range(c['dimension']))*_simpson(lambda x:np.sin(sd*x)*normal(x),-12,12)
    if k=='cosine':
        return _simpson(lambda x:c['amplitude']*np.cos(math.sqrt(3)*x)*normal(x),-12,12)
    if k=='lognormal':
        sd=math.sqrt(1-1/(2*c['source_p']))
        # exp is safe on this bounded integration interval; distinct from truth.logaddexp.
        return 3*_simpson(lambda x:np.log(1+np.exp(sd*x))**2*normal(x),-12,12)+3*c['offset_per_coordinate']
    if k=='interaction':
        first=_simpson(lambda x:x*normal(x),-12,12)
        return first**2+_simpson(lambda x:c['quadratic_scale']*(x+c['shift'])**2*normal(x),-12,12)
    if k=='poisson':
        mass=math.exp(-c['x_rate']); total=0.0
        for j in range(1,151):
            mass*=c['x_rate']/j
            total+=j*mass*c['response_multiplier']
        return total
    a=c['truncation_bound']
    normalizer=_simpson(normal,-a,a)
    second=_simpson(lambda x:x*x*normal(x),-a,a)/normalizer
    b=[1 if (j<c['dimension']//2 or c['coefficient_pattern']=='dense') else 0 for j in range(c['dimension'])]
    # Independent coordinate-wise expansion of the population normal equations.
    if k=='quadratic':return sum(b[j]*b[j]*second for j in range(c['dimension']))
    return sum((b[j]*(j>=c['dimension']//2)+(j%2==0))*second for j in range(c['dimension']))

def verify(config):
    c=config; g=_load('generator'); t=_load('truth')
    got=t.truth(c); independent=_independent(c)
    checks=[]
    def check(name,passed,details):checks.append(dict(name=name,passed=bool(passed),details=details))
    check('source_parameter_fixture',any(c==f for f in FIXTURES),'Exact declared source scenario; no invented defaults')
    check('independent_population_integral',abs(got['value']-independent)<1e-9,{'oracle':got['value'],'independent':independent,'absolute_difference':abs(got['value']-independent)})
    check('oracle_convergence',got['estimated_error']<=1e-9,got['estimated_error'])
    # The zero and all-one fixtures are manually transcribed algebra, not a call to _mean itself.
    d=c['dimension']; k=c['mechanism']
    points=np.stack([np.zeros(d),np.ones(d)])
    if k=='linear': expected=[0,math.sqrt(c['sparsity'])]
    elif k=='cosine':expected=[c['amplitude'],c['amplitude']*math.cos(3)]
    elif k=='sine':expected=[0,math.sin(1)*sum(c['decay']**j for j in range(d))]
    elif k=='lognormal':
        points=np.stack([np.ones(d),np.full(d,math.e-1)])
        expected=[3*math.log(2)**2+3*c['offset_per_coordinate'],3+3*c['offset_per_coordinate']]
    elif k=='interaction':expected=[c['quadratic_scale']*c['shift']**2,1+c['quadratic_scale']*(1+c['shift'])**2]
    elif k=='poisson':expected=[0,c['response_multiplier']]
    elif k=='quadratic':
        s=d if c['coefficient_pattern']=='dense' else d//2
        expected=[0,s+s*s]
    else:
        s=d if c['coefficient_pattern']=='dense' else d//2
        expected=[0,s*(1+d//2)+((d+1)//2)**2]
    check('conditional_mean_source_fixtures',np.allclose(g._mean(points,c),expected,rtol=0,atol=1e-10),{'expected':expected})
    if k in ('sine','lognormal'):
        rho=1/(2*c['source_p']); factor=np.c_[np.eye(3)*math.sqrt(1-2*rho),np.ones(3)*math.sqrt(rho)]
        expected_cov=np.full((3,3),rho); np.fill_diagonal(expected_cov,1-rho)
        check('literal_covariance_factor',np.allclose(factor@factor.T,expected_cov,rtol=0,atol=1e-14),'Published diagonal=1-rho; off diagonal=rho; lognormal refers to latent Gaussian covariance')
    data=g.generate(c,128,8181); mask=np.array(data['R']); y=np.array(data['Y_obs'])
    expected_columns={f'X{j+1}' for j in range(d)}|{'R','Y_obs'}
    check('observed_only_mask',set(data)==expected_columns and np.all(y[mask==0]==0) and 0<mask.sum()<128,'No complete outcome, latent Z, conditional mean, noise, prediction or truth column')
    check('finite_observations',all(np.all(np.isfinite(v)) for v in data.values()),'Includes no NaN/null')
    # Concrete special cases of the response map, including a genuinely structural interaction check.
    if k=='interaction':
        q=np.zeros((1,d)); q[0,0]=2;q[0,1]=3;q[0,2]=-c['shift']
        check('zero_quadratic_and_product',abs(g._mean(q,c)[0]-6)<1e-12,'X3=-shift removes quadratic term; X1*X2 remains six')
    if k in ('quadratic','three_component'):
        x=np.column_stack([data[f'X{j+1}'] for j in range(d)])
        check('truncated_support',np.all(np.abs(x)<=c['truncation_bound']),'Truncation by rejection, not clipping')
        e=np.zeros((1,d));e[0,0]=1
        check('single_coordinate_algebra',abs(g._mean(e,c)[0]-2)<1e-12,'First b/omega coordinates are one; delta first coordinate is zero')
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'shared_components':'Same written scientific equations/config; separate numerical integration and moment implementation. The mask/source fixtures call generator intentionally. This is computational cross-checking by the same contributor, not an independent human reproduction.',
            'integration_tail_note':'Normal integrations restricted to [-12,12]; absolute polynomial/softplus-tail contribution is below 1e-26 for these declared parameters. Poisson recurrence through 150 has negligible tail at lambda=10; convergence diagnostic is not an identification/coverage proof.'}
