"""Population functional, independent of generated observations. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss

def truth(config):
    c=config
    error=0.0
    value=c['amplitude']*math.exp(-1.5)
    return {'value':float(value),'estimated_error':float(error),
            'method':'Analytic population moments, separately verified by real-axis integration or discrete PMF summation', 'explanation':'S=X_1+X_2+X_3 is N(0,3). Its characteristic function gives E[Y]=3*exp(-3/2).',
            'error_interpretation':'Analytic values use floating-point arithmetic. Nonzero numerical error is a convergence diagnostic, not a rigorous uniform bound.'}
