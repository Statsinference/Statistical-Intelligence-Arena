"""Population functional, independent of generated observations. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss

def truth(config):
    c=config
    error=0.0
    value=c['x_rate']*c['response_multiplier']
    return {'value':float(value),'estimated_error':float(error),
            'method':'Analytic population moments, separately verified by real-axis integration or discrete PMF summation', 'explanation':'Iterated expectation gives E[Y]=10*E[X_1]=100. Total variance is 10*10+10^2*10=1100. Independent verification sums the Poisson mass via a recurrence with a bounded residual tail.',
            'error_interpretation':'Analytic values use floating-point arithmetic. Nonzero numerical error is a convergence diagnostic, not a rigorous uniform bound.'}
