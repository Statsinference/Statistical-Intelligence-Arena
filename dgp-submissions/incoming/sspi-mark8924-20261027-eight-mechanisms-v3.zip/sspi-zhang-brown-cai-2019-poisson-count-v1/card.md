# Poisson response driven by an observed Poisson count

Status: locally prepared contribution; scientific acceptance and named independent-person replication are pending.
Contributor: 马铭远 (Mark8924). Task: SSPI (T05/T06).

## Source and exact reconstruction

Zhang, A., Brown, L. D. and Cai, T. T. (2019). Semi-supervised inference: General theory and estimation of means. The Annals of Statistics 47(5), 2538-2566. DOI: https://doi.org/10.1214/18-AOS1756.
Reading version: Final journal PDF from coauthor T. Tony Cai; arXiv v2 is not used as the governing source.
Download: https://tony-cai.com/assets/pdf/papers/Semisupervised-Means.pdf
SHA-256: `8b39c34f2435f5c7fbca700f2c959d3c9756d22121bd808db404ad6718f915dc`.
Mechanism locator: **Section 4, Setting 3, unnumbered Poisson equations and Table 1, PDF p. 17 / journal p. 2554; sampling equations (1.1)-(1.2), PDF p. 2 / journal p. 2539**. These model equations are unnumbered in the source.
Sampling/target locator: Section 1, equations (1.1)-(1.2), PDF p. 2 / journal p. 2539; Section 4, Table 1, PDF p. 17 / journal p. 2554.

- X_j are independent Poisson(10), j=1,...,10.
- Y|X~Poisson(10*X_1), independently across units; no added Gaussian noise.
- Use the p=10 rows of Table 1: n_labeled in {100,500}, m_unlabeled in {100,1000,10000}.
- Independent units from the same population in labeled and unlabeled samples. R=1 on the first n_labeled rows and R=0 on the rest, fixed by design independently of values. Y_obs=Y when R=1 and zero placeholder when R=0.

Every variance, coefficient, distribution, and source allocation is transcribed in config.json and the equations above. The generator creates covariates first, then only the labeled outcomes using an independent RNG stream. There are no causal interventions. `source_audit.json` maps these components back to the paper. No author software was relied on, so there is no invented code commit.

## Observation contract and target

Population mean of Y in the common labeled/unlabeled population.

`generate(config,n,seed)` takes the selected scenario object. Its n is the **total combined row count**. At n=source_n_labeled+source_n_unlabeled, the paper allocation is reproduced exactly. At other n, the integer formula in collection.json preserves the ratio approximately and leaves both groups nonempty. The first L rows have R=1; the rest have R=0. Ordering is a representation choice and conveys only sample membership. All X columns are observed. Y_obs on R=0 rows is a **zero placeholder**, never a true zero response; downstream fitting and evaluation must mask by R. Hidden Y, latent Gaussian Z in the lognormal case, noise, regression function and oracle truth are not exported. Independent MCAR samples are assumed, not outcome-dependent selection or distribution shift.

The DGP supplies **no fitted predictor**. PFN or classical predictors, if later used, must be trained only on permitted labeled data; cross-fitting, validation splits and external-predictor provenance belong to the later method stage. Never use this truth routine or the complete data law as method inputs.

## Source scenarios and population truth

| Scenario | Source labeled n | Source unlabeled m | Population truth | Numerical error diagnostic |
|---|---:|---:|---:|---:|
| original_n100_m100 | 100 | 100 | 100 | 0 |
| original_n100_m1000 | 100 | 1000 | 100 | 0 |
| original_n100_m10000 | 100 | 10000 | 100 | 0 |
| original_n500_m100 | 500 | 100 | 100 | 0 |
| original_n500_m1000 | 500 | 1000 | 100 | 0 |
| original_n500_m10000 | 500 | 10000 | 100 | 0 |

Iterated expectation gives E[Y]=10*E[X_1]=100. Total variance is 10*10+10^2*10=1100. Independent verification sums the Poisson mass via a recurrence with a bounded residual tail.

`truth.py` uses population calculations, not Monte Carlo over generated observations. `verify.py` uses separate real-axis Simpson integration or a discrete probability-mass recurrence, plus hand-evaluated response fixtures, source constants, finite observed-only schema and mask checks. For Gaussian integrals the real-axis cutoff is 12 standard deviations. Analytic special cases include zero/noise symmetry, product/shift identities, or one-coordinate polynomial evaluations as appropriate. Both routines share the documented equations and configuration; they do **not** constitute a second person's reproduction. The lognormal error field is an observed quadrature convergence estimate, not a proof of uniform numerical accuracy. Declared comparison tolerance is 1e-9.

## Diversity and limitations

Discrete covariates and conditionally Poisson, heteroskedastic outcomes; the conditional mean is linear. Extra nine covariates do not increase active dimension. Six sample allocations remain ONE mechanism.

Eight contributed mechanisms are distinguished by functional structure and data law, not by seeds or sample sizes. This package implements only its declared scenarios, not every simulation in the article. It does not reproduce estimator tables, confidence-interval coverage, PFN performance or training.

## Explicit adaptations and implementation choices

1. Represent the two independent samples as one numeric table with mandatory R and zero placeholder Y_obs; n in generate is total rows, unlike the source n which denotes labeled rows. No hidden labels are returned.
2. For source totals the labeled/unlabeled sizes are exact. Other requested n values use nearest-integer proportional allocation, clamped to keep both groups nonempty. Such smaller smoke samples are interface checks, not a reproduction of paper performance.
3. Original NumPy PCG64 implementation; source random-number streams and estimator fitting are not reproduced. No pretrained/external predictor is supplied; later predictors must use observed labels with their own training/evaluation separation.
4. Collect p=10 and all six finite (n,m) combinations shown for that dimension in Table 1; the ideal m=infinity method and other dimensions are outside this contribution.
5. Source consistency flag: the printed Setting 3 law gives E[Y]=100 and Var(Y)=E[10*X1]+Var(10*X1)=1100, hence sample-mean MSE=1100/n. At p=10, Table 1 reports 98.337 for n=100 and 20.062 for n=500, whereas the formula implies 11 and 2.2. The cause is unresolved; this contribution implements the explicit probability law, does not modify parameters to match that table, and does not claim to reproduce the reported estimator losses. Scientific review should confirm this source interpretation.

## Reproduce and inspect

Requires Python >=3.11 and the pinned NumPy version. From the student toolkit root, replace CONTRIBUTION with this extracted directory:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTSIDE_CONTRIBUTION.zip
```

Run all scenarios; editing any source/config/card requires rerunning check and repacking. Check evidence is in checks/report.json. Do not fit on Y_obs without R. A small-n check only validates implementation; it is not a benchmark run at the source sample size.

For the additional reproducible audit, run `python audit.py` inside this contribution directory. It prints JSON and does not write files or use the network. `extra_validation.json` records its actual run: original source sample counts, a fixed-seed distribution diagnostic, scalar-versus-vectorized equation checks, boundary cases and checks that the generator leaves global RNG state untouched. These are finite computational tests, not a general distribution proof.

## Rights and assistance

Source article copyright remains with its rights holders. PDFs/figures/author code are not redistributed. Equations are independently implemented; contributed original code is Apache-2.0, matching the destination repository. No real individual records are used.

AI assistance: Codex extracted sources, implemented equations, derived/checks truth and performed computational self-review for Mark8924. A human scientific reviewer has not signed off. No approval, acceptance, authorship allocation or independent-human replication is asserted. The paper PDFs stay outside the ZIP. Reviewers should confirm the source interpretation, scalar target, assumptions and all adaptations. The currently deployed six-category registry may put this correctly labeled semi_supervised contribution in Needs classification until maintained.
