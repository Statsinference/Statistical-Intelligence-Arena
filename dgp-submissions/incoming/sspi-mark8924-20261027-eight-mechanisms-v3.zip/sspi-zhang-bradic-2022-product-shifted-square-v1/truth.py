"""Population functional, independent of generated observations. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss

def truth(config):
    c=config
    error=0.0
    value=c['quadratic_scale']*(1+c['shift']**2)
    return {'value':float(value),'estimated_error':float(error),
            'method':'Analytic population moments, separately verified by real-axis integration or discrete PMF summation', 'explanation':'Independence yields E[X_1 X_2]=0; E[(X_3+0.5)^2]=1.25, so E[Y]=0.625.',
            'error_interpretation':'Analytic values use floating-point arithmetic. Nonzero numerical error is a convergence diagnostic, not a rigorous uniform bound.'}
