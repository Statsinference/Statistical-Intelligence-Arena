"""Population functional, independent of generated observations. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss

def truth(config):
    c=config
    error=0.0
    variance=1-1/(2*c['source_p'])
    def integrate(order):
        nodes,weights=hermgauss(order)
        softplus=np.logaddexp(0,np.sqrt(2*variance)*nodes)
        return 3*float(weights@(softplus**2))/math.sqrt(math.pi)+3*c['offset_per_coordinate']
    low,value=integrate(96),integrate(192)
    error=abs(low-value)+1e-13
    return {'value':float(value),'estimated_error':float(error),
            'method':'Gauss-Hermite 96/192 with independent Simpson verification', 'explanation':'Let v=1-1/(2*101). By linearity of expectation, E[Y]=3*E[log(1+exp(sqrt(v)*G))^2]+0.3 for G~N(0,1). Cross-coordinate correlation does not change this additive marginal expectation. Gauss-Hermite 96/192 estimates convergence; independent Simpson integration checks it.',
            'error_interpretation':'Analytic values use floating-point arithmetic. Nonzero numerical error is a convergence diagnostic, not a rigorous uniform bound.'}
