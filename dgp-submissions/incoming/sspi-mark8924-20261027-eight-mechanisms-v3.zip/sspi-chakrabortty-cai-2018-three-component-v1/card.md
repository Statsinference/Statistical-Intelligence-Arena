# Truncated-Gaussian three-component interaction regression intercept

Status: locally prepared contribution; scientific acceptance and named independent-person replication are pending.
Contributor: 马铭远 (Mark8924). Task: SSPI (T05/T06).

## Source and exact reconstruction

Chakrabortty, A. and Cai, T. (2018). Efficient and adaptive linear regression in semi-supervised settings. The Annals of Statistics 46(4), 1541-1572. DOI: https://doi.org/10.1214/17-AOS1594.
Reading version: Final journal PDF from author; author-posted combined supplement inspected separately.
Download: https://faculty.wharton.upenn.edu/wp-content/uploads/2018/10/Chakrabortty-AOS1594.pdf
SHA-256: `27b7937eb9f22c9722807029fd67579a2ed21a6d66d83f6fb6c3ce1ed0b940b4`.
Mechanism locator: **Section 6.1, model (iv) NL3C and coefficient definitions, PDF p. 19 / journal p. 1559; sample sizes PDF p. 18 / journal p. 1558; Definition 2.1, PDF p. 6 / journal p. 1546**. These model equations are unnumbered in the source.
Sampling/target locator: Section 2 and Assumption 2.1, PDF pp. 4-5 / journal pp. 1544-1545; Definition 2.1, PDF p. 6 / journal p. 1546; Section 6.1, PDF pp. 18-19 / journal pp. 1558-1559.

- d=p=10; X follows independent standard normal coordinates conditioned on -5<=X_j<=5 (rejection, not clipping).
- b=(1,1,1,1,1,0,0,0,0,0) or b=(1,...,1); delta=(0,0,0,0,0,1,1,1,1,1); omega=(1,0,1,0,1,0,1,0,1,0).
- Y=(X^T b)*(1+X^T delta)+(X^T omega)^2+epsilon; epsilon~N(0,1) independent of X.
- Independent units from the same population in labeled and unlabeled samples. R=1 on the first n_labeled rows and R=0 on the rest, fixed by design independently of values. Y_obs=Y when R=1 and zero placeholder when R=0.

Every variance, coefficient, distribution, and source allocation is transcribed in config.json and the equations above. The generator creates covariates first, then only the labeled outcomes using an independent RNG stream. There are no causal interventions. `source_audit.json` maps these components back to the paper. No author software was relied on, so there is no invented code commit.

## Observation contract and target

Population mean of Y in the common labeled/unlabeled population. Equivalently the intercept of the population least-squares projection with an intercept and all X coordinates.

`generate(config,n,seed)` takes the selected scenario object. Its n is the **total combined row count**. At n=source_n_labeled+source_n_unlabeled, the paper allocation is reproduced exactly. At other n, the integer formula in collection.json preserves the ratio approximately and leaves both groups nonempty. The first L rows have R=1; the rest have R=0. Ordering is a representation choice and conveys only sample membership. All X columns are observed. Y_obs on R=0 rows is a **zero placeholder**, never a true zero response; downstream fitting and evaluation must mask by R. Hidden Y, latent Gaussian Z in the lognormal case, noise, regression function and oracle truth are not exported. Independent MCAR samples are assumed, not outcome-dependent selection or distribution shift.

The DGP supplies **no fitted predictor**. PFN or classical predictors, if later used, must be trained only on permitted labeled data; cross-fitting, validation splits and external-predictor provenance belong to the later method stage. Never use this truth routine or the complete data law as method inputs.

## Source scenarios and population truth

| Scenario | Source labeled n | Source unlabeled m | Population truth | Numerical error diagnostic |
|---|---:|---:|---:|---:|
| original_p10_sparse | 500 | 10000 | 4.99992566398 | 0 |
| original_p10_dense | 500 | 10000 | 9.99985132796 | 0 |

For a=5, v=1-2*a*phi(a)/(2*Phi(a)-1). E[Y]=v*(b^T delta+||omega||^2), equal to 5*v (sparse b) or 10*v (dense b). E[X]=0 makes this the population projection intercept; third moments vanish so slopes equal b.

`truth.py` uses population calculations, not Monte Carlo over generated observations. `verify.py` uses separate real-axis Simpson integration or a discrete probability-mass recurrence, plus hand-evaluated response fixtures, source constants, finite observed-only schema and mask checks. For Gaussian integrals the real-axis cutoff is 12 standard deviations. Analytic special cases include zero/noise symmetry, product/shift identities, or one-coordinate polynomial evaluations as appropriate. Both routines share the documented equations and configuration; they do **not** constitute a second person's reproduction. The lognormal error field is an observed quadrature convergence estimate, not a proof of uniform numerical accuracy. Declared comparison tolerance is 1e-9.

## Diversity and limitations

Three different indices with multiplicative cross-block interactions and an additional squared index; not a coefficient variant of NL1C. All ten coordinates affect Y.

Eight contributed mechanisms are distinguished by functional structure and data law, not by seeds or sample sizes. This package implements only its declared scenarios, not every simulation in the article. It does not reproduce estimator tables, confidence-interval coverage, PFN performance or training.

## Explicit adaptations and implementation choices

1. Represent the two independent samples as one numeric table with mandatory R and zero placeholder Y_obs; n in generate is total rows, unlike the source n which denotes labeled rows. No hidden labels are returned.
2. For source totals the labeled/unlabeled sizes are exact. Other requested n values use nearest-integer proportional allocation, clamped to keep both groups nonempty. Such smaller smoke samples are interface checks, not a reproduction of paper performance.
3. Original NumPy PCG64 implementation; source random-number streams and estimator fitting are not reproduced. No pretrained/external predictor is supplied; later predictors must use observed labels with their own training/evaluation separation.
4. Select the scalar intercept of the source population linear projection (Definition 2.1). It equals E[Y] here because E[X]=0. The complete coefficient vector and its coverage are not evaluated.
5. Make the paper phrase restricted to [-5,5]^p explicit as conditional truncation using rejection sampling, not winsorization/clipping. The paper gives no sampling implementation; this boundary convention is transparent and awaits reviewer confirmation. No source code was copied.
6. Collect only the p=10 main-text designs; p=20 and the distinct p=2 supplementary designs are outside this contribution.

## Reproduce and inspect

Requires Python >=3.11 and the pinned NumPy version. From the student toolkit root, replace CONTRIBUTION with this extracted directory:

```sh
python -m pip install -r CONTRIBUTION/requirements.txt
python collect.py check CONTRIBUTION --run --n 128 --seed 1729
python collect.py pack CONTRIBUTION --out OUTSIDE_CONTRIBUTION.zip
```

Run all scenarios; editing any source/config/card requires rerunning check and repacking. Check evidence is in checks/report.json. Do not fit on Y_obs without R. A small-n check only validates implementation; it is not a benchmark run at the source sample size.

For the additional reproducible audit, run `python audit.py` inside this contribution directory. It prints JSON and does not write files or use the network. `extra_validation.json` records its actual run: original source sample counts, a fixed-seed distribution diagnostic, scalar-versus-vectorized equation checks, boundary cases and checks that the generator leaves global RNG state untouched. These are finite computational tests, not a general distribution proof.

## Rights and assistance

Source article copyright remains with its rights holders. PDFs/figures/author code are not redistributed. Equations are independently implemented; contributed original code is Apache-2.0, matching the destination repository. No real individual records are used.

AI assistance: Codex extracted sources, implemented equations, derived/checks truth and performed computational self-review for Mark8924. A human scientific reviewer has not signed off. No approval, acceptance, authorship allocation or independent-human replication is asserted. The paper PDFs stay outside the ZIP. Reviewers should confirm the source interpretation, scalar target, assumptions and all adaptations. The currently deployed six-category registry may put this correctly labeled semi_supervised contribution in Needs classification until maintained.
