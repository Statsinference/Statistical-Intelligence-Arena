"""Population functional, independent of generated observations. SPDX-License-Identifier: Apache-2.0."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss

def truth(config):
    c=config
    error=0.0
    a=c['truncation_bound']
    v=1-2*a*math.exp(-a*a/2)/math.sqrt(2*math.pi)/math.erf(a/math.sqrt(2))
    overlap=c['dimension']//2 if c['coefficient_pattern']=='dense' else 0
    value=v*(overlap+(c['dimension']+1)//2)
    return {'value':float(value),'estimated_error':float(error),
            'method':'Analytic population moments, separately verified by real-axis integration or discrete PMF summation', 'explanation':'For a=5, v=1-2*a*phi(a)/(2*Phi(a)-1). E[Y]=v*(b^T delta+||omega||^2), equal to 5*v (sparse b) or 10*v (dense b). E[X]=0 makes this the population projection intercept; third moments vanish so slopes equal b.',
            'error_interpretation':'Analytic values use floating-point arithmetic. Nonzero numerical error is a convergence diagnostic, not a rigorous uniform bound.'}
