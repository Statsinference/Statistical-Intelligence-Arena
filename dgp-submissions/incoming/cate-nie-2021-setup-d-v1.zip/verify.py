"""Independent re-derivation and structural identities for the CATE target.

Independent route: the surface below is typed a second time from the source
equations (closed form in truth.py vs explicit steps here), then checked against
the realised outcome column of generator.py.  Both routes share the same declared
mechanism, so this is NOT an independent-person reproduction.
"""
import importlib.util
import math
from pathlib import Path

QUERY_POINTS = {
    "primary": {
        "X1": 0.5,
        "X2": 0.5,
        "X3": 0.5,
        "X4": 0.0,
        "X5": 0.0
    },
    "secondary": {
        "X1": 0.2,
        "X2": 0.2,
        "X3": 0.2,
        "X4": 0.1,
        "X5": 0.0
    }
}


def _module(name):
    path = Path(__file__).with_name(name)
    spec = importlib.util.spec_from_file_location("cate_check_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def tau_independent(x):
    """Second, explicitly typed implementation of the declared CATE surface."""
    upper = x["X1"] + x["X2"] + x["X3"]
    lower = x["X4"] + x["X5"]
    return (upper if upper > 0.0 else 0.0) - (lower if lower > 0.0 else 0.0)


def verify(config):
    oracle = _module("truth.py")
    data = _module("generator.py")
    scale = float(config["tau_scale"])

    truth_value = oracle.truth(config)["value"]
    x0 = QUERY_POINTS["primary"]
    x1 = QUERY_POINTS["secondary"]
    direct0, direct1 = oracle.tau_at(x0) * scale, oracle.tau_at(x1) * scale
    interp0, interp1 = tau_independent(x0) * scale, tau_independent(x1) * scale

    null = dict(config, tau_scale=0.0)
    scaled = dict(config, tau_scale=2.5)
    noisy = dict(config, noise_scale=3.0)

    n = 20000
    base = data.generate(dict(config, tau_scale=1.0), n, 2026)
    flat = data.generate(dict(config, tau_scale=0.0), n, 2026)
    arm1 = [i for i, a in enumerate(base["A"]) if a == 1]
    arm0 = [i for i, a in enumerate(base["A"]) if a == 0]

    def contrast(table):
        y1 = sum(table["Y"][i] for i in arm1) / len(arm1)
        y0 = sum(table["Y"][i] for i in arm0) / len(arm0)
        return y1 - y0

    # Same seed => identical covariates, treatment and noise in both runs, so the
    # shift of the arm contrast equals mean(tau(X) | A = 1) exactly.
    observed_shift = contrast(base) - contrast(flat)
    declared_shift = sum(
        tau_independent({k: base[k][i] for k in base if k != "Y"}) for i in arm1
    ) / len(arm1)

    names = list(base)
    checks = [
        {"name": "closed_form_matches_second_typing_primary",
          "passed": abs(direct0 - interp0) < 1e-9,
          "details": "truth.py {:.12g} vs verify.py {:.12g}".format(direct0, interp0)},
        {"name": "closed_form_matches_second_typing_secondary",
          "passed": abs(direct1 - interp1) < 1e-9,
          "details": "second query point {:.12g} vs {:.12g}".format(direct1, interp1)},
        {"name": "null_heterogeneity_gives_zero",
          "passed": abs(oracle.truth(null)["value"]) < 1e-12,
          "details": "tau_scale = 0 removes the A * tau(X) path, so the CATE is exactly 0"},
        {"name": "truth_scales_linearly_in_declared_parameter",
          "passed": abs(oracle.truth(scaled)["value"] - 2.5 * truth_value) < 1e-9,
          "details": "tau_scale = 2.5 gives 2.5 x {:.12g}".format(truth_value)},
        {"name": "residual_scale_does_not_move_the_estimand",
          "passed": abs(oracle.truth(noisy)["value"] - truth_value) < 1e-12,
          "details": "the target is a contrast of conditional means; residual scale is irrelevant"},
        {"name": "generator_carries_the_declared_surface",
          "passed": abs(observed_shift - declared_shift) < 1e-7,
          "details": "arm-contrast shift {:.12g} vs mean tau over treated rows {:.12g} at n = {}".format(observed_shift, declared_shift, n)},
        {"name": "empirical_overlap_in_generated_sample",
          "passed": len(arm1) >= 0.05 * n and len(arm0) >= 0.05 * n,
          "details": "treated {}, control {} of {}".format(len(arm1), len(arm0), n)},
        {"name": "observed_columns_match_declaration",
          "passed": set(names) == {"X1", "X2", "X3", "X4", "X5", "A", "Y"},
          "details": "generator returns exactly the observed columns declared in schema.csv"},
        {"name": "generated_values_are_finite",
          "passed": all(math.isfinite(v) for v in base["Y"]),
          "details": "all {} outcome values finite".format(n)},
    ]
    return {"passed": all(item["passed"] for item in checks), "checks": checks,
            "shared_components": "Both implementations interpret the same declared mechanism; they differ in code path, not in scientific assumption.",
            "query_points": QUERY_POINTS}
