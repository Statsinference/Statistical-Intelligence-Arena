# Nie–Wager (2021) Setup D: unrelated treatment and control surfaces

**Contribution `cate-nie-2021-setup-d-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `nie-wager-2021-setup-d`

## Source and reconstruction

- Citation: Nie, X. and Wager, S. (2021). Quasi-oracle estimation of heterogeneous treatment effects. Biometrika 108(2), 299-319. DOI: 10.1093/biomet/asaa076.
- Venue / year: Biometrika, 2021
- Link: https://arxiv.org/abs/1712.04912
- **Exact locator**: Section 6.1, arXiv:1712.04912v4 (6 Aug 2020) PDF p.16, unnumbered Setup D paragraph (no equation number in the source): 'e*(Xi) = 1/(1 + e^{-Xi1} + e^{-Xi2}), tau*(Xi) = max{Xi1+Xi2+Xi3, 0} - max{Xi4+Xi5, 0}, and b*(Xi) = (max{Xi1+Xi2+Xi3,0} + max{Xi4+Xi5,0})/2'. The same paragraph continues: 'Here, mu*(0)(X) and mu*(1)(X) are uncorrelated, and so there is no upside to learning them jointly.'
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **X1-X5**: `Xj ~ Normal(0,1) independently, j = 1..5`
2. **Treatment**: `e(X) = 1 / (1 + exp(-X1) + exp(-X2))`
3. **Baseline**: `b(X) = (max{X1+X2+X3, 0} + max{X4+X5, 0}) / 2`
4. **Heterogeneity**: `tau(X) = max{X1+X2+X3, 0} - max{X4+X5, 0}`
5. **Outcome**: `Y = b(X) + (A - 1/2) tau(X) + sigma eps, eps ~ Normal(0,1), sigma = 1`
6. **Arm surfaces**: `mu0(X) = b(X) - tau(X)/2 = max{X4+X5, 0};  mu1(X) = b(X) + tau(X)/2 = max{X1+X2+X3, 0}`

Sampling unit: individual · dependence: independent and identically distributed

Fixed parameters: baseline multiplier 1/2, effect as the rectified difference, noise sigma = 1.

### Adaptations relative to the source

- Dimension fixed at d = 5, the smallest dimension for which Setup D is defined; the source varies d in {6, 12}.
- The source writes Y = b(X) + (W - 0.5) tau(X) + sigma eps with W in {0,1}; this package keeps that centred form exactly and writes it as Y = b(X) + (A - 1/2) tau(X) + sigma eps with A in {0,1}. The CATE is unchanged by the rewrite.
- Keeping the centring is essential for this design and is therefore not treated as a cosmetic choice: it is what makes the two arm surfaces disjoint. With it, mu0(X) = b - tau/2 = max{X4+X5,0} and mu1(X) = b + tau/2 = max{X1+X2+X3,0}, so each arm depends on its own coordinate block only. A plain Y = b(X) + A tau(X) would leave both arms carrying b(X) and would destroy the unrelated-arms property that Setup D exists to test.
- sigma fixed at 1.

## Target and identification

- Symbol: `tau(x0) = E[Y(1) - Y(0) | X = x0]`
- Definition: Conditional average treatment effect at the declared query points; a difference of two rectified sums supported on disjoint coordinate blocks.
- Query points (part of the estimand): `primary`: (X1 = 0.5, X2 = 0.5, X3 = 0.5, X4 = 0.0, X5 = 0.0); `secondary`: (X1 = 0.2, X2 = 0.2, X3 = 0.2, X4 = 0.1, X5 = 0.0)

Identification assumptions:

- SUTVA: one version of treatment, no interference
- Unconfoundedness: treatment depends on X1, X2 through a sum of exponentials; the baseline uses all five coordinates, so confounding is strong
- Overlap: e(x) in (0, 1/3] because the denominator is at least 1 + 2 exp(min(-x1,-x2)) > 1; the design leans towards control
- Homoscedastic Gaussian noise with sigma = 1

Setup D is the 'unrelated arms' regime: mu(0) and mu(1) share no structure, so pooling information across arms actively hurts. This property only holds under the centred parameterisation; it is the reason the centring is preserved here rather than replaced by A tau. The effect surface is piecewise linear with two kinks, which is a useful stress test for smooth CATE estimators.

## Truth and independent verification

With the centred parameterisation, mu0(x) = b(x) - tau(x)/2 = max{x4+x5,0} and mu1(x) = b(x) + tau(x)/2 = max{x1+x2+x3,0}, so E[Y|A=1,X=x] - E[Y|A=0,X=x] = tau(x) = max{x1+x2+x3,0} - max{x4+x5,0}. At (0.5,0.5,0.5,0,0) this is 1.5 - 0 = 1.5.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and then checks the centred parameterisation
arm by arm at identical seed: the treated rows must shift by +tau/2 and the control
rows by -tau/2 when the heterogeneity is switched on. A plain A*tau form would leave
the control-arm shift at zero and fail this check. Both routes share the declared
mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 5 (effective 5) · high dimensional: False · interactions: True · nonlinear: True
- Gaussian covariates put mass on both sides of both kinks, so the design genuinely exercises non-differentiable structure rather than a nearly-linear region. Positivity holds but the propensity never exceeds 1/3, so the treated group is a minority by construction.

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| X1 | covariate | float | · | · | true |
| X2 | covariate | float | · | · | true |
| X3 | covariate | float | · | · | true |
| X4 | covariate | float | · | · | true |
| X5 | covariate | float | · | · | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by Oxford University Press for Biometrika. No PDF or author code is redistributed.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: d fixed at 5, sigma fixed at 1.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
