"""Population CATE at the declared query points.

The target is never estimated from generated rows: it is evaluated from the
declared mechanism.  The query points are part of the estimand definition and are
repeated in card.md and collection.json.
"""
import math

QUERY_POINTS = {
    "primary": {
        "X1": 0.5,
        "X2": 0.5,
        "X3": 0.5,
        "X4": 0.0,
        "X5": 0.0
    },
    "secondary": {
        "X1": 0.2,
        "X2": 0.2,
        "X3": 0.2,
        "X4": 0.1,
        "X5": 0.0
    }
}


def tau_at(x):
    """CATE surface of the mechanism, evaluated at one query point."""
    return (
        (max(x["X1"] + x["X2"] + x["X3"], 0.0) - max(x["X4"] + x["X5"], 0.0))
    )


def truth(config):
    scale = float(config["tau_scale"])
    primary = tau_at(QUERY_POINTS["primary"]) * scale
    secondary = tau_at(QUERY_POINTS["secondary"]) * scale
    return {
        "value": primary,
        "estimated_error": 1e-12,
        "method": "Closed form: tau(x0) is a difference of two rectified sums, evaluated exactly; the second typing implements the rectifier by branching instead of max(). Checked end-to-end, including the arm-wise identities that the centred parameterisation implies: the treated arm must move by +tau/2 and the control arm by -tau/2 when tau is switched on.",
        "target": "tau(x0) at QUERY_POINTS['primary'], evaluated from the declared mechanism",
        "value_at_secondary_query": secondary,
        "scale_used": scale,
    }
