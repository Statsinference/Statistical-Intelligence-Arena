"""Scalar conditional quantile/CDF oracle, with no fitted-model information."""
import math
from statistics import NormalDist
from generator import validate_config


def truth(config):
    validate_config(config)
    x = config['query_x']
    mean = 3.0*x
    scale = 0.5 + 2.0*x + math.sin(2.0*math.pi*x - 0.5)
    if config['target'] == 'conditional_quantile':
        value = mean + scale*NormalDist().inv_cdf(config['tau'])
        method = 'Q(tau|x)=3*x+g(x)*Phi_inverse(tau); statistics.NormalDist.'
    else:
        z = (config['threshold_y'] - mean) / scale
        value = 0.5*math.erfc(-z/math.sqrt(2.0))
        method = 'F(y|x)=Phi((y-3*x)/g(x)); stable erfc representation.'
    return {'value': value, 'estimated_error': 0.0, 'method': method,
            'error_note': 'Closed form: no quadrature or Monte Carlo error. Floating-point rounding remains; tolerance is 1e-10, not an exact-arithmetic claim.'}
