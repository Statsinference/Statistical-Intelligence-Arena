"""Bondell--Reich--Wang (2010), section 4.2, Example 5, equation (9).

g multiplies a standard normal error, so g is the standard deviation, not
the variance. Only observed X and Y are returned. Query parameters do not
change the data law or the random-number stream.
"""
import math
import random

SOURCE_TAUS = (0.1, 0.3, 0.5, 0.7, 0.9)


def validate_config(config):
    if not isinstance(config, dict):
        raise ValueError('config must be a scenario parameter object.')
    target = config.get('target')
    if target not in ('conditional_quantile', 'conditional_cdf'):
        raise ValueError('target must be conditional_quantile or conditional_cdf.')
    query_key = 'tau' if target == 'conditional_quantile' else 'threshold_y'
    if set(config) != {'target', 'query_x', query_key}:
        raise ValueError('Unexpected or missing query parameters.')
    for key in ('query_x', query_key):
        value = config[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(key + ' must be a finite number.')
    if not 0 <= config['query_x'] <= 1:
        raise ValueError('query_x must lie in [0,1].')
    if target == 'conditional_quantile' and config['tau'] not in SOURCE_TAUS:
        raise ValueError('tau must be one of the five source nonparametric levels.')


def noise_scale(x):
    return 0.5 + 2.0*x + math.sin(2.0*math.pi*x - 0.5)


def generate(config, n, seed):
    """Generate IID observed pairs with an explicit independent product design."""
    validate_config(config)
    if isinstance(n, bool) or not isinstance(n, int) or n < 1:
        raise ValueError('n must be a positive integer.')
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError('seed must be an integer.')
    rng = random.Random(seed)
    x_values = [rng.random() for _ in range(n)]
    errors = [rng.gauss(0.0, 1.0) for _ in range(n)]
    outcomes = [3.0*x + noise_scale(x)*e for x, e in zip(x_values, errors)]
    return {'X': x_values, 'Y': outcomes}
