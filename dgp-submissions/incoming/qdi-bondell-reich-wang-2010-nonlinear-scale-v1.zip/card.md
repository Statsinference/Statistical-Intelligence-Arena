# QDI：Bondell–Reich–Wang（2010）非线性尺度机制

ID：`qdi-bondell-reich-wang-2010-nonlinear-scale-v1`；family：`quantile_distribution`。
本贡献是一套 Example 5 数据生成机制，含 24 个标量查询场景：15 个条件分位数、9 个条件 CDF。没有复制成 24 个 DGP。

## 来源核对与认领信息

Bondell, H. D., Reich, B. J. & Wang, H. (2010). *Noncrossing quantile regression curve estimation*.
Biometrika **97(4)**, 825–838. [DOI](https://doi.org/10.1093/biomet/asq048)。
期刊、卷期、页码、作者已与出版社页面及 Crossref 核对。
直接阅读的是[公开作者稿](https://bpb-ap-se2.wpmucdn.com/blogs.unimelb.edu.au/dist/d/296/files/2018/02/noCross-26c5pn3.pdf)，PDF 第 9 页已渲染核对。

| 核对项 | 作者稿定位与本贡献处理 |
|---|---|
| 生成方程 | §4.2，式 (9)，PDF/印刷第 9 页，行 387–389 |
| X、噪声、n | 同页行 390–391：U(0,1)、N(0,1)、n=100 |
| f 与 g | 同页 Example 5，行 396–397 |
| 分位水平与重复次数 | 同页行 403–407：0.1、0.3、0.5、0.7、0.9；500 次 |
| 本轮目标 | 固定 x 的条件分位数；新增条件 CDF 查询，均为标量 |
| 抽样单位与条件 | 完全观测的 (X,Y)；本实现明确采用 IID、X 与噪声独立 |
| 真值 | 条件正态解析式；Decimal 级数与反演另路核验 |

作者稿没有明确的修订日期，首页卷期/页码为占位符，版权行写 2007；这些不是最终出版信息。这里引用经过核对的 2010 年正式条目，页码定位仅指作者稿；未声称已取得或逐页比对最终出版社 PDF。下载文件的 SHA-256 保存在 `source_audit.json`，PDF 不随 ZIP 分发。

## 原文机制与方差记号

\[
X_i\sim U(0,1),\quad \varepsilon_i\sim N(0,1),\quad
Y_i=3X_i+g(X_i)\varepsilon_i,
\qquad g(x)=0.5+2x+\sin(2\pi x-0.5).
\]

本实现取不同个体独立、X 与 epsilon 独立。原段落给了边际分布，没有另列联合抽样算法；产品分布实现已在 adaptations 中说明。
文字称 g 为“variance function”，但式 (9) 中它直接乘标准正态噪声，因此 **条件标准差是 g(x)，条件方差是 g(x)²**。不能改成 sqrt(g(x))。
g 在 [0,1] 上严格为正；检查端点及全部驻点后，最小值位于 0，约为 0.02057446。

只有一个有效协变量，维度为 1；中位数为线性函数 3x，非中位数曲线因正弦尺度项而弯曲。异方差来自 g(x)²；无多变量交互、无无关变量，也不宣称重尾或条件偏态。
只生成观察列 X、Y，不输出 epsilon、真实条件尺度或分位数标签。

## 统计目标与 24 个查询

\[
Q(\tau\mid x_0)=3x_0+g(x_0)\Phi^{-1}(\tau),\qquad
F(y_0\mid x_0)=\Phi\!\left(\frac{y_0-3x_0}{g(x_0)}\right).
\]

Phi 是标准正态 CDF。分位数定义为 inf{y:F(y|x0)>=tau}，这里因连续正密度而唯一。目标是总体条件分位数/CDF 的统计区间，不是未来单个响应的预测区间。
连续条件分布版本定义固定 x 的目标；x=0、1 采用从支持集内逼近的单侧极限。

| 场景 | 固定查询 | 来源关系 |
|---|---|---|
| 15 个 quantile | x∈{0,0.5,1} × tau∈{0.1,0.3,0.5,0.7,0.9} | DGP、tau 沿用原文；固定 x 集合是接口适配 |
| 3 个左边界 CDF | x=0，y∈{-0.02,0,0.02} | 本贡献新增功能目标和阈值 |
| 3 个中心 CDF | x=0.5，y∈{0,1.5,3} | 本贡献新增功能目标和阈值 |
| 3 个右边界 CDF | x=1，y∈{1,3,5} | 本贡献新增功能目标和阈值 |

默认 `source_ex5_q90_x_center` 为 Q(0.9|0.5)，高精度参考值见 `source_audit.json`。所有源方程参数固定，不把新噪声分布冒充原文。
`n` 是 generate 的独立输入；原文 n=100，指南检查 n=128。原文 §4.2 明确未使用 0.99，本包也不把它混入原文场景。
原文此节比较分位数曲线估计误差；本轮只为后续 CI 评测提供机制和真值，不重跑 500 次估计器实验，不声称原文报告过本包 CDF 的 coverage。24 个点态 PASS 不代表同时置信带检验。

## 真值与核验

`truth.py` 的分位数用 Python `statistics.NormalDist.inv_cdf`，CDF 用 `erfc`。闭式表达不含 Monte Carlo 或积分误差，`estimated_error=0` 仍保留浮点舍入；预设绝对容差 1e-10。

`verify.py` 在 64 位十进制精度下，用 Taylor 级数计算 sin，用正态密度积分的级数计算 Phi，并以 160 次二分求逆：
\[
\Phi(z)=\tfrac12+\frac{1}{\sqrt{2\pi}}
\sum_{k=0}^{\infty}\frac{(-1)^kz^{2k+1}}{2^k k!(2k+1)}.
\]
这条参考路线不调用 float 真值中的 sin、erfc 或 NormalDist。|z|>=12 时只在核验路线截为 0/1，遗漏尾概率上界小于 1.8e-33；登记场景不依赖该截断。
另验：g 全支持正性、中位数 3x、F(3x|x)=0.5、分位数次序、反函数与对称性；用 Decimal 尺度重建样本，检查 g 与 sqrt(g) 混淆；查询不改变数据、局部 RNG、观察列及非法输入拒绝。
生成器重放共用标准库 RNG；不同计算路径不等同于另一人独立复现。误差数值为实际交叉核对，不冒称对任意参数的形式化误差证明。

## 在学生包中复现

从 **20261027 统计任务扩展版**含 `collect.py` 的根目录运行。贡献本身只用 Python>=3.10 标准库。

```powershell
python -m pip install -r contributions/qdi-bondell-reich-wang-2010-nonlinear-scale-v1/requirements.txt
python collect.py check contributions/qdi-bondell-reich-wang-2010-nonlinear-scale-v1
python collect.py check contributions/qdi-bondell-reich-wang-2010-nonlinear-scale-v1 --run --n 128 --seed 1729
python collect.py pack contributions/qdi-bondell-reich-wang-2010-nonlinear-scale-v1 --out submissions/qdi-bondell-reich-wang-2010-nonlinear-scale-v1.zip
```

检查默认覆盖全部场景。修改源码、配置或卡片后要重检；已有 ZIP 不覆盖，改版需另用文件名。
局部 `random.Random(seed)` 先生成 n 个 X，再生成 n 个标准正态误差；原文 RNG/seed 未知，不宣称重现原文随机样本。查询不进入抽样过程。同 seed 可复现；跨 Python 版本的实际重放结果见包外交付记录，不承诺任意版本位级兼容。
ZIP 根目录直接放八项必需文件，另含 `source_audit.json`、`environment.json`、`checks/` 与 `MANIFEST.json`。
本地 `collect.py submit ZIP --inbox 目录` 仅测试收件，不代表已经发送给维护人。

## 范围、去重与待审核事项

同文 Examples 1–3 的线性结构及 Example 4 的非线性均值结构已列入来源清单，本次只收 Example 5，不宣称收齐全文；分位数和 CDF 不重复计数。已有 GRF 的均值/尺度跳变公式与本机制不同，本地两个 contribution 目录没有发现 asq048/Bondell 条目；全局认领和查重仍待维护人确认。
论文版权归 Biometrika Trust；不随包分发论文、作者代码、敏感数据或权重。代码按引用公式重写，项目发布许可由维护人确定。
AI 协助：OpenAI Codex，2026-10-28，检索、转写、实现与检查；没有代签 human-read、具名审核或人员独立复现。检查 PASS 只表示格式、运行、真值交叉核验和哈希合格，科学接收仍待审核。
本次按用户要求不生成 report；规范卡片和自动检查证据保留。
