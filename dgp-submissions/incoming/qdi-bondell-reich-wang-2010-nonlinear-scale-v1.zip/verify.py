"""Decimal series/inversion independently checks double-precision oracles.

The verification path uses neither math.sin/erfc nor NormalDist to obtain
its reference truth. It shares config validation and random.Random for the
generator replay; this is computational cross-checking, not another person's
independent reproduction.
"""
from decimal import Decimal, localcontext
import math
import random
from generator import generate
from truth import truth

TOLERANCE = 1e-10
PI = Decimal('3.141592653589793238462643383279502884197169399375105820974944592308')
D = Decimal


def decimal_sin(x):
    term = total = x
    for k in range(1, 300):
        term *= -x*x / D((2*k)*(2*k+1))
        total += term
        if abs(term) < D('1e-58'):
            return total
    raise ArithmeticError('Sine series did not converge.')


def decimal_scale(x):
    return D('0.5') + 2*x + decimal_sin(2*PI*x-D('0.5'))


def decimal_cdf(z):
    # Mills bound at |z|>=12 is below 1.8e-33; sufficient for 1e-10 checks.
    if z >= 12:
        return D(1)
    if z <= -12:
        return D(0)
    term = total = z
    for k in range(1, 1000):
        term *= -z*z*D(2*k-1) / D(2*k*(2*k+1))
        total += term
        if abs(term) < D('1e-58'):
            return D('0.5') + total/(2*PI).sqrt()
    raise ArithmeticError('Normal CDF integral series did not converge.')


def decimal_quantile(tau):
    # Source tau in {.1,.3,.5,.7,.9}; all solutions lie in [-6,6].
    left, right = D(-6), D(6)
    for _ in range(160):
        middle = (left+right)/2
        if decimal_cdf(middle) < tau:
            left = middle
        else:
            right = middle
    return (left+right)/2


def decimal_reference(config):
    with localcontext() as ctx:
        ctx.prec = 64
        x = D(str(config['query_x']))
        scale = decimal_scale(x)
        if config['target'] == 'conditional_quantile':
            value = 3*x + scale*decimal_quantile(D(str(config['tau'])))
        else:
            value = decimal_cdf((D(str(config['threshold_y']))-3*x)/scale)
        return value


def quantile_config(x, tau):
    return {'target': 'conditional_quantile', 'query_x': x, 'tau': tau}


def cdf_config(x, y):
    return {'target': 'conditional_cdf', 'query_x': x, 'threshold_y': y}


def verify(config):
    value = truth(config)['value']
    reference = decimal_reference(config)
    error = abs(value-float(reference))
    checks = [{'name': 'decimal_series_and_bisection_truth', 'passed': error <= TOLERANCE,
               'absolute_error': error, 'reference_decimal': str(reference),
               'decimal_precision': 64, 'normal_quantile_bisections': 160,
               'tolerance': TOLERANCE}]

    # These are all derivative-zero candidates of g on [0,1], plus endpoints.
    angle = math.acos(-1/math.pi)
    stationary = [(angle+0.5)/(2*math.pi), (2*math.pi-angle+0.5)/(2*math.pi)]
    with localcontext() as ctx:
        ctx.prec = 64
        scales = [float(decimal_scale(D(str(x)))) for x in [0, 1, *stationary]]
    checks.append({'name': 'positive_scale_on_entire_design_support',
                   'passed': min(scales) > 0.02,
                   'minimum_scale': min(scales), 'minimum_location': 0.0,
                   'argument': 'Evaluate both endpoints and all roots of g_prime(x)=2+2*pi*cos(2*pi*x-.5). The smallest is the left endpoint.'})

    x = config['query_x']
    median_error = abs(truth(quantile_config(x, 0.5))['value']-3*x)
    central_cdf_error = abs(truth(cdf_config(x, 3*x))['value']-0.5)
    checks.append({'name': 'linear_median_and_half_mass_special_cases',
                   'passed': max(median_error, central_cdf_error) <= TOLERANCE,
                   'median_error': median_error, 'cdf_at_median_error': central_cdf_error})

    levels = (0.1, 0.3, 0.5, 0.7, 0.9)
    quantiles = [truth(quantile_config(x, tau))['value'] for tau in levels]
    probabilities = [truth(cdf_config(x, y))['value'] for y in quantiles]
    inverse_error = max(abs(p-t) for p,t in zip(probabilities, levels))
    checks.append({'name': 'quantile_order_and_cdf_inverse',
                   'passed': all(a < b for a,b in zip(quantiles, quantiles[1:]))
                             and inverse_error <= TOLERANCE,
                   'max_inverse_error': inverse_error,
                   'independence_note': 'Consistency check between two special functions; primary independent check is the Decimal path.'})

    symmetry_error = max(abs(quantiles[i]+quantiles[-1-i]-6*x) for i in (0,1))
    checks.append({'name': 'conditional_quantile_symmetry',
                   'passed': symmetry_error <= TOLERANCE, 'max_error': symmetry_error})

    with localcontext() as ctx:
        ctx.prec = 64
        series_cdf_errors = [abs(truth(cdf_config(x, y))['value']-float(decimal_reference(cdf_config(x, y))))
                             for y in quantiles]
    checks.append({'name': 'cdf_series_at_all_five_source_levels',
                   'passed': max(series_cdf_errors) <= TOLERANCE,
                   'max_absolute_error': max(series_cdf_errors)})

    # Reconstruct the observations with Decimal scale, detecting g vs sqrt(g).
    n, seed = 48, 74821
    generated = generate(config, n, seed)
    rng = random.Random(seed)
    reference_x = [rng.random() for _ in range(n)]
    errors = [rng.gauss(0.0, 1.0) for _ in range(n)]
    with localcontext() as ctx:
        ctx.prec = 64
        expected_y = [float(3*D(str(xi))+decimal_scale(D(str(xi)))*D(str(e)))
                      for xi,e in zip(reference_x, errors)]
    replay_error = max(abs(a-b) for a,b in zip(generated['Y'], expected_y))
    checks.append({'name': 'generator_equation_uses_scale_not_square_root',
                   'passed': generated['X'] == reference_x and replay_error <= TOLERANCE,
                   'max_response_error': replay_error, 'n': n,
                   'shared_components': 'The standard-library RNG and its draw order are intentionally shared.'})

    sample_equal = generated == generate(cdf_config(0.25, 1.0), n, seed)
    checks.append({'name': 'query_does_not_change_data_law', 'passed': sample_equal})

    state = random.getstate()
    generate(config, 3, 19)
    checks.append({'name': 'local_rng_and_observed_only_columns',
                   'passed': random.getstate() == state and set(generated) == {'X','Y'}
                             and all(len(v) == n for v in generated.values())
                             and all(0 <= xi <= 1 for xi in generated['X'])})

    invalid = [quantile_config(0.5, 0.99), quantile_config(-0.1, 0.5),
               cdf_config(0.5, float('nan')), {**config, 'noise_sd': 1},
               quantile_config(True, 0.5), {'target': 'marginal_cdf','query_x': 0.5,'threshold_y': 0}]
    rejected = 0
    for candidate in invalid:
        try:
            truth(candidate)
        except ValueError:
            rejected += 1
    for bad_n, bad_seed in [(0, 1), (True, 1), (2, True), (2, 1.5)]:
        try:
            generate(config, bad_n, bad_seed)
        except ValueError:
            rejected += 1
    checks.append({'name': 'reject_unsupported_and_invalid_inputs',
                   'passed': rejected == len(invalid)+4, 'rejected': rejected})
    return {'passed': all(item['passed'] for item in checks), 'checks': checks}
