"""Independent source equations, population integration, and generated-law checks.

No integration implementation is imported from truth.py. See independence limits in card.md.
"""
import importlib.util
import math
from pathlib import Path
import numpy as np

def _load(name):
    spec=importlib.util.spec_from_file_location("local_verify_"+name,Path(__file__).with_name(name+".py"))
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def _sigmoid(v):
    return (1+math.tanh(v/2))/2

def _softplus(v):
    return max(v,0)+math.log1p(math.exp(-abs(v)))

def _simpson(function,lo,hi,steps=8192):
    h=(hi-lo)/steps
    return h/3*math.fsum((1 if j in (0,steps) else 4 if j%2 else 2)*function(lo+j*h) for j in range(steps+1))

def _normal_integral(function,sd=1):
    density=lambda z: math.exp(-z*z/2)/math.sqrt(2*math.pi)
    return _simpson(lambda z:function(sd*z)*density(z),-12,12)

def verify(config):
    generator=_load("generator"); oracle=_load("truth")
    checks=[]
    def add(name,passed,details):
        checks.append({"name":name,"passed":bool(passed),"details":details})
    reference=oracle.truth(config)
    independent=_normal_integral(lambda t:max(t,0),math.sqrt(3))-_normal_integral(lambda t:max(t,0),math.sqrt(2))
    add("population_truth_independent_route",abs(reference["value"]-independent)<1e-9,
        {"oracle":reference["value"],"independent":independent,"absolute_difference":abs(reference["value"]-independent),"route":'Separate positive-part Gaussian density integrals'})
    # Literal source fixture is separate from the NumPy generator implementation.
    anchors=[[0.1, -0.4, 0.2, 0.7, -0.3, 0.2], [-0.6, 0.2, -0.4, 0.1, 0.2, -0.3]]
    for i,row in enumerate(anchors):
        x=np.zeros((1,config["dimension"]))
        x[0,:len(row)]=row
        expected=_source_equations(row)
        actual=generator.components(config,x)
        delta=max(abs(float(actual[k][0])-expected[k]) for k in range(3))
        add("source_equation_anchor_"+str(i),delta<1e-11,{"max_difference":delta,"p_m0_m1":list(expected)})
    # Conditional treatment effect from implemented arms at symmetric integration points.
    qx,qw=_effect_quadrature(config["dimension"])
    _,q0,q1=generator.components(config,qx)
    integrated=float(qw@(q1-q0))
    add("implemented_conditional_contrast_integration",abs(integrated-independent)<2e-8,
        {"integrated_generator_contrast":integrated,"independent_population_truth":independent})
    n=8192 if config["dimension"]>=1000 else 32768
    sample=generator.generate(config,n,59317)
    x=np.column_stack([sample[f"X{j+1}"] for j in range(config["dimension"])])
    a=np.asarray(sample["A"]); y=np.asarray(sample["Y"])
    p,m0,m1=generator.components(config,x)
    residual=y-np.where(a==1,m1,m0)
    assignment_z=float(np.sum(a-p)/math.sqrt(max(float(np.sum(p*(1-p))),1e-30)))
    add("conditional_assignment_calibration",abs(assignment_z)<6,{"z":assignment_z,"n":n,"criterion":"fixed-seed diagnostic, abs(z)<6; not proof of independence"})
    variance=np.full(n,config["noise_sd"]**2)
    residual_mean=float(np.mean(residual)); predicted_mean_sd=math.sqrt(float(np.sum(variance)))/n
    add("noise_mean",abs(residual_mean)<6*predicted_mean_sd,{"mean":residual_mean,"mean_sd":predicted_mean_sd})
    ratio=float(np.mean(residual**2)/np.mean(variance))
    add("noise_second_moment",abs(ratio-1)<.06,{"observed_to_expected_ratio":ratio,"relative_diagnostic_limit":.06})
    add("normal_covariate_moments",np.max(np.abs(x.mean(axis=0)))<.04 and np.max(np.abs(x.var(axis=0)-1))<.05,{"max_mean_error":float(np.max(np.abs(x.mean(axis=0))))})
    add("observed_only",set(sample)=={f"X{j+1}" for j in range(config["dimension"])}|{"A","Y"},"No potential outcomes, oracle propensity or effect labels")
    return {"passed":all(c["passed"] for c in checks),"checks":checks,
            "shared_components":"The paper equations/configuration and NumPy are shared. truth uses separate analytic/quadrature derivation; the verifier implements scalar source equations, separate integration and law diagnostics. This is algorithmic cross-checking by one AI system, not an independent-person reproduction or scientific acceptance."}

def _source_equations(x):
    return 1/(1+math.exp(-x[0])+math.exp(-x[1])),max(x[3]+x[4],0),max(sum(x[:3]),0)

def _effect_quadrature(d):
    u=np.linspace(-12,12,16385); h=u[1]-u[0]
    w=np.ones(u.size); w[1:-1:2]=4; w[2:-1:2]=2
    w*=h/3*np.exp(-u*u/2)/math.sqrt(2*math.pi)
    x=np.zeros((u.size,d)); x[:,0]=math.sqrt(3)*u; x[:,3]=math.sqrt(2)*u
    # Common quadrature variable is valid for an expectation of a difference of marginal functions;
    # it does not assert those two sums are dependent in the actual generator.
    return x,w
