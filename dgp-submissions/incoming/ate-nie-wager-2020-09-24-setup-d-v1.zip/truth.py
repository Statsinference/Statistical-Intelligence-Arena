"""Population ATE; never estimated from the generated observed table."""
import math
import numpy as np

def _result(value, method, error=1e-14):
    return {"value":float(value),"estimated_error":float(error),"method":method,
            "target":"E[Y(1)-Y(0)] over the full declared population",
            "error_interpretation":"Floating-point allowance for analytic identities, or observed quadrature convergence; not a uniform rigorous numerical-error theorem."}

def truth(config):
    return _result((math.sqrt(3)-math.sqrt(2))/math.sqrt(2*math.pi),"Analytic expectations of positive parts of N(0,3) and N(0,2)")
