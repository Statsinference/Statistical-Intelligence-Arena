# Lei–Candès (2021) simulation: zero control outcome with a double-sigmoid effect

**Contribution `cate-lei-2021-conformal-cate-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `lei-candes-2021-double-sigmoid`

## Source and reconstruction

- Citation: Lei, L. and Candes, E. J. (2021). Conformal inference of counterfactuals and individual treatment effects. Journal of the Royal Statistical Society: Series B (Statistical Methodology) 83(5), 911-938. DOI: 10.1111/rssb.12445.
- Venue / year: Journal of the Royal Statistical Society Series B: Statistical Methodology, 2021
- Link: https://arxiv.org/abs/2006.06138
- **Exact locator**: Section 3.6 'Numerical experiments', arXiv:2006.06138v4 PDF p.9 (covariate construction: 'Xj = Phi(X'_j) ... equicorrelated multivariate Gaussian') and PDF p.10 (second and third bullets: 'Y(0) = 0', 'E[Y(1)|X] = f(X1) f(X2), f(x) = 2/(1+exp{-12(x-0.5)})', and 'e(x) = (1/4){1 + beta_{2,4}(x1)}'). The section uses unnumbered bullets, so the locator cites the bullets and page rather than an equation number.
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **X1-X10**: `Xj = Phi(X'_j), X' equicorrelated Gaussian with rho = 0, so Xj ~ Uniform(0,1) independently, j = 1..10`
2. **Treatment**: `e(X) = (1/4) { 1 + F_{2,4}(X1) }, F_{2,4} the Beta(2,4) cdf`
3. **Control outcome**: `Y(0) = 0`
4. **Treated outcome**: `E[Y(1)|X] = f(X1) f(X2), f(u) = 2 / (1 + exp(-12 (u - 1/2)));  Y(1) = E[Y(1)|X] + sigma eps`
5. **Heterogeneity**: `tau(X) = f(X1) f(X2)`
6. **Observed**: `Y = A Y(1) + (1-A) Y(0), sigma = 1`

Sampling unit: individual · dependence: independent and identically distributed at rho = 0

Fixed parameters: sigmoid steepness 12 and centre 1/2 in f; Beta(2,4) cdf in the propensity; sigma^2 = 1; rho = 0 and d = 10 as declared.

### Adaptations relative to the source

- The source uses d = 10 or d = 100 covariates and an equicorrelation rho in {0, 0.9}; this package fixes d = 10 with rho = 0, so the covariates are independent uniforms and X3..X10 are inert.
- Only the homoscedastic scenario sigma^2 = 1 is used; the source also reports sigma^2(x) = -log(x1).
- Phi(Z) with Z standard normal is distributed as Uniform(0,1), so the covariates are drawn directly as uniforms; no numerical normal cdf is needed at rho = 0.
- The source evaluates interval coverage of CATE and ITE; this package only declares the mechanism and its population CATE. No conformal procedure is run.

## Target and identification

- Symbol: `tau(x0) = E[Y(1) - Y(0) | X = x0]`
- Definition: Conditional average treatment effect at the declared query points when the control potential outcome is identically zero, so the effect equals the treated conditional mean.
- Query points (part of the estimand): `primary`: (X1 = 0.5, X2 = 0.5, X3 = 0.5, X4 = 0.5, X5 = 0.5, X6 = 0.5, X7 = 0.5, X8 = 0.5, X9 = 0.5, X10 = 0.5); `secondary`: (X1 = 0.8, X2 = 0.2, X3 = 0.5, X4 = 0.5, X5 = 0.5, X6 = 0.5, X7 = 0.5, X8 = 0.5, X9 = 0.5, X10 = 0.5)

Identification assumptions:

- SUTVA: one version of treatment, no interference
- Unconfoundedness: the propensity depends on X1 only, and Y(1) depends on X1 and X2, so the assignment is confounded
- Overlap: e(X) in [0.25, 0.5] by construction, giving a uniform overlap margin of 0.25
- Homoscedastic Gaussian noise with sigma^2 = 1, added only under treatment because Y(0) = 0

Because Y(0) is identically zero, the CATE coincides with the treated conditional mean, which makes the target unusually easy to interpret but brutal for methods that shrink towards a pooled mean. It is also the design the source uses to compare CATE and ITE coverage.

## Truth and independent verification

Y(0) = 0 and Y(1) = f(X1)f(X2) + eps, so E[Y|A=1,X=x] - E[Y|A=0,X=x] = f(x1)f(x2). At (0.5, 0.5) both factors equal 1, hence tau = 1 exactly. At (0.8, 0.2) the value is 1.946806 x 0.053194 = 0.1035584.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and confirms end-to-end that the realised
outcome column of `generator.py` carries the declared surface (arm-contrast shift
equals the mean of tau over treated rows, at identical seed). Both routes share the
declared mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 10 (effective 2) · high dimensional: False · interactions: True · nonlinear: True
- The propensity lives in [0.25, 0.5], so overlap is uniformly good and the treated arm is a minority; this isolates the effect of an asymmetric arm rather than of weak overlap. The unsupported region is none, but note that a constant-shift model for Y cannot represent Y(0) = 0 and Y(1) = tau simultaneously without the interaction with A.

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| X1 | covariate | float | 0.0 | 1.0 | true |
| X2 | covariate | float | 0.0 | 1.0 | true |
| X3 | covariate | float | 0.0 | 1.0 | true |
| X4 | covariate | float | 0.0 | 1.0 | true |
| X5 | covariate | float | 0.0 | 1.0 | true |
| X6 | covariate | float | 0.0 | 1.0 | true |
| X7 | covariate | float | 0.0 | 1.0 | true |
| X8 | covariate | float | 0.0 | 1.0 | true |
| X9 | covariate | float | 0.0 | 1.0 | true |
| X10 | covariate | float | 0.0 | 1.0 | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by Oxford University Press for the Royal Statistical Society. No PDF or author code is redistributed; equations cited and independently implemented.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: Only the (d, rho, sigma) = (10, 0, 1) cell is implemented; the correlated and heteroscedastic cells are separate scenarios.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
