"""Population CATE at the declared query points.

The target is never estimated from generated rows: it is evaluated from the
declared mechanism.  The query points are part of the estimand definition and are
repeated in card.md and collection.json.
"""
import math

QUERY_POINTS = {
    "primary": {
        "X1": 0.5,
        "X2": 0.5,
        "X3": 0.5,
        "X4": 0.5,
        "X5": 0.5,
        "X6": 0.5,
        "X7": 0.5,
        "X8": 0.5,
        "X9": 0.5,
        "X10": 0.5
    },
    "secondary": {
        "X1": 0.8,
        "X2": 0.2,
        "X3": 0.5,
        "X4": 0.5,
        "X5": 0.5,
        "X6": 0.5,
        "X7": 0.5,
        "X8": 0.5,
        "X9": 0.5,
        "X10": 0.5
    }
}


def tau_at(x):
    """CATE surface of the mechanism, evaluated at one query point."""
    return (
        (2.0 / (1.0 + math.exp(-12.0 * (x["X1"] - 0.5)))) * (2.0 / (1.0 + math.exp(-12.0 * (x["X2"] - 0.5))))
    )


def truth(config):
    scale = float(config["tau_scale"])
    primary = tau_at(QUERY_POINTS["primary"]) * scale
    secondary = tau_at(QUERY_POINTS["secondary"]) * scale
    return {
        "value": primary,
        "estimated_error": 1e-12,
        "method": "Closed form: tau(x0) = f(x1) f(x2) with f a logistic sigmoid, exact up to floating point; cross-checked by a second typing and by the realised outcome column.",
        "target": "tau(x0) at QUERY_POINTS['primary'], evaluated from the declared mechanism",
        "value_at_secondary_query": secondary,
        "scale_used": scale,
    }
