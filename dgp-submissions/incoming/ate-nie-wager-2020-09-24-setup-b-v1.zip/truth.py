"""Population ATE; never estimated from the generated observed table."""
import math
import numpy as np

def _result(value, method, error=1e-14):
    return {"value":float(value),"estimated_error":float(error),"method":method,
            "target":"E[Y(1)-Y(0)] over the full declared population",
            "error_interpretation":"Floating-point allowance for analytic identities, or observed quadrature convergence; not a uniform rigorous numerical-error theorem."}

def truth(config):
    values=[]
    for order in (64,128):
        nodes,weights=np.polynomial.hermite.hermgauss(order)
        values.append(float(weights@np.logaddexp(0,math.sqrt(2)*nodes)/math.sqrt(math.pi)))
    return _result(values[1],"Gauss-Hermite 64/128 for E[softplus(N(0,1))]",abs(values[1]-values[0])+1e-14)
