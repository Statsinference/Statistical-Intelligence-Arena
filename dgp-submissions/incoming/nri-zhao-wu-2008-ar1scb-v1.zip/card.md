# N03 非线性自回归的马尔可夫条件均值

Contribution: `nri-zhao-wu-2008-ar1scb-v1` · `synthetic_dgp` · `nonparametric_regression` · **v1**

## Source and reconstruction

Zhao, Z. and Wu, W. B. (2008). Confidence bands in nonparametric time series regression. The Annals of Statistics 36(4), 1854-1878. DOI: 10.1214/07-AOS533.

[DOI](https://doi.org/10.1214/07-AOS533) · [固定阅读版本 0808.1010v1](https://arxiv.org/pdf/0808.1010v1)

实读 PDF SHA-256：`088fbe116a891909bf3f878e1a190262029c6dfc47ffcc7c0c7388471b0ae6f0`。IMS electronic reprint of the published article; the actual first-page declaration says pagination and typographic detail differ from the original.

Formula bodies: (1.1) on PDF p.2, (5.1) on PDF p.12, (5.2) on PDF p.12. Section starts: Section 5 on PDF p.11, Section 6 on PDF p.13. Unnumbered paragraph on PDF p.11: "In this section" (standard-normal innovations and two structural models). Unnumbered paragraph on PDF p.12: "To assess the performance of our SCB" (Model1 numerical mean, scale, n, replications, evaluation interval). All PDF pages are 1-based pages of the fixed reading file 0808.1010v1. No printed journal page is inferred by adding an offset.

**原文参数逐页登记**

- PDF p.11：innovations epsilon_i iid standard normal; Model1 Y_i=mu(Y_{i-1})+s*epsilon_i; Model2 Y_i=sigma(Y_{i-1})*epsilon_i。
- PDF p.12：mu=.9*sin(x); s=.4; n2500; 10^4 replications; evaluation interval[-1.1,1.1]。

**按实际执行顺序的生成步骤**

1. **Initialization** — Set Y0=0 and burn_in=1000 before collecting the n regression pairs. Implementation choices; not source-specified initialization or burn-in parameters.
2. **Innovation sequence** — epsilon_t iid N(0,1), independent of the past; draw sequentially during recursion. Source standard-normal innovations; noise multiplier s=0.4.
3. **Recursion** — Y_t=0.9*sin(Y_(t-1))+0.4*epsilon_t for burn_in+n updates. Compute source nonlinear mean before adding each independent innovation.
4. **Observation pairs** — Return (X_i,Y_i)=(Y_(burn_in+i-1),Y_(burn_in+i)), i=1..n. Deterministic export in time order; X_(i+1)=Y_i exactly; no innovation column.

**抽样单位与依赖**：time series observation (consecutive pairs of one Markov chain realisation)；Time-homogeneous Markov recursion with finite zero initialization and burn-in 1000; adjacent pairs share X_(i+1)=Y_i; exact stationarity is not asserted.

**边界与尺度**：The process has real-valued support; the paper evaluation interval [-1.1,1.1] is not a truncation of generated observations. Finite burn-in from zero is not an exact stationary initial draw.

**与来源的改动及理由**

1. Keep Model 1 only; Model 2 targets conditional variance rather than the selected mean target.
2. Set Y0=0 and burn-in=1000 as explicit implementation choices, not recovered paper parameters.
3. Keep chronological Markov pairs and add fixed query x0=0.5 or 0.0; run CPU pointwise checks instead of the original band experiment.

固定点目标由已声明条件响应律识别：高斯模型使用零条件均值的误差/随机效应，广义回归直接用指定分布的链接均值。接口 n 和查询为适配；未把 n=128 说成论文原实验样本量。

**版本关系**：The actual fixed reading PDF is an IMS electronic reprint of the published article, not a separate author-preprint draft merely because it is hosted on arXiv. The first-page declaration explicitly notes pagination and typographic differences. We use only verified section/equation/1-based PDF locators and do not claim identical publisher typesetting, exact printed-page offsets or entire-text identity. No separate author-preprint-to-formal substitution is involved for this reading source; that conditional comparison is N/A.

## Target and identification

`mu(x0) = E[Y_i | X_i = x0] = 0.9*sin(x0)`

Pointwise conditional mean of the Markov regression at a single fixed query point x0 inside the source design interval T = [-1.1,1.1]; a scalar quantity, not a simultaneous confidence band and not a coverage probability.

**登记场景与查询**

| Scenario | Parameters / query |
|:--|:--|
| `original-s04`（默认） | `{"mu_scale": 0.9, "noise_sd": 0.4, "burn_in": 1000, "query_x": 0.5}` |
| `interior-anchor` | `{"mu_scale": 0.9, "noise_sd": 0.4, "burn_in": 1000, "query_x": 0.0}` |

场景中的 original-* 表示保留的来源生成参数，不代表新增查询和接口样本量属于原文实验。本包另设 interior-anchor 作为原模型参数下的自选查询；不复制同义场景充数。

**抽样、设计与支持条件**

- Time-homogeneous first-order Markov recursion Y_t=.9*sin(Y_(t-1))+.4*epsilon_t; innovations iid N(0,1) and independent of the past.
- The mean map is globally contractive with Lipschitz constant .9. The process admits an invariant law, but the finite simulation starts at zero; burn-in 1000 does not certify exact stationarity.
- Adjacent exported rows are dependent: X_(i+1)=Y_i. The marginal distribution after finite initialization need not equal the invariant law.
- For every exported time, the new innovation has conditional mean zero. Therefore E[Y_t|Y_(t-1)=x]=.9*sin(x) without an exact-stationarity assumption.
- The positive Gaussian transition density gives support around each fixed query after at least one update.
- No band coverage, finite-sample cutoff, mixing-rate estimate or named human scientific acceptance is established by the diagnostics.

固定点条件均值正确，不等于点态区间或同时置信带覆盖率达标。非因果任务不套用干预/无混杂假设。

## Truth and independent verification

Closed form mu(x0) = a*sin(x0) with a = 0.9, evaluated by standard-library math.sin and cross-checked by a numpy evaluation, a 60-digit Decimal Taylor series and a Gauss-Hermite integration of the innovation law; no rows from generate() are used.

`truth.tolerance=1e-08`。estimated_error 是浮点/数值路线诊断，不是严格统一误差界或统计标准误；其非负且不大于 tolerance。

**不同路线与解析特例**：独立三角函数/高精度 Taylor 求值、64 点 Gauss–Hermite 新息积分、奇对称与原点零锚点；实际相邻对必须满足 X[i+1]=Y[i]。平稳性检查仅是有限样本诊断。

**实际共享函数与独立边界**：verify 调用 truth.truth 作比较，并使用 generator.simulate_chain/generate 取得被测链和相邻对。因此 stationarity_sanity 与 alignment 是共享生成器的诊断，独立的 .9*sin、Taylor/新息积分路线才是数值参照。

外部另按论文公式用 mpmath 70 位重算全部登记查询；另对各场景 generate(n=4096, seed=7312026) 实际观察列独立重构残差，不导入私有均值助手或 verify 作外部参照。N08 的源数学参照取精确 1/sqrt(3)，与配置中最短十进制权重的浮点差计入比较；阈值仍逐包取 tolerance，不靠放宽阈值通过。

## Diversity and scope

`dimension=1`，`effective_dimension=1`。Single scalar covariate X = Y_{i-1}; the regression function mu(x) = 0.9*sin(x) is nonlinear in x. The serial dependence itself comes from the first-order Markov recursion, not from interactions or from extra covariates. No products of covariates are formed. high_dimensional is false: there is exactly one covariate for any sample size.

Only source Model 1 is generated. Model 2 is an ARCH/conditional-variance problem and is outside this contribution. No treatment, label or missingness mechanism is applicable.

处理分配、标注、缺失与真实数据分支均不适用。未执行论文估计器、bootstrap、点态/同时覆盖率、PFN 训练、大规模压力测试或第二人独立人工复现。

## Rights and assistance

Source equations are cited and independently implemented. Paper copyright is not transferred; no paper PDF, author software, original participant data or model weights are redistributed. No external author code was used. The contributor must confirm the release licence for the independently implemented code before publication; pending review is not a grant of rights. AI assisted equation extraction, implementation, numerical checks and drafting; named human scientific review and independent-person reproduction are not claimed.

**未使用作者原始代码或补充材料代码**；因此作者软件 commit 追溯项 N/A。本包依赖以 requirements.txt 为准：标准库或 NumPy 的使用不等于移植作者代码。论文全文、页图、作者软件、权重、数据银行、凭据不随贡献包分发。

**missing / 尚待确认**

- missing(source_initialization): the cited simulation paragraph does not specify Y0 or burn-in; this implementation declares 0/1000. An exact author-simulation replay would need those values and the original random algorithm, but E[Y_t|Y_(t-1)=x] is identified at every t under the declared recursion.
- 本人须审核 AI 协助的来源提取、代码、数值和文本，并确认独立实现代码的发布许可；pending 不是授权。
- 具名科学审核、第二人独立人工复现：未执行。
- GitHub Fork/Sync/SUBMIT DGP/Actions/PR/收录确认：本次未执行。本地 submit 不等于网络提交或项目收件。

**状态**：以最终 checks/report.json 记录本地 runnable_dgp；归档仅 awaiting_scientific_review、scientific_acceptance=false。
