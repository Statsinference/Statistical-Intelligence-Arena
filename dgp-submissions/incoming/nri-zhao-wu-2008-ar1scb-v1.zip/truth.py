"""Conditional mean at a fixed query point; never estimated from generated rows."""
import math


def truth(config):
    for key in ("mu_scale", "query_x"):
        if key not in config:
            raise ValueError("truth requires mu_scale and query_x")
    mu_scale = float(config["mu_scale"])
    x0 = float(config["query_x"])
    value = mu_scale * math.sin(x0)
    if not math.isfinite(value):
        raise ValueError("population value must be finite")
    return {
        "value": value,
        "estimated_error": 1e-12,
        "method": "Closed form mu(x0) = a*sin(x0) evaluated with the standard library math.sin; no simulation or numerical integration enters the reported value.",
        "error_interpretation": "Double-precision round-off of a closed-form expression, not a quadrature or Monte Carlo error bound.",
        "target": "mu(x0) = E[Y_i | X_i = x0]",
        "query_x": x0,
        "reason": "Given X_i = Y_{i-1} = x0 we have Y_i = a*sin(x0) + s*eps_i with eps_i ~ N(0,1) independent of the past, hence E[Y_i|X_i=x0] = a*sin(x0).",
    }
