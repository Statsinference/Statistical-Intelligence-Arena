"""Independent checks: source fixtures, alternative evaluation routes, anchors, Monte Carlo window, burn-in.

Nothing here weakens tolerance; the closed-form target is recomputed by other
machinery and by a vectorised Monte Carlo check of the exported mechanism.
"""
import importlib.util
import math
from pathlib import Path

import numpy as np

SOURCE_FIXTURE = {"mu_scale": 0.9, "noise_sd": 0.4}          # Zhao & Wu (2008) Section 5, Model 1
DECLARED_BURN_IN = 1000                                       # declared implementation choice, not a paper parameter
DESIGN_INTERVAL = (-1.1, 1.1)                                 # paper T used for the SCB construction
MC_SEED = 20260808
MC_LENGTH = 400000
WINDOW_HALF_WIDTH = 0.02
STATIONARITY_WINDOW = 0.05
STATIONARITY_TOL = 0.02


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("zhaowu_ar1_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _sin_taylor(x0, terms=40):
    """High-precision sine from its Taylor series in Decimal: independent of libm."""
    from decimal import Decimal, getcontext
    getcontext().prec = 60
    x = Decimal(repr(float(x0)))
    total = Decimal(0)
    term = x
    for k in range(terms):
        if k:
            term = -term * x * x / Decimal((2 * k) * (2 * k + 1))
        total += term
    bound = Decimal(0) if float(x0) == 0.0 else abs(x) ** (2 * terms + 1) / Decimal(math.factorial(2 * terms + 1))
    return total, float(bound)


def _window_mean(chain, start, length, query_x, half_width):
    x = chain[start:start + length]
    y = chain[start + 1:start + 1 + length]
    mask = np.abs(x - query_x) < half_width
    count = int(mask.sum())
    mean = float(y[mask].mean()) if count else float("nan")
    return mean, count


def verify(config):
    generator = _module("generator.py")
    oracle = _module("truth.py")
    mu_scale = float(config["mu_scale"])
    noise_sd = float(config["noise_sd"])
    query_x = float(config["query_x"])
    reference = oracle.truth(config)

    # Route A: standard-library math.sin (the reported value).
    closed = mu_scale * math.sin(query_x)
    # Route B: numpy scalar sine, different libm entry points.
    numpy_route = float(np.float64(mu_scale) * np.sin(np.float64(query_x)))
    # Route C: 60-digit Taylor series in Decimal, no libm sine at all.
    series, series_bound = _sin_taylor(query_x)
    series_route = float(series) * mu_scale

    # Independent analytic route: integrate the conditional law over the innovation.
    nodes, weights = np.polynomial.hermite.hermgauss(64)
    weights = weights / math.sqrt(math.pi)
    innovation_expectation = float(weights @ (np.sqrt(2.0) * nodes))
    mass = float(weights.sum())
    quadrature_route = mu_scale * math.sin(query_x) + noise_sd * innovation_expectation

    source_mismatch = [key for key, value in SOURCE_FIXTURE.items()
                       if key not in config or abs(float(config[key]) - value) > 1e-12]
    in_design = DESIGN_INTERVAL[0] <= query_x <= DESIGN_INTERVAL[1]
    fixture_ok = (not source_mismatch and int(config["burn_in"]) == DECLARED_BURN_IN
                  and sorted(config) == ["burn_in", "mu_scale", "noise_sd", "query_x"] and in_design)

    routes = {"stdlib_math_sin": closed, "numpy_sin": numpy_route,
              "decimal_taylor_series": series_route, "gauss_hermite_innovation_integral": quadrature_route}
    worst = max(abs(value - closed) for value in routes.values())

    chain = np.asarray(generator.simulate_chain(config, DECLARED_BURN_IN + 1000 + MC_LENGTH + 1, MC_SEED))
    mc_mean, mc_count = _window_mean(chain, DECLARED_BURN_IN, MC_LENGTH, query_x, WINDOW_HALF_WIDTH)
    mc_tolerance = 6.0 * noise_sd / math.sqrt(mc_count) if mc_count else float("inf")
    late_mean, late_count = _window_mean(chain, DECLARED_BURN_IN + 1000, MC_LENGTH, query_x, STATIONARITY_WINDOW)
    base_mean, base_count = _window_mean(chain, DECLARED_BURN_IN, MC_LENGTH, query_x, STATIONARITY_WINDOW)
    stationarity_gap = abs(late_mean - base_mean)

    sample = generator.generate(config, 64, 424242)
    xs, ys = sample["X"], sample["Y"]
    aligned = all(xs[i + 1] == ys[i] for i in range(len(xs) - 1))
    distinct = any(xs[i] != ys[i] for i in range(len(xs)))

    checks = [
        {"name": "source_constants_original",
         "passed": bool(fixture_ok),
         "details": f"Model 1 constants mu_scale={mu_scale} and noise_sd={noise_sd} match the source fixture {SOURCE_FIXTURE}; burn_in={DECLARED_BURN_IN} and Y_0=0 are declared implementation choices, not paper parameters; query_x={query_x} lies in the source design interval T=[{DESIGN_INTERVAL[0]},{DESIGN_INTERVAL[1]}]. Mismatches: {source_mismatch or 'none'}."},
        {"name": "independent_closed_form",
         "passed": bool(abs(reference["value"] - closed) < 1e-9 and worst < 1e-9),
         "details": f"Three implementations of mu(x0): stdlib math.sin={closed:.15g}, numpy sin={numpy_route:.15g}, 60-digit Decimal Taylor series={series_route:.15g} (series remainder bound={series_bound:.3g}); worst pairwise deviation={worst:.3g} < 1e-9."},
        {"name": "innovation_integral_identity",
         "passed": bool(abs(quadrature_route - reference["value"]) < 1e-9 and abs(innovation_expectation) < 1e-9 and abs(mass - 1.0) < 1e-12),
         "details": f"64-point Gauss-Hermite integration of the conditional law Y=a*sin(x0)+s*e over e~N(0,1) returns {quadrature_route:.15g}; E[e]={innovation_expectation:.3g} and total mass={mass:.15g}, confirming the noise term integrates out and the mean is not averaged from rows."},
        {"name": "odd_symmetry_and_zero_anchor",
         "passed": bool(abs(mu_scale * math.sin(-query_x) + reference["value"]) < 1e-12
                       and abs(float(np.sin(np.float64(0.0)))) < 1e-15
                       and (abs(query_x) > 1e-15 or reference["value"] == 0.0)),
         "details": f"mu is odd so mu(-x0)=-mu(x0): residual={abs(mu_scale*math.sin(-query_x)+reference['value']):.3g}; the origin anchor mu(0)=0 is reproduced exactly, and an interior query at x0=0 therefore has value 0."},
        {"name": "mc_window_mean",
         "passed": bool(mc_count >= 1000 and abs(mc_mean - reference["value"]) < mc_tolerance),
         "details": f"One vectorised realisation of length {MC_LENGTH} after burn-in {DECLARED_BURN_IN} (seed {MC_SEED}); {mc_count} rows with |X-x0|<{WINDOW_HALF_WIDTH} give mean(Y)={mc_mean:.8f} against truth {reference['value']:.8f}; deviation={abs(mc_mean-reference['value']):.4g} < 6*s/sqrt(N_win)={mc_tolerance:.4g}. Mechanism check only, not a coverage claim."},
        {"name": "stationarity_sanity",
         "passed": bool(base_count >= 1000 and late_count >= 1000 and stationarity_gap < STATIONARITY_TOL),
         "details": f"Window means from the same trajectory started {DECLARED_BURN_IN} and {DECLARED_BURN_IN+1000} steps after Y_0: {base_mean:.8f} vs {late_mean:.8f}; gap={stationarity_gap:.4g} < {STATIONARITY_TOL}. Consistent with geometric ergodicity |mu'|<1 making the burn-in choice immaterial; not a mixing-time proof."},
        {"name": "markov_pair_alignment",
         "passed": bool(aligned and distinct),
         "details": f"Exported rows satisfy X_{{i+1}} = Y_i on a 64-row probe, so adjacent rows share a value and must NOT be treated as independent; X_i and Y_i are not identical. Dependence is declared as Markov (alpha-mixing) in the sampling block."},
    ]
    return {"passed": all(check["passed"] for check in checks), "checks": checks,
            "shared_components": "All routes share the documented Model 1 equations and the scenario config; they differ in evaluation machinery (math.sin, numpy libm, Decimal Taylor series, Gauss-Hermite quadrature, independent Monte Carlo). Source reconstruction against the paper and independent-person reproduction are still separate review tasks.",
            "monte_carlo": {"length": MC_LENGTH, "seed": MC_SEED, "window_half_width": WINDOW_HALF_WIDTH,
                            "selected_rows": mc_count, "tolerance": mc_tolerance},
            "gaps": "Single Monte Carlo realisation and finite CPU checks only; no simultaneous confidence band coverage, no mixing-time bound, no named scientific review."}
