# Zhou et al. weighted block-network outcome, average edge weight

## 来源与关系

Zhou, Y., Kurisu, D., Otsu, T. and Müller, H.-G. (2026). Geodesic difference-in-differences. Biometrika, asag054. [DOI](https://doi.org/10.1093/biomet/asag054)。定位：arXiv:2501.17436v2, Section 5.4 p.22; author simulations/net.R.

**ADAPTED；不是原论文标量 DGP 的原样复现。**

- Project each independent network to mean undirected edge weight = trace(L)/(2*number_of_possible_edges). This is a scalar outcome, not interference among sampled units.
- Retain fresh independent edge indicators and uniform edge noise at each time, group-level baseline offset, and additive treatment edge shift.
- Target scalar ATT, not geodesic effect; enforce nonnegative edge weights for the declared parameter prior.
- Treat the source D-dependent baseline as latent group type G with observed assignment D=G; intervention changes only the post treatment term.

## 数学定义与识别证明

Each iid sampled unit is one network with latent group G~Bernoulli(pi), D=G and empty X. For edge j and period t, A_tj~Bernoulli(p_j), U_tj~Uniform(-h,h), independently across edges, periods and units. Define Y_t(d)=L^-1 sum_j A_tj(a1+a2 t+a3 G+b d t+U_tj). No anticipation holds, and E[DeltaY(0)|G]=a2 mean(p_j), hence CPT even though levels depend on G. ATT=b mean(p_j), e=pi. For group g the change variance is L^-2 sum_j{p_j(1-p_j)[c_g0²+c_g1²]+2 p_j h²/3}, with c_g0=a1+a3 g, c_g1=c_g0+a2+b g. Then V=v1/pi+v0/(1-pi). Graph nodes are not sampled causal units. All units are independent; there is no network interference.

## 参数与家族

`config.json` 给出 3 个明确场景；`adapted_reference` 保留可保留的来源常数，不命名为 original。完整参数区间与采样分布在 `family_prior.json`，`family.sample_mechanism(seed)` 只生成固定参数，`generate(config,n,seed)` 再独立生成样本。改变场景、系数或随机种子不增加家族数。此家族的 paper lineage 为 `zhou-kurisu-otsu-muller-2026`。

## 输入与标签隔离

只使用 `fsp_adapter.model_input` 构造 X,D,delta_y。y_pre/y_post 仅供观察数据审核；特别是无协变量家族，不得擅自把 y_pre 加入 X。所有真实 propensity、m0、ATT、V、EIF、teacher 都在独立 sidecar 中。样本为空组时 teacher 明确报错，不重抽、不截断分母。

## 真值与验证

`truth.py` 不依赖当前 episode。`independent_reference.py` 用不同积分或枚举路径核验人口矩；`verify.py` 另外核验真实生成数据的处理概率、EIF 一二阶矩。更完整的重复抽样、区间覆盖率、家族抽样检查见 `audit_results.json` 与 `audit.md`。数值积分阶数差是误差诊断，不冒称严格误差上界。

## 使用

安装 requirements.txt，在本目录运行 `python -c "import json; from generator import generate; c=json.load(open('config.json'))['scenarios']['adapted_reference']; print(generate(c,5,1729))"`。

学生工具：`python collect.py check <本目录> --run --n 128 --seed 1729`；随后 `python collect.py pack <本目录> --out <新 ZIP>`。包内 `checks/report.json` 是格式及执行检查，科学审核以 `audit.md` 为准。本文档与实现由 AI 辅助完成，不伪造人工评审或独立研究者复现签名。
