import numpy as np

def validate(c):
    assert .1 <= c['pi'] <= .9
    assert len(c['blocks'])==2 and all(isinstance(m,int) and 2<=m<=8 for m in c['blocks'])
    assert all(.05<=p<=.9 for p in c['edge_probs']) and len(c['edge_probs'])==3
    assert 0<c['noise']<=1.5 and abs(c['effect'])<=2
    centers=[c['intercept']+c['trend']*t+c['group_level']*g+c['effect']*d*t for g in [0,1] for t in [0,1] for d in [0,1]]
    assert min(centers)>=c['noise']-1e-12

def edge_probabilities(c):
    a,b=c['blocks'];return np.repeat(c['edge_probs'],[a*(a-1)//2,a*b,b*(b-1)//2])

def draw(c,n,seed):
    validate(c);r=np.random.default_rng(seed);d=r.binomial(1,c['pi'],size=n)
    p=edge_probabilities(c);L=len(p);out=[]
    for t in [0,1]:
        center=c['intercept']+c['trend']*t+c['group_level']*d+c['effect']*d*t
        edge=r.binomial(1,p,size=(n,L))
        noise=r.uniform(-c['noise'],c['noise'],size=(n,L))
        out.append(np.mean(edge*(center[:,None]+noise),axis=1))
    y0,y1=out
    return dict(x0=np.zeros(n),D=d,y_pre=y0,y_post=y1,delta_y=y1-y0)

def moments(c,order=None):
    validate(c);p=edge_probabilities(c);L=len(p);pi=c['pi']
    def variance(g):
        a=c['intercept']+c['group_level']*g;b=a+c['trend']+c['effect']*g
        return float(np.sum(p*(1-p)*(a*a+b*b)+2*p*c['noise']**2/3)/L**2)
    return dict(pi=pi,theta=float(np.mean(p)*c['effect']),V=variance(1)/pi+variance(0)/(1-pi),m0=float(np.mean(p)*c['trend']))

def nuisances(c,data,pop):
    n=len(data['D']);return np.full(n,pop['pi']),np.full(n,pop['m0'])
