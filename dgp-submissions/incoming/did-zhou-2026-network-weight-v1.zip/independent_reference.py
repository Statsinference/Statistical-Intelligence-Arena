import numpy as np
from numpy.polynomial.legendre import leggauss

def reference(c):
    # Enumerate edge Bernoulli states and integrate uniform noise, then sum edges.
    z,w=leggauss(5);z=z*c['noise'];w=w/2
    a,b=c['blocks'];counts=[a*(a-1)//2,a*b,b*(b-1)//2];L=sum(counts)
    means=[];variances=[]
    for g in [0,1]:
        group=[];var=0.
        for t in [0,1]:
            center=c['intercept']+c['group_level']*g+c['trend']*t+c['effect']*g*t
            mean=0.
            for count,p in zip(counts,c['edge_probs']):
                ey=p*float(w@(center+z));ey2=p*float(w@((center+z)**2))
                mean+=count*ey/L;var+=count*(ey2-ey*ey)/L**2
            group.append(mean)
        means.append(group[1]-group[0]);variances.append(var)
    p=c['pi'];return dict(pi=p,theta=means[1]-means[0],m0=means[0],V=variances[1]/p+variances[0]/(1-p))
