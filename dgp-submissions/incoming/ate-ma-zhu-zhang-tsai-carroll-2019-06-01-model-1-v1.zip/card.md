# 交互处理分配与平方项结果

Contributor: 张佳怡. Task family: ate. Status: runnable candidate pending named scientific review and independent-person reproduction.

## Source and version

Shujie Ma, Liping Zhu, Zhiwei Zhang, Chih-Ling Tsai and Raymond J. Carroll (2019). A robust and efficient approach to causal inference based on sparse sufficient dimension reduction. The Annals of Statistics 47(3):1505–1535. DOI: https://doi.org/10.1214/18-AOS1722.
Actual reading version: Published typeset 31-page author-hosted copy, June 2019 issue; no day of publication invented in filename.
Source URL: https://carroll.stat.tamu.edu/wp-content/uploads/2019/07/PMC6588012_Robust-and-Efficient-approach-to-tausal.pdf
Exact location: Section 7.2, PDF p.14 / journal p.1518, unnumbered Models 1 and 2 and shared X/noise paragraph; Section 7.3 PDF p.17 / journal p.1521 confirms ATE=1; collected Model 1
Locators use one-based PDF page numbers. Journal page numbers are separately labeled; supplement pages are not main-paper pages.
Local verification source SHA-256: 7dfcb928216ef4e3df281a288f95dc61e92ecea49f4d825cd36fa2c7122f539a. The source PDF is retained outside the submission ZIP.
Version and scope differences: Published typeset source is used directly; no preprint or author software supplies parameters. Source p=20 is selected; p=40/100 and different n are parameter scenarios, not new mechanism families.
No author software is copied or used to fill parameters. Repository/file/function/commit citations are therefore not applicable; all implementations are independently written from the cited equations.

## Original generation order and fixed parameters

1. X~N_20(0,Sigma), Sigma[j,k]=0.5**abs(j-k); independent individuals.
2. p(X)=expit((X1+X2)*(X3+1)/2); A|X~Bernoulli(p).
3. Y=A+X1**2+X2**2+epsilon; epsilon~N(0,1), independent across individuals and of X/assignment randomness.

Fixed configuration: `{"dimension": 20, "rho": 0.5, "noise_sd": 1.0, "treatment_effect": 1.0, "propensity_scale": 0.5}`.
Original source sample size is recorded in collection.json as context. The generate interface deliberately accepts n and seed, and the required smoke check uses n=128; this is not a recreation of the paper's estimator performance experiments.
Sampling units are independent individuals, with no interference, clusters, panels, or shared random coefficients. Random draws for treatment and noise are independent conditional on the generated covariates. Within-person covariate dependence follows the equations above. Potential-outcome residual coupling that is not specified by a source is not inferred: the generator implements its observed conditional law without claiming a unique joint counterfactual law.


## Target and identification

Population ATE = E[Y(1)-Y(0)] under the declared full covariate distribution, with treatment levels 1 versus 0. This is not ATT, a trimmed/overlap population, a sample-average realized effect, or a fixed-point CATE. No outcome-dependent sample selection or missingness is introduced.
Identification requires consistency, no interference, conditional exchangeability of treatment and potential outcomes given observed X, and positivity. These are part of the synthetic scientific model, not inferred from machine PASS. For Gaussian logistic mechanisms positivity holds pointwise but there is no uniform overlap bound over unbounded support. No propensity clipping is added unless it is part of the cited original equation.

## Population truth and independent verification

The conditional arm contrast is exactly 1 for every covariate value; integrating over the full AR(1) Gaussian population leaves population ATE=1.
truth.py returns value, estimated_error and method separately from generated rows. verify.py uses independent scalar source fixtures and a separate analytic/numerical integration route, integrates the implemented arm contrast, and checks assignment, covariate and noise distributions. Statistical diagnostics use fixed seeds and explicit broad six-standard-error criteria; they are not coverage tests or mathematical proofs. Gaussian-tail truncation and order-refinement estimates are numerical diagnostics, not uniform error bounds.
The verifier shares the declared scientific equations, configuration, NumPy and the same AI author with the generator. Independent numerical routes reduce implementation risk but do not constitute independent-person reproduction. No named human scientific review is claimed.

## Mechanism identity and properties

Three directly active covariates. Products X1*X3 and X2*X3 occur in assignment; squared X1 and X2 occur in outcome. The submitted d=20 is below source n=1500; no high-dimensional claim is made. The noise variance is 1. Main-paper Model 1 is collected, not a parameter variant of Model 2.
Canonical mechanism family: ma_quadratic. It is distinguished by its covariate law and/or functional treatment/outcome/noise structure, not by seed, sample size or a mere coefficient change. Source scenarios with the same functional structure are grouped. The final family count is subject to the maintainer's scientific interpretation, with full equations provided for review.

## Adaptations and boundaries

- Rename source treatment D or W to A; observed conditional law unchanged.
- Independent Python/NumPy implementation; no source estimator fitting or reported performance tables are reproduced.

RNG is local numpy.random.default_rng(seed); identical seeds reproduce under the recorded Python/NumPy environment. Exact bitwise reproducibility across arbitrary dependency upgrades is not promised. Stable expit/logaddexp implementations are algebraic evaluations, not scientific changes. No clipping of Gaussian covariates, deletion of extreme rows, winsorization or silent finite-value replacement is used. Nonfinite outputs raise errors. Binary treatment is generated without forcing a fixed group size or resampling a missing arm.

## Rights, AI assistance and unresolved review

The scientific equations are attributed to their authors; paper copyrights remain with their respective rights holders. Paper PDFs, author software and original personal records are not redistributed in the ZIP. Implementation licensing is reserved for contributor/maintainer confirmation; no third-party code license is presumed from public accessibility.
AI assistance: literature discovery, source extraction and visual equation review, implementation, analytic derivation, numerical cross-checking, packaging and report drafting. Contributor review is still required before upload. Scientific acceptance, a separate human reproducer, project-wide deduplication and PR checks remain external steps. The local package does not assert any of those outcomes.


## Final source audit
AI source audit completed against the exact local source version and source_map.json. Human scientific acceptance and independent-person reproduction are not claimed. Dependencies are pinned to NumPy 2.3.5; only the original source scenario is registered.

Publication-date audit: publisher-deposited Crossref published/print date is 2019-06-01. DOI creation is not publication. The contribution ID now uses the full recorded publication date.
