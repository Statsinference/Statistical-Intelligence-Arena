"""Analytic population ATE of the source mechanism."""

def truth(config):
    return {'value': 1.0, 'estimated_error': 1e-14, 'method': 'The conditional arm contrast is exactly 1 for every covariate value; integrating over the full AR(1) Gaussian population leaves population ATE=1.', 'error_interpretation': 'Analytic identity with floating-point allowance, not Monte Carlo uncertainty.'}
