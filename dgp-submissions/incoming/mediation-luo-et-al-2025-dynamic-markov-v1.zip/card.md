# Markov longitudinal mediation (Luo et al., 2025)

**Status:** local candidate; named human scientific review pending.

## 1. Source and source version

Source: https://doi.org/10.1214/24-AOS2475; arXiv:2310.16203, equations (3),(4), Definition 1 equation (8), §4.1–4.2.

## 2. Generating mechanism

At each of T=10 stages, A_t~Bern(.5). Draw all Theta coefficients independently Uniform(-.5,.5), with the specific seed 20251031 draw stored in config.json. W=[[0,-.80,.61],[0,0,-.82],[0,0,0]]. Start M_0=0, R_0=0. Let mu_t=alpha_1t+delta_1t A_t+Gamma_1t M_(t-1)+zeta_1t R_(t-1). The paper's residual structural equation is M_t-mu_t=W^T(M_t-mu_t)+epsilon_wt, so M_t=mu_t+(I-W^T)^-1 epsilon_wt. R_t=alpha_2t+delta_2t A_t+gamma_2t^T M_(t-1)+zeta_2t R_(t-1)+kappa_t^T M_t+epsilon_rt; all errors independent N(0,1).

## 3. Causal target and population truth

Target Definition 1 equation (8) individual mediator-1 effect eta_1^(10): total A=1 versus A=0 cumulative reward contrast minus that contrast under `do(M_{s,1}=m)` at every stage `s<=t`. This linear SEM makes the contrast independent of the fixed value `m`; the implementation chooses `m=0`. The intervention is imposed anew at every stage, with subsequent mediators and rewards responding through the Markov transition. Exact value for the recorded coefficient draw: -0.028043454709554. Four deterministic mean recursions and a separate derivative recursion agree. The authors use a large Monte Carlo approximation for their own undisclosed draw; this number is not quoted from their table.

## 4. Changes, checks and limits

Changes: fixed and recorded **new** uniform coefficient draw with Python `random.Random(20251031)`; all realized arrays are stored in `config.json`. It obeys the source's distributional rule but is **not the authors' realized simulation**. The `-0.028043454709554` truth is conditional on this new draw. Wide subject rows preserve time dependence; generator n varies for validation. No PDF redistributed. AI-assisted implementation awaits human scientific review.

## 5. Rights and AI assistance

This ZIP contains an independent Python implementation and source references. The paper PDF and author code are not redistributed. Codex assisted with source transcription, derivation, implementation and this card. `collect.py check --run` verifies the local interface and contributor-supplied mathematical checks; it does not confer scientific acceptance. A named human reviewer must compare all equations, parameters, estimand interpretation, and stated changes against the cited original before submission.
