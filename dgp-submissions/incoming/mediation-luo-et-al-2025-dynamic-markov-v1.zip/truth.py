"""Exact source Definition 1 binary treatment individual mediation effect."""
from pathlib import Path
import importlib.util
def _trajectory(c,a,knock):
    p=Path(__file__).with_name('generator.py');s=importlib.util.spec_from_file_location('luo_generator',p);g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
    mp=[0.,0.,0.];rp=0.;total=0.
    for st in c['stages']:
        mp,rp=g.step(st,c['W'],a,mp,rp,[0.,0.,0.],0.,knock)
        total+=rp
    return total
def truth(c):
    j=c['target_mediator_index']
    val=(_trajectory(c,1,None)-_trajectory(c,0,None))-(_trajectory(c,1,j)-_trajectory(c,0,j))
    return {'value':float(val),'estimated_error':1e-13,'method':'Deterministic mean recursion for four treatment/mediator interventions; linear zero-mean errors vanish exactly.','target':'Definition 1: [E sum_t R_t(do A=1)-E sum_t R_t(do A=0)] minus the same contrast under do M_{t,1}=0 at every t'}
