"""Independent treatment-derivative recursion and zero-path special case."""
import importlib.util
from pathlib import Path
from copy import deepcopy
def _truth(c):
    q=importlib.util.spec_from_file_location('luo_truth',Path(__file__).with_name('truth.py'));x=importlib.util.module_from_spec(q);q.loader.exec_module(x);return x.truth(c)['value']
def _derivative(c,knock):
    dm=[0.,0.,0.];dr=0.;acc=0.
    w=c['W']
    for s in c['stages']:
        base=[s['delta1'][j]+sum(s['gamma1'][j][k]*dm[k] for k in range(3))+s['zeta1'][j]*dr for j in range(3)]
        m=[0.,0.,0.]
        for j in range(3):
            m[j]=base[j]+sum(w[k][j]*(m[k]-base[k]) for k in range(j))
            if knock==j+1:m[j]=0.
        nr=s['delta2']+sum(s['gamma2'][j]*dm[j] for j in range(3))+s['zeta2']*dr+sum(s['kappa'][j]*m[j] for j in range(3))
        dm,dr=m,nr;acc+=nr
    return acc
def verify(c):
    v=_truth(c);other=_derivative(c,None)-_derivative(c,c['target_mediator_index'])
    z=deepcopy(c)
    for s in z['stages']:
        s['delta1']=[0.,0.,0.];s['delta2']=0.
    checks=[{'name':'independent_gradient_recursion','passed':abs(v-other)<1e-10,'details':f'Four policy contrasts {v:.12g}; derivative recursion {other:.12g}'},{'name':'zero_treatment_paths','passed':abs(_truth(z))<1e-10,'details':'Removing A->M and A->R paths zeros the individual mediation effect, including feedback via prior R.'},{'name':'source_structure','passed':c['T']==10 and c['W']==[[0.,-.8,.61],[0.,0.,-.82],[0.,0.,0.]],'details':'T=10 and fixed triangular W checked.'}]
    return {'passed':all(x['passed'] for x in checks),'checks':checks,'shared_components':'Independent four-intervention level recursion and tangent/derivative recursion; both conditional on stored source-distributed coefficient draw.'}
