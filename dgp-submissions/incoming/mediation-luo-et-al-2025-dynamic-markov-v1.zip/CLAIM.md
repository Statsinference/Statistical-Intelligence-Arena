Candidate T06 contribution; human scientific review pending.
