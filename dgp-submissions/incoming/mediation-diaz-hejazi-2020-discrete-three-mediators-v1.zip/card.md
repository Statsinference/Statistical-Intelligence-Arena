# Three-binary-mediator natural indirect effect from Díaz–Hejazi §5

**Status:** locally reconstructed candidate. Named scientific review and independent-person reproduction are pending. No PFN or estimator-performance experiment is included.

## 1. Source and scenario

Díaz, I. and Hejazi, N. S. (2020), *Causal Mediation Analysis for Stochastic Interventions*, **Journal of the Royal Statistical Society: Series B** 82(3), 661–683, DOI [10.1111/rssb.12362](https://doi.org/10.1111/rssb.12362). The simulation mechanism appears in §5 as an unnumbered displayed block. I read the [author preprint arXiv:1901.02776v2](https://arxiv.org/pdf/1901.02776), dated 2019-06-24, PDF p.19, and compared the displayed equations with the journal HTML. The archived author simulation code is separately documented in `source_audit.json` because its mediator formulas are **not the same** as the displayed equations. This reconstruction follows the displayed paper equations.

The registered `journal_section_5` scenario has the original published constants. A different sample size, seed, nuisance estimator, or policy parameter does not make another DGP family.

## 2. Mechanism, target and population truth

For each independent individual, generate in this order:

\[
\begin{aligned}
W_1&\sim\operatorname{Bern}(0.50),\quad
W_2\sim\operatorname{Bern}(0.65),\quad W_3\sim\operatorname{Bern}(0.35),\\
A\mid W&\sim\operatorname{Bern}\{(W_1+W_2+W_3)/4+0.1\},\\
Z_1\mid A,W&\sim\operatorname{Bern}\{1-\operatorname{expit}[(A+W_1)/(A+W_1+0.5)]\},\\
Z_2\mid A,W&\sim\operatorname{Bern}\{\operatorname{expit}[(A-1+W_2)/(W_3+3)]\},\\
Z_3\mid A,W&\sim\operatorname{Bern}\{\operatorname{expit}[(A-1+2W_1-1)/(2W_1+0.5)]\},\\
Y&=Z_1+Z_2-Z_3+A-0.1(W_1+W_2+W_3)^2+\varepsilon,\quad
\varepsilon\sim N(0,0.25).
\end{aligned}
\]

The three baseline variables are independent. The Python generator makes the three Bernoulli mediator disturbances independent conditional on \(A,W\), consistent with the archived simulation's sequential draws. The outcome noise is independent of all preceding draws. The eight observable columns are `W1,W2,W3,A,Z1,Z2,Z3,Y`; no potential outcomes or oracle labels are returned.

This contribution targets the **joint natural indirect effect at treatment 1**:

\[
\operatorname{NIE}_1=E\{Y(1,Z(1))-Y(1,Z(0))\},\quad Z=(Z_1,Z_2,Z_3).
\]

Let \(q_{j,a}(w)=P(Z_j=1\mid A=a,W=w)\), as given by the three displayed Bernoulli expressions. Additivity of the outcome yields

\[
\operatorname{NIE}_1=\sum_{w\in\{0,1\}^3}P(W=w)
\left[(q_{1,1}-q_{1,0})+(q_{2,1}-q_{2,0})-(q_{3,1}-q_{3,0})\right]
=-0.11950701713951137\ldots.
\]

`truth.py` enumerates the eight baseline states and uses this conditional-mean identity. `verify.py` separately enumerates all eight **joint mediator states** under each intervention and evaluates the outcome mean, then checks two zero-path cases. The stated `estimated_error` only reflects floating-point rounding; it is not an independent scientific error bound.

The natural-effect interpretation requires consistency, no interference, treatment and mediator exchangeability given baseline \(W\), independent structural disturbances for the cross-world contrast, and positivity. With the displayed finite binary support, treatment probability ranges from 0.1 to 0.85, and each mediator probability lies strictly between zero and one.

## 3. Changes relative to the source

1. **Estimand:** the paper studies a stochastic population-intervention direct effect. This package instead derives \(\operatorname{NIE}_1\) from the paper's displayed DGP. The value above is **not reported by the original paper** and must not be confused with the paper's approximate 0.137 stochastic-effect number.
2. **Paper versus archived code:** the archived `simulation/R/01_setup_data.R` writes different expressions. For `Z1`, the code's powers `A^2,W1^3` have no numerical effect because both variables are binary. For `Z2`, the paper has `expit(((A-1)+W2)/(W3+3))`, while the code has `plogis((A-1)^3+W2/(W3+3))`: the denominator applies to different terms. For `Z3`, the paper has `expit(((A-1)+2W1-1)/(2W1+0.5))`, while the code has `plogis((A-1)^2+2W1^3-1/(2W1+0.5))`. The latter two yield genuinely different probabilities. This package follows the paper's §5 expressions and does not claim to reproduce the archived R simulation's samples.
3. **Implementation:** Python `random.Random` replaces R's RNG. Small `n=128` checks verify the contribution interface; the paper's large estimator comparison is outside this collection task.

## 4. Verification and scope

The family has three binary mediators and a continuous outcome, with nonlinear rational logits and a quadratic baseline term. It is not marked high dimensional. One named original scenario is included. Distinct sample sizes and seeds remain the same family.

Local `collect.py check --run` checks structure, reproducibility, schema and hooks. It cannot certify that the paper-to-code transcription or natural-effect assumptions are scientifically correct. Those require the named human review requested by the project.

## 5. Rights and AI assistance

No paper PDF, real data, or author R code is redistributed in this ZIP. The linked scholarly source and archived code remain under their owners' terms; licensing for any reuse beyond this independent equation reconstruction is for the maintainer to review. Codex assisted with source comparison, truth derivation, Python implementation and this card. A human reviewer must compare the equations and changes to the source before submission.
