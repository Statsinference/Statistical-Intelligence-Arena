"""Independent joint-mediator-state enumeration and null-path checks."""
from copy import deepcopy
import importlib.util
import itertools
import math
from pathlib import Path


def _truth_module():
    path = Path(__file__).with_name("truth.py")
    spec = importlib.util.spec_from_file_location("diaz_truth", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _joint_enumeration(config):
    # Enumerate all mediator states and evaluate counterfactual outcome means.
    # This does not use the mediator-mean shortcut in truth.py.
    result = 0.0
    pbase = config["baseline_probabilities"]
    for w1, w2, w3 in itertools.product((0, 1), repeat=3):
        w = (w1, w2, w3)
        pw = math.prod((p if bit else 1-p) for p, bit in zip(pbase, w))
        conditional = []
        for a in (0.0, config["mediation_path_scale"]):
            q = (
                1.0 / (1.0 + math.exp((a+w1)/(a+w1+0.5))),
                1.0 / (1.0 + math.exp(-(a-1+w2)/(w3+3))),
                1.0 / (1.0 + math.exp(-(a+2*w1-2)/(2*w1+0.5))),
            )
            ey = 0.0
            for z in itertools.product((0, 1), repeat=3):
                pz = math.prod(prob if bit else 1-prob for prob, bit in zip(q, z))
                mean_y = (sum(b*bit for b, bit in zip(config["outcome_mediator_coefficients"], z))
                          + config["outcome_treatment_coefficient"]
                          + config["outcome_baseline_quadratic_coefficient"]*sum(w)**2)
                ey += pz*mean_y
            conditional.append(ey)
        result += pw*(conditional[1]-conditional[0])
    return result


def verify(config):
    reference = _truth_module().truth(config)
    independent = _joint_enumeration(config)
    no_a = deepcopy(config)
    no_a["mediation_path_scale"] = 0.0
    no_m = deepcopy(config)
    no_m["outcome_mediator_coefficients"] = [0.0, 0.0, 0.0]
    is_source = (config["baseline_probabilities"] == [0.5, 0.65, 0.35]
                 and config["treatment_denominator"] == 4.0
                 and config["treatment_intercept"] == 0.1
                 and config["outcome_mediator_coefficients"] == [1.0, 1.0, -1.0]
                 and config["outcome_treatment_coefficient"] == 1.0
                 and config["outcome_baseline_quadratic_coefficient"] == -0.1
                 and config["outcome_noise_sd"] == 0.5
                 and config["mediation_path_scale"] == 1.0)
    checks = [
        {"name": "published_section_5_constants", "passed": is_source,
         "details": "Checked against displayed §5 equations, not against divergent archived R mediator code."},
        {"name": "independent_joint_state_enumeration", "passed": abs(reference["value"]-independent) < 1e-12,
         "details": f"conditional-mean route={reference['value']:.15g}; 8x8 joint-state route={independent:.15g}; difference={abs(reference['value']-independent):.3g}"},
        {"name": "derived_nie_anchor", "passed": abs(reference["value"]+0.11950701713951137) < 1e-12,
         "details": "-0.11950701713951137 is newly derived for the NIE target, not a source-reported stochastic effect."},
        {"name": "zero_treatment_to_mediator_path", "passed": abs(_truth_module().truth(no_a)["value"]) < 1e-14,
         "details": "Replacing A in all mediator equations by zero makes joint NIE zero."},
        {"name": "zero_mediator_to_outcome_path", "passed": abs(_truth_module().truth(no_m)["value"]) < 1e-14,
         "details": "Setting all outcome mediator coefficients to zero makes joint NIE zero."}
    ]
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "shared_components": "Both routes share the cited §5 equations and config; one sums mediator means and the other enumerates all joint mediator states with separately coded probability expressions. Named independent scientific review remains pending."}
