"""Exact eight-state baseline enumeration for the source-derived natural NIE."""
import itertools
import math


def _expit(x):
    return 0.5 * (1.0 + math.tanh(x / 2.0))


def _probs(a, w):
    x, y, z = w
    return (1.0 - _expit((a + x) / (a + x + 0.5)),
            _expit((a - 1.0 + y) / (z + 3.0)),
            _expit((a + 2.0 * x - 2.0) / (2.0 * x + 0.5)))


def truth(config):
    total = 0.0
    for w in itertools.product((0, 1), repeat=3):
        weight = math.prod(p if v else 1.0 - p
                           for p, v in zip(config["baseline_probabilities"], w))
        q0, q1 = _probs(0.0, w), _probs(config["mediation_path_scale"], w)
        total += weight * math.fsum(b * (p1 - p0)
                                    for b, p1, p0 in zip(config["outcome_mediator_coefficients"], q1, q0))
    return {"value": float(total), "estimated_error": 2e-15,
            "method": "Exact enumeration of 8 baseline states and conditional mediator means; floating-point rounding estimate only.",
            "target": "NIE_1 = E[Y(1,Z(1))-Y(1,Z(0))]"}
