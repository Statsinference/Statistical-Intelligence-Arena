# T06 mechanism claim

- Source: Díaz & Hejazi (2020), JRSS-B, DOI 10.1111/rssb.12362, §5 displayed DGP.
- Family: three nonlinear binary mediator probabilities with a continuous additive outcome.
- Target: joint natural NIE at treatment 1; this is a declared target adaptation.
- Distinction from T05 planned sources: the published Díaz–Hejazi §5 mechanism is a three-binary-mediator rational-logit design. It is not Zhou (2022), Xia & Chan (2022), Liu et al. (2022), or Shi & Li (2022).
- Registry: the main repository mediation registry showed only the official teaching example when checked on 2026-10-31. This does not establish that no unsubmitted T05 work exists.
- Claim and scientific acceptance: pending maintainer confirmation and named human source review.
