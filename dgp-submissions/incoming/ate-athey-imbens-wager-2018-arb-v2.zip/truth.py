"""Exact analytic population ATE for the many-cluster linear design."""

def truth(config):
    """Return the ATE for intervention W=0 versus W=1.

    With X and the same additive error held fixed, Y(w)=X^T beta + tau*w +
    epsilon. Thus E[Y(1)-Y(0)] = tau exactly.
    """
    tau = float(config["treatment_effect"])
    return {
        "value": tau,
        "estimated_error": 0.0,
        "method": "Exact algebraic potential-outcome contrast; no Monte Carlo or quadrature.",
        "error_interpretation": "Zero numerical error conditional on the declared structural interpretation. The source paragraph's implicit cross-variable independence assumptions remain subject to scientific review.",
        "target": "Population ATE = E[Y(1)-Y(0)] for intervention W: 0 -> 1, holding pretreatment X and the shared additive error fixed."
    }
