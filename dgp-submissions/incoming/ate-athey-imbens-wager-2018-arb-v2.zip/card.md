# ATE DGP collection: Section 5.2 many-cluster layout

**Status: candidate; automated checks do not constitute scientific acceptance.**

## Source and reconstruction

Athey, Susan, Guido W. Imbens and Stefan Wager (2018), “Approximate residual balancing: Debiased inference of average treatment effects in high dimensions,” *Journal of the Royal Statistical Society: Series B (Statistical Methodology)* 80(4), 597–623, DOI [10.1111/rssb.12268](https://doi.org/10.1111/rssb.12268). The actually read electronic-reprint PDF is available [here](https://file-lianxh.oss-cn-shenzhen.aliyuncs.com/Refs/Spring2024/Athey_2018_Approximate_Residual_Balancing.pdf).

**Exact source locator:** Section 5.2 “Simulation designs”; many-cluster paragraph is unnumbered, in the article PDF reader page 20/27 (zero-based PDF page index 19), printed page 616–617. The four beta-profile definitions continue onto PDF reader page 21/27 (zero-based index 20), printed page 617. Table 2 and footnote on printed page 617 give `n=800`, `p=4000`, `||beta||_2=3`, and 400 replications. There is no equation number for these simulation DGP statements. The paper says the implementation is available in R package `balanceHD`, but this contribution did not use author code and therefore has no pinned author-code commit.

### Source equations and fixed settings

1. Generate 20 independently drawn cluster centres: `c_k ~ N_p(0, I_p)`, `k=1,...,20`. In the Table 2 setting `p=4000`.
2. For each individual draw a cluster index `K_i` uniformly from `{1,...,20}`, then set `C_i=c_{K_i}`.
3. Treatment assignment follows the selected centre group: `W_i | K_i=k ~ Bernoulli(eta)` for the first ten centres and `Bernoulli(1-eta)` for the last ten centres. The source reports `eta=0.1` and `eta=0.25`.
4. Draw covariate noise `Z_i ~ N_p(0,I_p)` and set `X_i=C_i+Z_i`.
5. Draw outcome noise `epsilon_i ~ N(0,1)` (variance 1). The observed outcome in the paper is written `Y_i=(C_i+Z_i)^T beta + W_i + epsilon_i`, equivalently `Y_i=X_i^T beta + W_i + epsilon_i`.
6. Use one of four beta profiles, each rescaled to `||beta||_2=3`:
   - dense: `beta_j ∝ 1/sqrt(j)`, all `p` coefficients active;
   - harmonic: `beta_j ∝ 1/(j+9)`, all `p` coefficients active;
   - moderately sparse: raw entries are 10 repeated 10 times, 1 repeated 90 times, then 0 for the remaining `p-100` entries;
   - very sparse: raw entries are 1 repeated 10 times, then 0 for the remaining `p-10` entries.

The collected family contains the eight original combinations of two eta values and four beta profiles. It does not treat seeds or the eight combinations as separate DGP families. The paper’s Table 2 reference experiment uses `n=800,p=4000` and averages over 400 repetitions; package smoke test sample size `n=128` is only a local interface check. The later coverage study associated with Table 6 varies `n,p` and uses 1000 repetitions; it is not reproduced in this contribution.

### Explicit implementation convention / adaptation

The source paragraph explicitly says cluster centres are independently generated and gives the conditional treatment probabilities by centre group, but it does **not** enumerate every cross-variable or cross-individual independence relation for `Z_i` and `epsilon_i`. For an executable reconstruction, this implementation draws cluster indices independently conditional on the shared centre set, and draws `Z_i`, treatment randomization conditional on `K_i`, and `epsilon_i` independently where not linked by the specified conditional law. This is recorded as `adapted_from_source`; maintainers/scientific reviewers should confirm that convention. This is not claimed to reproduce the authors’ random-number sequence.

## Target and identification

The source observed outcome is structurally additive in treatment. To express the benchmark target, hold pre-treatment `X_i` and the same `epsilon_i` fixed under both interventions and write `Y_i(w)=X_i^T beta+w+epsilon_i`, for `w∈{0,1}`. Then

`Y_i(1)-Y_i(0) = (X_i^T beta + 1 + epsilon_i) - (X_i^T beta + epsilon_i) = 1`,

so the population `ATE=E[Y(1)-Y(0)]=1` exactly. The estimated numerical error is `0.0` because this is algebraic, not numerical integration.

The causal interpretation requires consistency, exchangeability given observed `X`, and positivity. Positivity follows from `eta∈{0.1,0.25}`: cluster-conditional treatment probabilities are either `eta` or `1-eta`, and the propensity given `X` is a mixture of these probabilities. Exchangeability given `X` follows under the implementation’s noise-independence convention; because the source paragraph does not state every cross-independence explicitly, this remains a review item rather than a claim established by machine checks.

## Sampling, dependence, and diversity

The sampling unit is an individual. Twenty centre vectors are drawn once per simulated dataset and shared by individuals assigned to each centre. Thus rows are conditionally independent given the centre vectors but dependent marginally through the shared random centres. There is no interference: one unit’s potential outcome does not depend on other units’ assignments.

The family has `p=4000` baseline covariates and the source reference `n=800`, so `p>n`. Effective outcome dimension depends on `beta_profile`: 4000 for dense/harmonic, 100 for moderately sparse, and 10 for very sparse. There are no treatment-covariate interactions or nonlinear functions in the outcome equation. The covariate distribution and treatment propensity are related through the shared latent cluster centres.

## Truth and verification

`truth.py` uses the structural contrast directly. `verify.py` independently reconstructs the four unnormalised beta vectors, checks their active counts and L2 normalization, checks the centre-group treatment probabilities and overlap bounds, verifies the source dimensions/scales and recomputes the potential-outcome contrast without calling `truth.py`; it also checks the zero-treatment-effect special case. The verifier necessarily shares the declared equations/config with the generator and is not an independent-person reproduction. The collector’s own run checks additionally examine output columns, finite values, schema/ranges, and seed reproducibility across all declared scenarios.

## Rights, scope, and unresolved items

The package includes no paper PDF, original data, or author software. No author-code commit was pinned or executed. The publisher’s supplementary proof file was not independently inspected in this run; the DGP parameters above are taken from the main article’s Section 5.2 and Table 2. Before scientific acceptance, confirm (i) the independence convention for `Z_i` and `epsilon_i`, (ii) the intended potential-outcome interpretation of the additive `W_i` term, and (iii) whether the maintainers want the Table 6 coverage variants as a later extension. No PFN was trained; no large bootstrap or formal coverage experiment was run. No named scientific acceptance is claimed.
