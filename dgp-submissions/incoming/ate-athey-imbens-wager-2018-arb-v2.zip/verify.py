"""Independent analytic checks for the many-cluster simulation design."""
import math
import numpy as np


def _raw_beta_independent(profile, p):
    # Deliberately separate construction from generator._beta_vector.
    j = np.arange(1, p + 1, dtype=float)
    if profile == "dense":
        return j ** (-0.5)
    if profile == "harmonic":
        return 1.0 / (j + 9.0)
    if profile == "moderately_sparse":
        b = np.zeros(p, dtype=float)
        b[0:10] = 10.0
        b[10:100] = 1.0
        return b
    if profile == "very_sparse":
        b = np.zeros(p, dtype=float)
        b[:10] = 1.0
        return b
    raise ValueError(f"Unknown beta_profile: {profile}")


def verify(config):
    checks = []
    p = int(config["p"])
    k_count = int(config["center_count"])
    first_group = int(config["centers_first_group"])
    eta = float(config["eta"])
    profile = config["beta_profile"]
    norm_target = float(config["beta_l2_norm"])
    tau = float(config["treatment_effect"])

    # 1. Source setting and number of clusters.
    ok = p == 4000 and int(config["n_reference"]) == 800 and k_count == 20 and first_group == 10
    checks.append({"name":"source_many_cluster_dimensions", "passed":bool(ok),
      "details":f"p={p}, paper Table 2 reference n={config['n_reference']}, centres={k_count}, low-treatment group={first_group}; expected p=4000,n=800,20,10."})

    # 2. Treatment overlap and source treatment probabilities. The centre label
    # is uniform, so P(W=1)=0.5 for both source eta choices.
    p_w1 = (first_group / k_count) * eta + ((k_count-first_group) / k_count) * (1.0-eta)
    lo, hi = min(eta,1.0-eta), max(eta,1.0-eta)
    overlap_ok = eta in (0.1,0.25) and abs(p_w1-0.5)<1e-14 and lo > 0.0 and hi < 1.0
    checks.append({"name":"source_cluster_treatment_probabilities_and_overlap", "passed":bool(overlap_ok),
      "details":f"eta={eta}; first 10 centre treatment p={eta}, last 10 p={1-eta}; marginal P(W=1)={p_w1}; conditional propensity is between {lo} and {hi}."})

    # 3. Independent beta vector reconstruction; verify active dimension and L2 scale.
    raw = _raw_beta_independent(profile,p)
    beta = norm_target*raw/np.linalg.norm(raw)
    active = int(np.count_nonzero(beta))
    expected_active = {"dense":p,"harmonic":p,"moderately_sparse":100,"very_sparse":10}[profile]
    beta_ok = abs(float(np.linalg.norm(beta))-3.0)<1e-12 and active==expected_active and norm_target==3.0
    checks.append({"name":"beta_profile_active_count_and_signal_norm", "passed":bool(beta_ok),
      "details":f"profile={profile}, nonzero coefficients={active} (expected {expected_active}), ||beta||_2={np.linalg.norm(beta):.15g} (source target 3)."})

    # 4. Source Gaussian scales; variance of each centre/noise coordinate is 1.
    scales_ok = (float(config["center_mean"])==0.0 and float(config["center_sd"])==1.0
                 and float(config["z_mean"])==0.0 and float(config["z_sd"])==1.0
                 and float(config["epsilon_mean"])==0.0 and float(config["epsilon_sd"])==1.0)
    checks.append({"name":"source_gaussian_means_and_variances", "passed":bool(scales_ok),
      "details":"Each centre-coordinate, Z coordinate and epsilon has mean 0 and variance 1 under the declared Normal laws."})

    # 5. Independent structural derivation, not a call to truth.py.
    contrast = (float(config["treatment_effect"]) + 0.0) - 0.0
    contrast_ok = abs(contrast-tau)<1e-14 and abs(tau-1.0)<1e-14
    checks.append({"name":"direct_potential_outcome_contrast", "passed":bool(contrast_ok),
      "details":f"From Y(w)=X^T beta + tau*w + epsilon, the shared X and epsilon cancel; contrast=tau={contrast:.15g} (source coefficient 1)."})

    # 6. Analytic zero-effect special case (verification fixture, not an extra scenario).
    tau_zero = 0.0
    zero_contrast = (0.0 + tau_zero*1.0) - (0.0 + tau_zero*0.0)
    checks.append({"name":"zero_treatment_effect_analytic_special_case", "passed":abs(zero_contrast)<1e-14,
      "details":"Setting the additive W coefficient to zero makes Y(1)=Y(0), so the ATE is exactly 0; this is a verifier fixture, not a declared source scenario."})

    # 7. The parameter grids have exactly the two source overlap levels and four
    # beta forms; this catches silent parameter or label drift.
    grid_ok = eta in {0.1,0.25} and profile in {"dense","harmonic","moderately_sparse","very_sparse"}
    checks.append({"name":"declared_scenario_on_original_grid", "passed":bool(grid_ok),
      "details":f"eta={eta}, beta_profile={profile}; accepted original values only."})

    return {
      "passed": all(c["passed"] for c in checks),
      "checks": checks,
      "shared_components": "The verifier independently reconstructs beta vectors, treatment overlap and the structural contrast without calling generator.py or truth.py. It necessarily shares the declared source equations/configuration; no independent-human reproduction has occurred.",
      "limitations": "The source Section 5.2 paragraph does not state all cross-variable/cross-row independence relations explicitly. The generator uses independent local-RNG draws under a documented adaptation, pending scientific confirmation."
    }
