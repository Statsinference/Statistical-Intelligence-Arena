# QDI：相关稀疏线性位置模型的条件分位数

状态：来源适配机制，等待具名科学审核。实际格式和运行结果见 `checks/report.json`；本卡不授予 accepted 状态。

## 1. 来源核对与版本

Tan, K. M., Wang, L., and Zhou, W.-X. (2022). *High-Dimensional Quantile Regression: Convolution Smoothing and Concave Regularization*. **Journal of the Royal Statistical Society Series B: Statistical Methodology**, 84(1), 205-233. [DOI: 10.1111/rssb.12485](https://doi.org/10.1111/rssb.12485)。在线发表 2021-12-16，卷期日期 2022-02-01；ID 使用卷期日期。

实际阅读版本：[arXiv:2109.05640v1](https://arxiv.org/abs/2109.05640v1)，2021-09-12 提交，共 61 页，正文后附补充材料。下表页码均为该版本从 1 开始的 PDF 页码；不能当作期刊页码。该 PDF 的 SHA-256 已写入 `collection.json/source/actual_read_version`。

| 核对项目 | 已核对依据与本包选择 |
|---|---|
| 期刊、作者、题名、DOI、卷期、页码 | 出版社元数据与 [Crossref DOI 记录](https://api.crossref.org/works/10.1111/rssb.12485) 一致。 |
| 生成方程、系数、协变量 | v1 第 20 页 Section 5，起首为“For all the numerical experiments”的未编号机制段落。 |
| 噪声 | 同段第 (iv) 项：0.7 N(0,1) + 0.3 N(0,25)。第二参数为方差，不是标准差；本包选这一项。 |
| 维数、样本量 | 同页下一段：n=500，p=400 或 1000；本包只保留 p=1000。原文重复 100 次不构成 100 个机制。 |
| 混合正态结果定位 | v1 第 22 页 Table 4；本包不复现其中估计器、TPR、FPR、SSE 数值。 |
| 固定查询与真值 | 本贡献定义并推导；不是原文报告的条件分位数数值。 |
| 版本差异 | 已确认预印本与正式论文的身份对应；正式期刊 PDF 获取返回 HTTP 403，尚未逐段核对最终版本差异。 |
| 作者代码 | 未用作者代码作为参数或实现依据，未执行或复制其 notebook。当前仓库示例设置与上述段落不同，不能混成一个“原文”设计。 |

## 2. 完整生成机制与观测表

每行是一个个体，各行独立同分布。1000 个随机协变量服从

```text
p = 1000, rho = 0.7
X_i ~ N_p(0, Sigma),  Sigma[j,k] = rho^|j-k|
beta[1,3,5,7,9,11,13,15,17,19]
    = (1.8,1.6,1.4,1.2,1,-1,-1.2,-1.4,-1.6,-1.8)
其他 beta_j = 0，截距 = 0
B_i ~ Bernoulli(0.7), U_i ~ N(0,1)
epsilon_i = (B_i + 5(1-B_i)) U_i
Y_i = sum_j beta_j X_ij + epsilon_i
```

本包明确规定 B、U、X 相互独立，且跨个体独立。这是对联合生成律的显式具体化：来源第 20 页给出 X 与噪声的边际分布，但该段未另写完整的独立性因子分解，因此不得声称此项已经逐字核实；须由科学审核人确认来源意图。真值结论针对上述已明确的联合律成立。

代码先生成独立标准正态创新 Z，再沿**特征索引**递推：`X_i1=Z_i1`，`X_ij=0.7 X_i,j-1 + sqrt(0.51) Z_ij`。归纳可得方差为 1、协方差为 `0.7^|j-k|`，与所选高斯边际分布相同。此递推不引入跨行时间依赖。

来源理论 Section 2 在 v1 第 5 页设 x1 恒为 1；数值研究第 20 页则明确写全部 p 维 X 为中心高斯。本包跟随**数值研究约定**，X1 是随机协变量，其系数 1.8 不是截距，不额外加入常数列。

`generate(config,n,seed)` 使用局部 NumPy PCG64；n 参数覆盖来源实验的 n=500。观察表仅含 `X1,...,X1000,Y`，均为有限浮点数；schema 上下界留空，表示实数支持而非有界截断。不裁剪、不标准化、不删列、不按 tau 平移误差；B、U、epsilon、系数和真值均不输出为观察列。没有缺失、删失或选择机制。

## 3. QDI 目标、假设与场景

主类别为 `quantile_distribution`。固定 `x0=e1=(1,0,...,0)`，定义

```text
theta_tau = inf{y : P(Y <= y | X=x0) >= tau}
F_epsilon(t) = 0.7 Phi(t) + 0.3 Phi(t/5)
theta_tau = x0' beta + F_epsilon^(-1)(tau)
          = 1.8 + F_epsilon^(-1)(tau)
```

这是**条件响应分位数**，不是边际分位数、回归系数、均值或未来单个响应的预测区间。连续 X 的单点事件概率为零，目标使用模型确定的连续条件分布；X 的高斯密度在 x0 处为正。误差混合密度处处为正，因而目标唯一。

| scenario | 数据生成参数 | 固定查询 | 推导真值 |
|---|---|---|---|
| `source-mixture-p1000` | 上述来源固定场景 | tau=0.5, x0=e1 | 1.8（对称性解析结果） |
| `q90-mixture-p1000`（默认） | 同一数据生成律 | tau=0.9, x0=e1 | 约 4.211483457105085 |

两场景只改变查询，同 seed 下应生成完全相同的观察表，合计 **1 个机制 family**。两个查询都由贡献者指定；名称含 source 只表示保留来源数据参数，不能解释为原文已执行这一点态查询。x0 和 tau 不作为每行数据的 oracle 标签。

本机制需要 iid 抽样、完整观测、所声明的独立噪声和正确的线性位置模型；无需套用因果无混杂或干预假设。若后续在 p>n 下作置信区间，还需对应方法自己的稀疏推断条件；本阶段未证明这些方法条件或任何 coverage 结论。

## 4. 真值与独立数值核验

`truth.py` 以 `math.erfc` 计算正态混合 CDF，在扩展括区间内二分求逆，区间宽度目标为 1e-12。返回值包含 value、estimated_error、最终括区间、CDF 残差和目标密度。默认目标处密度约为 0.036557416923，尾部密度比中位数处低，会增加未来分位数推断难度。

`verify.py` 不使用上述 CDF 求独立解：直接对混合密度从 0 至 t 作复合 Simpson 积分，采用带区间保护的 Newton 求根，再将 2048 与 4096 个小区间的积分结果比较。另检验对称混合中位数、混合权重退化为 0/1 时的单正态分位数、互补分位数对称性及查询点平移关系。单正态特例使用 `statistics.NormalDist.inv_cdf`。

两路线共享 config、同一数学分布和 Python math 库；verify 调用被测 truth 作比较，但其独立求根路线不调用 truth。此数值独立性不等于另一个人的独立复现。estimated_error 为二分括区间半宽加浮点舍入诊断；未把 CDF 库误差做严格区间包络，不是统一误差定理。验收容差固定 1e-9，未因失败放宽。实际差异、运行种子和数据哈希均由工具记录在 `checks/report.json`。

## 5. 标签、适配与范围

- 总维数 1000，直接有效维数 10。p 大于来源 n=500 及检查 n=128，登记为稀疏高维回归；其余 990 列与活动列相关，不必是边际无信息列。
- 无交互项；条件分位数曲面对 X 是线性的。混合 CDF 对阈值非线性不等于非线性回归。噪声为方差污染型正态混合，不宣称幂律重尾或高维混杂。
- 保留来源的 p=1000 混合分支；不收集 p=400、标准正态、t1.5、Cauchy 分支。改变样本量和随机种子不另计 family。
- 适配包括显式联合独立性、点态查询目标、数值真值、采样实现和 CPU 小样本核验；`collection.json/source/adaptations` 逐条登记。
- 不提供估计器训练、bootstrap、置信区间覆盖率或同时置信带评测。高维点态条件分位数的经典方法比较属于下一阶段。

## 6. 重现、打包与状态

在扩展版学生包根目录，将贡献解压并保留原件作为证据；需要重检再打包时，将**八项源文件**复制到新的 `contributions/` 目录，原包的 `MANIFEST.json` 和 `checks/` 不复制过去。安装本贡献 `requirements.txt` 后运行：

```text
python collect.py check contributions/qdi-tan-wang-zhou-20220201-gaussian-mixture-v1 --run --n 128 --seed 1729
python collect.py pack contributions/qdi-tan-wang-zhou-20220201-gaussian-mixture-v1 --out submissions/qdi-tan-wang-zhou-20220201-gaussian-mixture-v1.zip
```

不要带 `--scenario` 跳过另一个场景。重检写入新的报告；修改任意来源文件后须重检再另名打包。原始 ZIP 可以直接验包或解压运行，但不要把旧 MANIFEST 当源文件再次 pack：本版工具会为新 ZIP 另生成一份 MANIFEST。严格跨环境复现需同时固定 Python、NumPy 和数值后端；本次实际版本见检查报告及另交简报，不承诺跨 NumPy 大版本逐位相同。

本包不内嵌学生工具、论文 PDF、真实数据、权重或凭据。ZIP 根目录含八项源文件、`checks/report.json`、`checks/sample.json`、`MANIFEST.json`；简短 report 单独交付。机器 PASS 仅覆盖接口、观察表、seed、真值与 verify；不授予科学接收。

## 7. 权利、AI 协助与未决事项

论文/预印本权利属于各权利人。这里仅引用机制并独立实现，不复制作者代码或论文全文；公开访问不等于已经确认下游再分发许可，维护人仍须核查。AI 协助了来源检索、方程转录、推导、实现和本地核验；没有代签人工审核或独立复现。

待维护人处理：认领及跨项目查重、正式版本逐段比对、来源联合独立性意图确认、使用/分发权利、学生署名、具名科学审核及另一人独立复现。本地目录检索未发现这一机制，但不能宣称全库不重复。未向 GitHub、微信或维护人发送文件；该成品状态仍为等待科学审核。
