# QDI：Tan–Wang–Zhou 正态混合模型的 10 维边际适配

版本：v2 / active10。状态：来源适配机制，等待科学审核。1 个机制 family、2 个查询场景。此包替换原 p=1000 的 v1 submission，不另计一个文献机制 family。

## 1. 来源与适配边界

Tan, K. M., Wang, L., and Zhou, W.-X. (2022). *High-Dimensional Quantile Regression: Convolution Smoothing and Concave Regularization*. **Journal of the Royal Statistical Society Series B: Statistical Methodology**, 84(1), 205–233. [DOI: 10.1111/rssb.12485](https://doi.org/10.1111/rssb.12485)。在线发表 2021-12-16，卷期日期 2022-02-01。

实际阅读依据为 [arXiv:2109.05640v1](https://arxiv.org/abs/2109.05640v1)，提交于 2021-09-12。机制位置：该版本 PDF 第 20 页 Section 5、以“For all the numerical experiments”起首的未编号段落；正态混合分支结果见第 22 页 Table 4。PDF 页码不是期刊页码。原文 n=500，p=400 或 1000，重复 100 次；本包从 p=1000、rho=0.7 的混合分支推导低维边际，**原文未报告本包的 10 维实验或点态分位数结果**。

原正式发表信息曾与出版社及 Crossref 核对；最终期刊 PDF 获取返回 403，尚未逐段比较预印本与最终版本。不能声称完全复现最终发表版本。实际阅读 PDF 的 SHA-256 见 collection.json。未执行或复制作者代码，代码由贡献者在 AI 协助下独立实现。

## 2. 10 维边际化推导

父模型为 X ~ N_1000(0,Sigma)，Sigma[j,k]=0.7^|j-k|，只有坐标

```text
A = (1,3,5,7,9,11,13,15,17,19)
beta_A = (1.8,1.6,1.4,1.2,1,-1,-1.2,-1.4,-1.6,-1.8)
```

的系数非零，其余 990 个系数严格为零。令 **W_k = X_original,2k-1**，k=1,...,10。高斯子向量的分布给出

```text
W ~ N_10(0, Sigma_AA)
Sigma_AA[j,k] = 0.7^|(2j-1)-(2k-1)| = 0.49^|j-k|
b = beta_A
epsilon ~ 0.7 N(0,1) + 0.3 N(0,25)
Y = b'W + epsilon，截距为 0
```

这里正态第二参数是方差，两个标准差为 1 和 5。本包明确规定 epsilon 与原完整 X 独立、跨个体独立；因而与 W 独立。来源第 20 页机制段列出了边际分布，没有另写完整联合独立性因子分解，这仍是显式建模补全，待科学审核确认。

这是对 (X_A,Y) 的**边际化**，没有把被删坐标条件固定为零。原被删坐标与活动坐标相关，不声称它们边际无信息或相互独立。因为它们在响应方程的系数为零，去掉它们不改变 (W,Y) 的联合律及 Y 的边际分布。用已知活动集合消除了变量筛选的困难，因此本包不能用于声称复现原高维变量选择性能。

## 3. 生成与观察表

各行 iid。生成独立标准正态 Z，按特征索引递推：W_i1=Z_i1，W_ik=0.49 W_i,k-1+sqrt(1-0.49²) Z_ik。其方差为 1、协方差为 0.49^|j-k|，不是跨行时间序列。

局部 NumPy PCG64 产生随机数，不更改全局随机状态。`generate(config,n,seed)` 仅返回 W1,...,W10,Y，共 11 个有限浮点观察列；不输出混合成分、噪声、系数或真值。所有 W 坐标均随机，W1 不是截距。支持为实数，schema 上下界留空；无裁剪、标准化、缺失、删失或选择。

固定 p=10；n 参数控制抽样量。高维标签为 false，依据是 p=10 相对本包检查 n=128、来源 n=500 的低维设置。它不声称任意 n<=10 仍然低维。两个查询使用相同 seed 时产生相同数据，但不承诺与旧 p=1000 生成器逐 seed 一致。

## 4. QDI 目标与真值

主类别为 `quantile_distribution`。固定 w0=e1=(1,0,...,0)∈R^10，目标为条件响应分位数：

```text
theta_tau = inf{y : P(Y <= y | W=w0) >= tau}
F_epsilon(t) = 0.7 Phi(t) + 0.3 Phi(t/5)
theta_tau = b'w0 + F_epsilon^(-1)(tau) = 1.8 + F_epsilon^(-1)(tau)
```

| scenario | 查询 | 真值 |
|---|---|---:|
| q50-active10-mixture | tau=0.5, w0=e1 | 1.8 |
| q90-active10-mixture（默认） | tau=0.9, w0=e1 | 约 4.211483457105085 |

这是条件分位数，不是边际分位数、系数或单个未来观测的预测区间。连续协变量的单点事件概率为零，这里采用模型定义的连续条件分布；该点的高斯密度为正。噪声混合密度处处为正，所以分位数唯一。

在独立噪声假设下，Y 对完整 X 的条件律仅依赖 X_A，因此本目标与父模型完整 X 在 x_A=e1（包括原 x=e1）处的条件分位数相同。保持这个真值不意味着完整观测数据仍为 1000 维，也不意味着推断难度相同。条件分位数曲面对 W 线性，无交互项；混合 CDF 对阈值非线性不构成非线性回归。

## 5. 核验及适用范围

`truth.py` 用 erfc 正态 CDF 和扩展括区间二分求逆，最终区间宽度目标为 1e-12。`verify.py` 直接积分混合密度（复合 Simpson），使用带区间保护的 Newton 求根，并比较 2048 与 4096 子区间积分。验收容差 1e-9，不为兼容 CI 放宽。

每个场景另核验解析中位数、单正态退化特例、互补分位数、查询平移，以及从原活动坐标推导的 10×10 协方差子矩阵。verify 的独立求解路线不调用 truth 求根，但两者共享配置、数学模型和 Python math 库，不能当作另一人的独立复现。误差诊断不是严格的全域区间证明。

官方检查须覆盖两个场景的观察表、seed 重放、换 seed、真值及 verify。运行证据在 checks/report.json、checks/sample.json；本卡不预先授予 PASS 或 scientific acceptance。未训练估计器/PFN，未做 bootstrap、coverage 或置信带实验。

## 6. 打包与替换提交

本包根目录严格保留八项源文件：collection.json、card.md、config.json、schema.csv、generator.py、truth.py、verify.py、requirements.txt；再加 checks/report.json、checks/sample.json、MANIFEST.json，共 11 项。

使用扩展版学生工具重检时，将八项源文件复制到新的贡献目录；不要复制旧 MANIFEST 和 checks：

```text
python collect.py check contributions/qdi-tan-wang-zhou-20220201-active10-mixture-v2 --run --n 128 --seed 1729
python collect.py pack contributions/qdi-tan-wang-zhou-20220201-active10-mixture-v2 --out submissions/qdi-tan-wang-zhou-20220201-active10-mixture-v2.zip
```

改任何源文件后都须重新检查全部场景、重新打包。要求 NumPy>=1.24,<3；严格逐位复现须同时固定 Python、NumPy 和数值后端，实际运行环境记录在检查证据中。

上传由用户自行操作。**在仓库 incoming 中替换旧 QDI ZIP，不要同时保留旧 p=1000 ZIP。**旧包仍存在时，现有仓库的全局“不得包含高维标签”测试仍会报错。此包无须修改仓库测试或标签函数，不能把旧包 high_dimensional 简单改成 false；当前 false 是实际降低观测维数后的声明。

新 ID 标示 v2 适配版；mechanism_family_id 沿用父模型，不能重复计数。提交仍需具名学生信息、维护人去重与科学审核。本轮不执行远端 commit 或上传。

## 7. 权利与未决事项

论文和预印本权利属于各权利人；arXiv 可访问不等于可任意再分发。本包不含论文 PDF、作者代码、真实数据、训练权重或凭据。代码独立实现并有 AI 协助，使用及下游分发权限仍需维护人审查。

待审事项包括最终发表版本差异、联合独立性补全、活动坐标边际适配、机制去重与作者/贡献者登记。机器检查和 CI 成功仅说明接口与本地检查通过，不代表科学接收。
