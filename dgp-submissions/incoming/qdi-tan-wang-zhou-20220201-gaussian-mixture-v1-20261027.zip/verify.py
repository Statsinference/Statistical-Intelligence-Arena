"""Independent density quadrature / Newton route and analytic special cases."""
from copy import deepcopy
import math
from statistics import NormalDist
from truth import truth


def _simpson(c, z, panels):
    """Integrate the explicit noise density from 0 to z, using symmetry."""
    if z == 0:
        return 0.5
    w = float(c["noise"]["weight_narrow"])
    v1 = float(c["noise"]["variance_narrow"])
    v2 = float(c["noise"]["variance_wide"])

    def density(t):
        return (w * math.exp(-t * t / (2 * v1)) / math.sqrt(2 * math.pi * v1)
                + (1 - w) * math.exp(-t * t / (2 * v2)) / math.sqrt(2 * math.pi * v2))

    h = abs(z) / panels
    odd = math.fsum(density(h * k) for k in range(1, panels, 2))
    even = math.fsum(density(h * k) for k in range(2, panels, 2))
    area = h / 3 * (density(0) + density(abs(z)) + 4 * odd + 2 * even)
    return 0.5 + math.copysign(area, z)


def _quadrature_newton(c, tau):
    """No erfc CDF and no call to the truth solver in this route."""
    w = float(c["noise"]["weight_narrow"])
    v1 = float(c["noise"]["variance_narrow"])
    v2 = float(c["noise"]["variance_wide"])
    bound = 8 * math.sqrt(max(v1, v2))
    lo, hi, z = -bound, bound, 0.0
    for _ in range(60):
        residual = _simpson(c, z, 2048) - tau
        if abs(residual) < 2e-14:
            return z
        if residual < 0:
            lo = z
        else:
            hi = z
        f = (w * math.exp(-z * z / (2 * v1)) / math.sqrt(2 * math.pi * v1)
             + (1 - w) * math.exp(-z * z / (2 * v2)) / math.sqrt(2 * math.pi * v2))
        candidate = z - residual / f
        z = candidate if lo < candidate < hi else (lo + hi) / 2
    raise ArithmeticError("quadrature/Newton route did not converge")


def verify(config):
    oracle = truth(deepcopy(config))
    tau = float(config["query"]["tau"])
    # Independently use a dense vector dot product for the query location.
    p = config["p"]
    beta = [float(config["beta_nonzero"].get(str(j), 0)) for j in range(1, p + 1)]
    x0 = [float(config["query"]["x_nonzero"].get(str(j), 0)) for j in range(1, p + 1)]
    location = math.fsum(a * b for a, b in zip(beta, x0))
    root = _quadrature_newton(config, tau)
    difference = abs(location + root - oracle["value"])
    cdf_fine = _simpson(config, root, 4096)
    cdf_coarse = _simpson(config, root, 2048)
    refinement_error = abs(cdf_fine - cdf_coarse) / 15
    checks = [
        {"name": "density_quadrature_newton_vs_erfc_bisection", "passed": difference < 1e-9,
         "absolute_difference": difference, "independent_value": location + root},
        {"name": "quadrature_resolution_and_cdf_identity", "passed": abs(cdf_fine - tau) < 1e-11 and refinement_error < 1e-11,
         "cdf_residual": abs(cdf_fine - tau), "simpson_refinement_diagnostic": refinement_error,
         "panels": [2048, 4096]},
    ]
    median = deepcopy(config)
    median["query"]["tau"] = 0.5
    median_error = abs(truth(median)["value"] - location)
    checks.append({"name": "analytic_symmetric_mixture_median", "passed": median_error < 1e-10,
                   "absolute_difference": median_error, "expected": location})
    normal_errors = []
    for weight, variance_key in [(1.0, "variance_narrow"), (0.0, "variance_wide")]:
        special = deepcopy(config)
        special["noise"]["weight_narrow"] = weight
        expected = location + math.sqrt(config["noise"][variance_key]) * NormalDist().inv_cdf(tau)
        normal_errors.append(abs(truth(special)["value"] - expected))
    checks.append({"name": "analytic_single_normal_special_cases", "passed": max(normal_errors) < 1e-10,
                   "absolute_differences": normal_errors})
    complement = deepcopy(config)
    complement["query"]["tau"] = 1 - tau
    symmetry_error = abs(truth(complement)["value"] + oracle["value"] - 2 * location)
    checks.append({"name": "complementary_quantiles_symmetry", "passed": symmetry_error < 1e-10,
                   "absolute_difference": symmetry_error})
    shifted = deepcopy(config)
    shifted["query"]["x_nonzero"] = {"1": 2.0}
    shift_error = abs(truth(shifted)["value"] - oracle["value"] - (2 * beta[0] - location))
    checks.append({"name": "conditional_query_translation", "passed": shift_error < 1e-10,
                   "absolute_difference": shift_error})
    # Check the Gaussian submatrix derivation, not just the scalar oracle.
    source = config["source_design"]
    active = source["active_coordinates"]
    mapping_valid = (p == 10 and source["p"] == 1000
                     and active == list(range(1, 20, 2))
                     and source["rho"] == 0.7)
    covariance_error = max(
        abs(config["rho"] ** abs(j-k)
            - source["rho"] ** abs(active[j]-active[k]))
        for j in range(p) for k in range(p)
    )
    checks.append({"name": "active_coordinate_gaussian_marginal",
                   "passed": mapping_valid and covariance_error < 1e-14,
                   "maximum_covariance_difference": covariance_error,
                   "source_coordinates": active})
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "independence_note": "Independent CDF construction and root algorithm; shared configuration, mathematical mixture law, Python math library, and production truth() under test. No independent human reproduction is claimed."}
