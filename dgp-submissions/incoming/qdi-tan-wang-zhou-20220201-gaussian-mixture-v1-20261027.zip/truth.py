"""Scalar conditional quantile via an erfc CDF and bracketed bisection."""
import math


def truth(config):
    tau = float(config["query"]["tau"])
    if not 0 < tau < 1:
        raise ValueError("quantile level must lie strictly between 0 and 1")
    p = int(config["p"])
    location = 0.0
    for index, value in config["query"]["x_nonzero"].items():
        if not 1 <= int(index) <= p or not math.isfinite(float(value)):
            raise ValueError("invalid fixed query coordinate")
        location += float(config["beta_nonzero"].get(index, 0.0)) * float(value)
    weight = float(config["noise"]["weight_narrow"])
    s1 = math.sqrt(float(config["noise"]["variance_narrow"]))
    s2 = math.sqrt(float(config["noise"]["variance_wide"]))
    if not 0 <= weight <= 1 or min(s1, s2) <= 0:
        raise ValueError("invalid mixture parameters")

    def cdf(z):
        return 0.5 * (weight * math.erfc(-z / (s1 * math.sqrt(2)))
                      + (1 - weight) * math.erfc(-z / (s2 * math.sqrt(2))))

    lo, hi = -max(s1, s2), max(s1, s2)
    for _ in range(100):
        if cdf(lo) <= tau <= cdf(hi):
            break
        lo *= 2
        hi *= 2
    else:
        raise ArithmeticError("failed to bracket quantile")
    for _ in range(200):
        if hi - lo <= 1e-12:
            break
        mid = (lo + hi) / 2
        if cdf(mid) < tau:
            lo = mid
        else:
            hi = mid
    else:
        raise ArithmeticError("quantile bisection did not converge")
    noise_quantile = (lo + hi) / 2
    value = location + noise_quantile
    density = (weight * math.exp(-0.5 * (noise_quantile / s1) ** 2) / s1
               + (1 - weight) * math.exp(-0.5 * (noise_quantile / s2) ** 2) / s2) / math.sqrt(2 * math.pi)
    return {
        "value": value,
        "estimated_error": (hi - lo) / 2 + 8 * math.ulp(value),
        "method": "normal erfc CDF plus bracketed bisection; floating-point error diagnostic, not a certified uniform bound",
        "noise_quantile": noise_quantile,
        "location_at_query": location,
        "noise_quantile_bracket": [lo, hi],
        "cdf_residual": abs(cdf(noise_quantile) - tau),
        "density_at_target": density,
        "tau": tau,
    }
