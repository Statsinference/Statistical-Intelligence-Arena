"""Independent Gaussian quadrature and published propensity spot checks."""
import math

def expit(z):
    return 1/(1+math.exp(-z))

def verify(config):
    mode=config["mode"]
    expected="quadratic_logistic"
    # Integrate x^2 under N(0,1) independently of the truth hook.
    h=0.002
    integral=sum(((-8+(i+0.5)*h)**2)*math.exp(-(-8+(i+0.5)*h)**2/2)/math.sqrt(2*math.pi)*h for i in range(8000))
    if mode=="quadratic_logistic":
        probs=[expit(v) for v in (-1,0,1)]
        expected_probs=[0.2689414213699951,0.5,0.7310585786300049]
    else:
        probs=[expit(-4+1.5*math.sqrt(abs(v))+0.75*v+0.5*abs(v)**1.5) for v in (-1,0,1)]
        expected_probs=[expit(-2.75),expit(-4),expit(-1.25)]
    checks=[{"name":"source_scenario","passed":mode==expected,"details":"JASA 2015 Section 4.1 chosen setting."},
            {"name":"independent_gaussian_integral","passed":abs(integral-1)<1e-9,"details":f"Numerical E(X^2)={integral:.12g}."},
            {"name":"propensity_spot_checks","passed":all(abs(a-b)<1e-12 for a,b in zip(probs,expected_probs)),"details":"R=1 probabilities at X=-1,0,1."},
            {"name":"finite_mask_value","passed":math.isfinite(float(config["missing_outcome_placeholder"])),"details":"Zero is a placeholder only."}]
    return {"passed":all(c["passed"] for c in checks),"checks":checks}
