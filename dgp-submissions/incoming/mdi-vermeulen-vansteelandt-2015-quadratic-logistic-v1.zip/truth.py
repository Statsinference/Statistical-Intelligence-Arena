"""Exact standard-normal second moment."""
def truth(config):
    if config["mode"] not in ("quadratic_logistic","quadratic_nonlinear"):
        raise ValueError("invalid source scenario")
    return {"value":1.0,"estimated_error":0.0,"method":"E(X^2)=Var(X)+E(X)^2=1; independent outcome noise has mean zero","target":"Full-data E(Y)"}
