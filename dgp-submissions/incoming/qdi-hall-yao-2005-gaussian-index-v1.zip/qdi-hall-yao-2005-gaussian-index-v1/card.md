# Marginal quantile in the Hall-Yao Gaussian single-index mechanism

编号 Q01 · 高斯单指标的边际分位数。状态：本地核验后仍待科学审核；未提交 GitHub。

## 来源与精确定位

Hall, P. and Yao, Q. (2005). Approximating conditional distribution functions using dimension reduction. The Annals of Statistics 33(3), 1404-1421. DOI: https://doi.org/10.1214/009053604000001282

实际读取：Published journal PDF, 18 pages, journal pagination 1404-1421。下载链接：https://stats.lse.ac.uk/q.yao/qyao.links/paper/hy02.pdf

定位：Section 4, Example 1; PDF page 10 = journal page 1413; unnumbered model immediately below Example 1. Independence specified in preceding paragraph.

读取 PDF 的 SHA-256：fd896d24a6c2589eef2797704b677c1b0b3c8bd4837b03aa513fbf5b83ac3569。不依赖作者源码，无代码 commit 需要引用。source_audit.json 另列版本及查重证据。

## 完整生成机制

\[
X_{ij},\varepsilon_i\overset{\mathrm{ind}}{\sim}\mathcal N(0,1),\quad j=1,\ldots,4
\]

\[
Y_i=\frac{X_{i1}+2X_{i2}+3X_{i4}}{\sqrt{14}}+\varepsilon_i
\]

\[
Q_Y(0.9)=\sqrt 2\,\Phi^{-1}(0.9)
\]

生成顺序：先抽协变量，再独立抽噪声，最后按显示方程构造响应。不同观察行独立；协变量和噪声按显示公式及下列实现约定独立。参数全部在 config.json。X1 到 X4 以及 Y 完全观测；无缺失、删失、标注抽样或因果处理分配。误差及混合成分只在生成器内部使用，不输出给模型。

样本量由 generate(config,n,seed) 的 n 决定；source_n 是原文样本量记录，不替代 n。随机数生成器为 NumPy PCG64，固定种子及相同依赖版本可复现；不声称与 R 或论文逐行随机数相同。所有列为等长有限数值列表。不对 Y 裁剪、截断或重新标准化；均匀分布的右端点在实现中不取，连续理论分布不受影响。

## 目标与真值

Marginal population quantile Q_Y(tau)=inf{y:P(Y<=y)>=tau}, tau=0.9; X is integrated over its N(0,I4) population, not fixed at zero.

独立高斯和的方差为 $1+(1^2+2^2+3^2)/14=2$，故 $Y\sim N(0,2)$，$Q_Y(\tau)=\sqrt{2}\Phi^{-1}(\tau)$。

默认场景真值为 **1.81238760487365**。这是按本包目标推导的新真值；未将论文估计值当作 oracle。truth.py 返回标量以及 1e-12 的浮点/求根诊断，非严格统一误差界。数值反演使用初始区间 [-100,100] 和 60 次二分，适用于登记的固定水平。verify.py 不调用生成器，使用独立密度 Simpson 积分和 1024/2048 网格（Q01 卷积为 2048/4096），并核对对称/支持/边界特例。两条路线仍由同一 AI 编写，不等于独立研究者复现。

分位数统一定义为 $Q_\tau=\inf\{y:F(y)\ge\tau\}$。边际目标处密度为 φ(Φ⁻¹(0.9))/√2，严格为正。

## 多样性及范围

Four observed covariates; X3 has coefficient zero. Effective dimension 3 counts active coordinates, while the sufficient index has dimension 1. No products or nonlinear covariate terms. high_dimensional=false 指本包维数相对于原文样本量以及 n=128 核验而言，不承诺 n 小于维数时仍属低维。多个噪声或查询场景不重复计数。标量真值核验不意味着整条分布函数带或分位曲线的覆盖率通过。所有登记场景见 config.json。

## 相对来源的改动

1. The original paper studies conditional distribution approximation and index estimation. This contribution keeps its data law and defines a marginal 0.9 quantile by integrating over X. The reported truth is newly derived here, not a number reported in the source.
2. Independent Python/NumPy implementation from mathematical formulas; no author code is redistributed. PCG64(seed) replaces unspecified/source software random-number generation. Sample size is the generate n argument; source_n only records the published sample sizes. No fitting, bootstrap, confidence-band coverage experiment or PFN training is included.

## 权利与 AI 协助

原论文归原著作权人；本包不含论文 PDF、真实个体数据或作者源码。方程被重新转写并单独实现。使用 AI 辅助提取、推导、编程、核验及排版，尚无具名科学审核人及独立复现者；不得将本地 PASS 或收件测试写为正式接收。提交人姓名由用户在 GitHub 提交说明中填写，不由 AI 代签。
