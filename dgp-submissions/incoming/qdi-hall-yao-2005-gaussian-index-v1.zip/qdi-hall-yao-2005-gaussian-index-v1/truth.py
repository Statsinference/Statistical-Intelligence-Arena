import math
from statistics import NormalDist

def truth(config):
    variance=sum(b*b for b in config['beta'])+config['noise_sd']**2
    value=math.sqrt(variance)*NormalDist().inv_cdf(config['tau'])
    return {"value":float(value),"estimated_error":1e-12,"error_interpretation":"Floating-point and bisection diagnostic; not a rigorous uniform error bound"}
