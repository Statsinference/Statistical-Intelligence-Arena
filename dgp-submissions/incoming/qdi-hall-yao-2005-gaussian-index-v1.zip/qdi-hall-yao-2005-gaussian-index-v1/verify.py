"""Deterministic cross-checks; independent numerical route, not an independent human reproduction."""
import math
from statistics import NormalDist
from truth import truth

def simpson(f,a,b,n):
    h=(b-a)/n
    return h/3*(f(a)+f(b)+4*sum(f(a+h*i) for i in range(1,n,2))+2*sum(f(a+h*i) for i in range(2,n,2)))

def normal_integral(z,n):
    return .5+simpson(lambda t:math.exp(-t*t/2)/math.sqrt(2*math.pi),0,z,n)

def check(name,error,tolerance):
    return dict(name=name,passed=bool(error<=tolerance),absolute_error=float(error),tolerance=tolerance)

def normal_checks(z,tau):
    p1=normal_integral(z,1024);p2=normal_integral(z,2048)
    return [check('Integrate normal density at the proposed quantile',abs(p2-tau),1e-9),check('Quadrature refinement',abs(p2-p1),1e-9),check('Normal symmetry at zero',abs(normal_integral(0,128)-.5),1e-12)]

def verify(config):
    value=truth(config)['value']
    checks=[]
    sd_signal=math.sqrt(sum(b*b for b in config['beta']))
    density=lambda z: math.exp(-z*z/(2*sd_signal**2))/(sd_signal*math.sqrt(2*math.pi))
    f=lambda z: density(z)*NormalDist().cdf((value-z)/config['noise_sd'])
    prob1=simpson(f,-10*sd_signal,10*sd_signal,2048)
    prob2=simpson(f,-10*sd_signal,10*sd_signal,4096)
    expected=config['tau']
    checks.append(check('Gaussian convolution CDF at the marginal quantile',abs(prob2-expected),1e-9))
    checks.append(check('Convolution quadrature refinement',abs(prob2-prob1),1e-9))
    checks.append(check('Zero coefficient on X3',abs(config['beta'][2]),0.0))
    return {"passed":all(c["passed"] for c in checks),"checks":checks}
