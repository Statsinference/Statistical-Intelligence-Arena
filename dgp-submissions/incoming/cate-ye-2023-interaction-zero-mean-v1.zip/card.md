# Ye-Shao-Yi-Zhao (2023) setting 1: treatment-by-covariate interaction with zero average effect

**Contribution `cate-ye-2023-interaction-zero-mean-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `ye-2023-interaction-zero-mean`

## Source and reconstruction

- Citation: Ye, T., Shao, J., Yi, Y. and Zhao, Q. (2023). Toward better practice of covariate adjustment in analyzing randomized clinical trials. Journal of the American Statistical Association 118(544), 2370-2382. DOI: 10.1080/01621459.2022.2049278.
- Venue / year: Journal of the American Statistical Association, 2023
- Link: https://arxiv.org/abs/2009.11828
- **Exact locator**: Section 4.1 'Simulation results', equation (20) on PDF p.23 ('Y (2) = Y (1) + zeta(U - muU), Y (3) = Y (2)'), with the following sentence on the same page defining theta1 = theta2 = theta3 and the allocation proportions. arXiv:2009.11828v2 (13 Jul 2021), 62-page author manuscript.
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **U, W**: `U, W ~ Normal(0,1) independently (standardised surrogate for the trial's empirical distribution)`
2. **Treatment**: `P(A=1) = 0.5 (simple randomisation, two arms at 1:1)`
3. **Potential responses**: `Y(1) = eps, Y(2) = Y(1) + zeta (U - muU), zeta = 1, muU = 0`
4. **Heterogeneity**: `tau(U) = zeta (U - muU) = U, with E[tau(U)] = 0`
5. **Observed**: `Y = A Y(2) + (1-A) Y(1) = eps + A tau(U)`

Sampling unit: patient · dependence: independent and identically distributed

Fixed parameters: zeta = 1, muU = 0, noise variance 1. The source reports zeta in [-1,1] and beta1 = -0.255 for the real baseline; both deviations are listed above.

### Adaptations relative to the source

- Three arms reduced to two: only the arm-2 versus arm-1 contrast is kept, because the registered target family is the binary-treatment CATE. The contrast surface is exactly the increment in equation (20).
- Y(1) in the source is the observed placebo-arm response of 481 real patients and is not distributed with the paper; this package replaces it with independent N(0,1) noise. The source reports R-squared <= 0.05 for a linear fit of Y(1) on (U,W), so the replacement preserves the near-independence of the baseline response from the covariates; it does change the paper's beta1 = -0.255 to 0 and this is a declared deviation.
- (U,W) in the source follow the empirical distribution of the same 481 patients; this package uses U, W ~ N(0,1) with muU = muW = 0 and E[U^2] = 1, i.e. the paper's centring constants are set to their standardised values.
- The source uses allocation 1:2:2 or 1:1:1 over three arms; this package uses simple randomisation with two arms at 1:1, so e = 0.5.
- The source varies zeta over [-1, 1]; this package fixes zeta = 1 as the single declared scenario.

## Target and identification

- Symbol: `tau(u0) = E[Y(1) - Y(0) | U = u0]`
- Definition: Conditional average treatment effect at the declared query points for the arm-2 versus arm-1 contrast; the surface is linear in U with slope zeta = 1 and has exactly zero mean over the covariate distribution, so there is heterogeneity but no average effect.
- Query points (part of the estimand): `primary`: (U = 0.5, W = 0.0); `secondary`: (U = -1.5, W = 0.0)

Identification assumptions:

- SUTVA: one version of treatment, no interference between patients
- Randomised assignment: e = 0.5, so the treatment is independent of the potential responses by design
- Overlap: e = 0.5 with margin 0.5
- The baseline response Y(1) is independent of (U,W) in this package, which is the declared surrogate for the source's near-zero R-squared

This is the pure treatment-by-covariate interaction regime with zero average effect. It separates 'the treatment works on average' from 'the treatment works differently for different patients', which is exactly where pooled ATE estimators and CATE estimators diverge.

## Truth and independent verification

Observed outcome is eps + A U with eps independent of A and U, so E[Y|A=1,U=u] - E[Y|A=0,U=u] = u. At U = 0.5 the value is 0.5 and at U = -1.5 it is -1.5; the average over U ~ N(0,1) is 0.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and confirms end-to-end that the realised
outcome column of `generator.py` carries the declared surface (arm-contrast shift
equals the mean of tau over treated rows, at identical seed). Both routes share the
declared mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 2 (effective 1) · high dimensional: False · interactions: True · nonlinear: False
- Because the average effect is zero, a method can be unbiased for the ATE while being wrong everywhere in the covariate space; the mechanism is built to expose that. No weak-overlap region, and no claim beyond the linear surface.

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| U | covariate | float | · | · | true |
| W | covariate | float | · | · | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by Taylor & Francis for the American Statistical Association. Supplementary materials are not redistributed; the equations are cited and independently implemented.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: The baseline response is a declared surrogate, not the trial data; the three-arm structure and the covariate-adaptive randomisation schemes are not reproduced.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
