"""Population CATE at the declared query points.

The target is never estimated from generated rows: it is evaluated from the
declared mechanism.  The query points are part of the estimand definition and are
repeated in card.md and collection.json.
"""
import math

QUERY_POINTS = {
    "primary": {
        "U": 0.5,
        "W": 0.0
    },
    "secondary": {
        "U": -1.5,
        "W": 0.0
    }
}


def tau_at(x):
    """CATE surface of the mechanism, evaluated at one query point."""
    return (
        1.0 * x['U']
    )


def truth(config):
    scale = float(config["tau_scale"])
    primary = tau_at(QUERY_POINTS["primary"]) * scale
    secondary = tau_at(QUERY_POINTS["secondary"]) * scale
    return {
        "value": primary,
        "estimated_error": 1e-12,
        "method": "Closed form: the contrast in equation (20) is zeta (U - muU), so with muU = 0 and zeta = 1 the surface is tau(u) = u exactly; cross-checked by a second typing and by the realised outcome column.",
        "target": "tau(x0) at QUERY_POINTS['primary'], evaluated from the declared mechanism",
        "value_at_secondary_query": secondary,
        "scale_used": scale,
    }
