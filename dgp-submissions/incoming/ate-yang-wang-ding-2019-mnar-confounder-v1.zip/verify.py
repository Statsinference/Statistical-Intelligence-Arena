"""Independent checks of Section 5.2 parameters, truth algebra and reported response rate."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss


def _expit(x):
    # Separate scalar/vector expression from generator.py.
    x = np.asarray(x, dtype=float)
    return 0.5 * (1.0 + np.tanh(0.5 * x))


def _ate_from_explicit_means(p):
    # Rebuild the expected potential-outcome means directly, not by calling truth.py.
    ey1 = p["y1_intercept"] + p["y1_x1"] * p["x1_mean"] + p["y1_x2"] * p["x2_probability"]
    ey0 = p["y0_intercept"] + p["y0_x1"] * p["x1_mean"] + p["y0_x2"] * p["x2_probability"]
    return float(ey1 - ey0)


def _expected_response_rate(p, order):
    # Integrate over X1 ~ N(1,1), enumerate X2 and A conditional on X.
    # This is a diagnostic of the paper's stated approximate 67% response rate.
    nodes, weights = hermgauss(order)
    x1_values = p["x1_mean"] + math.sqrt(2.0 * p["x1_variance"]) * nodes
    weights = weights / math.sqrt(math.pi)
    total = 0.0
    for x2 in (0, 1):
        prob_x2 = p["x2_probability"] if x2 == 1 else 1.0 - p["x2_probability"]
        pa = _expit(p["treatment_intercept"] + p["treatment_x1"] * x1_values + p["treatment_x2"] * x2)
        for a in (0, 1):
            prob_a = pa if a == 1 else 1.0 - pa
            eta_r = (p["missing_intercept"] + p["missing_x1"] * x1_values
                     + p["missing_a"] * a + p["missing_a_x2"] * a * x2)
            pr = _expit(eta_r)
            total += prob_x2 * float(np.sum(weights * prob_a * pr))
    return total


def verify(config):
    expected = {
        "x1_mean": 1.0, "x1_variance": 1.0, "x2_probability": 0.5,
        "y0_intercept": 0.5, "y0_x1": 2.0, "y0_x2": 1.0,
        "y1_intercept": 0.0, "y1_x1": 3.0, "y1_x2": 2.0,
        "error_variance": 1.0,
        "treatment_intercept": 1.25, "treatment_x1": -0.5, "treatment_x2": -0.5,
        "missing_intercept": -2.0, "missing_x1": 2.0, "missing_a": 1.5, "missing_a_x2": 1.0,
    }
    source_match = all(config.get(k) == v for k, v in expected.items())
    ate = _ate_from_explicit_means(config)
    response_64 = _expected_response_rate(config, 64)
    response_128 = _expected_response_rate(config, 128)

    # Parseable zero-effect special case: set both potential-outcome mean functions
    # equal while leaving treatment and missingness mechanisms untouched.
    zero = dict(config)
    zero.update({"y1_intercept": zero["y0_intercept"],
                 "y1_x1": zero["y0_x1"], "y1_x2": zero["y0_x2"]})
    zero_ate = _ate_from_explicit_means(zero)

    checks = [
        {
            "name": "joint_law_gaps_explicitly_declared",
            "passed": "no explicit joint-dependence statement" in config.get("joint_law_convention", "") and "cross-independence is an implementation convention" in config.get("potential_outcome_error_convention", ""),
            "details": "Verifies that unspecified X1-X2 dependence and potential-outcome-error cross-independence are visibly declared as implementation conventions requiring review, rather than represented as fully specified source facts."
        },
        {
            "name": "section_5_2_source_marginal_parameters",
            "passed": source_match,
            "details": "Checks the marginal X distributions, potential-outcome coefficients, unit error variance, treatment logit and missingness logit from the paper's Section 5.2 paragraph. X1-X2 dependence and error cross-independence are implementation conventions, not source-fixed parameters."
        },
        {
            "name": "independent_analytic_ate",
            "passed": abs(ate - 1.0) < 1e-12,
            "details": f"Independently computes E[Y(1)]-E[Y(0)] from coefficient means: {ate:.15g}; target is A=0 -> A=1."
        },
        {
            "name": "zero_effect_special_case",
            "passed": abs(zero_ate) < 1e-12,
            "details": f"Setting both potential-outcome mean coefficient vectors equal yields ATE={zero_ate:.3g}, a direct algebraic null-path check. This is verifier-only and not declared as an original scenario."
        },
        {
            "name": "reported_response_rate_diagnostic",
            "passed": abs(response_128 - response_64) < 1e-10 and 0.66 < response_128 < 0.69,
            "details": f"Independent Gauss-Hermite integration gives response rate {response_128:.12g} (order-64/128 difference {abs(response_128-response_64):.3g}); this is consistent with the paper's approximate 67%, not a source-reported exact value."
        },
        {
            "name": "unbounded_support_positivity_caveat_recorded",
            "passed": "uniform" in config.get("positivity_review_note", "") and "unbounded" in config.get("positivity_review_note", ""),
            "details": "Confirms that the full-support Gaussian/logistic specification is not incorrectly described as satisfying a uniform overlap/complete-case probability bound."
        },
        {
            "name": "missingness_interaction_parameter",
            "passed": config.get("missing_a_x2") == 1.0 and config.get("missing_a") == 1.5,
            "details": "Confirms logit P(R1=1|X1,X2,A) includes A*(1.5+X2), including the explicit A*X2 interaction."
        }
    ]
    return {
        "passed": all(c["passed"] for c in checks),
        "checks": checks,
        "shared_components": "The verifier uses a separate expression for the ATE coefficient contrast and a separate Gauss-Hermite implementation for the response-rate diagnostic. It necessarily shares the source-defined equations and configuration with generator.py/truth.py; this is not an independent-person reproduction.",
        "response_rate_error_note": "The quadrature convergence difference is a numerical diagnostic, not a rigorous uniform bound."
    }
