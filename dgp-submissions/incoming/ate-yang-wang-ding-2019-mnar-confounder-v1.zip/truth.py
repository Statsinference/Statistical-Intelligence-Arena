"""Analytic population ATE from Section 5.2 potential-outcome equations."""
import math


def truth(config):
    """Return E[Y(1)-Y(0)] for intervention A: 0 -> 1 in the full population."""
    mean_x1 = float(config["x1_mean"])
    mean_x2 = float(config["x2_probability"])
    contrast_intercept = float(config["y1_intercept"]) - float(config["y0_intercept"])
    contrast_x1 = float(config["y1_x1"]) - float(config["y0_x1"])
    contrast_x2 = float(config["y1_x2"]) - float(config["y0_x2"])
    value = contrast_intercept + contrast_x1 * mean_x1 + contrast_x2 * mean_x2
    if not math.isfinite(value):
        raise ValueError("ATE calculation produced a non-finite result")
    return {
        "value": float(value),
        "estimated_error": 0.0,
        "method": "Analytic coefficient contrast; no Monte Carlo or numerical integration is used.",
        "derivation": "Y(1)-Y(0)=(y1_intercept-y0_intercept)+(y1_x1-y0_x1)*X1+(y1_x2-y0_x2)*X2+eps1-eps0. Use the covariate means and zero-mean errors.",
        "target": "ATE = E[Y(1)-Y(0)] for intervention A: 0 (control) -> 1 (active), averaged over the full population before X1 missingness.",
        "error_interpretation": "Zero arithmetic/numerical error for the declared analytic formula; this does not resolve the source's unspoken cross-independence convention for the errors."
    }
