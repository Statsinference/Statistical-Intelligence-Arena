# ATE DGP contribution: one confounder subject to missingness

**Status: candidate; not scientifically accepted.** This is a synthetic mechanism, not a `real_data_claim`. No PFN is trained or evaluated.

## Source and reconstruction

Yang, S., Wang, L. and Ding, P. (2019), “Causal inference with confounders missing not at random,” *Biometrika* 106(4), 875–888. DOI: [10.1093/biomet/asz048](https://doi.org/10.1093/biomet/asz048). The actual journal-version electronic reprint was read as a 27-page PDF. The target DGP is Section 5.2, “One confounder subject to missingness,” unnumbered prose across journal pp. 884–885 (PDF reader pp. 10–11 of 27). The source defines the ATE in Section 2.1 and the outcome-independent missingness assumption in Section 2.3. The 13-page supplementary PDF was also read: it contains extra causal diagrams, proofs, estimator details and Bayesian-estimation material, but no additional Section 5.2 DGP parameters were found. PDF screenshot rendering attempts returned a cache error; page locators were checked using the accessible text extraction and the printed page labels.

The complete source mechanism, in generation order:

1. **Baseline confounders:** `X1 ~ Normal(mean=1, variance=1)` and `X2 ~ Bernoulli(0.5)`. Section 5.2 gives their marginal laws but does not explicitly state the joint dependence. The executable candidate draws them independently; the approximately 67% response rate reported in the paper is consistent with this choice but does not uniquely prove it. This needs maintainer/scientific confirmation.
2. **Potential outcomes:** `Y(0) = 0.5 + 2*X1 + X2 + epsilon(0)` and `Y(1) = 3*X1 + 2*X2 + epsilon(1)`, with each marginal error law `epsilon(a) ~ Normal(0,1)`. Thus the error variance is 1 for each potential outcome.
3. **Treatment assignment:** `A | X1,X2 ~ Bernoulli(pi)` with `logit(pi) = 1.25 - 0.5*X1 - 0.5*X2`.
4. **Missingness indicator:** `R1 | X1,X2,A ~ Bernoulli(p)` with `logit(p) = -2 + 2*X1 + A*(1.5 + X2)`. `R1=1` means X1 is observed, `R1=0` means X1 is missing. The logit includes the explicit interaction `A*X2`. The paper reports an average response rate of about 67%, not an exact value; independent integration under these parameters gives about 0.673410.
5. **Observed outcome and rows:** `Y = A*Y(1) + (1-A)*Y(0)`. Full-data individuals are iid; within an individual, X1 and X2 determine treatment, both potential-outcome means and the missingness probability. Missingness depends on X1 itself, so it is MNAR, but the mechanism is outcome-independent conditional on `(A,X)` as in Assumption 6. There is no interference or clustering.

The paper's Section 5.1 says the study used sample sizes n=400, 800, 1600, 2,000 Monte Carlo samples per sample size, 100 imputed data sets for MI estimators, and 500 bootstrap replicates for variance estimates. Those are study-evaluation choices, not additional DGP parameters. This contribution implements the fixed equations and uses the required local smoke test at n=128 instead of reproducing the full paper experiment.

## Source fidelity and adaptations

- The marginal laws and all numerical coefficients above are transcribed from Section 5.2. Two joint laws are **not fully specified in that paragraph**: (a) dependence between X1 and X2, and (b) dependence between `epsilon(0)`, `epsilon(1)` and X. To make the executable generator well-defined, this implementation draws X1 and X2 independently and draws each potential-outcome error independently of the other and X. These conventions are adaptations pending scientific confirmation; please confirm or supply a more explicit source statement.
- The collection worker only accepts finite numeric values. It rejects NaN, so exported `X1` is set to the sentinel `0.0` when `R1=0`; the explicit `R1` column marks the value as missing. If `R1=1`, `X1` is the original generated value. This is a representation adaptation, not stochastic imputation; never interpret `X1=0` without consulting `R1`.
- `generator.py` generates an independent implementation. The paper's authors' original code was not used; no authors' code commit is claimed.
- The ATE oracle is analytic. The response-rate integral in `verify.py` is a diagnostic for the paper's “about 67%” statement, not a target estimand and not used as the ATE truth.

## Target and identification

The target is the full-population ATE under intervention `A=1` versus `A=0`, before covariate missingness:

`ATE = E[Y(1)-Y(0)]`.

The paper states consistency and conditional exchangeability `{Y(0),Y(1)} independent of A given X`, as well as bounded treatment positivity in Assumption 2 of Section 2.1. The missingness setup uses outcome-independent missingness `R independent of Y given (A,X)` (Assumption 6 in Section 2.3). The logistic probabilities are strictly between 0 and 1 at every finite covariate value, but with unbounded Gaussian support they do not satisfy a uniform lower/upper bound over all X. Likewise, the specified missingness logit cannot ensure the uniform complete-case lower bound in Assumption 7. Assumption 8 (bounded completeness) also needs separate review. Thus the parameterized simulation has a known DGP oracle, but this alone does not establish that every formal identification condition in the paper's theorem holds. This mismatch is explicitly unresolved and should be reviewed by the maintainer.

## Truth and independent verification

From the two potential outcomes,

`Y(1)-Y(0) = -0.5 + X1 + X2 + epsilon(1)-epsilon(0)`.

Since `E[X1]=1`, `E[X2]=0.5` and the errors have zero means,

`ATE = -0.5 + 1 + 0.5 = 1`.

`truth.py` reports `value=1.0` and `estimated_error=0.0`; this is analytic, conditional on the declared zero-mean errors, not a Monte Carlo estimate. `verify.py` independently computes the contrast of the marginal potential-outcome means, checks all fixed source parameters, checks the explicit missingness interaction, calculates the response rate using a separate Gauss-Hermite implementation, and includes a verifier-only zero-effect special case by making the two potential-outcome mean functions equal. The verifier shares the specified source equations/configuration, so this is not an independent-person reproduction.

## Data and properties

Only `X1`, `X2`, `A`, `Y`, and `R1` are exported. No `Y(0)`, `Y(1)`, errors, probabilities, or ATE is an observed input column. `X1` is a numeric masked value with sentinel 0 when `R1=0`, as required by the collector's finite-numeric interface. Dimension = 2; effective dimension = 2; high-dimensional = false. Interactions = true due to `A*X2` in the missingness logit. Nonlinear = true due to the logistic links in the treatment and missingness equations.

## Rights, supplementary material and open issues

The journal article remains under its applicable copyright. This package distributes no paper PDF or original-author code. The publisher's supplementary PDF (13 pages) was read; it contains additional proofs, causal diagrams, estimator details and Bayesian estimation, but no additional parameters for this Section 5.2 DGP were identified. Its Bayesian scalar-confounder illustration is a separate estimation example, not the parameter list for Section 5.2. The webpage PDF screenshot tool returned a cache error, so visual screenshot verification was unavailable; textual PDF extraction includes printed page markers. Outstanding items: scientific confirmation of X1-X2 independence and error cross-independence conventions; confirmation that sentinel encoding is acceptable to maintainers; review of the formal uniform-positivity mismatch; and a second-person reproduction. Machine checks do not constitute named scientific review, permission, or scientific acceptance. No PFN, bootstrap/coverage study, GitHub upload, PR or external message was run/sent.
