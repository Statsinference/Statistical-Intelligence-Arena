# 随机处理与稀有个体响应

Contributor: 张佳怡. Task family: ate. Status: runnable candidate pending named scientific review and independent-person reproduction.

## Source and version

Stefan Wager and Susan Athey (2018). Estimation and Inference of Heterogeneous Treatment Effects using Random Forests. Journal of the American Statistical Association 113(523):1228–1242. DOI: https://doi.org/10.1080/01621459.2017.1319839.
Actual reading version: arXiv:1510.04342v4, submitted revision 2017-07-10; PDF title date July 11, 2017; 48-page prepublication version of the JASA article.
Source URL: https://arxiv.org/pdf/1510.04342v4
Exact location: arXiv:1510.04342v4 Appendix B, PDF p.31, unnumbered paragraph beginning “We are in a randomized controlled trial”, equation Yi=2WiAi+epsilon_i and noise/Bernoulli definitions
Locators use one-based PDF page numbers. Journal page numbers are separately labeled; supplement pages are not main-paper pages.
Local verification source SHA-256: 4ce3bc946f2f3aae9f0d2a485e5f6632b7e5cfd94639f4b50edd6347bb219e6a. The source PDF is retained outside the submission ZIP.
Version and scope differences: Actual reading version is explicitly arXiv v4, not the 15-page JASA typeset article. Its page/equation references and appended material belong to v4. Publisher identity/DOI are verified; equation-by-equation equivalence to the publisher layout has not been asserted. Source conditional-effect targets are adapted to population ATE; rare-response source effect is already constant.
No author software is copied or used to fill parameters. Repository/file/function/commit citations are therefore not applicable; all implementations are independently written from the cited equations.

## Original generation order and fixed parameters

1. X~Uniform([0,1]^10); A~Bernoulli(0.5), independent of X.
2. B~Bernoulli(0.05), epsilon~N(0,0.1**2), independent of X,A and each other.
3. Y=2*A*B+epsilon. Source W is treatment A here; source A_i is the latent response indicator B, not a baseline covariate.

Fixed configuration: `{"dimension": 10, "noise_sd": 0.1, "treatment_probability": 0.5, "response_probability": 0.05, "response_magnitude": 2.0}`.
Original source sample size is recorded in collection.json as context. The generate interface deliberately accepts n and seed, and the required smoke check uses n=128; this is not a recreation of the paper's estimator performance experiments.
Sampling units are independent individuals, with no interference, clusters, panels, or shared random coefficients. Random draws for treatment and noise are independent conditional on the generated covariates. Within-person covariate dependence follows the equations above. Potential-outcome residual coupling that is not specified by a source is not inferred: the generator implements its observed conditional law without claiming a unique joint counterfactual law.
The Appendix B statement about independence concerns X versus (W,Y). It cannot mean that treatment W and outcome Y are independent. In the source A_i denotes a rare response, so the implementation renames it B and renames treatment W to A. The noise variance is 0.1 squared, not 0.1.

## Target and identification

Population ATE = E[Y(1)-Y(0)] under the declared full covariate distribution, with treatment levels 1 versus 0. This is not ATT, a trimmed/overlap population, a sample-average realized effect, or a fixed-point CATE. No outcome-dependent sample selection or missingness is introduced.
Identification requires consistency, no interference, conditional exchangeability of treatment and potential outcomes given observed X, and positivity. These are part of the synthetic scientific model, not inferred from machine PASS. For Gaussian logistic mechanisms positivity holds pointwise but there is no uniform overlap bound over unbounded support. No propensity clipping is added unless it is part of the cited original equation.

## Population truth and independent verification

E[Y(1)-Y(0)]=2*E[B]=2*0.05=0.1. Individual responses are 0 or 2; the conditional mean effect is constant 0.1. The treated outcome is a normal mixture, not N(0.1,0.01).
truth.py returns value, estimated_error and method separately from generated rows. verify.py uses independent scalar source fixtures and a separate analytic/numerical integration route, integrates the implemented arm contrast, and checks assignment, covariate and noise distributions. Statistical diagnostics use fixed seeds and explicit broad six-standard-error criteria; they are not coverage tests or mathematical proofs. Gaussian-tail truncation and order-refinement estimates are numerical diagnostics, not uniform error bounds.
The verifier shares the declared scientific equations, configuration, NumPy and the same AI author with the generator. Independent numerical routes reduce implementation risk but do not constitute independent-person reproduction. No named human scientific review is claimed.

## Mechanism identity and properties

All ten observed covariates are irrelevant; effective_dimension=0 and high_dimensional=false. Latent B is never returned. No observed covariate interaction/nonlinear mean is claimed; mixture non-Gaussianity is described separately.
Canonical mechanism family: wager_rare. It is distinguished by its covariate law and/or functional treatment/outcome/noise structure, not by seed, sample size or a mere coefficient change. Source scenarios with the same functional structure are grouped. The final family count is subject to the maintainer's scientific interpretation, with full equations provided for review.

## Adaptations and boundaries

- Population ATE uses the constant source conditional mean effect 0.1; source pointwise forest-inference experiment is not reproduced.
- Source treatment indicator is named A in the observed output; no scientific change.
- Independently implemented Python/NumPy sampler; source estimator fitting and large simulation replications are outside this collection task.
- Rename source rare-response A_i to latent B to avoid confusion with treatment; B is not exported.

RNG is local numpy.random.default_rng(seed); identical seeds reproduce under the recorded Python/NumPy environment. Exact bitwise reproducibility across arbitrary dependency upgrades is not promised. Stable expit/logaddexp implementations are algebraic evaluations, not scientific changes. No clipping of Gaussian covariates, deletion of extreme rows, winsorization or silent finite-value replacement is used. Nonfinite outputs raise errors. Binary treatment is generated without forcing a fixed group size or resampling a missing arm.

## Rights, AI assistance and unresolved review

The scientific equations are attributed to their authors; paper copyrights remain with their respective rights holders. Paper PDFs, author software and original personal records are not redistributed in the ZIP. Implementation licensing is reserved for contributor/maintainer confirmation; no third-party code license is presumed from public accessibility.
AI assistance: literature discovery, source extraction and visual equation review, implementation, analytic derivation, numerical cross-checking, packaging and report drafting. Contributor review is still required before upload. Scientific acceptance, a separate human reproducer, project-wide deduplication and PR checks remain external steps. The local package does not assert any of those outcomes.


## Final source audit
AI source audit completed against the exact local source version and source_map.json. Human scientific acceptance and independent-person reproduction are not claimed. Dependencies are pinned to NumPy 2.3.5; only the original source scenario is registered.
