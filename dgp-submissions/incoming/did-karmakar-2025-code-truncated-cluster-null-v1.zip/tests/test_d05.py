"""Substantive D05 source-law diagnostics, not historical R replay."""
import sys,json,math,pathlib,copy
import numpy as np
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import generator
from truth import truth
from verify import verify
BASE=pathlib.Path(__file__).resolve().parents[1]
CFG=json.loads((BASE/'config.json').read_text())['scenarios']['baseline']
checks=[]
def record(name,ok,**detail):
    checks.append(dict(name=name,passed=bool(ok),**detail))
    if not ok: raise AssertionError(name)
def reject(fn):
    try: fn()
    except (ValueError,TypeError): return True
    return False

# Floor, ceiling, inclusive start/end, shared endpoint and final clipping.
class ExpSequence:
    def __init__(self,x): self.x=iter(x)
    def exponential(self,scale): return next(self.x)
q=generator._damping(ExpSequence([0.9,1.1,0.2,0.1,200]),.1)
record('renewal_zero_wait_floor_ceil_inclusive_overlap',np.flatnonzero(q).tolist()==[0,1,2,3])
q=generator._damping(ExpSequence([97.9,5.1]),.1)
record('renewal_final99_inclusive_clipping',np.flatnonzero(q).tolist()==[97,98])
q=generator._damping(ExpSequence([98.1,.1]),.1)
record('renewal_start99_allowed_before_exit',np.flatnonzero(q).tolist()==[98])
q=generator._damping(ExpSequence([99.1]),.1)
record('renewal_first_start100_break',not q.any())

# Deterministic primitive injection independently fixes all observables.
class Fixed:
    def uniform(self,low,high,size): return np.arange(30)+10.
    def normal(self,size): return np.zeros(size)
    def exponential(self,scale): return 200.
    def choice(self,ids,p):
        expected=1+np.array([10+i for i in ids])+np.mean(np.arange(19,45)//4+2*(np.arange(19,45)%4))
        assert np.allclose(p,expected/expected.sum())
        return ids[-1]
with patch.object(generator.np.random,'default_rng',return_value=Fixed()): d=generator.generate(CFG,30,0)
a=np.array([d[k] for k in list(d)[2:]]).T
t=np.arange(55)
record('source_trend_time20to45_weights_post46_index',np.array_equal(a,np.arange(10,40)[:,None]+t//4+2*(t%4)))
record('group_selection_g_c_layout',d['G']==([0]*9+[1])*3 and d['C']==[1]*10+[2]*10+[3]*10)
record('output_schema57_observed_columns',list(d)==['G','C']+['Y_pre%03d'%i for i in range(1,46)]+['Y_post%03d'%i for i in range(1,11)])

x=generator.generate(CFG,30,42)
record('local_seed_repeat',x==generator.generate(CFG,30,42))
record('seed_changes_panel',x!=generator.generate(CFG,30,43))
np.random.seed(818); state=np.random.get_state(); generator.generate(CFG,30,15); later=np.random.get_state()
record('global_numpy_rng_untouched',state[0]==later[0] and np.array_equal(state[1],later[1]) and state[2:]==later[2:])
for n in (0,29,31,30.,True,None): record('invalid_n_'+repr(n),reject(lambda n=n:generator.generate(CFG,n,0)))
for seed in (-1,True,1.5,None): record('invalid_seed_'+repr(seed),reject(lambda seed=seed:generator.generate(CFG,30,seed)))
for key in CFG:
    bad=copy.deepcopy(CFG); bad[key]=None
    record('invalid_config_'+key,reject(lambda bad=bad:generator.generate(bad,30,0)))
record('reject_extra_config',reject(lambda:generator.generate(dict(CFG,x=1),30,0)))
record('truth_exact_null',truth(CFG)['value']==0 and truth(CFG)['estimated_error']==0 and verify(CFG)['passed'])

# Statistical diagnostics from3000 independent complete panels.
# Track actual conditional categorical probabilities without changing draws.
original=np.random.default_rng
residual=np.zeros(30); variance=np.zeros(30); pre1=np.zeros(3); zeros=np.zeros(3); panels=3000
class Tracked:
    def __init__(self,seed): self.r=original(seed); self.ps=[]
    def __getattr__(self,key): return getattr(self.r,key)
    def choice(self,ids,p): self.ps.append((ids.copy(),p.copy())); return self.r.choice(ids,p=p)
for seed in range(panels):
    r=Tracked(seed)
    with patch.object(generator.np.random,'default_rng',return_value=r): d=generator.generate(CFG,30,seed)
    y=np.array([d[k] for k in list(d)[2:]]).T; g=np.array(d['G'])
    assert y.shape==(30,55) and np.isfinite(y).all() and (y>=0).all()
    assert all(g[j*10:(j+1)*10].sum()==1 for j in range(3))
    expected=1+y[:,19:45].mean(axis=1)
    for ids,p in r.ps:
        assert np.allclose(p,expected[ids]/expected[ids].sum(),atol=1e-15)
        residual[ids]+=g[ids]-p; variance[ids]+=p*(1-p)
    pre1+=y[:,0].reshape(3,10).mean(axis=1)
    zeros+=(y[:,0].reshape(3,10)==0).mean(axis=1)
record('3000panel_support_groups_probability_formula',True,panels=panels)
z=residual/np.sqrt(variance)
record('conditional_assignment_martingale_standardized',np.max(np.abs(z))<4.5,max_abs_z=float(np.max(np.abs(z))))
# Independent Gaussian-positive-part integration over U(10,60).
def pos(m):
    return m*.5*(1+math.erf(m/5/math.sqrt(2)))+5/math.sqrt(2*math.pi)*math.exp(-.5*(m/5)**2)
a=np.linspace(10,60,10001)
mu0=np.trapezoid([pos(v) for v in a],a)/50 if hasattr(np,'trapezoid') else np.trapz([pos(v) for v in a],a)/50
mud=np.trapezoid([pos(v-80) for v in a],a)/50 if hasattr(np,'trapezoid') else np.trapz([pos(v-80) for v in a],a)/50
rates=np.array([.1,1/15,1/7]); qprob=1-np.exp(-rates); expected=(1-qprob)*mu0+qprob*mud
record('initial_state_group_rate_distribution',np.max(np.abs(pre1/panels-expected))<1.0,empirical=(pre1/panels).tolist(),expected=expected.tolist())
record('group1_damping_at_time1_possible',zeros[0]>0,zero_fraction=(zeros/panels).tolist())
out={'passed':all(x['passed'] for x in checks),'checks':checks,'panels':panels,'scope':'Independent diagnostics against static source equations and analytic expectations; root independent scientific review pending; no author-code execution'}
(BASE/'checks/independent_audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'passed':out['passed'],'checks':len(checks),'panels':panels}))
