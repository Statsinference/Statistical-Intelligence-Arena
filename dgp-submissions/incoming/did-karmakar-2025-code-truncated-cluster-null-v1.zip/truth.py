"""Sharp-null scalar ATT and SATT; no Monte Carlo or generator imports."""

def truth(config):
    expected={"scenario":"official_code_null_id1","units":30,"clusters":3,"cluster_size":10,"generated_periods":99,"T_pre":45,"T_post":10,"similarclus":0,"hetero":True}
    if type(config)!=dict or set(config)!=set(expected) or any(type(config[k]) is not type(v) or config[k]!=v for k,v in expected.items()):
        raise ValueError("Unsupported configuration")
    return {"value":0.0,"estimated_error":0.0,"method":"Exact pathwise sharp null in official2024 code id1: Eff=(0,0,0), hence every post contrast and ATT=SATT=0"}
