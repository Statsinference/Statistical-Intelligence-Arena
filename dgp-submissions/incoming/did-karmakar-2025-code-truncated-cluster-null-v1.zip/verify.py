"""Independent deterministic counterfactual null calculation; no hook imports."""
import math

def verify(config):
    expected={"scenario":"official_code_null_id1","units":30,"clusters":3,"cluster_size":10,"generated_periods":99,"T_pre":45,"T_post":10,"similarclus":0,"hetero":True}
    if type(config)!=dict or set(config)!=set(expected) or any(type(config[k]) is not type(v) or config[k]!=v for k,v in expected.items()):
        raise ValueError("Unsupported configuration")
    contrasts=[]
    # Evaluate source's effect placement independently across boundary examples.
    for z in (-100,-1,0,1,100):
        for damped in (False,True):
            untreated=max(z,0)
            treated=untreated+(0 if not damped else 0)
            contrasts.append(treated-untreated)
    # Arbitrary outcome-dependent selection weights cannot alter a zero contrast.
    weighted=math.fsum(w*d for w,d in zip(range(1,11),contrasts))/55
    checks=[{"name":"post_truncation_null_all_boundaries","passed":all(x==0 for x in contrasts)},
            {"name":"selection_weighted_null","passed":weighted==0,"value":weighted},
            {"name":"period_group_averaging_null","passed":sum(contrasts*3)==0}]
    return {"passed":all(x["passed"] for x in checks),"checks":checks,"scope":"Independent exact null diagnostic; sampling mechanism tested separately"}
