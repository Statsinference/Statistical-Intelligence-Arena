import math
from statistics import NormalDist

def truth(config):
    v=config['x_query'][0]
    m=math.sin(math.pi*v)/(math.pi*v) if v else 1.0
    value=m+config['noise_sd']*NormalDist().inv_cdf(config['tau'])
    return {"value":float(value),"estimated_error":1e-12,"error_interpretation":"Floating-point and bisection diagnostic; not a rigorous uniform error bound"}
