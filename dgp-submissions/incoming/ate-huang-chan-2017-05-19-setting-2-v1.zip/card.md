# 变换观测特征与潜在正态线性结果

Contributor: 张佳怡. Task family: ate. Status: runnable candidate pending named scientific review and independent-person reproduction.

## Source and version

Ming-Yueh Huang and Kwun Chuen Gary Chan (2017). Joint sufficient dimension reduction and estimation of conditional and average treatment effects. Biometrika 104(3):583–596. DOI: https://doi.org/10.1093/biomet/asx028.
Actual reading version: Published typeset article plus author supplementary material asx028_supp.pdf from Europe PMC deposit PMC5793490.
Source URL: https://faculty.washington.edu/kcgchan/papers/ate_dr.pdf
Exact location: Supplement asx028_supp.pdf Section 3.1, PDF/printed p.4, unnumbered Setting 1 and Setting 2 paragraphs; Section 3.4 PDF/printed p.6 for both reported ATEs = 1; main article Section 2.1 PDF p.3 / journal p.585 for estimand and assumptions; collected second setting
Locators use one-based PDF page numbers. Journal page numbers are separately labeled; supplement pages are not main-paper pages.
Local verification source SHA-256: dd0dd599f991aede34d8396dafdac0bcc6291704c857d779846a986b6e24e725. The source PDF is retained outside the submission ZIP.
Version and scope differences: Main paper and supplement are separated in all locators. No preprint parameters substituted. The second setting uses epsilon_0, epsilon_1 defined immediately above in the same settings paragraph; its variance is 1/10, hence SD sqrt(1/10), not 1/10. This scope reading is explicitly recorded for human review.
No author software is copied or used to fill parameters. Repository/file/function/commit citations are therefore not applicable; all implementations are independently written from the cited equations.

## Original generation order and fixed parameters

1. Z1,...,Z10 iid N(0,1).
2. X1=exp(Z1/2); X2=Z2/(1+exp(Z1)); X3=(Z1*Z3/25+3/5)**3; X4,...,X10=Z4,...,Z10.
3. p(X)=expit(X1-X2+X3); A|X~Bernoulli(p).
4. Y(1)=1+Z1+epsilon1; Y(0)=Z2+epsilon0; epsilon0,epsilon1 as defined in the same paragraph, N(0,1/10) independently; Y=A*Y(1)+(1-A)*Y(0).

Fixed configuration: `{"dimension": 10, "noise_sd": 0.31622776601683794, "propensity_coefficients": [1.0, -1.0, 1.0], "intercept_treated": 1.0, "intercept_control": 0.0, "transform_divisor": 25.0, "transform_offset": 0.6}`.
Original source sample size is recorded in collection.json as context. The generate interface deliberately accepts n and seed, and the required smoke check uses n=128; this is not a recreation of the paper's estimator performance experiments.
Sampling units are independent individuals, with no interference, clusters, panels, or shared random coefficients. Random draws for treatment and noise are independent conditional on the generated covariates. Within-person covariate dependence follows the equations above. Potential-outcome residual coupling that is not specified by a source is not inferred: the generator implements its observed conditional law without claiming a unique joint counterfactual law.
The noise variance in Setting 2 is taken from the epsilon definitions in the immediately preceding sentences of the same paragraph. This is a documented scope interpretation, not a guessed fresh variance. A human reviewer should confirm this reading before scientific acceptance.

## Target and identification

Population ATE = E[Y(1)-Y(0)] under the declared full covariate distribution, with treatment levels 1 versus 0. This is not ATT, a trimmed/overlap population, a sample-average realized effect, or a fixed-point CATE. No outcome-dependent sample selection or missingness is introduced.
Identification requires consistency, no interference, conditional exchangeability of treatment and potential outcomes given observed X, and positivity. These are part of the synthetic scientific model, not inferred from machine PASS. For Gaussian logistic mechanisms positivity holds pointwise but there is no uniform overlap bound over unbounded support. No propensity clipping is added unless it is part of the cited original equation.

## Population truth and independent verification

E[Z1]=E[Z2]=0, so ATE=1. Conditional means in observed coordinates are 1+2*log(X1) and X2*(1+X1**2). Thus mean exchangeability can be stated given observed X; latent generation does not imply hidden confounding here.
truth.py returns value, estimated_error and method separately from generated rows. verify.py uses independent scalar source fixtures and a separate analytic/numerical integration route, integrates the implemented arm contrast, and checks assignment, covariate and noise distributions. Statistical diagnostics use fixed seeds and explicit broad six-standard-error criteria; they are not coverage tests or mathematical proofs. Gaussian-tail truncation and order-refinement estimates are numerical diagnostics, not uniform error bounds.
The verifier shares the declared scientific equations, configuration, NumPy and the same AI author with the generator. Independent numerical routes reduce implementation risk but do not constitute independent-person reproduction. No named human scientific review is claimed.

## Mechanism identity and properties

Three observed covariates affect assignment/outcomes. Do not add +10 to X2 and do not square X4: those are different Kang–Schafer variants, not this source. Internal Z1–Z3 are not learner inputs. Noise definition is inherited from the immediately preceding sentence; this explicit scope interpretation is flagged for human review.
Canonical mechanism family: huang_transformed. It is distinguished by its covariate law and/or functional treatment/outcome/noise structure, not by seed, sample size or a mere coefficient change. Source scenarios with the same functional structure are grouped. The final family count is subject to the maintainer's scientific interpretation, with full equations provided for review.

## Adaptations and boundaries

- Source treatment indicator is named A in the observed output; no scientific change.
- Independently implemented Python/NumPy sampler; source estimator fitting and large simulation replications are outside this collection task.
- Setting 2 epsilon definitions are read as inherited from Setting 1 in the same paragraph; this explicitly documented scope reading needs human confirmation.

RNG is local numpy.random.default_rng(seed); identical seeds reproduce under the recorded Python/NumPy environment. Exact bitwise reproducibility across arbitrary dependency upgrades is not promised. Stable expit/logaddexp implementations are algebraic evaluations, not scientific changes. No clipping of Gaussian covariates, deletion of extreme rows, winsorization or silent finite-value replacement is used. Nonfinite outputs raise errors. Binary treatment is generated without forcing a fixed group size or resampling a missing arm.

## Rights, AI assistance and unresolved review

The scientific equations are attributed to their authors; paper copyrights remain with their respective rights holders. Paper PDFs, author software and original personal records are not redistributed in the ZIP. Implementation licensing is reserved for contributor/maintainer confirmation; no third-party code license is presumed from public accessibility.
AI assistance: literature discovery, source extraction and visual equation review, implementation, analytic derivation, numerical cross-checking, packaging and report drafting. Contributor review is still required before upload. Scientific acceptance, a separate human reproducer, project-wide deduplication and PR checks remain external steps. The local package does not assert any of those outcomes.


## Final source audit
AI source audit completed against the exact local source version and source_map.json. Human scientific acceptance and independent-person reproduction are not claimed. Dependencies are pinned to NumPy 2.3.5; only the original source scenario is registered.
The epsilon definition in the same Section 3.1 paragraph continues into Setting 2: N(0,1/10) means variance 0.1, implemented with SD sqrt(0.1). This was checked against the full paragraph, not supplied as a missing parameter.
