# Ye / 异方差弱无效 IV

状态：candidate；认领/查重尚未由维护人确认；不是八个已验收family。

## 7. 认领、原文定位与八份文件

Ye T, Liu Z, Sun B, Tchetgen Tchetgen E (2024). GENIUS-MAWII: For robust Mendelian randomization with many weak invalid instruments. JRSS-B 86(4):1045–1067. DOI:10.1093/jrsssb/qkae024.

原始来源：https://arxiv.org/pdf/2107.06238v3

阅读版本：页面页首核实为arXiv v3，2024-02-24；显式v3 URL前轮曾超时，本轮v3 PDF可读。定位：§2识别；§6.1未编号生成方程与四组SNP比例；§6.2/补充材料仅作范围核对。阅读范围为识别条件、目标与DGP相关正文/可访问补充段落，不声称逐行审阅全篇证明。

### 已核对机制与参数出处

Zj~Binomial(2,.5)，j=1…100；A=ΣγjZj+U+(1+ΣδjZj)εA；Y=.4A+ΣαjZj+U+εY。U~N(0,.6(1−h²))，εA,εY~N(0,.4(1−h²))；h²=.2，κ=1。

§6.1：γ=φγ√(h²/1.5m)，δ=φδκ√(h²/1.5m)，φ一次抽取N(0,1)；α为0、N(√τ²,τ²)或γ/2；τ²=h²/1.5m；四组比例(1,0,0)、(.6,.2,.2)、(.1,.9,0)、(.1,0,.9)。

目标：β0=.4；do(A=a+1)相对do(A=a)的均值变化。抽样单位：独立个体。

识别条件：Z与潜在U独立；GENIUS加性结构限制；异方差相关矩非退化；不要求所有SNP满足排除限制。

### 缺失与所需补充

- `author_frozen_coefficients_and_seed` — not_reported_in_read_text：原文规定一次抽取规则，未列出原表使用的具体向量和种子。此实现会公开固定新实现化，不声称复现原表。 需要：如要逐值复现论文表格，需作者参数快照/种子及commit；机制分布本身可按原规则实现。

## 8. 检查与失败保留

四个场景均已实现；未知作者原始冻结向量属于原表复现缺口，不把当前已实现hooks称为未实现。实际命令、退出码及失败历史保留在总目录logs/history，当前报告由官方collect.py产生。

## 9. 交付与科学状态

仅当前检查通过的贡献可pack；失败候选不生成提交ZIP。若有ZIP，其SHA-256在总目录清单。未执行submit、外部上传、发消息或PR；没有项目组收件回执。所有机制仍待具名科学审核和另一人的独立复现。

## 10. 真实数据分支

本条是synthetic_dgp，不认领真实数据，不适用real_data_claim；未使用UK Biobank个体数据或LD分支。

权利与AI协助：AI辅助定位/提取/代码，非具名科学审核；不分发论文PDF、原始敏感数据、凭据、数据银行或权重。训练PFN、bootstrap、coverage和大规模超分布均未执行。


## 本轮实现：原分布规则下的新固定实现化

四个`setting*_new_draw`场景全部保留。按原文一次抽系数规则，用Python局部RNG种子104729生成并将全部向量写入config；原作者固定向量未知，此改动明确标adapted_from_source，不声称重现论文表格。SNP类型使用固定索引块，比例完全按§6.1。只导出100列Z、A、Y，不导出U、噪声、oracle nuisance或个体效应。

真值：固定Z/U/结局误差，干预A增加1使Y增加β=.4，故truth=.4、estimated_error=0（解析恒等式）。令R=A−E(A|Z)，Cov(Zj,E[RY|Z])/Cov(Zj,E[RA|Z])=β；混杂项ηAηY Var(U)不依赖Z，协方差消除。分母为var_eA·δj·(1+Σδ)。verify用实际generator的受控符号立方体精确再现所需正态前两阶矩，另以独立分母公式核对；零因果路径与零异方差特例也核验。误差阈值预先固定1e−10，不随失败放宽。共享同一模型/config和实际generator，非独立人员复现，也不证明完整分布尾部。

无观察基线协变量，总/有效基线维数均0；100个活跃工具变量另行注明，不称为100维混杂。交互为δj Zj εA；不加入U×Z的其他新结构，不使用UK Biobank真实SNP或LD分支。


## 第7节固定贡献格式：本次整理与代码审阅

任务类别：IV；kind：synthetic_dgp。认领/查重材料已整理在总目录《认领与查重表.md》，尚未发送维护人，未获认领或科学接收。

| 文件 | 本贡献内容与检查范围 |
|---|---|
| `collection.json` | 来源citation/期刊年/版本定位、IV目标、假设、属性、入口及adaptation关系。 |
| `card.md` | 保留上述方程、参数出处、噪声、抽样单位、推导、权利及缺口；本附录记录整理改动。 |
| `config.json` | 种子104729生成一次新gamma/delta/alpha并冻结；原作者向量未给，固定索引块保持来源四组比例。四场景合为一个family。 |
| `schema.csv` | 只声明实际观察列；角色、数值类型、上下界与输出一致。 |
| `generator.py` | generate(config,n,seed)；局部RNG；支持config关键字；不输出潜变量或oracle。 |
| `truth.py` | truth(config)返回value、estimated_error；目标与干预方向以上文为准。 |
| `verify.py` | verify(config)返回passed、checks；共享模型/生成器的局限保留，不等于另一人复现。 |
| `requirements.txt` | 依赖及版本范围；不使用作者电脑绝对路径。 |

声明场景：`setting1_new_draw`、`setting2_new_draw`、`setting3_new_draw`、`setting4_new_draw`。

属性：总协变量维数=0，有效维数=0；含义：No baseline observed covariates: dimension/effective_dimension=0. There are 100 active candidate instruments (not 100 observed confounders). Explicit product delta_j*Z_j*epsilon_A creates heteroskedasticity; outcome mean is linear. No claim of high-dimensional confounding.

参数调用示例（不要把整个config.json对象传给hook）：

```python
import json
from generator import generate
from truth import truth
from verify import verify
with open("config.json", encoding="utf-8") as f:
    settings = json.load(f)
params = settings["scenarios"][settings["default_scenario"]]
observed = generate(config=params, n=128, seed=1729)
result = truth(config=params)
validation = verify(config=params)
```

本次仅修正入口契约/输入报错、数值稳定性和核验覆盖，统一文本换行，并补充整理信息；不改来源方程、场景数、已声明目标、维度标签或tolerance。具体改动/未决事项见总目录《代码审阅报告.md》。所有有改动的源文件均重新check/pack，旧报告保存在history并明确不代表当前状态。未训练PFN、未运行作者R、未外发、未执行submit。


## 来源逐文件审核修正 r3

arXiv:2107.06238v3，2024-02-24；PDF物理22–23页§6.1 A/Y生成方程、噪声、系数一次抽取规则和四种SNP比例；§2识别。显式v3 PDF本轮可读。

参数定位：§6.1物理22–23页：m100,h²=.2,kappa1；gamma/delta为一次标准正态抽样乘sqrt(.2/150)；U方差.48，epsilonA/Y方差.32；beta.4，etaA=etaY=1；四组比例(1,0,0)/(.6,.2,.2)/(.1,.9,0)/(.1,0,.9)。

本轮修正：

- 明确v3页码并清除“当前hooks未实现”和无关Zhao模板遗留文字。
- 除GENIUS矩比外加入实际生成器的条件均值、Var(A)、Cov(A,Y)、Var(Y)及SNP边缘分配核验。
- 核对四组冻结系数可由公开Python seed104729重建；不冒充原作者参数快照。

保留未决：

- 作者原始固定向量/seed未提供；目前是同分布规则下新实现，不复现原表。
- 期刊终版与所读v3尚未逐式比较；标准化矩核验不证明全部高斯尾部。

详细八份文件对照见本贡献source_audit.md/json。新增核验是共享模型下的独立计算路线，不是具名科学审核或另一人复现。保持原scenario数量、所选机制和tolerance；验证用零路径不作为新场景。后续实际check/pack结果以本轮总清单与checks/report.json为准。


## 八部分标准修正 r4（2026-10-30）

基线维数口径：baseline=[]，dimension=0、effective_dimension=0。工具变量、处理后变量和重复时点不计作基线协变量。标签参考n_ref=128个独立受试者，p/n_ref=0.00000000；high_dimensional=false仅按所述基线口径和参考设置解释。实际n仍由接口传入，不对任意n/p扩展作高维承诺。

依赖：Python>=3.10；无第三方必需依赖；无可选依赖、训练/GPU依赖。独立干净环境安装与运行证据在本目录dependency_check.json及总目录logs/eight-parts-r4；仅宣称实际测试的平台/版本，不宣称覆盖所有Python或NumPy版本。

干净安装实际结果：本贡献独立venv初始无NumPy、未继承系统site-packages；按requirements.txt安装退出0，pip check退出0；测试Python 3.12.14，NumPy None。详见dependency_check.json；模型运行以随后正式check为准。


## 2026-10-31：严格示例格式整理

文件布局与指定单DGP示例一致。CLAIM.md记录真实的待认领状态，environment.json记录本贡献实测运行环境。既有source_audit.md、missing_parameters.json、dependency_check.json及网络interface_claim.md没有丢弃，完整内容合并保存在source_audit.json的format_revision_20261031.merged_supplementary_records。原collection扩展元数据保留在同文件preserved_extension_metadata，含维数参考及网络接口未批准状态。

原机制方程、全部场景参数、schema、generator/truth/verify及依赖逐字不变；本次不是新的原文阅读或科学接收。认领人真实姓名和维护人批准尚未确认。修改元数据后重新执行全部场景check并pack，旧报告不复用为本轮证明。

### 既有逐文件审计记录（原文保留）

# iv-ye-2024-genius-heteroskedastic-v1：八份文件来源核对与修正 r3

实际来源：[Ye T, Liu Z, Sun B, Tchetgen Tchetgen E (2024). GENIUS-MAWII: For robust Mendelian randomization with many weak invalid instruments. JRSS-B 86(4):1045–1067. DOI:10.1093/jrsssb/qkae024.](https://arxiv.org/pdf/2107.06238v3)。

精确定位：arXiv:2107.06238v3，2024-02-24；PDF物理22–23页§6.1未编号A/Y方程、噪声/一次系数抽取和四组比例；§2识别。显式v3 PDF本轮可读；与期刊终版未逐式比较。

参数出处：§6.1物理22–23页：m100,h²=.2,kappa1；gamma/delta为一次标准正态抽样乘sqrt(.2/150)；U方差.48，epsilonA/Y方差.32；beta.4，etaA=etaY=1；四组比例(1,0,0)/(.6,.2,.2)/(.1,.9,0)/(.1,0,.9)。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；arXiv:2107.06238v3，2024-02-24；PDF物理22–23页§6.1 A/Y生成方程、噪声、系数一次抽取规则和四种SNP比例；§2识别。显式v3 PDF本轮可读。 iid individuals conditional on frozen coefficient vectors. One hundred independent Binomial(2,.5) SNPs and mutually independent U/epsilon_A/epsilon_Y; heteroskedastic exposure noise retained. No baseline covariates or LD data. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；§6.1物理22–23页：m100,h²=.2,kappa1；gamma/delta为一次标准正态抽样乘sqrt(.2/150)；U方差.48，epsilonA/Y方差.32；beta.4，etaA=etaY=1；四组比例(1,0,0)/(.6,.2,.2)/(.1,.9,0)/(.1,0,.9)。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；种子104729生成一次新gamma/delta/alpha并冻结；原作者向量未给，固定索引块保持来源四组比例。四场景合为一个family。 |
| `schema.csv` | 102个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid individuals conditional on frozen coefficient vectors. One hundred independent Binomial(2,.5) SNPs and mutually independent U/epsilon_A/epsilon_Y; heteroskedastic exposure noise retained. No baseline covariates or LD data. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic unit exposure effect beta=.4; independently recovered via heteroskedastic covariance ratios and actual-generator conditional first/second moments. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；明确v3页码并清除“当前hooks未实现”和无关Zhao模板遗留文字。；除GENIUS矩比外加入实际生成器的条件均值、Var(A)、Cov(A,Y)、Var(Y)及SNP边缘分配核验。；核对四组冻结系数可由公开Python seed104729重建；不冒充原作者参数快照。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`setting1_new_draw`, `setting2_new_draw`, `setting3_new_draw`, `setting4_new_draw`。

属性方程依据：No baseline observed covariates: dimension/effective_dimension=0. There are 100 active candidate instruments (not 100 observed confounders). Explicit product delta_j*Z_j*epsilon_A creates heteroskedasticity; outcome mean is linear. No claim of high-dimensional confounding.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 作者原始固定向量/seed未提供；目前是同分布规则下新实现，不复现原表。
- 期刊终版与所读v3尚未逐式比较；标准化矩核验不证明全部高斯尾部。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=0/0；baseline=[]。参考n_ref=128（independent subjects），p/n_ref=0.00000000。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
