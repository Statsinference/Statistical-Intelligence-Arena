"""Recover beta through exact conditional noise moments of actual sampler.

Controlled sign cube has exactly Gaussian first/second moments required here.
This is not a Monte Carlo coverage experiment or independent-person review.
"""
import math
import itertools
import json
from pathlib import Path
import importlib.util
from unittest.mock import patch

def _load(file):
    spec=importlib.util.spec_from_file_location('ye_check_'+file,Path(__file__).with_name(file))
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

class _RNG:
    def __init__(self,j,z,signs):self.j=j;self.z=z;self.signs=iter(signs);self.k=0
    def random(self):
        j,b=divmod(self.k,2);self.k+=1
        v=self.z if j==self.j else 1
        return (.1 if b<v else .9)
    def gauss(self,mu,sd):return mu+sd*next(self.signs)

def _moments(gen,c,j):
    variances=[];covariances=[]
    for z in (0,1,2):
        pairs=[]
        for signs in itertools.product((-1,1),repeat=3):
            with patch.object(gen.random,'Random',return_value=_RNG(j,z,signs)):
                data=gen.generate(c,1,1729)
            pairs.append((data['A'][0],data['Y'][0]))
        ma=math.fsum(a for a,y in pairs)/8; my=math.fsum(y for a,y in pairs)/8
        variances.append(math.fsum((a-ma)**2 for a,y in pairs)/8)
        covariances.append(math.fsum((a-ma)*(y-my) for a,y in pairs)/8)
    # Cov(Z, conditional second moment), Z~Binomial(2,.5).
    den=(variances[2]-variances[0])/4
    num=(covariances[2]-covariances[0])/4
    return num,den

def _existing_verify(config):
    if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
    gen=_load('generator.py'); oracle=_load('truth.py')
    checks=[];errors=[]
    # Independent identity for the denominator, compared to actual generator.
    s=1+math.fsum(config['delta'])
    ranked=sorted(range(100),key=lambda j:abs(s*config['delta'][j]),reverse=True)[:3]
    for j in ranked:
        num,den=_moments(gen,config,j)
        expected=config['var_eA']*s*config['delta'][j]
        recovered = num/den if abs(den)>1e-12 else None
        errors.append(abs(recovered-oracle.truth(config)['value']) if recovered is not None else math.inf)
        checks.append({'name':'actual_sampler_moment_ratio_Z'+str(j+1),'passed':abs(den)>1e-12 and abs(den-expected)<1e-12 and errors[-1]<1e-10,
                       'details':{'recovered':recovered,'denominator':den,'denominator_formula':expected}})
    null=json.loads(json.dumps(config));null['beta']=0.
    num,den=_moments(gen,null,ranked[0])
    checks.append({'name':'zero_causal_path','passed':abs(num)<1e-12 and abs(den)>1e-12})
    homo=json.loads(json.dumps(config));homo['delta']=[0.]*100
    num,den=_moments(gen,homo,ranked[0])
    checks.append({'name':'homoskedastic_case_loses_GENIUS_identification','passed':abs(den)<1e-12,'details':'Structural beta remains defined; the GENIUS ratio is not identified here. This is a validation input, not an added collected scenario.'})
    data=gen.generate(config,128,1729)
    checks.append({'name':'no_latent_or_truth_columns','passed':set(data)=={*(f'Z{j+1}' for j in range(100)),'A','Y'}})
    checks.append({'name':'source_noise_and_target_constants','passed':config['beta']==.4 and config['eta_A']==config['eta_Y']==1 and config['var_U']==.48 and config['var_eA']==config['var_eY']==.32})
    return {'passed':all(x['passed'] for x in checks),'checks':checks,'max_ratio_error':max(errors),
            'shared_components':'Same model/config and actual generator are shared. Truth is structural intervention algebra; verify independently recovers beta with heteroskedastic covariance ratios, exercised on the actual sampler using a deterministic sign cube. Other SNPs fixed at their means: their variance contribution is constant in the selected SNP and cancels in this covariance. Gaussian tails/full distribution are not proved by the sign-cube check.'}


def _source_audit_checks(config):
    gen=_load('generator.py')
    error=0.0
    # Conditional moments from an independently written source formula.
    for j,zj in ((0,0),(49,1),(99,2)):
        z=[1]*100
        z[j]=zj
        values=[]
        for signs in itertools.product((-1,1),repeat=3):
            with patch.object(gen.random,'Random',return_value=_RNG(j,zj,signs)):
                row=gen.generate(config,1,0)
            values.append((row['A'][0],row['Y'][0]))
        ma=math.fsum(a for a,y in values)/8
        my=math.fsum(y for a,y in values)/8
        va=math.fsum((a-ma)**2 for a,y in values)/8
        vy=math.fsum((y-my)**2 for a,y in values)/8
        cay=math.fsum((a-ma)*(y-my) for a,y in values)/8
        mean_a=math.fsum(g*x for g,x in zip(config['gamma'],z))
        mean_y=.4*mean_a+math.fsum(a*x for a,x in zip(config['alpha'],z))
        variance_a=.48+.32*(1+math.fsum(d*x for d,x in zip(config['delta'],z)))**2
        variance_y=.4**2*variance_a+.48+.32+2*.4*.48
        covariance=.4*variance_a+.48
        error=max(error,*(abs(a-b) for a,b in zip((ma,my,va,vy,cay),(mean_a,mean_y,variance_a,variance_y,covariance))))
    import random as local_random
    rng=local_random.Random(104729)
    scale=math.sqrt(.2/150)
    gamma=[rng.gauss(0,1)*scale for _ in range(100)]
    delta=[rng.gauss(0,1)*scale for _ in range(100)]
    directional=[rng.gauss(scale,scale) for _ in range(100)]
    options=[]
    for valid,inside in ((100,0),(60,20),(10,90),(10,0)):
        options.append([0.0 if j<valid else directional[j] if j<valid+inside else gamma[j]/2 for j in range(100)])
    frozen=config['gamma']==gamma and config['delta']==delta and config['alpha'] in options
    class SNPGrid:
        def __init__(self):
            self.calls = 0
        def random(self):
            observation, within = divmod(self.calls, 200)
            self.calls += 1
            pair = ((.25,.25),(.25,.75),(.75,.25),(.75,.75))[observation]
            return pair[within] if within < 2 else .75
        def gauss(self,mu,sd):return mu
    with patch.object(gen.random,'Random',return_value=SNPGrid()):
        marginal=gen.generate(config,4,0)
    snp_law=sorted(marginal['Z1'])==[0,1,1,2] and all(marginal['Z'+str(j)]==[0]*4 for j in range(2,101))
    return [
        {'name':'actual_SNP_binomial_two_coin_marginal','passed':snp_law,
         'details':'Four equally weighted coin quadrants give counts 0,1,1,2; this tests sampling map, not a statistical frequency test.'},
        {'name':'source_conditional_means_variances_covariance','passed':error<1e-12,
         'details':{'max_moment_error':error,'Z_cases':3,'sign_cube_points_per_case':8}},
        {'name':'disclosed_seed104729_frozen_coefficient_reconstruction','passed':frozen,
         'details':'Local realization and one of four source proportions; not original author frozen vectors.'}
    ]

def verify(config):
    result = _existing_verify(config)
    result['checks'].extend(_source_audit_checks(config))
    result['passed'] = all(item['passed'] is True for item in result['checks'])
    result['shared_components'] += ' Source-audit additions exercise the same local generator against separate source-equation/moment calculations; no independent-person review or complete distribution proof is claimed.'
    return result
