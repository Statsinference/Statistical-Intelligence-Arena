# 维护人认领/查重材料（待确认）

- 拟贡献ID：`iv-ye-2024-genius-heteroskedastic-v1`；任务：iv；mechanism_family_id：`iv-ye-2024-genius-heteroskedastic`。
- 来源：Ye T, Liu Z, Sun B, Tchetgen Tchetgen E (2024). GENIUS-MAWII: For robust Mendelian randomization with many weak invalid instruments. JRSS-B 86(4):1045–1067. DOI:10.1093/jrsssb/qkae024.
- 链接：https://arxiv.org/pdf/2107.06238v3
- 版本：arXiv:2107.06238v3, 2024-02-24; new fixed vectors; version-of-record equation comparison pending
- 定位：arXiv:2107.06238v3，2024-02-24；PDF物理22–23页§6.1未编号A/Y方程、噪声/一次系数抽取和四组比例；§2识别。显式v3 PDF本轮可读；与期刊终版未逐式比较。
- 声明场景：setting1_new_draw, setting2_new_draw, setting3_new_draw, setting4_new_draw。
- 目标：β0=.4；do(A=a+1)相对do(A=a)的均值变化
- 主要适配：Original Section6.1 structural equations, noise variances and four SNP-type proportions retained. New, fully recorded one-time coefficient realization uses Python random.Random(104729); author frozen coefficient vectors/seed were not supplied in the read text. This does not reproduce published Monte Carlo tables.; SNP type groups use fixed index blocks; SNPs are iid and this is a deterministic labelling of the source proportions. Coefficients fixed across repeated samples, never treated as a new family.; All four settings are declared; small CPU samples n=128 are interface checks, not the original n=10000/100000 estimator experiment. No LD/UK-Biobank or covariate supplement scenarios are claimed.
- 用户截图显示GitHub账号wuwenti已创建PR #10；本文件不表示认领查重已批准或已获科学接收。
- 认领人真实姓名：未提供、未核实；不得用目录用户名代替人工署名。
- 待确认：family正式去重、来源版本对应、权利许可、具名科学审核、另一人独立复现。详细缺口及访问/核验失败记录保留在source_audit.json。

查重提醒：用户提供的IV目录已有同论文/相同或相近机制条目，需维护人决定是否重复；不能因新系数或种子计为新family。
