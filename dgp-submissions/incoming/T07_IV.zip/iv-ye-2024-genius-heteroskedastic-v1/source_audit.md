# iv-ye-2024-genius-heteroskedastic-v1：八份文件来源核对与修正 r3

实际来源：[Ye T, Liu Z, Sun B, Tchetgen Tchetgen E (2024). GENIUS-MAWII: For robust Mendelian randomization with many weak invalid instruments. JRSS-B 86(4):1045–1067. DOI:10.1093/jrsssb/qkae024.](https://arxiv.org/pdf/2107.06238v3)。

精确定位：arXiv:2107.06238v3，2024-02-24；PDF物理22–23页§6.1未编号A/Y方程、噪声/一次系数抽取和四组比例；§2识别。显式v3 PDF本轮可读；与期刊终版未逐式比较。

参数出处：§6.1物理22–23页：m100,h²=.2,kappa1；gamma/delta为一次标准正态抽样乘sqrt(.2/150)；U方差.48，epsilonA/Y方差.32；beta.4，etaA=etaY=1；四组比例(1,0,0)/(.6,.2,.2)/(.1,.9,0)/(.1,0,.9)。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；arXiv:2107.06238v3，2024-02-24；PDF物理22–23页§6.1 A/Y生成方程、噪声、系数一次抽取规则和四种SNP比例；§2识别。显式v3 PDF本轮可读。 iid individuals conditional on frozen coefficient vectors. One hundred independent Binomial(2,.5) SNPs and mutually independent U/epsilon_A/epsilon_Y; heteroskedastic exposure noise retained. No baseline covariates or LD data. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；§6.1物理22–23页：m100,h²=.2,kappa1；gamma/delta为一次标准正态抽样乘sqrt(.2/150)；U方差.48，epsilonA/Y方差.32；beta.4，etaA=etaY=1；四组比例(1,0,0)/(.6,.2,.2)/(.1,.9,0)/(.1,0,.9)。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；种子104729生成一次新gamma/delta/alpha并冻结；原作者向量未给，固定索引块保持来源四组比例。四场景合为一个family。 |
| `schema.csv` | 102个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid individuals conditional on frozen coefficient vectors. One hundred independent Binomial(2,.5) SNPs and mutually independent U/epsilon_A/epsilon_Y; heteroskedastic exposure noise retained. No baseline covariates or LD data. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic unit exposure effect beta=.4; independently recovered via heteroskedastic covariance ratios and actual-generator conditional first/second moments. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；明确v3页码并清除“当前hooks未实现”和无关Zhao模板遗留文字。；除GENIUS矩比外加入实际生成器的条件均值、Var(A)、Cov(A,Y)、Var(Y)及SNP边缘分配核验。；核对四组冻结系数可由公开Python seed104729重建；不冒充原作者参数快照。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`setting1_new_draw`, `setting2_new_draw`, `setting3_new_draw`, `setting4_new_draw`。

属性方程依据：No baseline observed covariates: dimension/effective_dimension=0. There are 100 active candidate instruments (not 100 observed confounders). Explicit product delta_j*Z_j*epsilon_A creates heteroskedasticity; outcome mean is linear. No claim of high-dimensional confounding.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 作者原始固定向量/seed未提供；目前是同分布规则下新实现，不复现原表。
- 期刊终版与所读v3尚未逐式比较；标准化矩核验不证明全部高斯尾部。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=0/0；baseline=[]。参考n_ref=128（independent subjects），p/n_ref=0.00000000。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
