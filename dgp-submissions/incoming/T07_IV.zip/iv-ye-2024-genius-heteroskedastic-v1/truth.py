"""Structural unit-intervention effect; not an observational regression slope."""
def truth(config):
    if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
    return {'value':float(config['beta']),'estimated_error':0.0,
            'method':'Holding Z,U,epsilon_Y fixed, Y(do(A=a+1))-Y(do(A=a))=beta exactly.',
            'error_interpretation':'Analytic identity, no integration error; floating checks recorded separately.'}
