import math
def truth(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 weights=[];p=c['z_probability'];K=2*c['L']
 for g in c['gamma0']:
  if c['model']==2:w=float(g<0<=g+c['gamma1'])
  else:w=sum(math.comb(K,k)*p**k*(1-p)**(K-k) for k in range(K+1) if g+c['gamma2']*k<0<=g+c['gamma2']*k+c['gamma1'])
  weights.append(w)
 den=math.fsum(weights)
 if den<=0:raise ArithmeticError('zero complier relevance')
 value=math.fsum(b*w for b,w in zip(c['beta1'],weights))/den
 return {'value':value,'estimated_error':0.,'method':'Finite-population direct-IV ratio; enumerate binomial neighbor-exposure probabilities for DGP1 and own compliers for DGP2.','complier_weight_sum':den,'error_interpretation':'Analytic finite sum, no Monte Carlo integration; floating diagnostics are in verify.'}
