# 维护人认领/查重材料（待确认）

- 拟贡献ID：`iv-hoshino-2024-ring-network-v1`；任务：iv；mechanism_family_id：`iv-hoshino-2024-ring-network`。
- 来源：Hoshino T, Yanagi T (2024). Causal Inference with Noncompliance and Unknown Interference. JASA 119(548):2869–2880. DOI:10.1080/01621459.2023.2284413.
- 链接：https://arxiv.org/pdf/2108.07455v5
- 版本：arXiv:2108.07455v5, 2023-10-23, Appendix G.1; new frozen coefficient realizations; interface/target adaptation unapproved
- 定位：arXiv:2108.07455v5，2023-10-23：Appendix G.1，PDF物理73–75页，印刷S37–S39；73页DGP1及DGP2方程，74页参数/一次冻结/L=2,3及目标，75页n=500设置。已重新渲染73页并核对后续文字。缓存PDF SHA256 2509e3d53ecb45a1d48f336b68cd720d0f0d6c97ae465a23f970adc1169a3ecf。
- 声明场景：DGP1_L2_new_draw, DGP1_L3_new_draw, DGP2_L2_new_draw, DGP2_L3_new_draw。
- 目标：unconditional_LADE：对他人Z按独立Bern(.4)边缘化后，平均自身结局变化/平均自身处理变化；处理/鼓励1减0的加权complier直接效应。
- 主要适配：Preserve both source network DGPs and L=2/3 as four scenarios in one family, not two new families.; Original N=500 retained. One collection row is an entire network; n=128 means128 independent encouragement experiments on the same fixed network, with all node columns observed. This adapter requires a network-aware benchmark.; Freeze a new disclosed realization of original coefficient distributions; author frozen vector/seed is unavailable.; Use unconditional IEM (constant exposure mapping) and unconditional direct-IV ratio rather than the paper selected t=2/t=1 conditional estimands; derive this target explicitly. No changes to source outcome/treatment mechanisms.
- 用户截图显示GitHub账号wuwenti已创建PR #10；本文件不表示认领查重已批准或已获科学接收。
- 认领人真实姓名：未提供、未核实；不得用目录用户名代替人工署名。
- 待确认：family正式去重、来源版本对应、权利许可、具名科学审核、另一人独立复现。详细缺口及访问/核验失败记录保留在source_audit.json。

网络抽样单位和unconditional目标适配未获维护人批准；完整待决表保留在source_audit.json的合并记录中，card.md亦保留完整说明。
