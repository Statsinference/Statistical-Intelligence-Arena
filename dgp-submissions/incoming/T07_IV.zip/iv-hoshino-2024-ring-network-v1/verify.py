import math,itertools,importlib.util
from pathlib import Path
from unittest.mock import patch
def mod(f):
 s=importlib.util.spec_from_file_location('ring_'+f,Path(__file__).with_name(f));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
class R:
 def __init__(self,z):self.v=iter(z)
 def random(self):return 0. if next(self.v) else .999999
def reference(c):
 # Enumerate individual assignments, not binomial probabilities as in truth.
 K=2*c['L'] if c['model']==1 else 0;p=c['z_probability'];num=den=0.
 for bits in itertools.product((0,1),repeat=K):
  pr=math.prod(p if b else 1-p for b in bits);total=sum(bits)
  for g,b in zip(c['gamma0'],c['beta1']):
   base=g+(total*c['gamma2'] if c['model']==1 else 0)
   delta=int(base+c['gamma1']>=0)-int(base>=0)
   den+=pr*delta;num+=pr*b*delta
 return num/den
def _existing_verify(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 g=mod('generator.py');v=mod('truth.py').truth(c)['value'];ref=reference(c);checks=[]
 for i in (0,173,499):
  z=[0]*500;nb=g.neighbors(i,500,c['L']);k=0
  if c['model']==1:
   ks=[k for k in range(len(nb)+1) if c['gamma0'][i]+k<0<=c['gamma0'][i]+k+1]
   k=ks[0] if ks else 0
  for j in nb[:k]:z[j]=1
  with patch.object(g.random,'Random',return_value=R(z)):low=g.generate(c,1,0)
  z[i]=1
  with patch.object(g.random,'Random',return_value=R(z)):high=g.generate(c,1,0)
  dy=high['Y'+str(i)][0]-low['Y'+str(i)][0];dd=high['D'+str(i)][0]-low['D'+str(i)][0]
  checks.append({'name':'actual_network_direct_contrast_node'+str(i),'passed':abs(dy-c['beta1'][i]*dd)<1e-12})
 checks.append({'name':'enumerated_assignments_vs_binomial_truth','passed':abs(v-ref)<1e-11,'details':{'analytic':v,'enumerated':ref,'difference':abs(v-ref)}})
 null={**c,'beta1':[0.]*500}
 checks.append({'name':'zero_own_causal_path','passed':abs(reference(null))<1e-12})
 # Exercise a nonzero cross-node path in the actual generator.
 candidates=[i for i,v in enumerate(c['gamma0']) if -1<v<0]
 if candidates:
  i=candidates[0];j=(i+1)%500;z=[0]*500
  with patch.object(g.random,'Random',return_value=R(z)):low=g.generate(c,1,0)
  z[j if c['model']==1 else i]=1
  with patch.object(g.random,'Random',return_value=R(z)):high=g.generate(c,1,0)
  target=i if c['model']==1 else j
  expected=c['beta1'][i] if c['model']==1 else c['beta2'][j]
  change=high['Y'+str(target)][0]-low['Y'+str(target)][0]
  checks.append({'name':'actual_nonzero_cross_node_path','passed':abs(change-expected)<1e-12 and abs(change)>1e-12,'details':{'node':i,'neighbor':j,'observed_change':change,'expected':expected}})
 else:
  checks.append({'name':'actual_nonzero_cross_node_path','passed':False,'details':'No suitable fixed-vector threshold witness; retain failure for review.'})
 return {'passed':all(x['passed'] for x in checks),'checks':checks,'shared_components':'Same fixed coefficient vectors/scientific model. Independent assignment enumeration versus binomial reduction; selected actual-generator interventions check spillover-preserving direct effects. Not a network estimator or independent-person review.'}


def _source_audit_checks(config):
    c = config
    g = mod('generator.py')
    maximum = 0.0
    for kind in (0,1):
        z = [int((i % 5 < 2) if kind == 0 else (i % 7 in (0,2,6))) for i in range(500)]
        # Independent cyclic-distance definition, never generator.neighbors().
        neighbors = [[j for j in range(500) if 0 < min(abs(i-j),500-abs(i-j)) <= c['L']] for i in range(500)]
        expected_d = [int(c['gamma0'][i]+z[i]+(sum(z[j] for j in neighbors[i]) if c['model']==1 else 0)>=0) for i in range(500)]
        expected_y = [c['beta0'][i]+c['beta1'][i]*expected_d[i]+(c['beta2'][i]*sum(expected_d[j] for j in neighbors[i]) if c['model']==2 else 0) for i in range(500)]
        with patch.object(g.random,'Random',return_value=R(z)):
            actual = g.generate(c,1,0)
        for i in range(500):
            maximum = max(maximum,abs(actual['D'+str(i)][0]-expected_d[i]),abs(actual['Y'+str(i)][0]-expected_y[i]))
    import random as local_random
    r = local_random.Random(314159 if c['model']==1 else 271828)
    b0 = [r.gauss(1,1) for _ in range(500)]
    b1 = [r.uniform(1,2) for _ in range(500)]
    g0 = [r.gauss(-1.5 if c['model']==1 else -1.0,1) for _ in range(500)]
    b2 = [r.gauss(1,1) for _ in range(500)] if c['model']==2 else [0.0]*500
    frozen = c['beta0']==b0 and c['beta1']==b1 and c['gamma0']==g0 and c['beta2']==b2
    return [
        {'name':'all_nodes_source_equations_independent_cyclic_distance','passed':maximum<1e-12,
         'details':{'assignments':2,'nodes_per_assignment':500,'max_error':maximum}},
        {'name':'disclosed_new_frozen_vectors_reconstruct','passed':frozen,
         'details':'Matches disclosed local new realization; not the original author seed or vector.'}
    ]

def verify(config):
    result = _existing_verify(config)
    result['checks'].extend(_source_audit_checks(config))
    result['passed'] = all(item['passed'] is True for item in result['checks'])
    result['shared_components'] += ' Source-audit additions exercise the same local generator against separate source-equation/moment calculations; no independent-person review or complete distribution proof is claimed.'
    return result
