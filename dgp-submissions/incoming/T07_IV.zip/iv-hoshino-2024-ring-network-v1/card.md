# Hoshino–Yanagi：保留干扰的环形网络IV

状态：candidate / awaiting scientific review；未发送、未获维护人查重或具名审核。

## 7. 认领与创建

Hoshino T, Yanagi T (2024). Causal Inference with Noncompliance and Unknown Interference. JASA 119(548):2869–2880. DOI:10.1080/01621459.2023.2284413.

原始来源：https://arxiv.org/pdf/2108.07455v5

精确版本/定位：arXiv:2108.07455v5，2023-10-23；§2/3，AppendixG.1，PDF物理73–75页：ring network、DGP1/DGP2、固定个体系数分布、L=2/3、Z~Bern(.4)。读取下载PDF URL为无版本入口，版本由对应HTML页首与81页PDF内容核对，下载SHA在来源清单。

### 完整机制与参数出处

环N=500，邻居为左右各L个节点，L=2或3。Zj iid Bern(.4)。DGP1：β0i~N(1,1)，β1i~U(1,2)，γ0i~N(−1.5,1)，Di=1{γ0i+Zi+Σ邻居Zj≥0}，Yi=β0i+β1iDi。DGP2：β0i~N(1,1)，β1i~U(1,2)，β2i~N(1,1)，γ0i~N(−1,1)，Di=1{γ0i+Zi≥0}，Yi=β0i+β1iDi+β2iΣ邻居Dj。个体系数按原文一次抽取后固定；完整向量写config，Python冻结种子314159/271828。原文为4组network场景，本贡献统一1个family。

目标：unconditional_LADE：对他人Z按独立Bern(.4)边缘化后，平均自身结局变化/平均自身处理变化；处理/鼓励1减0的加权complier直接效应。

抽样单位：一个完整500节点网络实验为一行；n表示独立重复网络实验数，节点按列展开。

识别假设：独立Bernoulli鼓励分配；网络固定；自身鼓励单调影响自身处理；相应DGP限制间接路径；分母非零；不假设节点之间独立或无干扰。

### 新family结构核对

与旧两个及其余本轮机制不同：观察单位内存在跨节点干扰，必须保留固定环和邻居路径。DGP1干扰进入处理分配，DGP2进入结局；本轮保守合并为同一network-IV family，不靠拆分该论文凑数。

不以估计器、参数、种子或目标名称变化作为新增family依据。与Wang二元联合概率机制、Ye异方差MR及本轮其余机制的比较见总目录history/family_matrix.json。此为结构核对，不是维护人正式去重结论。

### 每项改动

- Preserve both source network DGPs and L=2/3 as four scenarios in one family, not two new families.
- Original N=500 retained. One collection row is an entire network; n=128 means128 independent encouragement experiments on the same fixed network, with all node columns observed. This adapter requires a network-aware benchmark.
- Freeze a new disclosed realization of original coefficient distributions; author frozen vector/seed is unavailable.
- Use unconditional IEM (constant exposure mapping) and unconditional direct-IV ratio rather than the paper selected t=2/t=1 conditional estimands; derive this target explicitly. No changes to source outcome/treatment mechanisms.

### 缺失/范围未决

- 作者原始冻结系数向量/种子未给，使用按原抽取规则的新实现化并标adaptation，不重现原表。
- 宽表完整网络与unconditional目标是显式接口/目标改动；维护人需确认网络接口与科学目标。原机制数值分布完整。

### 真值推导与独立核验

固定个体系数后，DGP1中wi=P[γ0i+K<0≤γ0i+K+1]，K~Binomial(2L,.4)；DGP2中wi=1[γ0i<0≤γ0i+1]。自身直接-IV均值比为Σβ1i wi/Σwi。DGP2邻居结局会变化，但自身Yi的对比仅β1i ΔDi；不能把邻居变化混入直接效应。truth做有限二项求和；verify另枚举邻居二元分配组合，另驱动实际完整网络生成器的单节点鼓励干预及零自身路径。保留干扰，未声称节点独立；标量目标区别于论文选定暴露t的条件目标。

## 8. 审阅后检查

使用官方collect.py check --run --n 128 --seed 1729，默认检查全部declared scenarios。源码先逐项审阅；只运行独立重写的本地Python，不执行作者R/下载脚本。真值路线、独立核验、零路径/解析特例和共享部分写在下文及verify.py；全部退出码/失败快照在总目录logs。不得裁剪非法概率/密度或放宽tolerance取得PASS。

## 9. 交付

仅最新check passed且execution_performed后pack为本family独立ZIP；路径/SHA-256在总目录。源码、config、card任何改动均重检后新建ZIP快照。无论文PDF、原始敏感数据、模型权重或凭据。正式接收需具名审核、另一人独立复现、维护人决定；机器PASS不能授予accepted。

## 10. 真实数据

本贡献是synthetic_dgp，不是real_data_claim；不利用该分支绕过未知真值。未获取真实个体数据，未训练/微调PFN，未构造大型超分布、bootstrap或coverage，不修改旧实验/checkpoint，不执行submit/外发。AI辅助提取、编程和检查，不代签科学审核。


## 第7节固定贡献格式：本次整理与代码审阅

任务类别：IV；kind：synthetic_dgp。认领/查重材料已整理在总目录《认领与查重表.md》，尚未发送维护人，未获认领或科学接收。

| 文件 | 本贡献内容与检查范围 |
|---|---|
| `collection.json` | 来源citation/期刊年/版本定位、IV目标、假设、属性、入口及adaptation关系。 |
| `card.md` | 保留上述方程、参数出处、噪声、抽样单位、推导、权利及缺口；本附录记录整理改动。 |
| `config.json` | DGP1/2分别用314159/271828重新抽取并冻结向量；L=2/3共享相应向量。原文两DGP和四场景合为一个family。 |
| `schema.csv` | 只声明实际观察列；角色、数值类型、上下界与输出一致。 |
| `generator.py` | generate(config,n,seed)；局部RNG；支持config关键字；不输出潜变量或oracle。 |
| `truth.py` | truth(config)返回value、estimated_error；目标与干预方向以上文为准。 |
| `verify.py` | verify(config)返回passed、checks；共享模型/生成器的局限保留，不等于另一人复现。 |
| `requirements.txt` | 依赖及版本范围；不使用作者电脑绝对路径。 |

声明场景：`DGP1_L2_new_draw`、`DGP1_L3_new_draw`、`DGP2_L2_new_draw`、`DGP2_L3_new_draw`。

属性：总协变量维数=0，有效维数=0；含义：No baseline covariates; 500 node instruments/treatments/outcomes are a single dependent experiment, not500 independent rows or confounders. Threshold treatment and explicit ring-neighbor spillovers. Both original DGPs grouped as scenarios in ONE family.

参数调用示例（不要把整个config.json对象传给hook）：

```python
import json
from generator import generate
from truth import truth
from verify import verify
with open("config.json", encoding="utf-8") as f:
    settings = json.load(f)
params = settings["scenarios"][settings["default_scenario"]]
observed = generate(config=params, n=128, seed=1729)
result = truth(config=params)
validation = verify(config=params)
```

本次仅修正入口契约/输入报错、数值稳定性和核验覆盖，统一文本换行，并补充整理信息；不改来源方程、场景数、已声明目标、维度标签或tolerance。具体改动/未决事项见总目录《代码审阅报告.md》。所有有改动的源文件均重新check/pack，旧报告保存在history并明确不代表当前状态。未训练PFN、未运行作者R、未外发、未执行submit。


## 来源逐文件审核修正 r3

arXiv:2108.07455v5，2023-10-23：Appendix G.1，PDF物理73–75页，印刷S37–S39；73页DGP1及DGP2方程，74页参数/一次冻结/L=2,3及目标，75页n=500设置。已重新渲染73页并核对后续文字。缓存PDF SHA256 2509e3d53ecb45a1d48f336b68cd720d0f0d6c97ae465a23f970adc1169a3ecf。

参数定位：G.1：Z iid Bern(.4)，DGP1 beta0~N(1,1),beta1~U(1,2),gamma0~N(−1.5,1),gamma1=gamma2=1；DGP2 beta2~N(1,1),gamma0~N(−1,1),gamma1=1；系数抽一次；N500,L2/3。

本轮修正：

- 补行/列、0基与论文1基节点索引映射，进一步明确unconditional目标不是原文选定暴露条件目标。
- 用独立循环距离计算全部500节点方程并驱动实际生成器，补全邻接回绕、截距及spillover核验。
- 保留四场景和已有非零跨节点验证，不把依赖结构改成iid人。

保留未决：

- 固定新向量不复现作者原表；原向量/种子未提供。
- 完整网络宽表与unconditional目标适配仍需维护人确认benchmark接口；未经确认不能声称直接适用于iid表格基准。

详细八份文件对照见本贡献source_audit.md/json。新增核验是共享模型下的独立计算路线，不是具名科学审核或另一人复现。保持原scenario数量、所选机制和tolerance；验证用零路径不作为新场景。后续实际check/pack结果以本轮总清单与checks/report.json为准。


## 八部分标准修正 r4（2026-10-30）

基线维数口径：baseline=[]，dimension=0、effective_dimension=0。工具变量、处理后变量和重复时点不计作基线协变量。标签参考n_ref=128个完整网络实验，p/n_ref=0.00000000；high_dimensional=false仅按所述基线口径和参考设置解释。实际n仍由接口传入，不对任意n/p扩展作高维承诺。

网络接口/目标批准尚未取得。数值表格可运行不等于可以用于普通iid个体基准；见interface_claim.md及collection.json.interface_review。维护人需确认完整网络行单位、邻接信息提供方式、unconditional目标和网络评测协议，不能由AI把pending改成approved。

依赖：Python>=3.10；无第三方必需依赖；无可选依赖、训练/GPU依赖。独立干净环境安装与运行证据在本目录dependency_check.json及总目录logs/eight-parts-r4；仅宣称实际测试的平台/版本，不宣称覆盖所有Python或NumPy版本。

干净安装实际结果：本贡献独立venv初始无NumPy、未继承系统site-packages；按requirements.txt安装退出0，pip check退出0；测试Python 3.12.14，NumPy None。详见dependency_check.json；模型运行以随后正式check为准。


## 2026-10-31：严格示例格式整理

文件布局与指定单DGP示例一致。CLAIM.md记录真实的待认领状态，environment.json记录本贡献实测运行环境。既有source_audit.md、missing_parameters.json、dependency_check.json及网络interface_claim.md没有丢弃，完整内容合并保存在source_audit.json的format_revision_20261031.merged_supplementary_records。原collection扩展元数据保留在同文件preserved_extension_metadata，含维数参考及网络接口未批准状态。

原机制方程、全部场景参数、schema、generator/truth/verify及依赖逐字不变；本次不是新的原文阅读或科学接收。认领人真实姓名和维护人批准尚未确认。修改元数据后重新执行全部场景check并pack，旧报告不复用为本轮证明。

### 既有逐文件审计记录（原文保留）

# iv-hoshino-2024-ring-network-v1：八份文件来源核对与修正 r3

实际来源：[Hoshino T, Yanagi T (2024). Causal Inference with Noncompliance and Unknown Interference. JASA 119(548):2869–2880. DOI:10.1080/01621459.2023.2284413.](https://arxiv.org/pdf/2108.07455v5)。

精确定位：arXiv:2108.07455v5，2023-10-23：Appendix G.1，PDF物理73–75页，印刷S37–S39；73页DGP1及DGP2方程，74页参数/一次冻结/L=2,3及目标，75页n=500设置。已重新渲染73页并核对后续文字。缓存PDF SHA256 2509e3d53ecb45a1d48f336b68cd720d0f0d6c97ae465a23f970adc1169a3ecf。

参数出处：G.1：Z iid Bern(.4)，DGP1 beta0~N(1,1),beta1~U(1,2),gamma0~N(−1.5,1),gamma1=gamma2=1；DGP2 beta2~N(1,1),gamma0~N(−1,1),gamma1=1；系数抽一次；N500,L2/3。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；arXiv:2108.07455v5，2023-10-23：Appendix G.1，PDF物理73–75页，印刷S37–S39；73页DGP1及DGP2方程，74页参数/一次冻结/L=2,3及目标，75页n=500设置。已重新渲染73页并核对后续文字。缓存PDF SHA256 2509e3d53ecb45a1d48f336b68cd720d0f0d6c97ae465a23f970adc1169a3ecf。 One row is an entire fixed 500-node ring experiment with 1500 observed columns. Rows are independent repeated encouragement assignments conditional on fixed coefficients; nodes within each row are dependent. No no-interference or iid-node assumption. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；G.1：Z iid Bern(.4)，DGP1 beta0~N(1,1),beta1~U(1,2),gamma0~N(−1.5,1),gamma1=gamma2=1；DGP2 beta2~N(1,1),gamma0~N(−1,1),gamma1=1；系数抽一次；N500,L2/3。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；DGP1/2分别用314159/271828重新抽取并冻结向量；L=2/3共享相应向量。原文两DGP和四场景合为一个family。 |
| `schema.csv` | 1500个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；One row is an entire fixed 500-node ring experiment with 1500 observed columns. Rows are independent repeated encouragement assignments conditional on fixed coefficients; nodes within each row are dependent. No no-interference or iid-node assumption. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic unconditional finite-network direct-IV ratio: binomial neighbor encouragement weights in DGP1 and own-complier weights in DGP2. Target/row adapter is explicit and requires maintainer agreement. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；补行/列、0基与论文1基节点索引映射，进一步明确unconditional目标不是原文选定暴露条件目标。；用独立循环距离计算全部500节点方程并驱动实际生成器，补全邻接回绕、截距及spillover核验。；保留四场景和已有非零跨节点验证，不把依赖结构改成iid人。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`DGP1_L2_new_draw`, `DGP1_L3_new_draw`, `DGP2_L2_new_draw`, `DGP2_L3_new_draw`。

属性方程依据：No baseline covariates; 500 node instruments/treatments/outcomes are a single dependent experiment, not500 independent rows or confounders. Threshold treatment and explicit ring-neighbor spillovers. Both original DGPs grouped as scenarios in ONE family.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 固定新向量不复现作者原表；原向量/种子未提供。
- 完整网络宽表与unconditional目标适配仍需维护人确认benchmark接口；未经确认不能声称直接适用于iid表格基准。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=0/0；baseline=[]。参考n_ref=128（complete 500-node network experiments），p/n_ref=0.00000000。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。

### 网络接口待决表（原文保留）

# 网络抽样单位与目标适配：待维护人确认

状态：requires_maintainer_confirmation；approval_received=false。本文件是确认申请材料，未发送、未获批准。机器运行通过不代表接口批准。

- 原机制：固定500节点环，L=2/3；每行保留Z0,D0,Y0至Z499,D499,Y499，共1500列。
- n：完整网络实验重复次数，n=128不是128个人、也不是500×128个独立人。
- 节点索引：本包0..499对应论文1..500；不得丢列、拆节点伪造独立样本或移除干扰。
- 目标：边缘化其他鼓励分配后的unconditional直接IV比值，与原文选定暴露条件目标不同，已标adaptation。

维护人待决定：

1. 是否接受以完整网络为一行的基准采样单位。
2. 环邻接和L如何提供给网络方法；不能默认普通表格模型已获得图结构。
3. 是否接受unconditional目标适配，或要求另选原文目标。
4. 使用何种网络评测协议、如何计样本量；在决定前不得登记为已批准的iid个体IV基准。

审核人：未指定；决定：pending；批准日期：未取得。不虚构具名审核、授权或维护人回执。
