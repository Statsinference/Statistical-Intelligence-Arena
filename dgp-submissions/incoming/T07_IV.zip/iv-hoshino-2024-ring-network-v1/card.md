# Hoshino–Yanagi：保留干扰的环形网络IV

状态：candidate / awaiting scientific review；未发送、未获维护人查重或具名审核。

## 7. 认领与创建

Hoshino T, Yanagi T (2024). Causal Inference with Noncompliance and Unknown Interference. JASA 119(548):2869–2880. DOI:10.1080/01621459.2023.2284413.

原始来源：https://arxiv.org/pdf/2108.07455v5

精确版本/定位：arXiv:2108.07455v5，2023-10-23；§2/3，AppendixG.1，PDF物理73–75页：ring network、DGP1/DGP2、固定个体系数分布、L=2/3、Z~Bern(.4)。读取下载PDF URL为无版本入口，版本由对应HTML页首与81页PDF内容核对，下载SHA在来源清单。

### 完整机制与参数出处

环N=500，邻居为左右各L个节点，L=2或3。Zj iid Bern(.4)。DGP1：β0i~N(1,1)，β1i~U(1,2)，γ0i~N(−1.5,1)，Di=1{γ0i+Zi+Σ邻居Zj≥0}，Yi=β0i+β1iDi。DGP2：β0i~N(1,1)，β1i~U(1,2)，β2i~N(1,1)，γ0i~N(−1,1)，Di=1{γ0i+Zi≥0}，Yi=β0i+β1iDi+β2iΣ邻居Dj。个体系数按原文一次抽取后固定；完整向量写config，Python冻结种子314159/271828。原文为4组network场景，本贡献统一1个family。

目标：unconditional_LADE：对他人Z按独立Bern(.4)边缘化后，平均自身结局变化/平均自身处理变化；处理/鼓励1减0的加权complier直接效应。

抽样单位：一个完整500节点网络实验为一行；n表示独立重复网络实验数，节点按列展开。

识别假设：独立Bernoulli鼓励分配；网络固定；自身鼓励单调影响自身处理；相应DGP限制间接路径；分母非零；不假设节点之间独立或无干扰。

### 新family结构核对

与旧两个及其余本轮机制不同：观察单位内存在跨节点干扰，必须保留固定环和邻居路径。DGP1干扰进入处理分配，DGP2进入结局；本轮保守合并为同一network-IV family，不靠拆分该论文凑数。

不以估计器、参数、种子或目标名称变化作为新增family依据。与Wang二元联合概率机制、Ye异方差MR及本轮其余机制的比较见总目录history/family_matrix.json。此为结构核对，不是维护人正式去重结论。

### 每项改动

- Preserve both source network DGPs and L=2/3 as four scenarios in one family, not two new families.
- Original N=500 retained. One collection row is an entire network; n=128 means128 independent encouragement experiments on the same fixed network, with all node columns observed. This adapter requires a network-aware benchmark.
- Freeze a new disclosed realization of original coefficient distributions; author frozen vector/seed is unavailable.
- Use unconditional IEM (constant exposure mapping) and unconditional direct-IV ratio rather than the paper selected t=2/t=1 conditional estimands; derive this target explicitly. No changes to source outcome/treatment mechanisms.

### 缺失/范围未决

- 作者原始冻结系数向量/种子未给，使用按原抽取规则的新实现化并标adaptation，不重现原表。
- 宽表完整网络与unconditional目标是显式接口/目标改动；维护人需确认网络接口与科学目标。原机制数值分布完整。

### 真值推导与独立核验

固定个体系数后，DGP1中wi=P[γ0i+K<0≤γ0i+K+1]，K~Binomial(2L,.4)；DGP2中wi=1[γ0i<0≤γ0i+1]。自身直接-IV均值比为Σβ1i wi/Σwi。DGP2邻居结局会变化，但自身Yi的对比仅β1i ΔDi；不能把邻居变化混入直接效应。truth做有限二项求和；verify另枚举邻居二元分配组合，另驱动实际完整网络生成器的单节点鼓励干预及零自身路径。保留干扰，未声称节点独立；标量目标区别于论文选定暴露t的条件目标。

## 8. 审阅后检查

使用官方collect.py check --run --n 128 --seed 1729，默认检查全部declared scenarios。源码先逐项审阅；只运行独立重写的本地Python，不执行作者R/下载脚本。真值路线、独立核验、零路径/解析特例和共享部分写在下文及verify.py；全部退出码/失败快照在总目录logs。不得裁剪非法概率/密度或放宽tolerance取得PASS。

## 9. 交付

仅最新check passed且execution_performed后pack为本family独立ZIP；路径/SHA-256在总目录。源码、config、card任何改动均重检后新建ZIP快照。无论文PDF、原始敏感数据、模型权重或凭据。正式接收需具名审核、另一人独立复现、维护人决定；机器PASS不能授予accepted。

## 10. 真实数据

本贡献是synthetic_dgp，不是real_data_claim；不利用该分支绕过未知真值。未获取真实个体数据，未训练/微调PFN，未构造大型超分布、bootstrap或coverage，不修改旧实验/checkpoint，不执行submit/外发。AI辅助提取、编程和检查，不代签科学审核。


## 第7节固定贡献格式：本次整理与代码审阅

任务类别：IV；kind：synthetic_dgp。认领/查重材料已整理在总目录《认领与查重表.md》，尚未发送维护人，未获认领或科学接收。

| 文件 | 本贡献内容与检查范围 |
|---|---|
| `collection.json` | 来源citation/期刊年/版本定位、IV目标、假设、属性、入口及adaptation关系。 |
| `card.md` | 保留上述方程、参数出处、噪声、抽样单位、推导、权利及缺口；本附录记录整理改动。 |
| `config.json` | DGP1/2分别用314159/271828重新抽取并冻结向量；L=2/3共享相应向量。原文两DGP和四场景合为一个family。 |
| `schema.csv` | 只声明实际观察列；角色、数值类型、上下界与输出一致。 |
| `generator.py` | generate(config,n,seed)；局部RNG；支持config关键字；不输出潜变量或oracle。 |
| `truth.py` | truth(config)返回value、estimated_error；目标与干预方向以上文为准。 |
| `verify.py` | verify(config)返回passed、checks；共享模型/生成器的局限保留，不等于另一人复现。 |
| `requirements.txt` | 依赖及版本范围；不使用作者电脑绝对路径。 |

声明场景：`DGP1_L2_new_draw`、`DGP1_L3_new_draw`、`DGP2_L2_new_draw`、`DGP2_L3_new_draw`。

属性：总协变量维数=0，有效维数=0；含义：No baseline covariates; 500 node instruments/treatments/outcomes are a single dependent experiment, not500 independent rows or confounders. Threshold treatment and explicit ring-neighbor spillovers. Both original DGPs grouped as scenarios in ONE family.

参数调用示例（不要把整个config.json对象传给hook）：

```python
import json
from generator import generate
from truth import truth
from verify import verify
with open("config.json", encoding="utf-8") as f:
    settings = json.load(f)
params = settings["scenarios"][settings["default_scenario"]]
observed = generate(config=params, n=128, seed=1729)
result = truth(config=params)
validation = verify(config=params)
```

本次仅修正入口契约/输入报错、数值稳定性和核验覆盖，统一文本换行，并补充整理信息；不改来源方程、场景数、已声明目标、维度标签或tolerance。具体改动/未决事项见总目录《代码审阅报告.md》。所有有改动的源文件均重新check/pack，旧报告保存在history并明确不代表当前状态。未训练PFN、未运行作者R、未外发、未执行submit。


## 来源逐文件审核修正 r3

arXiv:2108.07455v5，2023-10-23：Appendix G.1，PDF物理73–75页，印刷S37–S39；73页DGP1及DGP2方程，74页参数/一次冻结/L=2,3及目标，75页n=500设置。已重新渲染73页并核对后续文字。缓存PDF SHA256 2509e3d53ecb45a1d48f336b68cd720d0f0d6c97ae465a23f970adc1169a3ecf。

参数定位：G.1：Z iid Bern(.4)，DGP1 beta0~N(1,1),beta1~U(1,2),gamma0~N(−1.5,1),gamma1=gamma2=1；DGP2 beta2~N(1,1),gamma0~N(−1,1),gamma1=1；系数抽一次；N500,L2/3。

本轮修正：

- 补行/列、0基与论文1基节点索引映射，进一步明确unconditional目标不是原文选定暴露条件目标。
- 用独立循环距离计算全部500节点方程并驱动实际生成器，补全邻接回绕、截距及spillover核验。
- 保留四场景和已有非零跨节点验证，不把依赖结构改成iid人。

保留未决：

- 固定新向量不复现作者原表；原向量/种子未提供。
- 完整网络宽表与unconditional目标适配仍需维护人确认benchmark接口；未经确认不能声称直接适用于iid表格基准。

详细八份文件对照见本贡献source_audit.md/json。新增核验是共享模型下的独立计算路线，不是具名科学审核或另一人复现。保持原scenario数量、所选机制和tolerance；验证用零路径不作为新场景。后续实际check/pack结果以本轮总清单与checks/report.json为准。


## 八部分标准修正 r4（2026-10-30）

基线维数口径：baseline=[]，dimension=0、effective_dimension=0。工具变量、处理后变量和重复时点不计作基线协变量。标签参考n_ref=128个完整网络实验，p/n_ref=0.00000000；high_dimensional=false仅按所述基线口径和参考设置解释。实际n仍由接口传入，不对任意n/p扩展作高维承诺。

网络接口/目标批准尚未取得。数值表格可运行不等于可以用于普通iid个体基准；见interface_claim.md及collection.json.interface_review。维护人需确认完整网络行单位、邻接信息提供方式、unconditional目标和网络评测协议，不能由AI把pending改成approved。

依赖：Python>=3.10；无第三方必需依赖；无可选依赖、训练/GPU依赖。独立干净环境安装与运行证据在本目录dependency_check.json及总目录logs/eight-parts-r4；仅宣称实际测试的平台/版本，不宣称覆盖所有Python或NumPy版本。

干净安装实际结果：本贡献独立venv初始无NumPy、未继承系统site-packages；按requirements.txt安装退出0，pip check退出0；测试Python 3.12.14，NumPy None。详见dependency_check.json；模型运行以随后正式check为准。
