# iv-hoshino-2024-ring-network-v1：八份文件来源核对与修正 r3

实际来源：[Hoshino T, Yanagi T (2024). Causal Inference with Noncompliance and Unknown Interference. JASA 119(548):2869–2880. DOI:10.1080/01621459.2023.2284413.](https://arxiv.org/pdf/2108.07455v5)。

精确定位：arXiv:2108.07455v5，2023-10-23：Appendix G.1，PDF物理73–75页，印刷S37–S39；73页DGP1及DGP2方程，74页参数/一次冻结/L=2,3及目标，75页n=500设置。已重新渲染73页并核对后续文字。缓存PDF SHA256 2509e3d53ecb45a1d48f336b68cd720d0f0d6c97ae465a23f970adc1169a3ecf。

参数出处：G.1：Z iid Bern(.4)，DGP1 beta0~N(1,1),beta1~U(1,2),gamma0~N(−1.5,1),gamma1=gamma2=1；DGP2 beta2~N(1,1),gamma0~N(−1,1),gamma1=1；系数抽一次；N500,L2/3。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；arXiv:2108.07455v5，2023-10-23：Appendix G.1，PDF物理73–75页，印刷S37–S39；73页DGP1及DGP2方程，74页参数/一次冻结/L=2,3及目标，75页n=500设置。已重新渲染73页并核对后续文字。缓存PDF SHA256 2509e3d53ecb45a1d48f336b68cd720d0f0d6c97ae465a23f970adc1169a3ecf。 One row is an entire fixed 500-node ring experiment with 1500 observed columns. Rows are independent repeated encouragement assignments conditional on fixed coefficients; nodes within each row are dependent. No no-interference or iid-node assumption. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；G.1：Z iid Bern(.4)，DGP1 beta0~N(1,1),beta1~U(1,2),gamma0~N(−1.5,1),gamma1=gamma2=1；DGP2 beta2~N(1,1),gamma0~N(−1,1),gamma1=1；系数抽一次；N500,L2/3。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；DGP1/2分别用314159/271828重新抽取并冻结向量；L=2/3共享相应向量。原文两DGP和四场景合为一个family。 |
| `schema.csv` | 1500个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；One row is an entire fixed 500-node ring experiment with 1500 observed columns. Rows are independent repeated encouragement assignments conditional on fixed coefficients; nodes within each row are dependent. No no-interference or iid-node assumption. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic unconditional finite-network direct-IV ratio: binomial neighbor encouragement weights in DGP1 and own-complier weights in DGP2. Target/row adapter is explicit and requires maintainer agreement. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；补行/列、0基与论文1基节点索引映射，进一步明确unconditional目标不是原文选定暴露条件目标。；用独立循环距离计算全部500节点方程并驱动实际生成器，补全邻接回绕、截距及spillover核验。；保留四场景和已有非零跨节点验证，不把依赖结构改成iid人。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`DGP1_L2_new_draw`, `DGP1_L3_new_draw`, `DGP2_L2_new_draw`, `DGP2_L3_new_draw`。

属性方程依据：No baseline covariates; 500 node instruments/treatments/outcomes are a single dependent experiment, not500 independent rows or confounders. Threshold treatment and explicit ring-neighbor spillovers. Both original DGPs grouped as scenarios in ONE family.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 固定新向量不复现作者原表；原向量/种子未提供。
- 完整网络宽表与unconditional目标适配仍需维护人确认benchmark接口；未经确认不能声称直接适用于iid表格基准。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=0/0；baseline=[]。参考n_ref=128（complete 500-node network experiments），p/n_ref=0.00000000。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
