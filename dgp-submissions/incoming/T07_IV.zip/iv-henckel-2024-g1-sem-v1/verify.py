import math,itertools,numpy as np,importlib.util
from pathlib import Path
from unittest.mock import patch
def mod(f):
 s=importlib.util.spec_from_file_location('graph_'+f,Path(__file__).with_name(f));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
class R:
 def __init__(self):self.v=iter(a for signs in itertools.product((-1,1),repeat=9) for a in signs)
 def gauss(self,m,s):return m+s*next(self.v)
 def uniform(self,lo,hi):return (lo+hi)/2+(hi-lo)*next(self.v)/(2*math.sqrt(3))
def _existing_verify(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 names=list(c['variance']);B=np.zeros((9,9));ix={v:i for i,v in enumerate(names)}
 for edge,val in c['coeff'].items():
  a,b=edge.split('_');B[ix[b],ix[a]]=val
 L=np.linalg.inv(np.eye(9)-B);S=L@np.diag(list(c['variance'].values()))@L.T
 def conditional(a,b):return float(S[ix[a],ix[b]]-S[ix[a],ix['C']]*S[ix['C'],ix[b]]/S[ix['C'],ix['C']])
 recovered=conditional('D','Y')/conditional('D','X');value=mod('truth.py').truth(c)['value']
 g=mod('generator.py')
 with patch.object(g.random,'Random',return_value=R()):rows=g.generate(c,512,0)
 observed=list(rows);cov=np.cov(np.array([rows[k] for k in observed]),bias=True);idx=[ix[k] for k in observed]
 discrepancy=float(np.max(np.abs(cov-S[np.ix_(idx,idx)])))
 null={**c,'coeff':{**c['coeff'],'X_Y':0.,'X_M':0.}}
 checks=[{'name':'conditional_IV_covariance_recovers_total_effect','passed':abs(recovered-value)<1e-10,'details':{'recovered':float(recovered),'path_sum':value,'unadjusted_Wald':float(S[ix['D'],ix['Y']]/S[ix['D'],ix['X']])}},
 {'name':'actual_sampler_sign_cube_vs_matrix_SEM_covariance','passed':discrepancy<1e-10,'details':{'max_covariance_difference':discrepancy}},
 {'name':'zero_all_directed_causal_paths','passed':abs(mod('truth.py').truth(null)['value'])<1e-12},
 {'name':'latent_common_causes_not_exported','passed':set(observed)=={'A','B','C','D','X','M','Y'}},
 {'name':'conditional_IV_relevance','passed':abs(conditional('D','X'))>1e-6}]
 return {'passed':all(x['passed'] for x in checks),'checks':checks,'shared_components':'Same source graph/config; independent matrix inverse and covariance-based conditional-IV recovery versus path-sum truth; actual sampler second moments tested by full sign cube, not a full-distribution proof or independent-person review.'}


def _source_audit_checks(config):
    c = config
    expected_edges = {'A_D','B_D','C_B','B_X','C_Y','X_M','M_Y','X_Y','Hdx_D','Hdx_X','Hxy_X','Hxy_Y'}
    expected_nodes = {'A','B','C','D','X','M','Y','Hdx','Hxy'}
    structure = set(c['coeff']) == expected_edges and set(c['variance']) == expected_nodes
    support = all(0.1 <= v <= 1 for v in c['variance'].values()) and all(0.1 <= abs(b) <= 2 for b in c['coeff'].values())
    null = {**c,'coeff':{**c['coeff'],'X_Y':0.0,'X_M':0.0}}
    g = mod('generator.py')
    with patch.object(g.random,'Random',return_value=R()):
        rows = g.generate(null,512,0)
    def covariance(a,b):
        ma = math.fsum(rows[a])/512
        mb = math.fsum(rows[b])/512
        return math.fsum((x-ma)*(y-mb) for x,y in zip(rows[a],rows[b]))/512
    numerator = covariance('D','Y')-covariance('D','C')*covariance('C','Y')/covariance('C','C')
    denominator = covariance('D','X')-covariance('D','C')*covariance('C','X')/covariance('C','C')
    recovered = numerator/denominator
    mean_error = max(abs(math.fsum(v)/512) for v in rows.values())
    return [
        {'name':'source_Figure1a_edges_and_parameter_support','passed':bool(structure and support)},
        {'name':'actual_null_sampler_conditional_IV_zero','passed':abs(recovered)<1e-12 and mean_error<1e-12,
         'details':{'conditional_IV_null_effect':recovered,'max_mean_error':mean_error}}
    ]

def verify(config):
    result = _existing_verify(config)
    result['checks'].extend(_source_audit_checks(config))
    result['passed'] = all(item['passed'] is True for item in result['checks'])
    result['shared_components'] += ' Source-audit additions exercise the same local generator against separate source-equation/moment calculations; no independent-person review or complete distribution proof is claimed.'
    return result
