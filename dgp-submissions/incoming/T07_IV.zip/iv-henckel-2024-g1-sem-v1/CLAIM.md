# 维护人认领/查重材料（待确认）

- 拟贡献ID：`iv-henckel-2024-g1-sem-v1`；任务：iv；mechanism_family_id：`iv-henckel-2024-g1-sem`。
- 来源：Henckel L, Buttenschön M, Maathuis MH (2024). Graphical tools for selecting conditional instrumental sets. Biometrika 111(3):771–788. DOI:10.1093/biomet/asad066.
- 链接：https://arxiv.org/pdf/2208.03697v3
- 版本：arXiv:2208.03697v3, 2023-11-06; fixed new SEM realization, not original author parameter snapshots
- 定位：arXiv:2208.03697v3，2023-11-06：物理第3页§2 Eq.(1)线性SEM；物理第5页Figure1a/Example3.5（已重新渲染核箭头）；物理第12页§5随机SEM抽取规则；物理41页Supplement E。PDF SHA256 60d4569a7d49a7c4a69467eefb4a58afb0ba96b22a7ec0200dd8bdb47d76957f。
- 声明场景：G1_gaussian_new_draw, G1_uniform_new_draw。
- 目标：tau_YX：do(X=x+1)相对do(X=x)的总效应，b_XY+b_XM b_MY。
- 主要适配：Freeze a new realization under source coefficient/variance distributions using seed1618033; original frozen100 SEMs not provided. Both Gaussian/uniform error-law branches retained as scenarios of the same family.; Keep original Figure1a mediator M and both bidirected edges via two hidden parents; no forbidden-projection shortcut. New Python RNG, scalar original total-effect target.
- 用户截图显示GitHub账号wuwenti已创建PR #10；本文件不表示认领查重已批准或已获科学接收。
- 认领人真实姓名：未提供、未核实；不得用目录用户名代替人工署名。
- 待确认：family正式去重、来源版本对应、权利许可、具名科学审核、另一人独立复现。详细缺口及访问/核验失败记录保留在source_audit.json。

查重提醒：用户提供的IV目录已有同论文/相同或相近机制条目，需维护人决定是否重复；不能因新系数或种子计为新family。
