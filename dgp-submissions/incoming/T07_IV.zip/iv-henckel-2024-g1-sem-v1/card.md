# Henckel：条件工具集合的混合图SEM

状态：candidate / awaiting scientific review；未发送、未获维护人查重或具名审核。

## 7. 认领与创建

Henckel L, Buttenschön M, Maathuis MH (2024). Graphical tools for selecting conditional instrumental sets. Biometrika 111(3):771–788. DOI:10.1093/biomet/asad066.

原始来源：https://arxiv.org/pdf/2208.03697v3

精确版本/定位：arXiv:2208.03697v3，2023-11-06；§2 Eq.(1)及路径总效应、Theorem3.2、§5、Figure1a；物理第5页已本地渲染并查看箭头，Supplement E。PDF SHA256 60d4569a7d49a7c4a69467eefb4a58afb0ba96b22a7ec0200dd8bdb47d76957f。

### 完整机制与参数出处

Figure1a有向边A→D、B→D、C→B、B→X、C→Y、X→M、M→Y、X→Y；双向边D↔X、X↔Y，分别用Hdx→D/X及Hxy→X/Y展开。全部节点（含H）各有独立均值0误差，误差方差一次抽U(.1,1)，边系数一次抽U([-2,−.1]∪[.1,2])；全Gaussian或全uniform误差各是原文允许的分支。Uniform按给定方差取[−√(3v),√(3v)]。完整系数/方差写config，冻结种子1618033。

目标：tau_YX：do(X=x+1)相对do(X=x)的总效应，b_XY+b_XM b_MY。

抽样单位：固定SEM后的独立个体；个体内保留潜在共同原因。

识别假设：已知无环混合图；线性SEM、指定独立噪声/潜变量；Theorem3.2有效条件IV集合；Cov(D,X|C)非零；总效应包括中介路径。

### 新family结构核对

与Guo独立根工具+无效直接路径不同：图中存在C→B→D/X和C→Y的条件混杂、D↔X、X↔Y两个潜在共同原因、X→M→Y中介路径；D仅在调整C等有效集合后识别X的总效应。可由Cov(D,Y|C)/Cov(D,X|C)核验，未调整比值一般不同；不是更换Guo系数或种子。

不以估计器、参数、种子或目标名称变化作为新增family依据。与Wang二元联合概率机制、Ye异方差MR及本轮其余机制的比较见总目录history/family_matrix.json。此为结构核对，不是维护人正式去重结论。

### 每项改动

- Freeze a new realization under source coefficient/variance distributions using seed1618033; original frozen100 SEMs not provided. Both Gaussian/uniform error-law branches retained as scenarios of the same family.
- Keep original Figure1a mediator M and both bidirected edges via two hidden parents; no forbidden-projection shortcut. New Python RNG, scalar original total-effect target.

### 缺失/范围未决

- 原文随机SEM分布完整，但作者原始100组参数/种子未给；按同一规则冻结新的实现化并标adaptation。
- Figure1a箭头现已视觉核实，前轮访问失败保留；家庭边界仍由维护人正式判定。

### 真值推导与独立核验

总效应=直接路径X→Y与间接路径X→M→Y乘积之和。独立构造9节点（含2潜变量）矩阵B与Σ=(I−B)^{-1}diag(v)(I−B)^{-T}；用条件协方差Cov(D,Y|C)/Cov(D,X|C)恢复总效应。verify还用512个噪声符号组合驱动实际生成器，核验Gaussian和uniform两种分支的所需二阶矩；将X→Y、X→M置0验证零总效应。两条路线共享图和配置；不把二阶矩检查声称为全分布/独立人员证明。

## 8. 审阅后检查

使用官方collect.py check --run --n 128 --seed 1729，默认检查全部declared scenarios。源码先逐项审阅；只运行独立重写的本地Python，不执行作者R/下载脚本。真值路线、独立核验、零路径/解析特例和共享部分写在下文及verify.py；全部退出码/失败快照在总目录logs。不得裁剪非法概率/密度或放宽tolerance取得PASS。

## 9. 交付

仅最新check passed且execution_performed后pack为本family独立ZIP；路径/SHA-256在总目录。源码、config、card任何改动均重检后新建ZIP快照。无论文PDF、原始敏感数据、模型权重或凭据。正式接收需具名审核、另一人独立复现、维护人决定；机器PASS不能授予accepted。

## 10. 真实数据

本贡献是synthetic_dgp，不是real_data_claim；不利用该分支绕过未知真值。未获取真实个体数据，未训练/微调PFN，未构造大型超分布、bootstrap或coverage，不修改旧实验/checkpoint，不执行submit/外发。AI辅助提取、编程和检查，不代签科学审核。


## 第7节固定贡献格式：本次整理与代码审阅

任务类别：IV；kind：synthetic_dgp。认领/查重材料已整理在总目录《认领与查重表.md》，尚未发送维护人，未获认领或科学接收。

| 文件 | 本贡献内容与检查范围 |
|---|---|
| `collection.json` | 来源citation/期刊年/版本定位、IV目标、假设、属性、入口及adaptation关系。 |
| `card.md` | 保留上述方程、参数出处、噪声、抽样单位、推导、权利及缺口；本附录记录整理改动。 |
| `config.json` | 按来源分布冻结一个新SEM；同一组系数保留Gaussian/Uniform两个分支。原文以概率.5选分支；本包条件列出两分支供逐项检查，这是场景组织改动。 |
| `schema.csv` | 只声明实际观察列；角色、数值类型、上下界与输出一致。 |
| `generator.py` | generate(config,n,seed)；局部RNG；支持config关键字；不输出潜变量或oracle。 |
| `truth.py` | truth(config)返回value、estimated_error；目标与干预方向以上文为准。 |
| `verify.py` | verify(config)返回passed、checks；共享模型/生成器的局限保留，不等于另一人复现。 |
| `requirements.txt` | 依赖及版本范围；不使用作者电脑绝对路径。 |

声明场景：`G1_gaussian_new_draw`、`G1_uniform_new_draw`。

属性：总协变量维数=1，有效维数=1；含义：C is an active pretreatment conditioning covariate; A,B,D are candidate instruments, M posttreatment mediator, X treatment, Y outcome. Seven observed nodes plus two hidden common causes; no padding, no high-dimensional confounding claim.

参数调用示例（不要把整个config.json对象传给hook）：

```python
import json
from generator import generate
from truth import truth
from verify import verify
with open("config.json", encoding="utf-8") as f:
    settings = json.load(f)
params = settings["scenarios"][settings["default_scenario"]]
observed = generate(config=params, n=128, seed=1729)
result = truth(config=params)
validation = verify(config=params)
```

本次仅修正入口契约/输入报错、数值稳定性和核验覆盖，统一文本换行，并补充整理信息；不改来源方程、场景数、已声明目标、维度标签或tolerance。具体改动/未决事项见总目录《代码审阅报告.md》。所有有改动的源文件均重新check/pack，旧报告保存在history并明确不代表当前状态。未训练PFN、未运行作者R、未外发、未执行submit。


## 来源逐文件审核修正 r3

arXiv:2208.03697v3，2023-11-06：物理第3页§2 Eq.(1)线性SEM；物理第5页Figure1a/Example3.5（已重新渲染核箭头）；物理第12页§5随机SEM抽取规则；物理41页Supplement E。PDF SHA256 60d4569a7d49a7c4a69467eefb4a58afb0ba96b22a7ec0200dd8bdb47d76957f。

参数定位：Figure1a固定8条有向边、两条双向边；§5含潜节点误差方差U(.1,1)、边系数U([-2,−.1]∪[.1,2])、全Gaussian/全uniform分支。当前具体向量是种子1618033的新实现，不是作者100组原始SEM。

本轮修正：

- 补准确页码及原文分支抽取与本包条件列举之间的区别。
- 把原来仅调用truth的零路径检查加强为实际null生成器的条件IV协方差检验。
- 校验图边/节点集合、系数方差支持与样本均值；保留中介和潜共同原因。

保留未决：

- 作者原100组SEM向量/种子未在所读材料列出；新实现已标adaptation。
- 此混合图SEM与一般线性IV的family粒度仍由维护人判定。

详细八份文件对照见本贡献source_audit.md/json。新增核验是共享模型下的独立计算路线，不是具名科学审核或另一人复现。保持原scenario数量、所选机制和tolerance；验证用零路径不作为新场景。后续实际check/pack结果以本轮总清单与checks/report.json为准。


## 八部分标准修正 r4（2026-10-30）

基线维数口径：baseline=['C']，dimension=1、effective_dimension=1。工具变量、处理后变量和重复时点不计作基线协变量。标签参考n_ref=128个独立受试者，p/n_ref=0.00781250；high_dimensional=false仅按所述基线口径和参考设置解释。实际n仍由接口传入，不对任意n/p扩展作高维承诺。

依赖：Python>=3.10；NumPy>=1.24,<3为必需依赖；无可选依赖、训练/GPU依赖。独立干净环境安装与运行证据在本目录dependency_check.json及总目录logs/eight-parts-r4；仅宣称实际测试的平台/版本，不宣称覆盖所有Python或NumPy版本。

干净安装实际结果：本贡献独立venv初始无NumPy、未继承系统site-packages；按requirements.txt安装退出0，pip check退出0；测试Python 3.12.14，NumPy 2.3.5。详见dependency_check.json；模型运行以随后正式check为准。
