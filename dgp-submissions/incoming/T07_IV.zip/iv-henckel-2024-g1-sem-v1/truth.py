def truth(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 b=c['coeff'];return {'value':b['X_Y']+b['X_M']*b['M_Y'],'estimated_error':0.,'method':'Sum of directed path products X->Y and X->M->Y; not merely the direct edge coefficient.'}
