# iv-henckel-2024-g1-sem-v1：八份文件来源核对与修正 r3

实际来源：[Henckel L, Buttenschön M, Maathuis MH (2024). Graphical tools for selecting conditional instrumental sets. Biometrika 111(3):771–788. DOI:10.1093/biomet/asad066.](https://arxiv.org/pdf/2208.03697v3)。

精确定位：arXiv:2208.03697v3，2023-11-06：物理第3页§2 Eq.(1)线性SEM；物理第5页Figure1a/Example3.5（已重新渲染核箭头）；物理第12页§5随机SEM抽取规则；物理41页Supplement E。PDF SHA256 60d4569a7d49a7c4a69467eefb4a58afb0ba96b22a7ec0200dd8bdb47d76957f。

参数出处：Figure1a固定8条有向边、两条双向边；§5含潜节点误差方差U(.1,1)、边系数U([-2,−.1]∪[.1,2])、全Gaussian/全uniform分支。当前具体向量是种子1618033的新实现，不是作者100组原始SEM。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；arXiv:2208.03697v3，2023-11-06：物理第3页§2 Eq.(1)线性SEM；物理第5页Figure1a/Example3.5（已重新渲染核箭头）；物理第12页§5随机SEM抽取规则；物理41页Supplement E。PDF SHA256 60d4569a7d49a7c4a69467eefb4a58afb0ba96b22a7ec0200dd8bdb47d76957f。 iid individuals conditional on one frozen SEM. Independent node noises include two hidden common causes; D-X and X-Y dependence is retained. M is posttreatment, C is the selected conditioning covariate. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；Figure1a固定8条有向边、两条双向边；§5含潜节点误差方差U(.1,1)、边系数U([-2,−.1]∪[.1,2])、全Gaussian/全uniform分支。当前具体向量是种子1618033的新实现，不是作者100组原始SEM。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；按来源分布冻结一个新SEM；同一组系数保留Gaussian/Uniform两个分支。原文以概率.5选分支；本包条件列出两分支供逐项检查，这是场景组织改动。 |
| `schema.csv` | 7个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid individuals conditional on one frozen SEM. Independent node noises include two hidden common causes; D-X and X-Y dependence is retained. M is posttreatment, C is the selected conditioning covariate. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic total path effect b_XY+b_XM*b_MY; independently checked using conditional-IV covariance from a matrix SEM and actual-sampler second moments, including the null graph. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；补准确页码及原文分支抽取与本包条件列举之间的区别。；把原来仅调用truth的零路径检查加强为实际null生成器的条件IV协方差检验。；校验图边/节点集合、系数方差支持与样本均值；保留中介和潜共同原因。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`G1_gaussian_new_draw`, `G1_uniform_new_draw`。

属性方程依据：C is an active pretreatment conditioning covariate; A,B,D are candidate instruments, M posttreatment mediator, X treatment, Y outcome. Seven observed nodes plus two hidden common causes; no padding, no high-dimensional confounding claim.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 作者原100组SEM向量/种子未在所读材料列出；新实现已标adaptation。
- 此混合图SEM与一般线性IV的family粒度仍由维护人判定。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=1/1；baseline=['C']。参考n_ref=128（independent subjects），p/n_ref=0.00781250。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
