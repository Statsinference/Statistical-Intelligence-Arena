"""Independent bisection/class-mixture map, Wald inversion and sampler checks.

Independent computation does not mean independent-person scientific reproduction.
"""
from copy import deepcopy
import importlib.util
import math
from pathlib import Path
from unittest.mock import patch

def _load(filename,name):
    spec=importlib.util.spec_from_file_location(name,Path(__file__).with_name(filename))
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def _reference(config,x,z):
    # Separately implement the links using hyperbolic identities.
    a0,a1=config['alpha']
    t=a0+a1*x
    e=math.exp(2*t)
    delta=(e-1)/(e+1)
    v=config['eta'][0]+config['eta'][1]*x
    odds_product=math.exp(v)
    phi=[0.5+0.5*math.tanh((b[0]+b[1]*x)/2) for b in config['beta_phi']]
    # Solve q0*(q0+delta)=r*(1-q0)*(1-q0-delta) in its feasible interval.
    lo=max(0.0,-delta); hi=min(1.0,1.0-delta)
    for _ in range(80):
        mid=(lo+hi)/2
        residual=mid*(mid+delta)-odds_product*(1-mid)*(1-mid-delta)
        if residual>0:
            hi=mid
        else:
            lo=mid
    q0=(lo+hi)/2; q1=q0+delta
    # Sum Bernoulli outcome laws over the three principal strata.
    cells=[0.0]*4
    for weight,d,q in [(phi[0],z,q1 if z else q0),
                       ((1-phi[0])*phi[1],1,phi[3]),
                       ((1-phi[0])*(1-phi[1]),0,phi[2])]:
        cells[2*d]+=weight*(1-q)
        cells[2*d+1]+=weight*q
    return cells,q0,q1

def _wald(config,x):
    p0,_,_=_reference(config,x,0)
    p1,_,_=_reference(config,x,1)
    dy=(p1[1]+p1[3])-(p0[1]+p0[3])
    dd=(p1[2]+p1[3])-(p0[2]+p0[3])
    return dy/dd

def _slope(config):
    # These are in-support points, not new DGP scenarios.
    return math.atanh(_wald(config,0.5))-math.atanh(_wald(config,-0.5))

class _GridRNG:
    def __init__(self,x,z,m):
        self.x=x; self.z=z; self.m=m; self.calls=0
    def uniform(self,lo,hi):
        return self.x
    def random(self):
        call=self.calls; self.calls+=1
        if call%2==0:
            return 0.0 if self.z else 1.0-2**-53
        return ((call//2)+0.5)/self.m

def _existing_verify(config):
    if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
    gen=_load('generator.py','wang_generator_check')
    oracle=_load('truth.py','wang_truth_check')
    expected={'x_bounds':[-1.0,1.0],'alpha':[0.0,-1.0],
              'beta_phi':[[-0.4,0.8] for _ in range(4)],
              'eta':[-0.4,1.0],'gamma':[0.1,-1.0]}
    checks=[{'name':'source_fixed_parameter_fixture','passed':config==expected}]
    grid=[-1+2*j/200 for j in range(201)]
    max_difference=0.0; max_odds_residual=0.0; valid=True; monotone=True
    for x in grid:
        pair=[]
        for z in (0,1):
            reference,q0,q1=_reference(config,x,z)
            actual=gen.observed_probabilities(config,x,z)
            max_difference=max(max_difference,*(abs(a-b) for a,b in zip(actual,reference)))
            valid &= all(0<=p<=1 for p in actual) and abs(math.fsum(actual)-1)<1e-12
            pair.append(actual)
            r=math.exp(config['eta'][0]+config['eta'][1]*x)
            max_odds_residual=max(max_odds_residual,abs(q0*q1-r*(1-q0)*(1-q1)))
        p0,p1=pair
        monotone &= all(p1[2+y]>=p0[2+y]-1e-14 and p0[y]>=p1[y]-1e-14 for y in (0,1))
    recovered=_slope(config)
    checks.extend([
     {'name':'closed_form_vs_independent_bisection_mixture','passed':max_difference<1e-12,'details':{'grid_points':201,'max_cell_probability_difference':max_difference}},
     {'name':'probability_normalization_and_bounds','passed':bool(valid)},
     {'name':'observed_monotonicity_inequalities','passed':bool(monotone)},
     {'name':'odds_product_equation_residual','passed':max_odds_residual<1e-12,'details':{'max_residual':max_odds_residual}},
     {'name':'independent_wald_inversion_recovers_slope','passed':abs(recovered-oracle.truth(config)['value'])<1e-12,'details':{'wald_recovered_alpha1':recovered,'analytic_alpha1':oracle.truth(config)['value']}},
     {'name':'anchor_conditional_effect','passed':abs(_wald(config,.5)+.4621171572600098)<1e-12,'details':'Derived LATE(0.5), not a source-reported population ATE.'}
    ])
    # Null effect and sign reversal are validation inputs, not extra collected mechanisms.
    null=deepcopy(config); null['alpha']=[0.0,0.0]
    reverse=deepcopy(config); reverse['alpha']=[0.0,1.0]
    checks.extend([
     {'name':'zero_effect_special_case','passed':abs(_slope(null))<1e-12 and all(abs(_wald(null,x))<1e-12 for x in (-.5,0,.5))},
     {'name':'sign_reversal_special_case','passed':abs(_slope(reverse)-1)<1e-12},
    ])
    x=.4 # Source odds product is exactly one here: closed-form removable singularity.
    p0,_,_=_reference(config,x,0)
    r1_error=max(abs(a-b) for a,b in zip(gen.observed_probabilities(config,x,0),p0))
    checks.append({'name':'odds_product_one_boundary_case','passed':r1_error<1e-12})
    # Exercise the actual categorical sampler against independently computed probabilities.
    max_frequency_error=0.0; mapping=True; m=4096
    for x in (-.6,.4):
        for z in (0,1):
            ref,_,_=_reference(config,x,z)
            with patch.object(gen.random,'Random',return_value=_GridRNG(x,z,m)):
                rows=gen.generate(config,m,1729)
            counts=[0]*4
            for d,y in zip(rows['D'],rows['Y']): counts[2*d+y]+=1
            max_frequency_error=max(max_frequency_error,*(abs(c/m-p) for c,p in zip(counts,ref)))
            mapping &= set(rows)=={'x','Z','D','Y'} and all(v==x for v in rows['x']) and all(v==z for v in rows['Z'])
    checks.append({'name':'actual_inverse_cdf_sampler_on_stratified_uniform_grid','passed':bool(mapping) and max_frequency_error<=1/m+1e-12,'details':{'grid_draws_per_condition':m,'max_frequency_error':max_frequency_error,'error_bound':'At most 1/m discrepancy for intervals sampled at uniform-grid midpoints; this is a deterministic sampler check, not coverage.'}})
    sample=gen.generate(config,128,1729)
    checks.append({'name':'observed_only_export','passed':set(sample)=={'x','Z','D','Y'}})
    return {'passed':all(c['passed'] for c in checks),'checks':checks,
            'shared_components':'Both routes share the documented source model and numeric configuration. Verification uses its own bisection and principal-stratum mixture, not the generator closed-form inversion. Actual sampler checked with a controlled uniform grid. No independent-person replication or general identification proof is claimed.'}


class _InstrumentGridRNG:
    def __init__(self,x,size):self.x=x;self.size=size;self.calls=0
    def uniform(self,lo,hi):return self.x
    def random(self):
        observation,stage=divmod(self.calls,2)
        self.calls+=1
        return (observation+.5)/self.size if stage==0 else .5

def _source_audit_checks(config):
    gen=_load('generator.py','wang_source_sampler')
    maximum=0.0
    m=4096
    for x in (-.5,.5):
        with patch.object(gen.random,'Random',return_value=_InstrumentGridRNG(x,m)):
            row=gen.generate(config,m,1729)
        reference=.5+.5*math.tanh((.1-x)/2)
        maximum=max(maximum,abs(math.fsum(row['Z'])/m-reference))
    return [{'name':'source_actual_instrument_propensity_grid','passed':maximum<=1/m+1e-12,
             'details':{'max_grid_error':maximum,'deterministic_interval_bound':1/m,'points_per_x':m}}]

def verify(config):
    result = _existing_verify(config)
    result['checks'].extend(_source_audit_checks(config))
    result['passed'] = all(item['passed'] is True for item in result['checks'])
    result['shared_components'] += ' Source-audit additions exercise the same local generator against separate source-equation/moment calculations; no independent-person review or complete distribution proof is claimed.'
    return result
