# Wang / 二元 IV 条件 LATE

状态：candidate；认领/查重尚未由维护人确认；不是八个已验收family。

## 7. 认领、原文定位与八份文件

Wang L, Zhang Y, Richardson TS, Robins JM (2021). Estimation of local treatment effects under the binary instrumental variable model. Biometrika 108(4):881–894. DOI:10.1093/biomet/asab003.

原始来源：https://arxiv.org/html/2007.14458v2

阅读版本：arXiv v2，2022-03-22。定位：§2 A1–A5；§3 Theorem 1；§5；Supplement S1 (S3)–(S5)、S5。阅读范围为识别条件、目标与DGP相关正文/可访问补充段落，不声称逐行审阅全篇证明。

### 已核对机制与参数出处

x~U(-1,1)；δL(x)=tanh(−x)；φi=expit(−.4+.8x)，i=1…4；OPco=exp(−.4+x)；P(Z=1|x)=expit(.1−x)。S1恢复P(D,Y|Z,x)。

§5明确全部系数；S1给出概率映射。仅选加性目标的原文场景；估计器拟合错设不是新DGP。

目标：α1：atanh{E[Y(1)−Y(0)|D(1)>D(0),x]}曲线的斜率，不是风险差本身。抽样单位：独立个体。

识别条件：一致性、无干扰；给定x的IV独立、排除限制、相关性、正性、单调性；正确tanh效应模型。

### 缺失与所需补充

所选DGP数值参数无已发现缺失；版本对应、权利、查重与科学审核仍待完成。

### 完整S1观察分布重建

令 e(t)=1/(1+exp(-t))；源设计向量是 (1,x)，观察表只输出随机变量 x。

    x ~ Uniform(-1,1)
    delta(x)=tanh(-x)
    phi_j(x)=e(-0.4+0.8*x), j=1,...,4
    r(x)=exp(-0.4+x)
    Z | x ~ Bernoulli(e(0.1-x))

以上参数均取自 PDF 第 7 页 §5。设 c=phi1，a=(1-c)*phi2，n=(1-c)*(1-phi2)。它们为 CO、AT、NT 概率；p_NT=phi3、p_AT=phi4。

    q0 = 2*r*(1-delta) / [r*(2-delta)+delta+sqrt(delta^2*(r-1)^2+4*r)]
    q1 = q0+delta

q0 是补充 S1 的 f0 经有理化得到的稳定等价式；r=1 时自动给出 (1-delta)/2，不裁剪。q1/q0 分别是依从者在 D=1/0 时的结果均值。完整联合分布如下，列顺序固定为 (D,Y)=(0,0),(0,1),(1,0),(1,1)：

| Z | p00 | p01 | p10 | p11 |
|---|---|---|---|---|
| 0 | n*(1-phi3)+c*(1-q0) | n*phi3+c*q0 | a*(1-phi4) | a*phi4 |
| 1 | n*(1-phi3) | n*phi3 | a*(1-phi4)+c*(1-q1) | a*phi4+c*q1 |

按此四格分类概率联合生成 D,Y，不能把它们按各自边缘独立抽样。各个个体独立；内部均匀随机流是新实现的逆 CDF 工具，不是添加的科学噪声。无删失、截断或边界裁剪；观察列只有 x,Z,D,Y。不生成未识别的 AT 未处理结果、NT 处理结果或潜在结果之间的联合耦合。


## 8. 检查与失败保留

八份文件已创建；未解决项保持显式失败，不能通过放宽tolerance、伪造truth或删除场景取得PASS。实际命令、退出码及标准输出保存在总目录logs；checks/report.json由官方collect.py产生。未实现候选的hooks主动拒绝执行，不输出伪数据。

## 9. 交付与科学状态

仅当前检查通过的贡献可pack；失败候选不生成提交ZIP。若有ZIP，其SHA-256在总目录清单。未执行submit、外部上传、发消息或PR；没有项目组收件回执。所有机制仍待具名科学审核和另一人的独立复现。

## 10. 真实数据分支

本条是仿真候选，不认领真实数据，不适用real_data_claim。未知/缺失不能靠改kind绕过。Zhao的真实参数依赖不是已获授权的半合成贡献。

权利与AI协助：AI辅助定位/提取/代码，非具名科学审核；不分发论文PDF、原始敏感数据、凭据、数据银行或权重。训练PFN、bootstrap、coverage和大规模超分布均未执行。


## 本轮已实现与真值

沿用本地已审阅的S1闭式概率恢复生成器，独立bisection/strata混合和Wald反演verify；零效应、符号反转、OP=1与受控均匀网格采样器核验。truth=-1，estimated_error=0（解析恒等式，不是运行误差保证）。只导出x,Z,D,Y，不暴露stratum或潜在结局。独立计算路线仍共享原文模型及config，不是独立人的科学复现。声明场景仅source_additive。


## 第7节固定贡献格式：本次整理与代码审阅

任务类别：IV；kind：synthetic_dgp。认领/查重材料已整理在总目录《认领与查重表.md》，尚未发送维护人，未获认领或科学接收。

| 文件 | 本贡献内容与检查范围 |
|---|---|
| `collection.json` | 来源citation/期刊年/版本定位、IV目标、假设、属性、入口及adaptation关系。 |
| `card.md` | 保留上述方程、参数出处、噪声、抽样单位、推导、权利及缺口；本附录记录整理改动。 |
| `config.json` | 直接采用原文固定参数；不重新抽系数。只选加性LATE曲线场景与原alpha向量的斜率分量，省略确定性截距列并用新局部RNG。 |
| `schema.csv` | 只声明实际观察列；角色、数值类型、上下界与输出一致。 |
| `generator.py` | generate(config,n,seed)；局部RNG；支持config关键字；不输出潜变量或oracle。 |
| `truth.py` | truth(config)返回value、estimated_error；目标与干预方向以上文为准。 |
| `verify.py` | verify(config)返回passed、checks；共享模型/生成器的局限保留，不等于另一人复现。 |
| `requirements.txt` | 依赖及版本范围；不使用作者电脑绝对路径。 |

声明场景：`source_additive`。

属性：总协变量维数=1，有效维数=1；含义：One genuinely active scalar baseline x; the source vector (1,x) contains an intercept, which is not counted as a random covariate. Nonlinearity is tanh(alpha0+alpha1*x), four expit links, exp(eta0+eta1*x), and the joint-probability inverse map. No explicit covariate-product interaction is added. D,Y dependence is not an added regression interaction.

参数调用示例（不要把整个config.json对象传给hook）：

```python
import json
from generator import generate
from truth import truth
from verify import verify
with open("config.json", encoding="utf-8") as f:
    settings = json.load(f)
params = settings["scenarios"][settings["default_scenario"]]
observed = generate(config=params, n=128, seed=1729)
result = truth(config=params)
validation = verify(config=params)
```

本次仅修正入口契约/输入报错、数值稳定性和核验覆盖，统一文本换行，并补充整理信息；不改来源方程、场景数、已声明目标、维度标签或tolerance。具体改动/未决事项见总目录《代码审阅报告.md》。所有有改动的源文件均重新check/pack，旧报告保存在history并明确不代表当前状态。未训练PFN、未运行作者R、未外发、未执行submit。


## 来源逐文件审核修正 r3

arXiv:2007.14458v2，2022-03-22：§2 A1–A5、§3 Theorem1、§5生成模型及参数段、Supplement S1(S3)–(S5)和f0/f1。物理页码沿用此前记录2/3/5/7/18，本轮PDF入口cache miss，已重读显式v2 HTML相关段；不宣称重看这些PDF页。

参数定位：§5：x~U(−1,1)，alpha=(0,−1)，beta_phi四组(−.4,.8)，eta=(−.4,1)，gamma=(.1,−1)；S1恢复完整P(D,Y|Z,x)。

本轮修正：

- 修正通用随机系数模板误述；区分斜率参数与LATE/ATE。
- 保留完整联合概率、OP=1特例及实际categorical采样检查；新增Z倾向分配的实际均匀网格验证。
- 更新本轮HTML读取与PDF入口失败记录，不声称期刊终版逐式一致。

保留未决：

- 期刊终版与v2仍待逐式核对；目标仅是变换后曲线斜率。

详细八份文件对照见本贡献source_audit.md/json。新增核验是共享模型下的独立计算路线，不是具名科学审核或另一人复现。保持原scenario数量、所选机制和tolerance；验证用零路径不作为新场景。后续实际check/pack结果以本轮总清单与checks/report.json为准。


## 八部分标准修正 r4（2026-10-30）

基线维数口径：baseline=['x']，dimension=1、effective_dimension=1。工具变量、处理后变量和重复时点不计作基线协变量。标签参考n_ref=128个独立受试者，p/n_ref=0.00781250；high_dimensional=false仅按所述基线口径和参考设置解释。实际n仍由接口传入，不对任意n/p扩展作高维承诺。

依赖：Python>=3.10；无第三方必需依赖；无可选依赖、训练/GPU依赖。独立干净环境安装与运行证据在本目录dependency_check.json及总目录logs/eight-parts-r4；仅宣称实际测试的平台/版本，不宣称覆盖所有Python或NumPy版本。

干净安装实际结果：本贡献独立venv初始无NumPy、未继承系统site-packages；按requirements.txt安装退出0，pip check退出0；测试Python 3.12.14，NumPy None。详见dependency_check.json；模型运行以随后正式check为准。
