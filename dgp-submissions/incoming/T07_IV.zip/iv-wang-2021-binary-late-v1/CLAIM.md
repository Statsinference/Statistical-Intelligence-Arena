# 维护人认领/查重材料（待确认）

- 拟贡献ID：`iv-wang-2021-binary-late-v1`；任务：iv；mechanism_family_id：`wang-zhang-richardson-robins-binary-iv-principal-strata`。
- 来源：Wang L, Zhang Y, Richardson TS, Robins JM (2021). Estimation of local treatment effects under the binary instrumental variable model. Biometrika 108(4):881-894. DOI:10.1093/biomet/asab003.
- 链接：https://arxiv.org/abs/2007.14458v2
- 版本：arXiv:2007.14458v2, 2022-03-22; additive Section5 and Supplement S1; version-of-record comparison pending
- 定位：arXiv:2007.14458v2，2022-03-22：§2 A1–A5、§3 Theorem1、§5生成模型及参数段、Supplement S1(S3)–(S5)和f0/f1。物理页码沿用此前记录2/3/5/7/18，本轮PDF入口cache miss，已重读显式v2 HTML相关段；不宣称重看这些PDF页。
- 声明场景：source_additive。
- 目标：Slope alpha1 in atanh(delta_L(x))=alpha0+alpha1*x, where delta_L(x)=E[Y(1)-Y(0)|D(1)>D(0),x]. Potential outcomes contrast D=1 versus D=0 among conditional compliers. Equivalently [atanh(delta_L(0.5))-atanh(delta_L(-0.5))]/1.0 under the declared curve model. This parameter is not a risk difference itself and is not the population ATE.
- 主要适配：Keep the additive Section 5 observed-data probability law and all its numeric parameters from the explicitly read arXiv v2. Only this single DGP scenario is declared; nuisance-model fitting variants are not separate DGPs.; Scalar collection interface reports the original curve parameter alpha1, the slope of atanh(LATE(x)), rather than the full two-component alpha vector or the entire curve. No new causal target population or intervention is introduced.; Return scalar x without the deterministic intercept column. Reconstruct the same observed joint law using Supplement S1 and a new local Python RNG categorical inverse CDF; author RNG and Monte Carlo outputs are not reproduced.; Run the required n=128 CPU check rather than the original estimator simulation. Full journal-Version-of-Record versus v2 comparison remains pending; the source version is explicit.
- 用户截图显示GitHub账号wuwenti已创建PR #10；本文件不表示认领查重已批准或已获科学接收。
- 认领人真实姓名：未提供、未核实；不得用目录用户名代替人工署名。
- 待确认：family正式去重、来源版本对应、权利许可、具名科学审核、另一人独立复现。详细缺口及访问/核验失败记录保留在source_audit.json。

查重提醒：用户提供的IV目录已有同论文/相同或相近机制条目，需维护人决定是否重复；不能因新系数或种子计为新family。
