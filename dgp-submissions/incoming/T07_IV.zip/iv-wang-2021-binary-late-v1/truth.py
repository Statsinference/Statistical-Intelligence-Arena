"""Original transformed local-effect curve slope; not an ATE or LATE value."""
import math

def truth(config):
    if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
    a=config['alpha']
    if len(a)!=2 or not all(math.isfinite(float(v)) for v in a):
        raise ValueError('alpha must contain two finite values')
    return {'value':float(a[1]),'estimated_error':0.0,
            'method':'atanh(LATE(x))=alpha0+alpha1*x; hence its slope equals alpha1 exactly.',
            'error_interpretation':'Analytic identity, no numerical integration or simulated truth. Source alpha1=-1 is exactly representable.',
            'target':'alpha1, the transformed conditional complier-effect slope, not a population ATE or raw risk difference.'}
