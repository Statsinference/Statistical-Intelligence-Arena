# iv-wang-2021-binary-late-v1：八份文件来源核对与修正 r3

实际来源：[Wang L, Zhang Y, Richardson TS, Robins JM (2021). Estimation of local treatment effects under the binary instrumental variable model. Biometrika 108(4):881-894. DOI:10.1093/biomet/asab003.](https://arxiv.org/abs/2007.14458v2)。

精确定位：arXiv:2007.14458v2，2022-03-22：§2 A1–A5、§3 Theorem1、§5生成模型及参数段、Supplement S1(S3)–(S5)和f0/f1。物理页码沿用此前记录2/3/5/7/18，本轮PDF入口cache miss，已重读显式v2 HTML相关段；不宣称重看这些PDF页。

参数出处：§5：x~U(−1,1)，alpha=(0,−1)，beta_phi四组(−.4,.8)，eta=(−.4,1)，gamma=(.1,−1)；S1恢复完整P(D,Y|Z,x)。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；arXiv:2007.14458v2，2022-03-22：§2 A1–A5、§3 Theorem1、§5生成模型及参数段、Supplement S1(S3)–(S5)和f0/f1。物理页码沿用此前记录2/3/5/7/18，本轮PDF入口cache miss，已重读显式v2 HTML相关段；不宣称重看这些PDF页。 iid individuals. One active scalar x~U(-1,1); Z depends on x, and D/Y are sampled jointly conditional on x,Z. Binary principal-stratum model without interference. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；§5：x~U(−1,1)，alpha=(0,−1)，beta_phi四组(−.4,.8)，eta=(−.4,1)，gamma=(.1,−1)；S1恢复完整P(D,Y|Z,x)。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；直接采用原文固定参数；不重新抽系数。只选加性LATE曲线场景与原alpha向量的斜率分量，省略确定性截距列并用新局部RNG。 |
| `schema.csv` | 4个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid individuals. One active scalar x~U(-1,1); Z depends on x, and D/Y are sampled jointly conditional on x,Z. Binary principal-stratum model without interference. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic alpha1=-1, the slope of atanh(LATE(x)); independently recovered by principal-stratum mixture, odds-product bisection and conditional Wald inversion; not population ATE or raw LATE. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；修正通用随机系数模板误述；区分斜率参数与LATE/ATE。；保留完整联合概率、OP=1特例及实际categorical采样检查；新增Z倾向分配的实际均匀网格验证。；更新本轮HTML读取与PDF入口失败记录，不声称期刊终版逐式一致。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`source_additive`。

属性方程依据：One genuinely active scalar baseline x; the source vector (1,x) contains an intercept, which is not counted as a random covariate. Nonlinearity is tanh(alpha0+alpha1*x), four expit links, exp(eta0+eta1*x), and the joint-probability inverse map. No explicit covariate-product interaction is added. D,Y dependence is not an added regression interaction.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 期刊终版与v2仍待逐式核对；目标仅是变换后曲线斜率。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=1/1；baseline=['x']。参考n_ref=128（independent subjects），p/n_ref=0.00781250。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
