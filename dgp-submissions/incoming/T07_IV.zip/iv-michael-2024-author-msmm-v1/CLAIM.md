# 维护人认领/查重材料（待确认）

- 拟贡献ID：`iv-michael-2024-author-msmm-v1`；任务：iv；mechanism_family_id：`iv-michael-2024-author-msmm`。
- 来源：Michael H, Cui Y, Lorch SA, Tchetgen Tchetgen EJ (2024). Instrumental Variable Estimation of Marginal Structural Mean Models for Time-Varying Treatment. JASA 119(546):1240–1251. DOI:10.1080/01621459.2023.2183131.
- 链接：https://github.com/haben-michael/iv-msmm/blob/b1e405f81400b13e58ea0bd3b0aa47728f681d8c/table/sim.R
- 版本：Author table/sim.R commit b1e405f81400b13e58ea0bd3b0aa47728f681d8c; comparison arXiv:2004.11769v2 (2020-07-24); not a hybrid of both sources
- 定位：实际机制为table/sim.R，commit b1e405f81400b13e58ea0bd3b0aa47728f681d8c，行11–40生成块，T/n为命令行参数；raw LF SHA256 df23204b8237dace7fa1c4ab8f381cdf74637942f9f0b4d9a926e60afd57a8d4。论文对照arXiv:2004.11769v2，2020-07-24，§6、物理63–64页Appendix16.1 Eq.(41)；两来源系数/噪声不同。
- 声明场景：author_T3。
- 目标：beta_T：最后一次处理增加1的MSMM均值效应，1。
- 主要适配：Use complete pinned-author DGP; do not combine beta=1 with older preprint Eq41 coefficients.; Wide table retains full longitudinal history; report final-time causal coefficient. New local RNG; no R estimator/bootstrap code executed.
- 用户截图显示GitHub账号wuwenti已创建PR #10；本文件不表示认领查重已批准或已获科学接收。
- 认领人真实姓名：未提供、未核实；不得用目录用户名代替人工署名。
- 待确认：family正式去重、来源版本对应、权利许可、具名科学审核、另一人独立复现。详细缺口及访问/核验失败记录保留在source_audit.json。
