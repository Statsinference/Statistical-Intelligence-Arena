# Michael：作者代码纵向MSMM机制

状态：candidate / awaiting scientific review；未发送、未获维护人查重或具名审核。

## 7. 认领与创建

Michael H, Cui Y, Lorch SA, Tchetgen Tchetgen EJ (2024). Instrumental Variable Estimation of Marginal Structural Mean Models for Time-Varying Treatment. JASA 119(546):1240–1251. DOI:10.1080/01621459.2023.2183131.

原始来源：https://github.com/haben-michael/iv-msmm/blob/b1e405f81400b13e58ea0bd3b0aa47728f681d8c/table/sim.R

精确版本/定位：正文arXiv:2004.11769v2 §6、Appendix16.1 Eq.(41)用于对照；本机制逐行依据table/sim.R的DGP块，commit b1e405f81400b13e58ea0bd3b0aa47728f681d8c，raw SHA256 df23204b8237dace7fa1c4ab8f381cdf74637942f9f0b4d9a926e60afd57a8d4。

### 完整机制与参数出处

t=1…T：Ut iid N(0,1)，mL1=1，mLt=A(t−1)；Lt=mLt+Ut（同一个Ut，不擅自换为独立噪声）；δt=Φ(.96+.46Lt)，P(Zt=1|Lt)=expit(.53−.10Lt)，P(At=1|Lt,Ut,Zt)=Φ(−.16+.11Lt+.26Ut)(1−δt)+Ztδt；Y=ΣUt/√T+Σ(Lt−mLt)/√T+ΣβtAt+ε，ε~N(0,1)，βt=1。全部系数来自固定作者代码。

目标：beta_T：最后一次处理增加1的MSMM均值效应，1。

抽样单位：独立受试者的完整T步轨迹，宽表一行一个人。

识别假设：一致性、序贯IV相关/排除/给定历史的独立及正性；正确MSMM；保留作者代码的共享U结构，不能宣称不可恢复的未测混杂。

### 新family结构核对

处理反馈A(t−1)→Lt→At与序贯Zt构成纵向机制；与单时间点二元IV、异方差MR、无效线性IV、静态图、删失/数据融合机制均不同。

不以估计器、参数、种子或目标名称变化作为新增family依据。与Wang二元联合概率机制、Ye异方差MR及本轮其余机制的比较见总目录history/family_matrix.json。此为结构核对，不是维护人正式去重结论。

### 每项改动

- Use complete pinned-author DGP; do not combine beta=1 with older preprint Eq41 coefficients.
- Wide table retains full longitudinal history; report final-time causal coefficient. New local RNG; no R estimator/bootstrap code executed.

### 缺失/范围未决

- 原文预印本与作者代码参数/噪声结构不同，不合并冒充；当前完整采用代码。
- 代码共享Ut意味着可由Lt及处理历史恢复；这是原实现限制，不把它改掉或宣称仍存在不可恢复混杂。
- 数值参数完整；正式期刊版本与该commit逐式对应、科学审核仍待维护人。

### 真值推导与独立核验

任何固定处理路径下，Σ[U+(L−mL)]/√T均值为0，故E(Y_a)=Σβt a_t，最终一次效应βT=1。verify以零噪声和强制处理路径驱动实际生成器，核验最后一步变化及前一步反馈中心化消除，再核验全零β。共享模型/config/生成器；此是解析路径检验，不是独立人员复现或对来源正确性的证明。

## 8. 审阅后检查

使用官方collect.py check --run --n 128 --seed 1729，默认检查全部declared scenarios。源码先逐项审阅；只运行独立重写的本地Python，不执行作者R/下载脚本。真值路线、独立核验、零路径/解析特例和共享部分写在下文及verify.py；全部退出码/失败快照在总目录logs。不得裁剪非法概率/密度或放宽tolerance取得PASS。

## 9. 交付

仅最新check passed且execution_performed后pack为本family独立ZIP；路径/SHA-256在总目录。源码、config、card任何改动均重检后新建ZIP快照。无论文PDF、原始敏感数据、模型权重或凭据。正式接收需具名审核、另一人独立复现、维护人决定；机器PASS不能授予accepted。

## 10. 真实数据

本贡献是synthetic_dgp，不是real_data_claim；不利用该分支绕过未知真值。未获取真实个体数据，未训练/微调PFN，未构造大型超分布、bootstrap或coverage，不修改旧实验/checkpoint，不执行submit/外发。AI辅助提取、编程和检查，不代签科学审核。


## 第7节固定贡献格式：本次整理与代码审阅

任务类别：IV；kind：synthetic_dgp。认领/查重材料已整理在总目录《认领与查重表.md》，尚未发送维护人，未获认领或科学接收。

| 文件 | 本贡献内容与检查范围 |
|---|---|
| `collection.json` | 来源citation/期刊年/版本定位、IV目标、假设、属性、入口及adaptation关系。 |
| `card.md` | 保留上述方程、参数出处、噪声、抽样单位、推导、权利及缺口；本附录记录整理改动。 |
| `config.json` | 系数是固定作者代码常数；选择T=3并重写宽表Python RNG，不是重新抽系数或声称复现旧预印本Eq.(41)。 |
| `schema.csv` | 只声明实际观察列；角色、数值类型、上下界与输出一致。 |
| `generator.py` | generate(config,n,seed)；局部RNG；支持config关键字；不输出潜变量或oracle。 |
| `truth.py` | truth(config)返回value、estimated_error；目标与干预方向以上文为准。 |
| `verify.py` | verify(config)返回passed、checks；共享模型/生成器的局限保留，不等于另一人复现。 |
| `requirements.txt` | 依赖及版本范围；不使用作者电脑绝对路径。 |

声明场景：`author_T3`。

属性：基线协变量总维数=1，有效基线维数=1；含义：Default T=3 time-varying L values, not padding. Delta(L)*Z in treatment probability; normal-CDF and logistic links. Author code has U_t=L_t-Lmean_t, recoverable from observed history; no irreducible hidden-confounding label.

参数调用示例（不要把整个config.json对象传给hook）：

```python
import json
from generator import generate
from truth import truth
from verify import verify
with open("config.json", encoding="utf-8") as f:
    settings = json.load(f)
params = settings["scenarios"][settings["default_scenario"]]
observed = generate(config=params, n=128, seed=1729)
result = truth(config=params)
validation = verify(config=params)
```

本次仅修正入口契约/输入报错、数值稳定性和核验覆盖，统一文本换行，并补充整理信息；不改来源方程、场景数、已声明目标、维度标签或tolerance。具体改动/未决事项见总目录《代码审阅报告.md》。所有有改动的源文件均重新check/pack，旧报告保存在history并明确不代表当前状态。未训练PFN、未运行作者R、未外发、未执行submit。


## 来源逐文件审核修正 r3

实际机制为table/sim.R，commit b1e405f81400b13e58ea0bd3b0aa47728f681d8c，行11–40生成块，T/n为命令行参数；raw LF SHA256 df23204b8237dace7fa1c4ab8f381cdf74637942f9f0b4d9a926e60afd57a8d4。论文对照arXiv:2004.11769v2，2020-07-24，§6、物理63–64页Appendix16.1 Eq.(41)；两来源系数/噪声不同。

参数定位：sim.R：sd.noise=sd.L=1；beta=rep(1,T)；nu.bar=(−.16,.11,.26)，alpha=(.96,.46)，gamma=(.53,−.10)；b.U=b.L=1/sqrt(T)；L1=1+U1,Lt=Aprev+Ut。采用T3是命令行参数的所选实现。

本轮修正：

- 修正通用随机系数模板误述；明确代码nu.bar与config.nu映射、T=3是所选命令行参数。
- 加入64条非零U轨迹，在来源概率阈值两侧驱动实际Z/A采样，检查历史、共享U和Y噪声。
- 保留作者实现U可由L及历史恢复的科学限制；不暗中改成独立噪声。

保留未决：

- 旧预印本Eq.(41)与作者commit的Z/L/噪声和系数不同；完整采用代码，不拼接。
- 共享U可恢复这一作者实现限制及正式期刊对应仍需具名科学审核。

详细八份文件对照见本贡献source_audit.md/json。新增核验是共享模型下的独立计算路线，不是具名科学审核或另一人复现。保持原scenario数量、所选机制和tolerance；验证用零路径不作为新场景。后续实际check/pack结果以本轮总清单与checks/report.json为准。


## 八部分标准修正 r4（2026-10-30）

基线维数口径：baseline=['L1']，dimension=1、effective_dimension=1。工具变量、处理后变量和重复时点不计作基线协变量。标签参考n_ref=128个独立受试者，p/n_ref=0.00781250；high_dimensional=false仅按所述基线口径和参考设置解释。实际n仍由接口传入，不对任意n/p扩展作高维承诺。

L1=1+U1位于首次处理A1之前；L2=A1+U2、L3=A2+U3属于时变协变量。原来的3/3误把三个观察时点当成三个基线变量，现改为1/1。保留全部L、Z、A历史列和生成方程，不把重复测量拆成独立样本。

依赖：Python>=3.10；无第三方必需依赖；无可选依赖、训练/GPU依赖。独立干净环境安装与运行证据在本目录dependency_check.json及总目录logs/eight-parts-r4；仅宣称实际测试的平台/版本，不宣称覆盖所有Python或NumPy版本。

干净安装实际结果：本贡献独立venv初始无NumPy、未继承系统site-packages；按requirements.txt安装退出0，pip check退出0；测试Python 3.12.14，NumPy None。详见dependency_check.json；模型运行以随后正式check为准。
