def truth(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 return {'value':float(c['beta'][-1]),'estimated_error':0.,'method':'Centered increments have zero mean under interventions; final treatment coefficient equals final beta. Intermediate L effects cancel after centering.'}
