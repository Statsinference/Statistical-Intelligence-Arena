# iv-michael-2024-author-msmm-v1：八份文件来源核对与修正 r3

实际来源：[Michael H, Cui Y, Lorch SA, Tchetgen Tchetgen EJ (2024). Instrumental Variable Estimation of Marginal Structural Mean Models for Time-Varying Treatment. JASA 119(546):1240–1251. DOI:10.1080/01621459.2023.2183131.](https://github.com/haben-michael/iv-msmm/blob/b1e405f81400b13e58ea0bd3b0aa47728f681d8c/table/sim.R)。

精确定位：实际机制为table/sim.R，commit b1e405f81400b13e58ea0bd3b0aa47728f681d8c，行11–40生成块，T/n为命令行参数；raw LF SHA256 df23204b8237dace7fa1c4ab8f381cdf74637942f9f0b4d9a926e60afd57a8d4。论文对照arXiv:2004.11769v2，2020-07-24，§6、物理63–64页Appendix16.1 Eq.(41)；两来源系数/噪声不同。

参数出处：sim.R：sd.noise=sd.L=1；beta=rep(1,T)；nu.bar=(−.16,.11,.26)，alpha=(.96,.46)，gamma=(.53,−.10)；b.U=b.L=1/sqrt(T)；L1=1+U1,Lt=Aprev+Ut。采用T3是命令行参数的所选实现。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；实际机制为table/sim.R，commit b1e405f81400b13e58ea0bd3b0aa47728f681d8c，行11–40生成块，T/n为命令行参数；raw LF SHA256 df23204b8237dace7fa1c4ab8f381cdf74637942f9f0b4d9a926e60afd57a8d4。论文对照arXiv:2004.11769v2，2020-07-24，§6、物理63–64页Appendix16.1 Eq.(41)；两来源系数/噪声不同。 iid subjects, each with a full T=3 trajectory. A_(t-1) feeds into L_t; U_t is shared between L and treatment/outcome. Source implementation makes U_t recoverable from observed history; no irreducible hidden-confounding claim. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；sim.R：sd.noise=sd.L=1；beta=rep(1,T)；nu.bar=(−.16,.11,.26)，alpha=(.96,.46)，gamma=(.53,−.10)；b.U=b.L=1/sqrt(T)；L1=1+U1,Lt=Aprev+Ut。采用T3是命令行参数的所选实现。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；系数是固定作者代码常数；选择T=3并重写宽表Python RNG，不是重新抽系数或声称复现旧预印本Eq.(41)。 |
| `schema.csv` | 10个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid subjects, each with a full T=3 trajectory. A_(t-1) feeds into L_t; U_t is shared between L and treatment/outcome. Source implementation makes U_t recoverable from observed history; no irreducible hidden-confounding claim. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic final-time unit intervention beta_T=1; treatment feedback cancels in centered L increments. Actual-source probability thresholds and nonzero-U trajectories supplement zero-path checks. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；修正通用随机系数模板误述；明确代码nu.bar与config.nu映射、T=3是所选命令行参数。；加入64条非零U轨迹，在来源概率阈值两侧驱动实际Z/A采样，检查历史、共享U和Y噪声。；保留作者实现U可由L及历史恢复的科学限制；不暗中改成独立噪声。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`author_T3`。

属性方程依据：Baseline L1; L2/L3 are time-varying covariates and are not included in baseline dimension. Delta(L)*Z in treatment probability; normal-CDF and logistic links. Author code has U_t=L_t-Lmean_t, recoverable from observed history; no irreducible hidden-confounding label.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 旧预印本Eq.(41)与作者commit的Z/L/噪声和系数不同；完整采用代码，不拼接。
- 共享U可恢复这一作者实现限制及正式期刊对应仍需具名科学审核。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=1/1；baseline=['L1']。参考n_ref=128（independent subjects），p/n_ref=0.00781250。修正旧3/3基线口径错误；时变L2/L3和全轨迹列保留。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
