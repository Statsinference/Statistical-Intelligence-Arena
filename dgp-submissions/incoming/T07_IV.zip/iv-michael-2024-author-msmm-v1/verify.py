import math,importlib.util
from pathlib import Path
from unittest.mock import patch
def mod(f):
 s=importlib.util.spec_from_file_location('msmm_'+f,Path(__file__).with_name(f));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
class R:
 def __init__(self,a):self.a=a;self.calls=0
 def gauss(self,m,s):return m
 def random(self):
  t,k=divmod(self.calls,2);self.calls+=1
  return .999999 if k==0 else (0. if self.a[t] else .999999)
def _existing_verify(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 g=mod('generator.py');ys=[];recoverable=True
 # Use the actual generator with zero noise and forced treatment paths, independently of its truth hook.
 for a in ([0,0,0],[0,0,1],[0,1,0]):
  with patch.object(g.random,'Random',return_value=R(a)):v=g.generate(c,1,0)
  ys.append(v['Y'][0])
  for t in range(1,4):
   mean=1. if t==1 else v['A'+str(t-1)][0]
   recoverable = recoverable and abs(v['L'+str(t)][0]-mean)<1e-12
 checks=[{'name':'actual_sampler_last_intervention','passed':abs(ys[1]-ys[0]-mod('truth.py').truth(c)['value'])<1e-12},
 {'name':'feedback_centering_cancels','passed':abs(ys[2]-ys[0]-c['beta'][1])<1e-12},
 {'name':'recoverable_U_limitation_retained','passed':recoverable,'details':'Zero-U actual-sampler paths check U_t=L_t-(1 at t1 else A_prev), from source code; not relabelled as irreducible hidden confounding.'},
 {'name':'author_constants','passed':c=={'T':3,'beta':[1.,1.,1.],'alpha':[.96,.46],'nu':[-.16,.11,.26],'gamma':[.53,-.10]}}]
 null=dict(c,beta=[0.,0.,0.])
 with patch.object(g.random,'Random',return_value=R([0,0,1])):v=g.generate(null,1,0)
 checks.append({'name':'zero_causal_coefficients','passed':abs(v['Y'][0])<1e-12})
 return {'passed':all(x['passed'] for x in checks),'checks':checks,'shared_components':'Same config and actual generator, checked against independently derived centered-increment intervention identities; no independent-person reproduction.'}


class _SourceTrajectoryRNG:
    def __init__(self,bits):
        self.bits=bits
        self.u=(0.3,-0.4,0.2)
        self.normals=iter((*self.u,0.07))
        self.calls=0
    def gauss(self,mu,sd):return mu+sd*next(self.normals)
    def random(self):
        t,stage=divmod(self.calls,2)
        self.calls+=1
        mean=1.0 if t==0 else self.bits[2*(t-1)+1]
        l=mean+self.u[t]
        z,a=self.bits[2*t:2*t+2]
        if stage==0:
            p=.5+.5*math.tanh((.53-.10*l)/2)
            target=z
        else:
            normal_cdf=lambda v:.5*(1+math.erf(v/math.sqrt(2)))
            delta=normal_cdf(.96+.46*l)
            p=normal_cdf(-.16+.11*l+.26*self.u[t])*(1-delta)+z*delta
            target=a
        margin=min(1e-6,p/2,(1-p)/2)
        return p-margin if target else p+margin

def _source_audit_checks(config):
    from itertools import product
    g=mod('generator.py')
    correct=True
    maximum=0.0
    for bits in product((0,1),repeat=6):
        rng=_SourceTrajectoryRNG(bits)
        with patch.object(g.random,'Random',return_value=rng):
            row=g.generate(config,1,0)
        for t in range(3):
            mean=1.0 if t==0 else bits[2*(t-1)+1]
            maximum=max(maximum,abs(row['L'+str(t+1)][0]-mean-rng.u[t]))
            correct=correct and row['Z'+str(t+1)]==[bits[2*t]] and row['A'+str(t+1)]==[bits[2*t+1]]
        expected=2*math.fsum(rng.u)/math.sqrt(3)+sum(config['beta'][t]*bits[2*t+1] for t in range(3))+.07
        maximum=max(maximum,abs(row['Y'][0]-expected))
    return [{'name':'source_nonzero_U_probability_thresholds_and_centered_outcome','passed':correct and maximum<1e-12,
             'details':{'trajectories':64,'max_equation_error':maximum,'U':[.3,-.4,.2],'outcome_noise':.07,
                        'limitation':'Preserves source shared recoverable U; not evidence of irreducible hidden confounding.'}}]

def verify(config):
    result = _existing_verify(config)
    result['checks'].extend(_source_audit_checks(config))
    result['passed'] = all(item['passed'] is True for item in result['checks'])
    result['shared_components'] += ' Source-audit additions exercise the same local generator against separate source-equation/moment calculations; no independent-person review or complete distribution proof is claimed.'
    return result
