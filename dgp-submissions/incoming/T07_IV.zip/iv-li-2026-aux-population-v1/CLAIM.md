# 维护人认领/查重材料（待确认）

- 拟贡献ID：`iv-li-2026-aux-population-v1`；任务：iv；mechanism_family_id：`iv-li-2026-aux-population`。
- 来源：Li W, Liu J, Ding P, Geng Z (2026). Identification and Multiply Robust Estimation of Causal Effects via Instrumental Variables from An Auxiliary Population. JASA 121(554):1372–1383. DOI:10.1080/01621459.2025.2576797. Read version has title ending auxiliary heterogeneous population.
- 链接：https://arxiv.org/pdf/2407.18166v1
- 版本：arXiv:2407.18166v1, 2024-07-25; journal bibliographic record retained separately; version-of-record equations not fully compared
- 定位：实际机制版本arXiv:2407.18166v1，2024-07-25：物理4–6页§2目标及Assumptions1–3；物理14–15页§6，14页V/U，15页R/Z/X/Y及目标2.22（已重新渲染15页）。PDF SHA256 bc12afdbee138b16f57d53977a349ffb84b81b08e89bb266389debb2334935a2。期刊2026记录与v1未逐式比较。
- 声明场景：source_v1。
- 目标：tau：目标总体R=0中E[Y(1)−Y(0)|R=0]，处理1减0。
- 主要适配：Use explicitly read v1 DGP; 2026 journal bibliographic status does not imply line-by-line matching with version of record.; Encode missing IV as Z_obs=0 when R=0 and supply R as the observation mask; never output the true unobserved IV.; Numerically integrate the exact population target instead of using source rounded value2.22 as exact truth; fit misspecification variants are not new DGPs.
- 用户截图显示GitHub账号wuwenti已创建PR #10；本文件不表示认领查重已批准或已获科学接收。
- 认领人真实姓名：未提供、未核实；不得用目录用户名代替人工署名。
- 待确认：family正式去重、来源版本对应、权利许可、具名科学审核、另一人独立复现。详细缺口及访问/核验失败记录保留在source_audit.json。
