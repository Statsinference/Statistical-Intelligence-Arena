# Li：辅助总体IV数据融合机制

状态：candidate / awaiting scientific review；未发送、未获维护人查重或具名审核。

## 7. 认领与创建

Li W, Liu J, Ding P, Geng Z (2026). Identification and Multiply Robust Estimation of Causal Effects via Instrumental Variables from An Auxiliary Population. JASA 121(554):1372–1383. DOI:10.1080/01621459.2025.2576797. Read version has title ending auxiliary heterogeneous population.

原始来源：https://arxiv.org/pdf/2407.18166v1

精确版本/定位：arXiv:2407.18166v1，2024-07-25；§2 Assumptions1–3，§6 Simulation studies，PDF物理14–15页（第15页已渲染看公式）；正式刊物2026记录另核对，不声称版本逐式一致。

### 完整机制与参数出处

Vk iid N(0,1)，vk=expit(2Vk−1)。ρ²=.75+1.5v1+1.5v2−.3v3−.3v4，U|V~U(−ρ,ρ)。P(R=1|V)=expit(.8+3v1−2v2−v3−v4)；R=1时P(Z=1|V)=expit(−.5−v1+1.5v2+2v3−v4)。α1(Z)=expit(1.3−2.4Z)，α0(V)=expit(v1−v2+.8v3−.6v4)；P(X=1)=Rα1+(1−R)α0+.1U。Y~N((2−R+2v1−v2+v3−.5v4)(1+X)+U,.5²)。原文§6给全部参数；目标为E[(1−pR(V))(2+2v1−v2+v3−.5v4)]/E[1−pR(V)]。

目标：tau：目标总体R=0中E[Y(1)−Y(0)|R=0]，处理1减0。

抽样单位：从两个总体合并而来的独立个体；R=0没有观测IV。

识别假设：一致性、潜在可忽略性；R=1中的条件IV独立/排除/相关；U⊥R|V；§2结构均值与equi-confounding限制；总体选择/处理正性。

### 新family结构核对

目标总体根本没有观测IV，需要辅助总体及跨总体结构假设；选择R改变效应与观测模式。这既不是Wang单总体二元IV，也不是二样本GWAS汇总MR或其他静态完整数据机制。

不以估计器、参数、种子或目标名称变化作为新增family依据。与Wang二元联合概率机制、Ye异方差MR及本轮其余机制的比较见总目录history/family_matrix.json。此为结构核对，不是维护人正式去重结论。

### 每项改动

- Use explicitly read v1 DGP; 2026 journal bibliographic status does not imply line-by-line matching with version of record.
- Encode missing IV as Z_obs=0 when R=0 and supply R as the observation mask; never output the true unobserved IV.
- Numerically integrate the exact population target instead of using source rounded value2.22 as exact truth; fit misspecification variants are not new DGPs.

### 缺失/范围未决

- 所选v1的数值参数完整；正式2026版本逐式比较尚未完成。
- 原文2.22为低精度数值，不把它当精确参考；积分误差单独记录。
- 基于完整已读公式重写Python；不运行作者代码/不获取应用中的真实数据。

### 真值推导与独立核验

令v=expit(2V−1)、s=P(R=1|V)。目标是∫(1−s)(2+2v1−v2+v3−.5v4)φ4(V)dV / ∫(1−s)φ4(V)dV。truth以80/96阶四维Gauss-Hermite比较，error=2倍阶数差+1e−12，为收敛诊断而非严格界。verify用标准正态[-9,9]上独立96/112阶Legendre和tanh链接交叉核对；尾部概率≤4 erfc(9/√2)，仍不把所有误差宣称为严格统一界。检验零因果效应时仅将原文常数1的effect_scale设0，属于验证输入，不新增场景；原source_v1固定1。

## 8. 审阅后检查

使用官方collect.py check --run --n 128 --seed 1729，默认检查全部declared scenarios。源码先逐项审阅；只运行独立重写的本地Python，不执行作者R/下载脚本。真值路线、独立核验、零路径/解析特例和共享部分写在下文及verify.py；全部退出码/失败快照在总目录logs。不得裁剪非法概率/密度或放宽tolerance取得PASS。

## 9. 交付

仅最新check passed且execution_performed后pack为本family独立ZIP；路径/SHA-256在总目录。源码、config、card任何改动均重检后新建ZIP快照。无论文PDF、原始敏感数据、模型权重或凭据。正式接收需具名审核、另一人独立复现、维护人决定；机器PASS不能授予accepted。

## 10. 真实数据

本贡献是synthetic_dgp，不是real_data_claim；不利用该分支绕过未知真值。未获取真实个体数据，未训练/微调PFN，未构造大型超分布、bootstrap或coverage，不修改旧实验/checkpoint，不执行submit/外发。AI辅助提取、编程和检查，不代签科学审核。


## 第7节固定贡献格式：本次整理与代码审阅

任务类别：IV；kind：synthetic_dgp。认领/查重材料已整理在总目录《认领与查重表.md》，尚未发送维护人，未获认领或科学接收。

| 文件 | 本贡献内容与检查范围 |
|---|---|
| `collection.json` | 来源citation/期刊年/版本定位、IV目标、假设、属性、入口及adaptation关系。 |
| `card.md` | 保留上述方程、参数出处、噪声、抽样单位、推导、权利及缺口；本附录记录整理改动。 |
| `config.json` | 保留v1原固定场景；effect_scale=1为实现中的显式默认，0仅用于核验，不新增收集场景。所有R/Z/X/Y固定系数同时列在card和source_audit。 |
| `schema.csv` | 只声明实际观察列；角色、数值类型、上下界与输出一致。 |
| `generator.py` | generate(config,n,seed)；局部RNG；支持config关键字；不输出潜变量或oracle。 |
| `truth.py` | truth(config)返回value、estimated_error；目标与干预方向以上文为准。 |
| `verify.py` | verify(config)返回passed、checks；共享模型/生成器的局限保留，不等于另一人复现。 |
| `requirements.txt` | 依赖及版本范围；不使用作者电脑绝对路径。 |

声明场景：`source_v1`。

属性：总协变量维数=4，有效维数=4；含义：Four active V components; expit(2V-1) transformations, heterogeneous treatment by V and R, product (2-R+...)*(1+X). IV recorded only for R=1; zero-filled slot with mask R is observation encoding, not exposure of missing Z.

参数调用示例（不要把整个config.json对象传给hook）：

```python
import json
from generator import generate
from truth import truth
from verify import verify
with open("config.json", encoding="utf-8") as f:
    settings = json.load(f)
params = settings["scenarios"][settings["default_scenario"]]
observed = generate(config=params, n=128, seed=1729)
result = truth(config=params)
validation = verify(config=params)
```

本次仅修正入口契约/输入报错、数值稳定性和核验覆盖，统一文本换行，并补充整理信息；不改来源方程、场景数、已声明目标、维度标签或tolerance。具体改动/未决事项见总目录《代码审阅报告.md》。所有有改动的源文件均重新check/pack，旧报告保存在history并明确不代表当前状态。未训练PFN、未运行作者R、未外发、未执行submit。


## 来源逐文件审核修正 r3

实际机制版本arXiv:2407.18166v1，2024-07-25：物理4–6页§2目标及Assumptions1–3；物理14–15页§6，14页V/U，15页R/Z/X/Y及目标2.22（已重新渲染15页）。PDF SHA256 bc12afdbee138b16f57d53977a349ffb84b81b08e89bb266389debb2334935a2。期刊2026记录与v1未逐式比较。

参数定位：§6：V四维iid标准正态；v=expit(2V−1)；rho²=.75+1.5v1+1.5v2−.3v3−.3v4；U~U(−rho,rho)；15页列全部R/Z/X/Y系数，X的U系数.1，Y噪声标准差.5。

本轮修正：

- 补主总体目标、掩码含义、准确页码及固定参数说明。
- 加入非零U、两总体、不同Z/X取值下的实际生成器阈值/条件结局检查。
- 保留严格概率守卫及数值误差诊断的非严格界限说明，不裁剪概率或改tolerance。

保留未决：

- 期刊终版与实际读取v1仍待逐式核对。
- 原文2.22是舍入值；积分误差诊断不是严格统一误差上界，现有概率网格检查也不是全域证明。

详细八份文件对照见本贡献source_audit.md/json。新增核验是共享模型下的独立计算路线，不是具名科学审核或另一人复现。保持原scenario数量、所选机制和tolerance；验证用零路径不作为新场景。后续实际check/pack结果以本轮总清单与checks/report.json为准。


## 八部分标准修正 r4（2026-10-30）

基线维数口径：baseline=['V1', 'V2', 'V3', 'V4']，dimension=4、effective_dimension=4。工具变量、处理后变量和重复时点不计作基线协变量。标签参考n_ref=128个独立受试者，p/n_ref=0.03125000；high_dimensional=false仅按所述基线口径和参考设置解释。实际n仍由接口传入，不对任意n/p扩展作高维承诺。

依赖：Python>=3.10；NumPy>=1.24,<3为必需依赖；无可选依赖、训练/GPU依赖。独立干净环境安装与运行证据在本目录dependency_check.json及总目录logs/eight-parts-r4；仅宣称实际测试的平台/版本，不宣称覆盖所有Python或NumPy版本。

干净安装实际结果：本贡献独立venv初始无NumPy、未继承系统site-packages；按requirements.txt安装退出0，pip check退出0；测试Python 3.12.14，NumPy 2.3.5。详见dependency_check.json；模型运行以随后正式check为准。
