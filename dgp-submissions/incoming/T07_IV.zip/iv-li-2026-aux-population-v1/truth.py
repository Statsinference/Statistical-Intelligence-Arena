import math,numpy as np
from numpy.polynomial.hermite import hermgauss
def integrate(c,k):
 z,w=hermgauss(k);v=1/(1+np.exp(-c['transform_intercept']-c['transform_slope']*np.sqrt(2)*z));w=w/math.sqrt(math.pi)
 a=np.repeat(v,k);b=np.tile(v,k);p=np.repeat(w,k)*np.tile(w,k)
 s34=a+b;t34=a-.5*b;num=den=0.
 for i in range(0,k*k,64):
  r0=1/(1+np.exp((.8+3*a[i:i+64]-2*b[i:i+64])[:,None]-s34[None,:]))
  effect=2+2*a[i:i+64,None]-b[i:i+64,None]+t34[None,:];wt=p[i:i+64,None]*p[None,:]
  den+=float(np.sum(wt*r0));num+=float(np.sum(wt*r0*effect))
 return c.get('effect_scale',1.)*num/den
def truth(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 low=integrate(c,80);high=integrate(c,96)
 return {'value':high,'estimated_error':2*abs(high-low)+1e-12,'method':'Four-dimensional Gauss-Hermite80/96 weighted target-population integral.','error_interpretation':'Observed convergence diagnostic, not a rigorous uniform bound; independent finite-domain Legendre route in verify.'}
