import math,numpy as np,importlib.util
from numpy.polynomial.legendre import leggauss
from pathlib import Path
from unittest.mock import patch
def mod(f):
 s=importlib.util.spec_from_file_location('aux_'+f,Path(__file__).with_name(f));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def reference(c,k):
 # Independent nodes/rule: truncated standard normals on [-9,9].
 z,w=leggauss(k);z=9*z;w=9*w*np.exp(-z*z/2)/math.sqrt(2*math.pi)
 t=c['transform_intercept']+c['transform_slope']*z;v=.5+.5*np.tanh(t/2)
 a=np.repeat(v,k);b=np.tile(v,k);p=np.repeat(w,k)*np.tile(w,k)
 numerator=denominator=0.
 for i in range(0,k*k,64):
  sel=.5+.5*np.tanh((-.8-3*a[i:i+64,None]+2*b[i:i+64,None]+a[None,:]+b[None,:])/2)
  tau=2+2*a[i:i+64,None]-b[i:i+64,None]+a[None,:]-.5*b[None,:]
  weight=p[i:i+64,None]*p[None,:];denominator+=float(np.sum(weight*sel));numerator+=float(np.sum(weight*sel*tau))
 return c.get('effect_scale',1.)*numerator/denominator

class ForcedTreatment:
 def __init__(self,x):self.x=x;self.calls=0
 def gauss(self,mean,sd):return mean
 def uniform(self,low,high):return (low+high)/2
 def random(self):
  self.calls+=1
  return .999999 if self.calls==1 or not self.x else 0.

def structural_contrast(c):
 g=mod('generator.py');out=[]
 for x in (0,1):
  with patch.object(g.random,'Random',return_value=ForcedTreatment(x)):
   row=g.generate(c,1,0)
  assert row['R']==[0] and row['X']==[x]
  out.append(row['Y'][0])
 return out[1]-out[0]

def _existing_verify(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 v=mod('truth.py').truth(c);ref=reference(c,112);coarse=reference(c,96)
 # Check probability support on a bounded transformed-covariate grid plus both U endpoints.
 valid=True;minimum=1.;maximum=0.
 import itertools
 for a,b,d,f in itertools.product(np.linspace(0,1,9),repeat=4):
  rho=math.sqrt(.75+1.5*a+1.5*b-.3*d-.3*f)
  for base in (1/(1+math.exp(-1.3)),1/(1+math.exp(1.1)),1/(1+math.exp(-a+b-.8*d+.6*f))):
   minimum=min(minimum,base-.1*rho);maximum=max(maximum,base+.1*rho)
 valid=minimum>=0 and maximum<=1
 rows=mod('generator.py').generate(c,128,1729)
 null=dict(c,effect_scale=0.);null_truth=mod('truth.py').truth(null)['value'];null_ref=reference(null,24)
 base=1/(1+math.exp(1));expected=c.get('effect_scale',1.)*(2+1.5*base)
 checks=[{'name':'actual_sampler_structural_intervention_and_zero_path','passed':abs(structural_contrast(c)-expected)<1e-12 and abs(structural_contrast(null))<1e-12,'details':'Forced X=0/1 at V=0,U=0,R=0; zero-effect and nonzero path both exercise the actual sampler.'},{'name':'GH_vs_independent_Legendre','passed':abs(v['value']-ref)<1e-8,'details':{'GH':v['value'],'Legendre112':ref,'difference':abs(v['value']-ref)}},
 {'name':'two_rules_converge','passed':v['estimated_error']<1e-8 and abs(ref-coarse)<1e-8},
 {'name':'probability_support_grid','passed':bool(valid),'details':{'min':minimum,'max':maximum,'limitation':'grid audit plus per-draw strict guard; not a global analytic proof'}},
 {'name':'missing_IV_mask_and_no_U','passed':all(r or z==0 for r,z in zip(rows['R'],rows['Z_obs'])) and 'U' not in rows},
 {'name':'rounded_paper_anchor','passed':round(v['value'],2)==2.22,'details':'2.22 is rounded, not used as exact truth'},
 {'name':'zero_treatment_effect_algebra','passed':abs(null_truth)<1e-12 and abs(null_ref)<1e-12,'details':'Setting the coefficient of X in the structural outcome to zero gives Y(1)-Y(0)=0; independent structural special case, not a second claimed source scenario.'}]
 return {'passed':all(x['passed'] for x in checks),'checks':checks,'shared_components':'Same equations/config; independent quadrature nodes and tanh versus expit evaluations. Numerical convergence diagnostics are not uniform error theorems; both quadrature and actual-sampler zero-effect paths are checked.'}


class _SourceThresholdRNG:
    def __init__(self, config, r, z, x, direction):
        self.c=config
        self.target=(r,z,x)
        self.normals=iter((-1.0,0.2,0.5,1.0,0.3))
        self.direction=direction
        self.calls=0
        raw=(-1.0,0.2,0.5,1.0)
        self.v=[0.5+0.5*math.tanh((-1+2*a)/2) for a in raw]
        a,b,d,f=self.v
        self.rho=math.sqrt(.75+1.5*a+1.5*b-.3*d-.3*f)
        self.u=direction*.5*self.rho
    def gauss(self,mu,sd):return mu+sd*next(self.normals)
    def uniform(self,lo,hi):return self.u
    def random(self):
        a,b,d,f=self.v
        r,z,x=self.target
        expit=lambda v:0.5+0.5*math.tanh(v/2)
        if self.calls==0:prob=expit(.8+3*a-2*b-d-f);bit=r
        elif r and self.calls==1:prob=expit(-.5-a+1.5*b+2*d-f);bit=z
        else:prob=(expit(1.3-2.4*z) if r else expit(a-b+.8*d-.6*f))+.1*self.u;bit=x
        self.calls+=1
        margin=min(1e-6,prob/2,(1-prob)/2)
        return prob-margin if bit else prob+margin

def _source_audit_checks(config):
    g=mod('generator.py')
    maximum=0.0
    assignments=True
    for r in (0,1):
        for z in ((0,) if r==0 else (0,1)):
            for x in (0,1):
                for direction in (-1,1):
                    rng=_SourceThresholdRNG(config,r,z,x,direction)
                    with patch.object(g.random,'Random',return_value=rng):
                        row=g.generate(config,1,0)
                    a,b,d,f=rng.v
                    expected=(2-r+2*a-b+d-.5*f)*(1+config.get('effect_scale',1.0)*x)+rng.u+.5*.3
                    maximum=max(maximum,abs(row['Y'][0]-expected))
                    assignments=assignments and row['R']==[r] and row['Z_obs']==[z] and row['X']==[x]
    constants=config['transform_slope']==2 and config['transform_intercept']==-1 and config['noise_sd']==.5 and config['u_treatment_coef']==.1
    return [
        {'name':'source_conditional_probabilities_nonzero_U_and_Y_noise','passed':assignments and maximum<1e-12,
         'details':{'controlled_cases':12,'max_outcome_error':maximum,'threshold_margin':1e-6}},
        {'name':'source_v1_fixed_constants','passed':constants}
    ]

def verify(config):
    result = _existing_verify(config)
    result['checks'].extend(_source_audit_checks(config))
    result['passed'] = all(item['passed'] is True for item in result['checks'])
    result['shared_components'] += ' Source-audit additions exercise the same local generator against separate source-equation/moment calculations; no independent-person review or complete distribution proof is claimed.'
    return result
