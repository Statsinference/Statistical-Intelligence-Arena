# iv-li-2026-aux-population-v1：八份文件来源核对与修正 r3

实际来源：[Li W, Liu J, Ding P, Geng Z (2026). Identification and Multiply Robust Estimation of Causal Effects via Instrumental Variables from An Auxiliary Population. JASA 121(554):1372–1383. DOI:10.1080/01621459.2025.2576797. Read version has title ending auxiliary heterogeneous population.](https://arxiv.org/pdf/2407.18166v1)。

精确定位：实际机制版本arXiv:2407.18166v1，2024-07-25：物理4–6页§2目标及Assumptions1–3；物理14–15页§6，14页V/U，15页R/Z/X/Y及目标2.22（已重新渲染15页）。PDF SHA256 bc12afdbee138b16f57d53977a349ffb84b81b08e89bb266389debb2334935a2。期刊2026记录与v1未逐式比较。

参数出处：§6：V四维iid标准正态；v=expit(2V−1)；rho²=.75+1.5v1+1.5v2−.3v3−.3v4；U~U(−rho,rho)；15页列全部R/Z/X/Y系数，X的U系数.1，Y噪声标准差.5。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；实际机制版本arXiv:2407.18166v1，2024-07-25：物理4–6页§2目标及Assumptions1–3；物理14–15页§6，14页V/U，15页R/Z/X/Y及目标2.22（已重新渲染15页）。PDF SHA256 bc12afdbee138b16f57d53977a349ffb84b81b08e89bb266389debb2334935a2。期刊2026记录与v1未逐式比较。 iid individuals from the merged population; R selects the target or auxiliary population. Z is observed only when R=1; Z_obs=0 is a masked slot when R=0, not an observed target-population instrument. U is latent. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；§6：V四维iid标准正态；v=expit(2V−1)；rho²=.75+1.5v1+1.5v2−.3v3−.3v4；U~U(−rho,rho)；15页列全部R/Z/X/Y系数，X的U系数.1，Y噪声标准差.5。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；保留v1原固定场景；effect_scale=1为实现中的显式默认，0仅用于核验，不新增收集场景。所有R/Z/X/Y固定系数同时列在card和source_audit。 |
| `schema.csv` | 8个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid individuals from the merged population; R selects the target or auxiliary population. Z is observed only when R=1; Z_obs=0 is a masked slot when R=0, not an observed target-population instrument. U is latent. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Target R=0 ATE from E[(1-p_R(V))*tau(V)]/E[1-p_R(V)]; Gauss-Hermite80/96 with independent Legendre96/112 convergence diagnostics, plus actual-sampler interventions and threshold tests. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；补主总体目标、掩码含义、准确页码及固定参数说明。；加入非零U、两总体、不同Z/X取值下的实际生成器阈值/条件结局检查。；保留严格概率守卫及数值误差诊断的非严格界限说明，不裁剪概率或改tolerance。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`source_v1`。

属性方程依据：Four active V components; expit(2V-1) transformations, heterogeneous treatment by V and R, product (2-R+...)*(1+X). IV recorded only for R=1; zero-filled slot with mask R is observation encoding, not exposure of missing Z.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 期刊终版与实际读取v1仍待逐式核对。
- 原文2.22是舍入值；积分误差诊断不是严格统一误差上界，现有概率网格检查也不是全域证明。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=4/4；baseline=['V1', 'V2', 'V3', 'V4']。参考n_ref=128（independent subjects），p/n_ref=0.03125000。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
