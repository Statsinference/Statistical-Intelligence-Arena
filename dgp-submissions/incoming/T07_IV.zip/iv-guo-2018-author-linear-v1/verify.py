import math,importlib.util,itertools
from pathlib import Path
from unittest.mock import patch
def _mod(name):
 s=importlib.util.spec_from_file_location('guo_'+name,Path(__file__).with_name(name));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
class R:
 def __init__(self,values):self.v=iter(values)
 def gauss(self,mu,sd):return mu+sd*next(self.v)
def _covs(c):
 g=_mod('generator.py');rows=[];k=12
 for j in range(k):
  for sign in (-1,1):
   v=[0.]*k;v[j]=sign*math.sqrt(k)
   with patch.object(g.random,'Random',return_value=R(v)):rows.append(g.generate(c,1,0))
 vals={key:[row[key][0] for row in rows] for key in rows[0]}
 def cov(a,b):
  av=sum(vals[a])/len(rows);bv=sum(vals[b])/len(rows)
  return sum((x-av)*(y-bv) for x,y in zip(vals[a],vals[b]))/len(rows)
 return [cov('Z'+str(j),'Y')/cov('Z'+str(j),'D') for j in range(1,11)]
def _existing_verify(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 ratios=_covs(c);t=_mod('truth.py').truth(c)['value'];null=dict(c,beta=0.)
 checks=[{'name':'actual_generator_sigma_point_valid_IV_Wald','passed':max(abs(v-t) for v in ratios[3:])<1e-12},
 {'name':'invalid_IV_direct_path_detected','passed':max(abs(v-(t+3)) for v in ratios[:3])<1e-12},
 {'name':'zero_causal_path','passed':max(abs(v) for v in _covs(null)[3:])<1e-12},
 {'name':'pinned_author_fixture','passed':c=={'beta':1.,'d_intercept':.5,'y_intercept':-.5,'gamma':[1.]*10,'pi':[3.]*3+[0.]*7,'rho':.8}}]
 return {'passed':all(x['passed'] for x in checks),'checks':checks,'shared_components':'Same scientific law and actual sampler; structural truth cross-checked using exact independent-driver sigma-point covariances, not truth versus itself. Not independent-person review.'}


def _source_audit_checks(config):
    # Fixed author constants; do not derive the expected matrix from generator helpers.
    g = _mod('generator.py')
    keys = [f'Z{j+1}' for j in range(10)] + ['D', 'Y']
    points = []
    for j in range(12):
        for sign in (-1, 1):
            v = [0.0] * 12
            v[j] = sign * math.sqrt(12)
            with patch.object(g.random, 'Random', return_value=R(v)):
                row = g.generate(config, 1, 0)
            points.append([row[k][0] for k in keys])
    means = [math.fsum(r[j] for r in points)/24 for j in range(12)]
    cov = [[math.fsum((r[i]-means[i])*(r[j]-means[j]) for r in points)/24
            for j in range(12)] for i in range(12)]
    expected = [[0.0]*12 for _ in range(12)]
    for j in range(10):
        expected[j][j] = 1.0
        expected[j][10] = expected[10][j] = 1.0
        expected[j][11] = expected[11][j] = 4.0 if j < 3 else 1.0
    expected[10][10] = 11.0
    expected[10][11] = expected[11][10] = 20.8
    expected[11][11] = 58.6
    mean_error = max(abs(x-y) for x,y in zip(means, [0.0]*10+[0.5,0.0]))
    cov_error = max(abs(cov[i][j]-expected[i][j]) for i in range(12) for j in range(12))
    errors = [(r[10]-0.5-sum(r[:10]), r[11]+0.5-r[10]-3*sum(r[:3])) for r in points]
    em = [math.fsum(r[j] for r in errors)/24 for j in range(2)]
    ec = [[math.fsum((r[i]-em[i])*(r[j]-em[j]) for r in errors)/24 for j in range(2)] for i in range(2)]
    discrepancy = max(abs(ec[i][j]-((1.0,0.8),(0.8,1.0))[i][j]) for i in range(2) for j in range(2))
    return [
        {'name':'source_intercepts_and_full_covariance','passed':mean_error<1e-12 and cov_error<1e-12,
         'details':{'max_mean_error':mean_error,'max_covariance_error':cov_error}},
        {'name':'actual_reconstructed_error_covariance','passed':discrepancy<1e-12,
         'details':{'covariance':ec,'max_error':discrepancy}}
    ]

def verify(config):
    result = _existing_verify(config)
    result['checks'].extend(_source_audit_checks(config))
    result['passed'] = all(item['passed'] is True for item in result['checks'])
    result['shared_components'] += ' Source-audit additions exercise the same local generator against separate source-equation/moment calculations; no independent-person review or complete distribution proof is claimed.'
    return result
