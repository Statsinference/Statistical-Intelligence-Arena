# Guo：作者代码线性无效IV机制

状态：candidate / awaiting scientific review；未发送、未获维护人查重或具名审核。

## 7. 认领与创建

Guo Z, Kang H, Cai TT, Small DS (2018). Confidence intervals for causal effects with invalid instruments by using two-stage hard thresholding with voting. JRSS-B 80(4):793–815. DOI:10.1111/rssb.12275.

原始来源：https://github.com/hyunseungkang/invalidIV/blob/02d8c3983525182111efbb559dd505c9d168e351/example.R

精确版本/定位：论文§2.1、§5.1；实际生成来源example.R #Working Low Dimensional Example / #Create data，commit 02d8c3983525182111efbb559dd505c9d168e351；下载raw SHA256 0d0b0e735aef93f34de1cd13dec27443804f527afed6be17d6469201abe8fe06。作者代码只读未运行。

### 完整机制与参数出处

Zj iid N(0,1), j=1…10；(εD,εY)为均值0联合正态，方差均1，Cov=.8。D=.5+ΣZj+εD；Y=−.5+3(Z1+Z2+Z3)+D+εY。全部常数/分布来自上述固定commit的example.R；所读论文§5.1对Cov=.25正文场景仅明确误差矩，完整联合误差法则未确认；这是未选正文场景的缺口，不是当前作者示例缺参。

目标：beta：do(D=d+1)−do(D=d)的结构均值效应，1。

抽样单位：独立个体。

识别假设：线性结构方程、一致性、无干扰；Z外生；有效子集排除/相关；多数或plurality识别，无效子集不满足排除。

### 新family结构核对

十个独立候选IV中存在Zj→Y直接路径（j≤3），有效子集未知；不是Wang的二元依从层，也不是Ye借异方差识别的SNP机制。与条件图SEM的差别是：这里有独立根工具及无效直接路径，没有调整C、图中间节点或双向混合图。

不以估计器、参数、种子或目标名称变化作为新增family依据。与Wang二元联合概率机制、Ye异方差MR及本轮其余机制的比较见总目录history/family_matrix.json。此为结构核对，不是维护人正式去重结论。

### 每项改动

- Python local RNG replaces MASS normal sampler; Gaussian covariance and intercepts follow the pinned author example, not article Table 1.
- Select scalar structural effect; no estimator fitting or original Monte Carlo experiment.

### 缺失/范围未决

- 作者代码例子与论文仿真表参数不同，已分清；不宣称重现原表。
- 固定commit提供完整所选机制，当前无待补数值参数；权利、正式版对应和维护人去重待审核。

### 真值推导与独立核验

固定Z/误差，D干预增加1使Y增加β=1。独立路线用实际生成器的12个独立正态驱动做±√12 sigma点，精确计算二阶矩；有效Z4…Z10的Cov(Z,Y)/Cov(Z,D)=β，无效Z1…Z3比值=β+3。零β特例有效IV比值为0。共享原文模型与实际生成器，不是独立人员复现；无积分误差，estimated_error=0。

## 8. 审阅后检查

使用官方collect.py check --run --n 128 --seed 1729，默认检查全部declared scenarios。源码先逐项审阅；只运行独立重写的本地Python，不执行作者R/下载脚本。真值路线、独立核验、零路径/解析特例和共享部分写在下文及verify.py；全部退出码/失败快照在总目录logs。不得裁剪非法概率/密度或放宽tolerance取得PASS。

## 9. 交付

仅最新check passed且execution_performed后pack为本family独立ZIP；路径/SHA-256在总目录。源码、config、card任何改动均重检后新建ZIP快照。无论文PDF、原始敏感数据、模型权重或凭据。正式接收需具名审核、另一人独立复现、维护人决定；机器PASS不能授予accepted。

## 10. 真实数据

本贡献是synthetic_dgp，不是real_data_claim；不利用该分支绕过未知真值。未获取真实个体数据，未训练/微调PFN，未构造大型超分布、bootstrap或coverage，不修改旧实验/checkpoint，不执行submit/外发。AI辅助提取、编程和检查，不代签科学审核。


## 第7节固定贡献格式：本次整理与代码审阅

任务类别：IV；kind：synthetic_dgp。认领/查重材料已整理在总目录《认领与查重表.md》，尚未发送维护人，未获认领或科学接收。

| 文件 | 本贡献内容与检查范围 |
|---|---|
| `collection.json` | 来源citation/期刊年/版本定位、IV目标、假设、属性、入口及adaptation关系。 |
| `card.md` | 保留上述方程、参数出处、噪声、抽样单位、推导、权利及缺口；本附录记录整理改动。 |
| `config.json` | 系数为作者示例固定常数，不是重新抽取的系数；Python RNG替代R，仅样本序列不同。 |
| `schema.csv` | 只声明实际观察列；角色、数值类型、上下界与输出一致。 |
| `generator.py` | generate(config,n,seed)；局部RNG；支持config关键字；不输出潜变量或oracle。 |
| `truth.py` | truth(config)返回value、estimated_error；目标与干预方向以上文为准。 |
| `verify.py` | verify(config)返回passed、checks；共享模型/生成器的局限保留，不等于另一人复现。 |
| `requirements.txt` | 依赖及版本范围；不使用作者电脑绝对路径。 |

声明场景：`author_lowdim`。

属性：总协变量维数=0，有效维数=0；含义：No observed baseline covariates. Ten instruments, three invalid; not ten confounders. Linear homoskedastic equations.

参数调用示例（不要把整个config.json对象传给hook）：

```python
import json
from generator import generate
from truth import truth
from verify import verify
with open("config.json", encoding="utf-8") as f:
    settings = json.load(f)
params = settings["scenarios"][settings["default_scenario"]]
observed = generate(config=params, n=128, seed=1729)
result = truth(config=params)
validation = verify(config=params)
```

本次仅修正入口契约/输入报错、数值稳定性和核验覆盖，统一文本换行，并补充整理信息；不改来源方程、场景数、已声明目标、维度标签或tolerance。具体改动/未决事项见总目录《代码审阅报告.md》。所有有改动的源文件均重新check/pack，旧报告保存在history并明确不代表当前状态。未训练PFN、未运行作者R、未外发、未执行submit。


## 来源逐文件审核修正 r3

机制依据example.R，commit 02d8c3983525182111efbb559dd505c9d168e351，第9–25行（尤其18–25）；raw LF SHA256 0d0b0e735aef93f34de1cd13dec27443804f527afed6be17d6469201abe8fe06。论文对照为arXiv:1603.05224v3，2017-08-08，物理5–6页§2.1 Eq.(1)–(3)，物理21页§5.1/5.2；非期刊终版逐式核对。

参数定位：example.R 18: n=500,L=10,s=3；19: beta=1,gamma十个1,alpha前三个3其余0（本包pi）；20/23: 联合正态方差1、协方差.8；21: iid标准正态Z；24/25: D/Y截距.5/−.5。

本轮修正：

- 修正把固定作者系数误称为新抽向量的模板句；补版本/页码/行号及alpha到pi命名映射。
- 正式verify加入均值、完整协方差与误差协方差核验，覆盖旧IV矩比看不到的截距/相关误差。
- 移除不需要的numpy依赖；修正通用抽样/真值文字，原场景和参数不变。

保留未决：

- 作者示例与论文正文Cov=.25及表1的pi幅度不同；当前仅声称作者示例适配。
- 所读正文§5.1仅给误差矩；未选正文场景完整误差法则仍未确认。

详细八份文件对照见本贡献source_audit.md/json。新增核验是共享模型下的独立计算路线，不是具名科学审核或另一人复现。保持原scenario数量、所选机制和tolerance；验证用零路径不作为新场景。后续实际check/pack结果以本轮总清单与checks/report.json为准。


## 八部分标准修正 r4（2026-10-30）

基线维数口径：baseline=[]，dimension=0、effective_dimension=0。工具变量、处理后变量和重复时点不计作基线协变量。标签参考n_ref=128个独立受试者，p/n_ref=0.00000000；high_dimensional=false仅按所述基线口径和参考设置解释。实际n仍由接口传入，不对任意n/p扩展作高维承诺。

依赖：Python>=3.10；无第三方必需依赖；无可选依赖、训练/GPU依赖。独立干净环境安装与运行证据在本目录dependency_check.json及总目录logs/eight-parts-r4；仅宣称实际测试的平台/版本，不宣称覆盖所有Python或NumPy版本。

干净安装实际结果：本贡献独立venv初始无NumPy、未继承系统site-packages；按requirements.txt安装退出0，pip check退出0；测试Python 3.12.14，NumPy None。详见dependency_check.json；模型运行以随后正式check为准。


## 2026-10-31：严格示例格式整理

文件布局与指定单DGP示例一致。CLAIM.md记录真实的待认领状态，environment.json记录本贡献实测运行环境。既有source_audit.md、missing_parameters.json、dependency_check.json及网络interface_claim.md没有丢弃，完整内容合并保存在source_audit.json的format_revision_20261031.merged_supplementary_records。原collection扩展元数据保留在同文件preserved_extension_metadata，含维数参考及网络接口未批准状态。

原机制方程、全部场景参数、schema、generator/truth/verify及依赖逐字不变；本次不是新的原文阅读或科学接收。认领人真实姓名和维护人批准尚未确认。修改元数据后重新执行全部场景check并pack，旧报告不复用为本轮证明。

### 既有逐文件审计记录（原文保留）

# iv-guo-2018-author-linear-v1：八份文件来源核对与修正 r3

实际来源：[Guo Z, Kang H, Cai TT, Small DS (2018). Confidence intervals for causal effects with invalid instruments by using two-stage hard thresholding with voting. JRSS-B 80(4):793–815. DOI:10.1111/rssb.12275.](https://github.com/hyunseungkang/invalidIV/blob/02d8c3983525182111efbb559dd505c9d168e351/example.R)。

精确定位：机制依据example.R，commit 02d8c3983525182111efbb559dd505c9d168e351，第9–25行（尤其18–25）；raw LF SHA256 0d0b0e735aef93f34de1cd13dec27443804f527afed6be17d6469201abe8fe06。论文对照为arXiv:1603.05224v3，2017-08-08，物理5–6页§2.1 Eq.(1)–(3)，物理21页§5.1/5.2；非期刊终版逐式核对。

参数出处：example.R 18: n=500,L=10,s=3；19: beta=1,gamma十个1,alpha前三个3其余0（本包pi）；20/23: 联合正态方差1、协方差.8；21: iid标准正态Z；24/25: D/Y截距.5/−.5。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；机制依据example.R，commit 02d8c3983525182111efbb559dd505c9d168e351，第9–25行（尤其18–25）；raw LF SHA256 0d0b0e735aef93f34de1cd13dec27443804f527afed6be17d6469201abe8fe06。论文对照为arXiv:1603.05224v3，2017-08-08，物理5–6页§2.1 Eq.(1)–(3)，物理21页§5.1/5.2；非期刊终版逐式核对。 iid individuals. Ten independent standard-normal candidate instruments are independent of the jointly normal structural errors; within-individual error variances are 1 and covariance is 0.8. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；example.R 18: n=500,L=10,s=3；19: beta=1,gamma十个1,alpha前三个3其余0（本包pi）；20/23: 联合正态方差1、协方差.8；21: iid标准正态Z；24/25: D/Y截距.5/−.5。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；系数为作者示例固定常数，不是重新抽取的系数；Python RNG替代R，仅样本序列不同。 |
| `schema.csv` | 12个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid individuals. Ten independent standard-normal candidate instruments are independent of the jointly normal structural errors; within-individual error variances are 1 and covariance is 0.8. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic unit intervention contrast beta=1; actual-generator means, full covariance and reconstructed error covariance checked against pinned author constants, in addition to IV moment ratios. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；修正把固定作者系数误称为新抽向量的模板句；补版本/页码/行号及alpha到pi命名映射。；正式verify加入均值、完整协方差与误差协方差核验，覆盖旧IV矩比看不到的截距/相关误差。；移除不需要的numpy依赖；修正通用抽样/真值文字，原场景和参数不变。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`author_lowdim`。

属性方程依据：No observed baseline covariates. Ten instruments, three invalid; not ten confounders. Linear homoskedastic equations.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 作者示例与论文正文Cov=.25及表1的pi幅度不同；当前仅声称作者示例适配。
- 所读正文§5.1仅给误差矩；未选正文场景完整误差法则仍未确认。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=0/0；baseline=[]。参考n_ref=128（independent subjects），p/n_ref=0.00000000。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
