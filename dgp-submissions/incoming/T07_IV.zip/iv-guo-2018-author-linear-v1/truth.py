def truth(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 return {'value':float(c['beta']),'estimated_error':0.,'method':'Analytic structural unit intervention contrast; no observation-based estimate.'}
