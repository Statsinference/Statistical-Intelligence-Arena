# 维护人认领/查重材料（待确认）

- 拟贡献ID：`iv-guo-2018-author-linear-v1`；任务：iv；mechanism_family_id：`iv-guo-2018-author-linear`。
- 来源：Guo Z, Kang H, Cai TT, Small DS (2018). Confidence intervals for causal effects with invalid instruments by using two-stage hard thresholding with voting. JRSS-B 80(4):793–815. DOI:10.1111/rssb.12275.
- 链接：https://github.com/hyunseungkang/invalidIV/blob/02d8c3983525182111efbb559dd505c9d168e351/example.R
- 版本：Author example.R commit 02d8c3983525182111efbb559dd505c9d168e351; comparison arXiv:1603.05224v3 (2017-08-08); no full journal-version equivalence claim
- 定位：机制依据example.R，commit 02d8c3983525182111efbb559dd505c9d168e351，第9–25行（尤其18–25）；raw LF SHA256 0d0b0e735aef93f34de1cd13dec27443804f527afed6be17d6469201abe8fe06。论文对照为arXiv:1603.05224v3，2017-08-08，物理5–6页§2.1 Eq.(1)–(3)，物理21页§5.1/5.2；非期刊终版逐式核对。
- 声明场景：author_lowdim。
- 目标：beta：do(D=d+1)−do(D=d)的结构均值效应，1。
- 主要适配：Python local RNG replaces MASS normal sampler; Gaussian covariance and intercepts follow the pinned author example, not article Table 1.; Select scalar structural effect; no estimator fitting or original Monte Carlo experiment.
- 用户截图显示GitHub账号wuwenti已创建PR #10；本文件不表示认领查重已批准或已获科学接收。
- 认领人真实姓名：未提供、未核实；不得用目录用户名代替人工署名。
- 待确认：family正式去重、来源版本对应、权利许可、具名科学审核、另一人独立复现。详细缺口及访问/核验失败记录保留在source_audit.json。
