# iv-guo-2018-author-linear-v1：八份文件来源核对与修正 r3

实际来源：[Guo Z, Kang H, Cai TT, Small DS (2018). Confidence intervals for causal effects with invalid instruments by using two-stage hard thresholding with voting. JRSS-B 80(4):793–815. DOI:10.1111/rssb.12275.](https://github.com/hyunseungkang/invalidIV/blob/02d8c3983525182111efbb559dd505c9d168e351/example.R)。

精确定位：机制依据example.R，commit 02d8c3983525182111efbb559dd505c9d168e351，第9–25行（尤其18–25）；raw LF SHA256 0d0b0e735aef93f34de1cd13dec27443804f527afed6be17d6469201abe8fe06。论文对照为arXiv:1603.05224v3，2017-08-08，物理5–6页§2.1 Eq.(1)–(3)，物理21页§5.1/5.2；非期刊终版逐式核对。

参数出处：example.R 18: n=500,L=10,s=3；19: beta=1,gamma十个1,alpha前三个3其余0（本包pi）；20/23: 联合正态方差1、协方差.8；21: iid标准正态Z；24/25: D/Y截距.5/−.5。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；机制依据example.R，commit 02d8c3983525182111efbb559dd505c9d168e351，第9–25行（尤其18–25）；raw LF SHA256 0d0b0e735aef93f34de1cd13dec27443804f527afed6be17d6469201abe8fe06。论文对照为arXiv:1603.05224v3，2017-08-08，物理5–6页§2.1 Eq.(1)–(3)，物理21页§5.1/5.2；非期刊终版逐式核对。 iid individuals. Ten independent standard-normal candidate instruments are independent of the jointly normal structural errors; within-individual error variances are 1 and covariance is 0.8. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；example.R 18: n=500,L=10,s=3；19: beta=1,gamma十个1,alpha前三个3其余0（本包pi）；20/23: 联合正态方差1、协方差.8；21: iid标准正态Z；24/25: D/Y截距.5/−.5。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；系数为作者示例固定常数，不是重新抽取的系数；Python RNG替代R，仅样本序列不同。 |
| `schema.csv` | 12个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid individuals. Ten independent standard-normal candidate instruments are independent of the jointly normal structural errors; within-individual error variances are 1 and covariance is 0.8. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic unit intervention contrast beta=1; actual-generator means, full covariance and reconstructed error covariance checked against pinned author constants, in addition to IV moment ratios. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；修正把固定作者系数误称为新抽向量的模板句；补版本/页码/行号及alpha到pi命名映射。；正式verify加入均值、完整协方差与误差协方差核验，覆盖旧IV矩比看不到的截距/相关误差。；移除不需要的numpy依赖；修正通用抽样/真值文字，原场景和参数不变。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`author_lowdim`。

属性方程依据：No observed baseline covariates. Ten instruments, three invalid; not ten confounders. Linear homoskedastic equations.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- 作者示例与论文正文Cov=.25及表1的pi幅度不同；当前仅声称作者示例适配。
- 所读正文§5.1仅给误差矩；未选正文场景完整误差法则仍未确认。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=0/0；baseline=[]。参考n_ref=128（independent subjects），p/n_ref=0.00000000。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
