# iv-wei-2021-censored-quantile-v1：八份文件来源核对与修正 r3

实际来源：[Wei B, Peng L, Zhang MJ, Fine JP (2021). Estimation of causal quantile effects with a binary instrumental variable and censored data. JRSS-B 83(3):559–578. DOI:10.1111/rssb.12431.](https://academic.oup.com/jrsssb/article/83/3/559/7056039)。

精确定位：期刊全文HTML：JRSS-B83(3),2021,559–578；§2 A1–A4；§3.1 Eq.(1)及CQCE定义；§4六步生成，A/B结局及紧随的log-quantile公式，G/H段删失端点2.2/1.4。本轮全文由academic.oup.com重定向oup.silverchair-cdn.com/article-minimal/7056039并可读。

参数出处：§4：X1~U(0,1),X2~Bern(.5)，CO/AT/NT=2/3,1/6,1/6，IV logit=.1X2+X1²+X1X2+N(0,.5²)；A/B结局对应G/H；G/H删失U(0,2.2/1.4)+X2。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；期刊全文HTML：JRSS-B83(3),2021,559–578；§2 A1–A4；§3.1 Eq.(1)及CQCE定义；§4六步生成，A/B结局及紧随的log-quantile公式，G/H段删失端点2.2/1.4。本轮全文由academic.oup.com重定向oup.silverchair-cdn.com/article-minimal/7056039并可读。 iid individuals; latent compliance stratum independent of the IV-generation noise given X. Given X2, censoring is generated independently; observed W=min(T,C), E=1(T<=C). No latent stratum, uncensored T or C exported. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；§4：X1~U(0,1),X2~Bern(.5)，CO/AT/NT=2/3,1/6,1/6，IV logit=.1X2+X1²+X1X2+N(0,.5²)；A/B结局对应G/H；G/H删失U(0,2.2/1.4)+X2。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；采用原文固定G/H参数，没有重新抽系数。tau=.5是选择报告的原目标分位点；未选A/B删失端点不补造。 |
| `schema.csv` | 6个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid individuals; latent compliance stratum independent of the IV-generation noise given X. Given X2, censoring is generated independently; observed W=min(T,C), E=1(T<=C). No latent stratum, uncensored T or C exported. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic complier log-time quantile treatment contrast: effect for G and effect*exp(.3*tau) for H, checked by independent CDF inversion and controlled full observation-process draws. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；修正通用随机系数模板误述；明确对数分位数差、G/H继承A/B结局与删失变化。；加入CO/AT/NT、两IV方向、非CO噪声、不同删失端点及实际零效应路径的受控采样检查。；对场景概率和tau增加合法性守卫；不改变原参数和场景。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`source_G`, `source_H`。

属性方程依据：X1,X2 both active; IV propensity includes X1^2 and X1*X2; exp survival map; H contains treatment times exp(.3*u). No latent stratum, censoring time or uncensored T is exported.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- A/B基础场景删失均匀端点仍未给出，不在当前收集范围。
- 作者随机seed/原Monte Carlo表未逐值复现；当前仅G/H机制。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=2/2；baseline=['X1', 'X2']。参考n_ref=128（independent subjects），p/n_ref=0.01562500。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
