import math
def truth(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 v=c['effect']*(1. if c['model']=='G' else math.exp(.3*c['tau']))
 return {'value':v,'estimated_error':0.,'method':'Analytic log-quantile contrast among compliers, treatment1 minus0; not a time ratio or population ATE.'}
