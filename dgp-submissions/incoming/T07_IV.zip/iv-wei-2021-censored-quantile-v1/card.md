# Wei：右删失依从者生存分位数IV

状态：candidate / awaiting scientific review；未发送、未获维护人查重或具名审核。

## 7. 认领与创建

Wei B, Peng L, Zhang MJ, Fine JP (2021). Estimation of causal quantile effects with a binary instrumental variable and censored data. JRSS-B 83(3):559–578. DOI:10.1111/rssb.12431.

原始来源：https://academic.oup.com/jrsssb/article/83/3/559/7056039

精确版本/定位：已读期刊全文HTML（工具重定向oup.silverchair-cdn.com/article-minimal/7056039）；§2 A1–A4、§3.1 Eq.(1) CQCE定义、§4六步DGP，ScenarioG/H（文中明确给出删失端点2.2/1.4）。PMC/直接下载403记录保留。

### 完整机制与参数出处

X1~U(0,1)，X2~Bern(.5)；CO/AT/NT比例2/3,1/6,1/6；εIV~N(0,.5²)，P(V=1|X,εIV)=expit(.1X2+X1²+X1X2+εIV)。CO取D=V，AT取1，NT取0。G：CO的logT=−.2X1−.3X2+.5D+log(−log(1−u))，u~U(0,1)；H：CO的logT=log(u)−.2X1−.3X2+.5 exp(.3u)D。非CO均logT=−.1X1−.2X2+.2D+N(0,.5²)。C~U(0,2.2)+X2（G），C~U(0,1.4)+X2（H）；仅观察W=min(T,C)、E=1(T≤C)、X1,X2,V,D。全部出自§4；极值分布方向由原文所给分位数log(−log(1−τ))确定。

目标：CQCE(.5)：条件complier的log生存时间中位数，处理1减0；G为.5，H为.5 exp(.15)。

抽样单位：独立个体，保留右删失观察过程。

识别假设：给定X的IV独立、排除、相关、正性、单调无defier；条件独立删失；所选分位数可辨识；不是总体ATE或风险比。

### 新family结构核对

依从层与Wang都有二元IV，但这里结局是被删失的连续事件时间、必须保留事件指示和删失模型，分位数生成方程不等于给二元Y更换参数/噪声；与网络、纵向、无效线性IV、图条件IV和双总体数据融合结构均不同。

不以估计器、参数、种子或目标名称变化作为新增family依据。与Wang二元联合概率机制、Ye异方差MR及本轮其余机制的比较见总目录history/family_matrix.json。此为结构核对，不是维护人正式去重结论。

### 每项改动

- Select original G/H scenarios because their censoring laws are explicitly supplied; A/B only state approximately30% without endpoints and are not claimed implemented.
- Scalar interface selects original CQCE at tau=.5; new local RNG; no quantile regression fitting/bootstrap or coverage experiments.

### 缺失/范围未决

- A/B原文未列删失均匀端点，保留缺失；改选原文完整G/H，不补造端点。
- 所选G/H无未定位数值参数；作者种子/软件实现未逐值重现，科学审核与许可待维护人。

### 真值推导与独立核验

G中logT_d的τ分位数为log(−log(1−τ))−.2X1−.3X2+.5d；H为logτ−.2X1−.3X2+.5exp(.3τ)d。相减得CQCE(.5)=.5或.5exp(.15)，estimated_error=0是解析恒等式。verify单独实现CDF并二分反演分位数；另用实际采样器的受控complier样本检查方向及删失观察图，加入零效应特例。不得把log分位数差误写成生存时间差、ATE或HR。

## 8. 审阅后检查

使用官方collect.py check --run --n 128 --seed 1729，默认检查全部declared scenarios。源码先逐项审阅；只运行独立重写的本地Python，不执行作者R/下载脚本。真值路线、独立核验、零路径/解析特例和共享部分写在下文及verify.py；全部退出码/失败快照在总目录logs。不得裁剪非法概率/密度或放宽tolerance取得PASS。

## 9. 交付

仅最新check passed且execution_performed后pack为本family独立ZIP；路径/SHA-256在总目录。源码、config、card任何改动均重检后新建ZIP快照。无论文PDF、原始敏感数据、模型权重或凭据。正式接收需具名审核、另一人独立复现、维护人决定；机器PASS不能授予accepted。

## 10. 真实数据

本贡献是synthetic_dgp，不是real_data_claim；不利用该分支绕过未知真值。未获取真实个体数据，未训练/微调PFN，未构造大型超分布、bootstrap或coverage，不修改旧实验/checkpoint，不执行submit/外发。AI辅助提取、编程和检查，不代签科学审核。


## 第7节固定贡献格式：本次整理与代码审阅

任务类别：IV；kind：synthetic_dgp。认领/查重材料已整理在总目录《认领与查重表.md》，尚未发送维护人，未获认领或科学接收。

| 文件 | 本贡献内容与检查范围 |
|---|---|
| `collection.json` | 来源citation/期刊年/版本定位、IV目标、假设、属性、入口及adaptation关系。 |
| `card.md` | 保留上述方程、参数出处、噪声、抽样单位、推导、权利及缺口；本附录记录整理改动。 |
| `config.json` | 采用原文固定G/H参数，没有重新抽系数。tau=.5是选择报告的原目标分位点；未选A/B删失端点不补造。 |
| `schema.csv` | 只声明实际观察列；角色、数值类型、上下界与输出一致。 |
| `generator.py` | generate(config,n,seed)；局部RNG；支持config关键字；不输出潜变量或oracle。 |
| `truth.py` | truth(config)返回value、estimated_error；目标与干预方向以上文为准。 |
| `verify.py` | verify(config)返回passed、checks；共享模型/生成器的局限保留，不等于另一人复现。 |
| `requirements.txt` | 依赖及版本范围；不使用作者电脑绝对路径。 |

声明场景：`source_G`、`source_H`。

属性：总协变量维数=2，有效维数=2；含义：X1,X2 both active; IV propensity includes X1^2 and X1*X2; exp survival map; H contains treatment times exp(.3*u). No latent stratum, censoring time or uncensored T is exported.

参数调用示例（不要把整个config.json对象传给hook）：

```python
import json
from generator import generate
from truth import truth
from verify import verify
with open("config.json", encoding="utf-8") as f:
    settings = json.load(f)
params = settings["scenarios"][settings["default_scenario"]]
observed = generate(config=params, n=128, seed=1729)
result = truth(config=params)
validation = verify(config=params)
```

本次仅修正入口契约/输入报错、数值稳定性和核验覆盖，统一文本换行，并补充整理信息；不改来源方程、场景数、已声明目标、维度标签或tolerance。具体改动/未决事项见总目录《代码审阅报告.md》。所有有改动的源文件均重新check/pack，旧报告保存在history并明确不代表当前状态。未训练PFN、未运行作者R、未外发、未执行submit。


## 来源逐文件审核修正 r3

期刊全文HTML：JRSS-B83(3),2021,559–578；§2 A1–A4；§3.1 Eq.(1)及CQCE定义；§4六步生成，A/B结局及紧随的log-quantile公式，G/H段删失端点2.2/1.4。本轮全文由academic.oup.com重定向oup.silverchair-cdn.com/article-minimal/7056039并可读。

参数定位：§4：X1~U(0,1),X2~Bern(.5)，CO/AT/NT=2/3,1/6,1/6，IV logit=.1X2+X1²+X1X2+N(0,.5²)；A/B结局对应G/H；G/H删失U(0,2.2/1.4)+X2。

本轮修正：

- 修正通用随机系数模板误述；明确对数分位数差、G/H继承A/B结局与删失变化。
- 加入CO/AT/NT、两IV方向、非CO噪声、不同删失端点及实际零效应路径的受控采样检查。
- 对场景概率和tau增加合法性守卫；不改变原参数和场景。

保留未决：

- A/B基础场景删失均匀端点仍未给出，不在当前收集范围。
- 作者随机seed/原Monte Carlo表未逐值复现；当前仅G/H机制。

详细八份文件对照见本贡献source_audit.md/json。新增核验是共享模型下的独立计算路线，不是具名科学审核或另一人复现。保持原scenario数量、所选机制和tolerance；验证用零路径不作为新场景。后续实际check/pack结果以本轮总清单与checks/report.json为准。


## 八部分标准修正 r4（2026-10-30）

基线维数口径：baseline=['X1', 'X2']，dimension=2、effective_dimension=2。工具变量、处理后变量和重复时点不计作基线协变量。标签参考n_ref=128个独立受试者，p/n_ref=0.01562500；high_dimensional=false仅按所述基线口径和参考设置解释。实际n仍由接口传入，不对任意n/p扩展作高维承诺。

依赖：Python>=3.10；无第三方必需依赖；无可选依赖、训练/GPU依赖。独立干净环境安装与运行证据在本目录dependency_check.json及总目录logs/eight-parts-r4；仅宣称实际测试的平台/版本，不宣称覆盖所有Python或NumPy版本。

干净安装实际结果：本贡献独立venv初始无NumPy、未继承系统site-packages；按requirements.txt安装退出0，pip check退出0；测试Python 3.12.14，NumPy None。详见dependency_check.json；模型运行以随后正式check为准。


## 2026-10-31：严格示例格式整理

文件布局与指定单DGP示例一致。CLAIM.md记录真实的待认领状态，environment.json记录本贡献实测运行环境。既有source_audit.md、missing_parameters.json、dependency_check.json及网络interface_claim.md没有丢弃，完整内容合并保存在source_audit.json的format_revision_20261031.merged_supplementary_records。原collection扩展元数据保留在同文件preserved_extension_metadata，含维数参考及网络接口未批准状态。

原机制方程、全部场景参数、schema、generator/truth/verify及依赖逐字不变；本次不是新的原文阅读或科学接收。认领人真实姓名和维护人批准尚未确认。修改元数据后重新执行全部场景check并pack，旧报告不复用为本轮证明。

### 既有逐文件审计记录（原文保留）

# iv-wei-2021-censored-quantile-v1：八份文件来源核对与修正 r3

实际来源：[Wei B, Peng L, Zhang MJ, Fine JP (2021). Estimation of causal quantile effects with a binary instrumental variable and censored data. JRSS-B 83(3):559–578. DOI:10.1111/rssb.12431.](https://academic.oup.com/jrsssb/article/83/3/559/7056039)。

精确定位：期刊全文HTML：JRSS-B83(3),2021,559–578；§2 A1–A4；§3.1 Eq.(1)及CQCE定义；§4六步生成，A/B结局及紧随的log-quantile公式，G/H段删失端点2.2/1.4。本轮全文由academic.oup.com重定向oup.silverchair-cdn.com/article-minimal/7056039并可读。

参数出处：§4：X1~U(0,1),X2~Bern(.5)，CO/AT/NT=2/3,1/6,1/6，IV logit=.1X2+X1²+X1X2+N(0,.5²)；A/B结局对应G/H；G/H删失U(0,2.2/1.4)+X2。

| 文件 | 对比结论 | 具体修正／说明 |
|---|---|---|
| `collection.json` | 来源与任务/目标/假设/属性/入口已比对；适配及待人审状态保留 | 补具体定位/抽样依赖/真值路线及source_audit记录；未改变来源关系或tolerance；期刊全文HTML：JRSS-B83(3),2021,559–578；§2 A1–A4；§3.1 Eq.(1)及CQCE定义；§4六步生成，A/B结局及紧随的log-quantile公式，G/H段删失端点2.2/1.4。本轮全文由academic.oup.com重定向oup.silverchair-cdn.com/article-minimal/7056039并可读。 iid individuals; latent compliance stratum independent of the IV-generation noise given X. Given X2, censoring is generated independently; observed W=min(T,C), E=1(T<=C). No latent stratum, uncensored T or C exported. |
| `card.md` | 完整方程与所选来源对照；范围和模板误述已修正 | 采用本family专属系数说明；更新版本定位与核验/未决问题；family矩阵位置指向history；§4：X1~U(0,1),X2~Bern(.5)，CO/AT/NT=2/3,1/6,1/6，IV logit=.1X2+X1²+X1X2+N(0,.5²)；A/B结局对应G/H；G/H删失U(0,2.2/1.4)+X2。 |
| `config.json` | 全部声明场景已逐项核对；本轮参数与文件字节不改 | 无；采用原文固定G/H参数，没有重新抽系数。tau=.5是选择报告的原目标分位点；未选A/B删失端点不补造。 |
| `schema.csv` | 6个观察列；角色/数值类型/支持与生成器逐项对应 | 无；只观察列，不导出潜变量、真实效应或oracle；复现/长度/支持由官方check逐场景实际验证 |
| `generator.py` | 分布、系数、共享噪声、依赖及输出与所选来源一致；RNG改动已披露 | Guo有限参数守卫/重复n检查整理、Wei概率/tau守卫；其他生成方程和RNG流未改；iid individuals; latent compliance stratum independent of the IV-generation noise given X. Given X2, censoring is generated independently; observed W=min(T,C), E=1(T<=C). No latent stratum, uncensored T or C exported. |
| `truth.py` | 原目标的干预方向、解析/数值路线已比对；不是拟合值真值 | 无；数值真值原本正确，补充准确说明在元数据/卡片；Analytic complier log-time quantile treatment contrast: effect for G and effect*exp(.3*tau) for H, checked by independent CDF inversion and controlled full observation-process draws. |
| `verify.py` | 保留原核验并补实际生成器来源方程检查 | 新增_source_audit_checks，保留旧检查及阈值；没有放宽tolerance；修正通用随机系数模板误述；明确对数分位数差、G/H继承A/B结局与删失变化。；加入CO/AT/NT、两IV方向、非CO噪声、不同删失端点及实际零效应路径的受控采样检查。；对场景概率和tau增加合法性守卫；不改变原参数和场景。 |
| `requirements.txt` | 依赖与实际imports对应，无作者绝对路径 | 六个标准库贡献移除无用依赖或统一说明；不声称验证所有版本范围；numpy>=1.24,<3仅Li积分和Henckel矩阵核验需要；其余标准库Python>=3.10 |

声明场景：`source_G`, `source_H`。

属性方程依据：X1,X2 both active; IV propensity includes X1^2 and X1*X2; exp survival map; H contains treatment times exp(.3*u). No latent stratum, censoring time or uncensored T is exported.

原文机制的完整方程见本目录card.md；观察列完整清单见schema.csv，代码逐项对照而非只比JSON。

保留未决：

- A/B基础场景删失均匀端点仍未给出，不在当前收集范围。
- 作者随机seed/原Monte Carlo表未逐值复现；当前仅G/H机制。

通用未决：维护人认领、跨学生/family正式去重、具名科学审核、另一人独立复现、期刊终版对应（如适用）与最终许可确认。当前不是accepted。

访问成功和失败均见总目录logs/source-review-r3/source_access.json。固定commit网页本轮打不开时，使用此前已保存并校验标准化SHA的原始副本，未宣称新下载成功；没有运行作者R。

本轮修正前快照在总目录history/科学审核修正前_r3.zip；正式check/pack执行结果见总目录execution_summary.json和submissions_SHA256.json。验证用特例不增加family/scenario。


## 八部分口径复核 r4

本轮基线dimension/effective_dimension=2/2；baseline=['X1', 'X2']。参考n_ref=128（independent subjects），p/n_ref=0.01562500。依赖安装与干净环境验证详见dependency_check.json；不以旧环境PASS冒充干净安装。原生成器、真值、场景参数、schema及tolerance不变；所有源文件修改后重新check/pack。

r4干净环境安装已实际通过：逐贡献独立venv、安装与pip check均退出0；详见dependency_check.json。仅覆盖所列实际平台/版本。
