import math,importlib.util
from pathlib import Path
from unittest.mock import patch
def mod(f):
 s=importlib.util.spec_from_file_location('wei_'+f,Path(__file__).with_name(f));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def cdf(c,t,d):
 # Independently invert the specified latent-rank law; x fixed(.4,0).
 if c['model']=='G':return 1-math.exp(-math.exp(t+.08-c['effect']*d))
 lo=0.;hi=1.
 for _ in range(90):
  u=(lo+hi)/2;lt=math.log(u)-.08+c['effect']*math.exp(.3*u)*d
  if lt<t:lo=u
  else:hi=u
 return (lo+hi)/2
def quantile(c,d):
 lo=-40.;hi=10.
 for _ in range(90):
  mid=(lo+hi)/2
  if cdf(c,mid,d)<c['tau']:lo=mid
  else:hi=mid
 return (lo+hi)/2
class R:
 def __init__(self,d,censored=False):self.v=iter([.4,.9,.1,0. if d else .999999,.5,0. if censored else .999999])
 def random(self):return next(self.v)
 def gauss(self,m,s):return m
def _existing_verify(config):
 if not isinstance(config, dict) or 'scenarios' in config: raise ValueError('Pass one selected scenario parameter object, not the whole config.json')
 c = config
 g=mod('generator.py');v=mod('truth.py').truth(c)['value'];obs=[]
 for d in (0,1):
  with patch.object(g.random,'Random',return_value=R(d)):data=g.generate(c,1,0)
  obs.append(math.log(data['W'][0]))
 with patch.object(g.random,'Random',return_value=R(1,True)):cen=g.generate(c,1,0)
 null=dict(c,effect=0.)
 checks=[{'name':'independent_CDF_bisection_quantiles','passed':abs(quantile(c,1)-quantile(c,0)-v)<1e-12},
 {'name':'actual_observed_sampler_complier_contrast','passed':abs(obs[1]-obs[0]-v)<1e-12},
 {'name':'censoring_observation_map','passed':cen['W']==[0.] and cen['E']==[0]},
 {'name':'zero_effect_special_case','passed':abs(quantile(null,1)-quantile(null,0))<1e-12},
 {'name':'no_uncensored_or_stratum_export','passed':set(cen)=={'X1','X2','V','D','W','E'}},
 {'name':'source_GH_constants','passed':c['pc']==2/3 and c['pa']==1/6 and c['effect']==.5 and c['tau']==.5 and c['censor_upper']==(2.2 if c['model']=='G' else 1.4)}]
 return {'passed':all(x['passed'] for x in checks),'checks':checks,'shared_components':'Same documented distribution/config; independent CDF inversion versus analytic quantile, plus controlled actual-generator checks. Not an independent-person review or coverage study.'}


class _SourceObservedRNG:
    def __init__(self,group,v,rank,censor_fraction,x2):
        # x1=.4; X2 bit; group CO/AT/NT; source IV noise zero.
        self.values=iter([.4,.1 if x2 else .9,group,0.0 if v else .999999]+([rank] if group<2/3 else [])+[censor_fraction])
        self.noises=iter((0.0,0.3))
    def random(self):return next(self.values)
    def gauss(self,mu,sd):return mu+sd*next(self.noises)

def _source_audit_checks(config):
    g=mod('generator.py')
    maximum=0.0
    correct=True
    count=0
    for group in (.1,.7,.95):
        for v in (0,1):
            for x2 in (0,1):
                for censor_fraction in (.1,.9):
                    rank=.5
                    d=v if group<2/3 else int(group<5/6)
                    if group<2/3:
                        logt=-.08-.3*x2+(config['effect']*d+math.log(math.log(2)) if config['model']=='G' else math.log(.5)+config['effect']*math.exp(.15)*d)
                    else:
                        logt=-.04-.2*x2+.2*d+.5*.3
                    t=math.exp(logt)
                    censor=config['censor_upper']*censor_fraction+x2
                    with patch.object(g.random,'Random',return_value=_SourceObservedRNG(group,v,rank,censor_fraction,x2)):
                        row=g.generate(config,1,0)
                    maximum=max(maximum,abs(row['W'][0]-min(t,censor)))
                    correct=correct and row['D']==[d] and row['V']==[v] and row['X2']==[x2] and row['E']==[int(t<=censor)]
                    count+=1
    null=dict(config,effect=0.0)
    ys=[]
    for d in (0,1):
        with patch.object(g.random,'Random',return_value=_SourceObservedRNG(.1,d,.5,.9,1)):
            row=g.generate(null,1,0)
        ys.append(row['W'][0])
    return [
        {'name':'source_CO_AT_NT_and_covariate_dependent_censoring','passed':correct and maximum<1e-12,
         'details':{'controlled_cases':count,'max_observed_time_error':maximum}},
        {'name':'actual_zero_effect_complier_sampler','passed':abs(ys[1]-ys[0])<1e-12}
    ]

def verify(config):
    result = _existing_verify(config)
    result['checks'].extend(_source_audit_checks(config))
    result['passed'] = all(item['passed'] is True for item in result['checks'])
    result['shared_components'] += ' Source-audit additions exercise the same local generator against separate source-equation/moment calculations; no independent-person review or complete distribution proof is claimed.'
    return result
