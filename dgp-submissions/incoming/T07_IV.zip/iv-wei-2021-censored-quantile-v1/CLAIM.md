# 维护人认领/查重材料（待确认）

- 拟贡献ID：`iv-wei-2021-censored-quantile-v1`；任务：iv；mechanism_family_id：`iv-wei-2021-censored-quantile`。
- 来源：Wei B, Peng L, Zhang MJ, Fine JP (2021). Estimation of causal quantile effects with a binary instrumental variable and censored data. JRSS-B 83(3):559–578. DOI:10.1111/rssb.12431.
- 链接：https://academic.oup.com/jrsssb/article/83/3/559/7056039
- 版本：JRSS-B 83(3),2021,559-578, journal full-text HTML Section4 G/H; no immutable HTML version identifier supplied
- 定位：期刊全文HTML：JRSS-B83(3),2021,559–578；§2 A1–A4；§3.1 Eq.(1)及CQCE定义；§4六步生成，A/B结局及紧随的log-quantile公式，G/H段删失端点2.2/1.4。本轮全文由academic.oup.com重定向oup.silverchair-cdn.com/article-minimal/7056039并可读。
- 声明场景：source_G, source_H。
- 目标：CQCE(.5)：条件complier的log生存时间中位数，处理1减0；G为.5，H为.5 exp(.15)。
- 主要适配：Select original G/H scenarios because their censoring laws are explicitly supplied; A/B only state approximately30% without endpoints and are not claimed implemented.; Scalar interface selects original CQCE at tau=.5; new local RNG; no quantile regression fitting/bootstrap or coverage experiments.
- 用户截图显示GitHub账号wuwenti已创建PR #10；本文件不表示认领查重已批准或已获科学接收。
- 认领人真实姓名：未提供、未核实；不得用目录用户名代替人工署名。
- 待确认：family正式去重、来源版本对应、权利许可、具名科学审核、另一人独立复现。详细缺口及访问/核验失败记录保留在source_audit.json。
