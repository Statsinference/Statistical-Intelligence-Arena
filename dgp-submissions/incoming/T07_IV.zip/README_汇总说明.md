# T07：八个IV DGP完整文件汇总

此ZIP直接包含8个以贡献ID命名的独立文件夹，解压后即可看到各机制完整文件；没有再嵌套8个ZIP。每个文件夹结构与所提供单DGP示例一致：根目录下有八份固定文件、来源/依赖审计与MANIFEST.json，checks/下有report.json和sample.json。保留既有额外审核文件；未为了与示例文件名完全相同而伪造CLAIM或environment记录。

各机制文件逐字取自此前最终submission内已校验的8个官方独立贡献包，未修改代码、参数、报告、样本或清单。重新验证了每个原MANIFEST的文件哈希以及汇总后所有成员的字节一致性。本次只重组文件目录，未重跑模型或改变科学状态。

解压后的布局：

iv-guo-2018-author-linear-v1/
iv-henckel-2024-g1-sem-v1/
iv-hoshino-2024-ring-network-v1/
iv-li-2026-aux-population-v1/
iv-michael-2024-author-msmm-v1/
iv-wang-2021-binary-late-v1/
iv-wei-2021-censored-quantile-v1/
iv-ye-2024-genius-heteroskedastic-v1/

清单.json记录各文件夹场景及来源包哈希。已有完整运行检查为8份/16场景/136核验项通过；各目录checks/report.json保留具体证据。认领、查重、具名科学审核及网络接口/目标确认仍未完成，状态awaiting_scientific_review。

如使用现有学生包重新运行，将实际ID文件夹放到仓库contributions/下；如准备重新check并pack，先把旧MANIFEST.json移到贡献目录外，避免旧归档清单进入新源码。不要将八份目录混成一份collection.json。
