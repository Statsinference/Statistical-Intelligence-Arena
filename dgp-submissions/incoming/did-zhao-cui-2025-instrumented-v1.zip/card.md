# 重复横截面工具变量 DiD：bridge 潜在混杂与异质效应

状态：审核稿；未提交；科学审核人与独立复现人尚未签署。类别：did_sc。来源关系：adapted_from_source。

## 来源与定位

Zhao, P., & Cui, Y. (2025). A semiparametric instrumented difference-in-differences approach to policy learning. Biometrika, 112(4), asaf043.

- DOI与期刊记录：https://doi.org/10.1093/biomet/asaf043
- 实际阅读全文：https://api.repository.cam.ac.uk/server/api/core/bitstreams/f53daf21-4f51-4cd4-8ca7-197da497310e/content
- 精确定位：正式排版文献 PDF p.11，§6 全部未编号 DGP 公式；§3 pp.5–7，Assumptions 1–7。main.R lines 6–29, simData；commit 11f92f2c29316810531935985a981b567b8abab5。
- 固定代码：https://github.com/panzhaooo/policy-learning-instrumented-DiD/blob/11f92f2c29316810531935985a981b567b8abab5/simulation/main.R
- 实际PDF及R代码的SHA-256见source_audit.json；原文未编号公式明确按节与PDF页定位，不虚造公式号。

## 机制与完整参数

每行是独立重复横截面个体，只观察t=0或t=1中的一期；两期个体不配对。X1,X2独立N(0,1)，T和Z独立Bernoulli(0.5)。U0,U1独立bridge(φ=0.5)，密度 f(u)=1/[2π cosh(u/2)]，均值0、方差π²。上述基础变量相互独立。

令expit(v)=1/(1+exp(−v))。条件于X,Z,U，使用独立Bernoulli随机数产生：

```text
A0 ~ Bernoulli(expit( 2   -7 Z +0.20 U0 +2 X1))
A1 ~ Bernoulli(expit(-1.5 +5 Z -0.15 U1 +1.5 X2))
h(X) = 1.5 X1 +2 X2 -0.5
Y0 = 200 +10[A0 h(X)+0.5 U0+2 Z+1.5 X1+2 X2] + ε0
Y1 = 240 +10[A1 h(X)+0.5 U1+2 Z+2 X1+1.5 X2] + ε1
A = (1-T) A0 +T A1
Y = (1-T) Y0 +T Y1
```

ε0,ε1独立N(0,1)，与所有协变量、潜变量及Bernoulli随机数独立。这里Y0、Y1下标表示时间，不表示处理潜在结局；处理潜在结局Y_t(a)是把方程中A_t设为a得到的值。所有截距、系数和噪声尺度均来自§6与作者`simData`。

bridge采样采用V~Uniform(0,1)、U=2 log tan(πV/2)。其CDF为(2/π)atan(exp(u/2))。浮点发生V=0时重抽该V，不把尾部截成正态分布，也不裁切U。稳定logistic实现使用logaddexp。n为正整数，固定φ=0.5，不对未实现的其他φ静默外推。原代码默认n=1000；n由调用者传入。

## 目标、真值与识别

原论文目标为最优政策 d_opt(x)=1{3x1+4x2−1>0}。为了适配本轮单一标量truth接口，此贡献明确改为总体ATE：

```text
τ(x) = E[Y_t(1)-Y_t(0)|X=x] = 10(1.5x1+2x2-0.5)
ATE = E_X[τ(X)] = -5,  t=0,1.
```

目标是对标准正态X总体求平均。不能在小样本中用样本X平均代替−5，也不能把它称为ATT、CATE查询点或政策价值。此例是instrumented DiD，需在DiD方向内单独标记与IV的交叉属性。普通两组DiD与普通截面IV并非自动适用。

具体识别条件对应原文§3 Assumptions 1–7：一致性；(T,Z)|X四格均有概率1/4；重复横截面随机抽样；处理效应随时间稳定；Z影响处理趋势；给定X时Z独立于潜在处理、处理效应及未处理结局趋势；无未测共同效应修饰因子。U同时影响A,Y，故一般的“无未测混杂”不成立。Z对结局水平有直接作用20Z，但对两期未处理结局之差没有直接作用，符合iDiD而非普通IV的排除限制。

令m_C(t,z,x)=E[C|T=t,Z=z,X=x]及δ_C=m_C(1,1,x)−m_C(0,1,x)−m_C(1,0,x)+m_C(0,0,x)。这里δ_Y=τ(x)δ_A，所以τ(x)=δ_Y/δ_A。对任何有限x，早期Z效应为负、晚期为正，δ_A>0；正态极端尾部可能很小，不能声称统一强工具。

## 独立核验与使用范围

`truth.py`按结构方程解析积分。`verify.py`走另一条路线：192阶Gauss–Legendre积分消去U，建立四格观测均值，计算条件DiD比率，再用每个X维度16阶Gauss–Hermite积分得到ATE；与−5比较，差须小于1e−8。对U的密度还在[−40,40]作独立梯形积分并核对逆CDF；以n=100000检查生成数据去掉可观察均值后的残差均值及理论方差25π²+1；共同随机数干预检查去掉处理效应时Y的差恰为Aτ(X)。积分诊断不是严格全域误差界。

保留观察列X1,X2,Z,T,A,Y。U0/U1、未观察的另一时期A/Y、概率和真实CATE均不输出。均值为零的协变量与平衡抽样也有固定seed检查。没有复现原文政策学习算法或正确决策率。

## 相对来源的改动

- 原文数据分布保留；将政策学习目标改为两个时点相同的总体 ATE=-5，不能称为原文报告的 ATT 或政策价值。
- 用 bridge 分布的解析逆CDF独立实现采样，不依赖 R bridgedist。
- 使用 NumPy PCG64；不输出 U0/U1、另一期结局、真值 CATE 或倾向概率。

## 文件、复现、权利与AI协助

每份机制含教学包要求的8个核心文件，外加来源审计与参考文献。`generate(config,n,seed)`的config须是某一个scenario参数对象。使用Python 3.10+及NumPy>=1.24,<3；本次本地环境Python3.12 / NumPy2.3.5。请在教学包根目录运行：

```text
python collect.py check <本贡献目录> --run --n 128 --seed 1729
python collect.py pack <本贡献目录> --out <新ZIP路径>
```

默认核验全部声明场景。改动任何源文件后必须重新check再pack，不能沿用旧的SHA-256检查。checks/report.json记录机器结果；机器通过不等于科学接收，也不意味着维护人已查重或有人独立复现。

论文与作者R代码的权利属于原权利人。本包不复制论文PDF、原R文件、真实数据或模型权重；Python代码为基于公开方程与明确代码行为的独立实现。未把“公开访问”推断成作者代码的开放许可；贡献许可由提交者按项目要求确认。AI协助包括文献检索、版本比对、代码编写、解析推导与本地核验；尚未有人类具名审核，不由AI代签。未知项及版本冲突均显式保留。
