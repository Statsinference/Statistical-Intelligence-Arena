import importlib.util
from pathlib import Path
import numpy as np
def load_generate():
    spec=importlib.util.spec_from_file_location('local_dgp_under_test',Path(__file__).with_name('generator.py'))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod.generate
def check(name,passed,**details):
    return {'name':name,'passed':bool(passed),'details':details}

from numpy.polynomial.hermite import hermgauss
from numpy.polynomial.legendre import leggauss

def verify(config):
    # Alternative route: build all four observed conditional means, integrate out U,
    # divide the DiD-in-Y by DiD-in-A, then integrate over X using Gauss-Hermite.
    gh,gw=hermgauss(16);x=gh*np.sqrt(2);w=gw/np.sqrt(np.pi)
    nodes,weights=leggauss(192);v=(nodes+1)/2;uw=weights/2
    u=2*np.log(np.tan(np.pi*v/2))
    e=config['effect_coefficients'];s=config['outcome_scale']
    recovered=[];ww=[];min_relevance=1.;max_cond_error=0.
    for i,x1 in enumerate(x):
      for j,x2 in enumerate(x):
        ma=np.zeros((2,2));my=np.zeros((2,2))
        h=e[0]+e[1]*x1+e[2]*x2
        for t in (0,1):
          b=config[f'a{t}_coefficients'];bx=config['x_outcome_coefficients'][t]
          for z in (0,1):
            pr=np.exp(-np.logaddexp(0.,-(b[0]+b[1]*z+b[2]*u+b[3]*x1+b[4]*x2)))
            ma[t,z]=uw@pr
            my[t,z]=uw@(config['outcome_intercepts'][t]+s*(pr*h+config['u_coefficient']*u+config['z_coefficient']*z+bx[0]*x1+bx[1]*x2))
        da=ma[1,1]-ma[0,1]-ma[1,0]+ma[0,0]
        dy=my[1,1]-my[0,1]-my[1,0]+my[0,0]
        # Far-tail weak instruments are tracked, not assumed uniformly bounded away from zero.
        if da<=0: return {'passed':False,'checks':[check('positive trend relevance',False)]}
        ratio=dy/da
        min_relevance=min(min_relevance,float(da));max_cond_error=max(max_cond_error,float(abs(ratio-s*h)))
        recovered.append(ratio);ww.append(w[i]*w[j])
    numerical=float(np.dot(recovered,ww));expected=s*e[0]
    checks=[check('observed-mean iDiD ratio integrated over X',abs(numerical-expected)<1e-8,quadrature_ate=numerical,analytic_ate=expected,absolute_difference=abs(numerical-expected),minimum_quadrature_relevance=min_relevance,max_conditional_difference=max_cond_error)]
    # Inverse CDF identity and bridge normalization use distinct calculations.
    grid=np.linspace(-40,40,40001);density=1/(2*np.pi*np.cosh(grid/2))
    mass=float(np.trapezoid(density,grid) if hasattr(np,'trapezoid') else np.trapz(density,grid))
    back=2/np.pi*np.arctan(np.exp(u/2))
    checks.append(check('bridge inverse CDF and density integral',np.max(np.abs(back-v))<1e-12 and abs(mass-1)<1e-8,mass_over_minus40_to40=mass))
    g=load_generate();data=g(config,100000,82173)
    x1=np.asarray(data['X1']);x2=np.asarray(data['X2']);z=np.asarray(data['Z']);t=np.asarray(data['T']);a=np.asarray(data['A']);y=np.asarray(data['Y'])
    bx=np.asarray(config['x_outcome_coefficients'])[t]
    residual=y-np.asarray(config['outcome_intercepts'])[t]-s*(a*(e[0]+e[1]*x1+e[2]*x2)+config['z_coefficient']*z+bx[:,0]*x1+bx[:,1]*x2)
    expected_var=(s*config['u_coefficient'])**2*np.pi**2+config['noise_sd']**2
    checks.append(check('generator observed residual bridge-plus-noise moments',abs(residual.mean())<6*np.sqrt(expected_var/len(y)) and abs(residual.var()/expected_var-1)<0.04,mean=float(residual.mean()),variance=float(residual.var()),theoretical_variance=float(expected_var)))
    checks.append(check('generator independent baseline covariates and balanced T,Z',abs(x1.mean())<0.02 and abs(x2.mean())<0.02 and abs(np.corrcoef(x1,x2)[0,1])<0.02 and abs(z.mean()-0.5)<0.01 and abs(t.mean()-0.5)<0.01))
    # Check actual generated treatment rates against independent marginal integration.
    hn,hw=hermgauss(64);xx=np.sqrt(2)*hn;hw=hw/np.sqrt(np.pi)
    rates=[];rates_pass=True
    for period in (0,1):
      b=config[f'a{period}_coefficients']
      # The source uses just X1 in A0 and just X2 in A1.
      for group in (0,1):
        logits=b[0]+b[1]*group+b[2]*u[None,:]+(b[3]+b[4])*xx[:,None]
        prob=np.exp(-np.logaddexp(0.,-logits))
        theoretical=float(hw@(prob@uw))
        mask=(t==period)&(z==group);count=int(mask.sum())
        empirical=float(a[mask].mean())
        standard_error=np.sqrt(theoretical*(1-theoretical)/count)
        rates_pass &= abs(empirical-theoretical)<6*standard_error+1e-4
        rates.append({'T':period,'Z':group,'n':count,'empirical':empirical,'quadrature':theoretical})
    checks.append(check('generated treatment rates in four T,Z cells',rates_pass,cells=rates))
    zero=dict(config,effect_coefficients=[0,0,0]);d0=g(zero,2000,771);d1=g(config,2000,771)
    expected_diff=s*np.asarray(d1['A'])*(e[0]+e[1]*np.asarray(d1['X1'])+e[2]*np.asarray(d1['X2']))
    error=float(np.max(np.abs(np.asarray(d1['Y'])-d0['Y']-expected_diff)))
    checks.append(check('common-random-number zero-effect intervention',error<1e-10,max_error=error))
    return {'passed':all(c['passed'] for c in checks),'checks':checks}
