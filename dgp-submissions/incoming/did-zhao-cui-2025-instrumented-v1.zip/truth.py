def truth(config):
    # X1,X2 have zero population mean. This is population ATE, not sample ATE or ATT.
    return {'value':float(config['outcome_scale']*config['effect_coefficients'][0]),
            'estimated_error':0.0,'method':'Analytic expectation of the time-invariant additive conditional effect.'}
