# 来源认领记录

mediation-jones-2024-sparse-mediators-nnn-v1

Jones, J., Ertefaie, A. and Strawderman, R. L. (2025). Causal mediation analysis: selection with asymptotically valid inference. Journal of the Royal Statistical Society Series B: Statistical Methodology 87(3), 678-700. DOI: 10.1093/jrsssb/qkae109.

实际阅读版本：arXiv:2110.06127v2 预印本。期刊正式版未取得。

定位：§5 Simulation Studies，预印本 PDF 第 15 页（μ_D0、ψ_M、ψ_Y 各两种形式与三字母场景命名）；**Appendix A，第 26 页**（各方差、维数、α0、β0、γ0，以及原文印出的 NIE = 2.4）；结构模型式 (1)，第 4 页；Proposition 2.1，第 6 页。

机制区别：本包登记 **NNN** 组合 —— 倾向得分 非线性、中介混杂 非线性、结局混杂 非线性。

**切分依据**：原文为三个 nuisance 函数各给出线性与非线性两种形式，并按该顺序用三字母命名场景（文中明确举例 LNN），理论上有八种组合。函数形式的改变是**机制的改变**而非参数的改变（李桫的 proximal 范例即把 Qi et al. 的线性/三角/二次三种形式各立为独立 ZIP），故一个组合是一个贡献。**本家族只提交三个，刻意而非穷举，构成“一个参考点 + 两个单因子邻居”**：LNN（原文唯一点名的组合）、NNN（只换 mu_D0 一个因子，且是三包中唯一带 X1·X2 乘积项的）、LNL（只换 psi_Y 一个因子）。其余五个组合不提交，因为只会添加换标签的重复；原文 Appendix B 的 p=60 变体也不提交，因为它与 p=10 的 LNN 函数形式全同、只差一个维数参数，属参数扫描而非新机制。三包共享 mechanism_family_id `jones-2024-robinson-additive-sparse-mediator-selection`；若审稿人认为应按家族计为一个 DGP，可据此合并。原文未逐一说明实际跑过哪些组合，本包也不发明原文之外的任何函数形式。

真值：NIE = 2.4 是**原文 Appendix A 直接印出的数值**，NDE = γ0 = 2 由 Proposition 2.1 给出；本包登记原文自报值并独立复算确认。

已在 2026-10-30 的仓库快照内查重：mediation 域仅有 nie-eric-original-v1，incoming/ 中无 mediation-* 包。未向维护人发送，待维护人认领/全库查重与具名科学审核。
