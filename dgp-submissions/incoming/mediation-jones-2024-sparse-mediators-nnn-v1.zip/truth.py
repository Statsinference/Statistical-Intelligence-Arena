"""Population natural indirect effect; the source's Proposition 2.1 identity.

M = alpha_0 D + psi_M(X) 1_p + eta with E[eta|X,D] = 0, and
Y = gamma_0 D + beta_0' M + psi_Y(X) + epsilon with E[epsilon|X,D,M] = 0.
Hence E[M(d)] = alpha_0 d + E[psi_M(X)] 1_p and

  NIE = E[Y(1, M(1))] - E[Y(1, M(0))] = beta_0' (E[M(1)] - E[M(0)]) = beta_0' alpha_0,
  NDE = E[Y(1, M(0))] - E[Y(0, M(0))] = gamma_0,

with the confounding functions cancelling, so no quadrature is needed and the value is
the same in every confounding-function scenario.
"""


def natural_indirect_effect(config):
    alpha0, beta0 = config["alpha0"], config["beta0"]
    return float(sum(a * b for a, b in zip(alpha0, beta0)))


def natural_direct_effect(config):
    return float(config["gamma0"])


def active_mediators(config):
    return [index + 1 for index, (a, b) in enumerate(zip(config["alpha0"], config["beta0"]))
            if a != 0.0 and b != 0.0]


def truth(config):
    return {
        "value": natural_indirect_effect(config),
        "estimated_error": 0.0,
        "method": "Closed form from the source's additive structural model and its Proposition 2.1: NIE = alpha_0 . beta_0. No quadrature or Monte Carlo is used.",
        "error_interpretation": "Exact up to IEEE-754 double rounding; the source itself prints NIE = 2.4 for this parameter setting.",
        "target": "NIE = E[Y(1, M(1))] - E[Y(1, M(0))] through the sparse mediator set",
        "components": {"NDE": natural_direct_effect(config),
                       "active_mediators": active_mediators(config)},
    }
