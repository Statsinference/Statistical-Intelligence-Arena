"""Independent verification of the registered sparse natural indirect effect.

Routes that do not share code with truth.py:
  * a fixed-seed structural simulation of the nested counterfactual outcomes
    Y(1, M(1)) and Y(1, M(0)) under common random numbers.  Under common random
    numbers the per-unit contrast is degenerate and must equal beta_0' alpha_0
    exactly, so any slip in the mediator or outcome equation shows up immediately;
  * Gauss-Hermite integration of the two confounding functions, used to confirm that
    they really do cancel from the target rather than being silently dropped.
Plus source-constant, published-truth, sparsity, zero-path, invariance, positivity and
column-leakage checks.
"""
from copy import deepcopy
import importlib.util
import math
from pathlib import Path

import numpy as np

SPARSE_TAIL = [0.0] * 7
# The source gives two forms for each of mu_D0, psi_M and psi_Y and names scenarios by
# the triple in that order, so these eight combinations are the source's own factorial.
FIXTURES = {(a, b, c): letters
            for letters, (a, b, c) in
            (("".join(k), tuple({"L": "linear", "N": "nonlinear"}[x] for x in k))
             for k in ("LLL", "LLN", "LNL", "LNN", "NLL", "NLN", "NNL", "NNN"))}
COMMON = {
    "covariate_count": 3,
    "covariate_variance": 0.25,
    "mediator_count": 10,
    "propensity_scale": 0.8,
    "alpha0": [1.0, 2.0, 2.0] + SPARSE_TAIL,
    "beta0": [0.8, 0.4, 0.4] + SPARSE_TAIL,
    "gamma0": 2.0,
    "mediator_noise_sd": 1.0,
    "outcome_noise_sd": 1.0,
    "target": "NIE",
}
SOURCE_PUBLISHED_NIE = 2.4
SOURCE_PUBLISHED_NDE = 2.0


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("jones_collection_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _crn_contrast(config, n, seed):
    """Per-unit Y(1, M(1)) - Y(1, M(0)) under common random numbers."""
    sampler = _module("generator.py")
    rng = np.random.Generator(np.random.PCG64(seed))
    width = int(config["mediator_count"])
    scale = math.sqrt(float(config["covariate_variance"]))
    x = scale * rng.standard_normal((n, 3))
    eta = float(config["mediator_noise_sd"]) * rng.standard_normal((n, width))
    epsilon = float(config["outcome_noise_sd"]) * rng.standard_normal(n)
    alpha0 = np.asarray(config["alpha0"], dtype=float)
    beta0 = np.asarray(config["beta0"], dtype=float)
    confounding_m = sampler.mediator_confounding(config, x)[:, None]
    confounding_y = sampler.outcome_confounding(config, x)

    def outcome(treatment_in_y, treatment_in_m):
        mediators = np.outer(np.full(n, treatment_in_m), alpha0) + confounding_m + eta
        return (float(config["gamma0"]) * treatment_in_y + mediators @ beta0
                + confounding_y + epsilon)

    return outcome(1.0, 1.0) - outcome(1.0, 0.0)


def _confounding_means(config, order):
    sampler = _module("generator.py")
    nodes, weights = np.polynomial.hermite.hermgauss(order)
    weights = weights / math.sqrt(math.pi)
    scale = math.sqrt(2.0 * float(config["covariate_variance"]))
    grid = scale * nodes
    # Product rule over the three independent covariates, built as nested sums.
    first = grid[:, None, None] * np.ones((1, order, order))
    second = grid[None, :, None] * np.ones((order, 1, order))
    third = grid[None, None, :] * np.ones((order, order, 1))
    x = np.column_stack([first.ravel(), second.ravel(), third.ravel()])
    mass = (weights[:, None, None] * weights[None, :, None] * weights[None, None, :]).ravel()
    return (float(mass @ sampler.mediator_confounding(config, x)),
            float(mass @ sampler.outcome_confounding(config, x)))


def verify(config):
    oracle = _module("truth.py")
    sampler = _module("generator.py")
    result = oracle.truth(config)
    reference = result["value"]

    forms = (config["propensity_form"], config["mediator_confounding_form"],
             config["outcome_confounding_form"])
    width = int(config["mediator_count"])
    expected = dict(COMMON)
    # The source registers p = 10 in its main text and p = 60 as a supplemental setting;
    # the active coefficients are the same in both, padded with zeros to the width.
    expected.update({"mediator_count": width,
                     "alpha0": [1.0, 2.0, 2.0] + [0.0] * (width - 3),
                     "beta0": [0.8, 0.4, 0.4] + [0.0] * (width - 3),
                     "propensity_form": forms[0], "mediator_confounding_form": forms[1],
                     "outcome_confounding_form": forms[2]})

    crn = _crn_contrast(config, 512, 20261030)
    crn_deviation = float(np.max(np.abs(crn - reference)))
    mediator_mean, outcome_mean = _confounding_means(config, 24)

    no_treatment_to_mediator = deepcopy(config)
    no_treatment_to_mediator["alpha0"] = [0.0] * int(config["mediator_count"])
    no_mediator_to_outcome = deepcopy(config)
    no_mediator_to_outcome["beta0"] = [0.0] * int(config["mediator_count"])
    other_forms = deepcopy(config)
    other_forms["mediator_confounding_form"] = "nonlinear" if forms[1] == "linear" else "linear"
    other_forms["outcome_confounding_form"] = "nonlinear" if forms[2] == "linear" else "linear"

    grid = np.linspace(-3.0, 3.0, 13)
    probe = np.column_stack([grid, grid[::-1], np.zeros_like(grid)])
    propensities = sampler.propensity(config, probe)

    sample = sampler.generate(config, 8, 4242)
    expected_columns = (["X1", "X2", "X3", "D"]
                        + [f"M{index + 1}" for index in range(int(config["mediator_count"]))]
                        + ["Y"])

    active = result["components"]["active_mediators"]

    checks = [
        {"name": "source_constants_appendix_a",
         "passed": config == expected and forms in FIXTURES,
         "details": "All parameters equal the 'Large' setting of Appendix A (arXiv:2110.06127v2 p.26) with the confounding forms of Section 5 (p.15); the scenario name %s matches the source's three-letter notation." % FIXTURES.get(forms, "unknown")},
        {"name": "independent_common_random_number_contrast",
         "passed": crn_deviation < 1e-12,
         "details": "512 units simulated from the structural equations give a per-unit contrast Y(1,M(1)) - Y(1,M(0)) that deviates from beta_0' alpha_0 by at most %.3g. Under common random numbers this contrast is degenerate, so the check is sharp on every entry of alpha_0 and beta_0 and on the additive structure of both equations." % crn_deviation},
        {"name": "confounding_functions_cancel",
         "passed": (abs(oracle.truth(other_forms)["value"] - reference) < 1e-12
                    and abs(mediator_mean) + abs(outcome_mean) > 0.0),
         "details": "Gauss-Hermite order 24 gives E[psi_M(X)] = %.12g and E[psi_Y(X)] = %.12g, both nonzero in at least one scenario, yet switching both confounding functions to their other form leaves the target unchanged. The confounding therefore cancels from the contrast rather than being quietly omitted." % (mediator_mean, outcome_mean)},
        {"name": "source_published_truth",
         "passed": (abs(reference - SOURCE_PUBLISHED_NIE) < 1e-12
                    and abs(result["components"]["NDE"] - SOURCE_PUBLISHED_NDE) < 1e-12),
         "details": "NIE = %.15g matches the value 2.4 PRINTED by the source in its Appendix A, and NDE = %.15g matches gamma_0 = 2 via the source's Proposition 2.1. Unlike most contributions in this batch, the registered truth here is the source's own number, not only a collector derivation." % (reference, result["components"]["NDE"])},
        {"name": "sparse_mediator_set",
         "passed": (active == [1, 2, 3] and width in (10, 60)
                    and all(config["alpha0"][index] == 0.0 and config["beta0"][index] == 0.0
                            for index in range(3, width))),
         "details": "Exactly three of the %d candidate mediators are active (indices %s); mediators 4 to %d have both a zero treatment coefficient and a zero outcome coefficient, so the sparsity the source studies is preserved and the inactive mediators are genuinely inactive rather than merely weak. The source registers p = 10 in its main text and p = 60 as a supplemental setting." % (width, active, width)},
        {"name": "zero_treatment_to_mediator_path",
         "passed": abs(oracle.truth(no_treatment_to_mediator)["value"]) < 1e-12,
         "details": "Setting alpha_0 to zero removes every treatment-to-mediator arrow and gives NIE = 0."},
        {"name": "zero_mediator_to_outcome_path",
         "passed": abs(oracle.truth(no_mediator_to_outcome)["value"]) < 1e-12,
         "details": "Setting beta_0 to zero removes every mediator-to-outcome arrow and gives NIE = 0."},
        {"name": "propensity_inside_unit_interval",
         "passed": bool(np.all(propensities > 0.0) and np.all(propensities < 1.0)),
         "details": "The propensity stays in (%.6f, %.6f) on a covariate probe spanning six standard deviations. The source states it chose the covariate variance 1/4 specifically to limit inadvertent positivity violations; no uniform overlap bound is claimed." % (float(propensities.min()), float(propensities.max()))},
        {"name": "observed_columns_only",
         "passed": (list(sample) == expected_columns
                    and all(len(values) == 8 for values in sample.values())),
         "details": "The generator returns exactly %d columns in the declared order and no counterfactual, oracle or confounding-function column; psi_M(X), psi_Y(X), M(1) and M(0) stay internal." % len(expected_columns)},
    ]
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": "All routes necessarily share the registered structural equations. truth.py uses only the Proposition 2.1 identity; the common-random-number route builds both nested counterfactual outcomes from the full equations; the quadrature route integrates the confounding functions. Transcription from the preprint and independent-person reproduction remain separate review tasks.",
        "limits": "Numerical diagnostics only. They do not establish the source's sparsity and exchangeability assumptions, do not cover the source's n-dependent 'Small' parameter setting or its p = 60 setting, and do not confirm that the preprint matches the published JRSS-B article.",
    }
