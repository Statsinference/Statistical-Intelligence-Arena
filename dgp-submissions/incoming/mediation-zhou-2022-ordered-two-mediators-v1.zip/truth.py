"""Population cumulative path-specific effect; integrates the law, never the sample.

Coefficient layouts registered in config.json:
  beta_M1 indexes (1, X1, X2, X3, X4, A)                      -> 6 entries
  beta_M2 indexes (1, X1, X2, X3, X4, A, M1)                   -> 7 entries
  beta_Y  indexes (1, UXY, X1, X2, X3, X4, A, M1, M2)          -> 9 entries
"""


def expected_m1(config, a1):
    """E[M1(a1)].  E[Xj] = 0 because Xj = beta_Xj . U + eps_j with E[U] = E[eps] = 0."""
    b = config["beta_M1"]
    return b[0] + b[5] * a1


def expected_m2(config, a2, a1):
    """E[M2(a2, M1(a1))]: the M2 equation is linear, so M1 enters through its mean."""
    b = config["beta_M2"]
    return b[0] + b[5] * a2 + b[6] * expected_m1(config, a1)


def psi(config, a1, a2, a3):
    """E[Y(a3, M1(a1), M2(a2, M1(a1)))].

    The outcome equation is linear with additive mean-zero noise, and E[UXY] = E[Xj] = 0,
    so only the intercept, the direct treatment term and the two mediator means remain.
    """
    b = config["beta_Y"]
    return (b[0]
            + b[6] * a3
            + b[7] * expected_m1(config, a1)
            + b[8] * expected_m2(config, a2, a1))


def truth(config):
    value = psi(config, 0, 1, 1) - psi(config, 0, 0, 1)
    return {
        "value": value,
        "estimated_error": 0.0,
        "method": "Closed-form linear-Gaussian nested intervention contrast; no quadrature or Monte Carlo is used.",
        "error_interpretation": "Exact up to IEEE-754 double rounding of the registered coefficients; not a statistical error bar.",
        "target": "cPSE_M2 = theta_011 - theta_001 = E[Y(1,M1(0),M2(1,M1(0)))] - E[Y(1,M1(0),M2(0,M1(0)))]",
    }
