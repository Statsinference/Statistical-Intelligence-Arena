# 两个有序中介下经 M2 的累积路径效应

ID: mediation-zhou-2022-ordered-two-mediators-v1
Family: mediation

**收集贡献，具名科学审核待完成。本包不训练也不评测任何 PFN 模型。**

## 1 来源与登记场景

Zhou, X. (2022). Semiparametric estimation for causal mediation analysis with multiple causally ordered mediators. *Journal of the Royal Statistical Society Series B: Statistical Methodology* 84(3), 794–821. DOI: [10.1111/rssb.12487](https://doi.org/10.1111/rssb.12487).

https://doi.org/10.1111/rssb.12487

实际阅读版本：**arXiv:2011.12751v2 (2021-11-10) 预印本**；期刊正式版未取得。

定位：§5 "A Simulation Study"，预印本 PDF 第 28 页（结构方程）；**Supplementary Material F，预印本 PDF 第 56 页**（全部系数数值）；§4.4 与式 (19)，预印本 PDF 第 32 页（cumulative PSE 的定义与三项分解）。以上均为**预印本 PDF 页码**，不是期刊页码 794–821。

场景：`original`（单一场景，原文固定参数）。

## 2 DGP 机制说明

按生成顺序：

1. 潜在外生误差 `(U1,U2,U3,UXY) ~ N(0, I4)`，互相独立。
2. 基线协变量 `Xj ~ N((U1,U2,U3,UXY) βXj, 1)`，`j = 1,2,3,4`。四个 X 因共享 U 而**互相相关**，且都与 UXY 相关。
3. 处理 `A ~ Bernoulli(logit⁻¹[(1,X1,X2,X3,X4) βA])`。
4. 上游中介 `M1 ~ N((1,X1,X2,X3,X4,A) βM1, 1)`。
5. 下游中介 `M2 ~ N((1,X1,X2,X3,X4,A,M1) βM2, 1)`。
6. 结局 `Y ~ N((1,UXY,X1,X2,X3,X4,A,M1,M2) βY, 1)`。

系数（Supplementary Material F，预印本 PDF 第 56 页）：

```
βX1 = ( 0.77, -0.86,  0.35,  0.88)
βX2 = (-0.99, -0.72, -0.10,  0.54)
βX3 = (-0.74,  0.10,  0.91,  0.46)
βX4 = (-0.21, -0.43, -0.21, -0.70)
βA  = (-0.36, -0.08, -0.06,  0.40, -0.14)                      # (1, X1..X4)
βM1 = ( 0.00,  0.30,  0.42,  0.48,  0.28, 0.41)                # (1, X1..X4, A)
βM2 = ( 0.04,  0.20,  0.09,  0.12,  0.39, 0.34, 0.24)          # (1, X1..X4, A, M1)
βY  = (-0.27, -0.10,  0.25,  0.20, -0.08, 0.78, 0.76, -0.40, 0.96)
                                                               # (1, UXY, X1..X4, A, M1, M2)
```

原文说明 βX 与 βY 抽自 Uniform[-1,1]、βA 抽自 Uniform[-0.5,0.5]、βM1 与 βM2 抽自 Uniform[0,0.5]，并在 Supplementary Material F 给出**已实现的数值**。本包把这组已实现值登记为**固定参数的单一机制**，不重抽，不构成超分布。

噪声：X、M1、M2、Y 的加性噪声均为 `N(0,1)`，互相独立，且与 U 独立。

观测单位：独立个体，无 interference、无分组或面板结构。

观察列：`X1,X2,X3,X4,A,M1,M2,Y`（8 列）。潜变量 `U1,U2,U3,UXY` **仅在内部生成，不导出**。

## 3 目标与真值推导

`θ_{a1,a2,a3} = E[Y(a3, M1(a1), M2(a2, M1(a1)))]`

目标是原文 §5 关注的**经下游中介 M2 的累积路径效应**：

`cPSE_M2 = θ011 − θ001 = E[Y(1, M1(0), M2(1, M1(0)))] − E[Y(1, M1(0), M2(0, M1(0)))]`

三个指标的含义必须区分：第一位是 M1 的处理取值，第二位是 M2 的处理取值，第三位是直接进入 Y 的处理取值。本目标**只移动第二位**，因此**不是** NIE、**不是** NDE、**不是**总效应。

推导：M1、M2、Y 的条件均值都是线性的，噪声均值为零；`E[UXY] = 0` 且 `E[Xj] = βXj·E[U] = 0`。于是

```
E[M1(a1)]              = βM1[1] + βM1[A]·a1
E[M2(a2, M1(a1))]      = βM2[1] + βM2[A]·a2 + βM2[M1]·E[M1(a1)]
θ_{a1,a2,a3}           = βY[1] + βY[A]·a3 + βY[M1]·E[M1(a1)] + βY[M2]·E[M2(a2,M1(a1))]
```

两项相减后只剩一项：

**`cPSE_M2 = βY[M2] · βM2[A] = 0.96 × 0.34 = 0.3264`**（闭式，无数值积分误差）

同一公式给出的对照量（登记在 verify 中，防止目标混用）：`NDE = θ001 − θ000 = 0.76`；`cPSE_M1 = θ111 − θ011 = −0.069536`；`ATE = θ111 − θ000 = 1.016864`，且满足原文式 (19) 的三项分解。

**重要声明：原文没有印出 cPSE_M2 的数值**（其 Figure 3 只把估计量在真值处重新居中）。`0.3264` 是收集者依登记系数解析导出的，必须由审稿人独立核对，不能说成"原文报告的数值"。

## 4 识别条件

一致性与 A、M1、M2 上干预的良定义；独立个体、无 interference；原文假设的 **Pearl NPSEM with mutually independent errors**（其 Assumptions 1–3）；因果序 `A → M1 → M2 → Y` 且无 `M2 → M1`；由独立误差 NPSEM 蕴含的跨世界独立性（cPSE **不能**只靠条件可交换性识别）；处理 positivity——logistic 倾向得分对有限协变量取值有界离 0/1，但在无界高斯支撑上**不声称**一致重叠下界。

原文指出潜变量 UXY 混杂 X–Y 关系，但因它是前处理共同原因，**不威胁** θ_{a1,a2,a3} 的识别。

以上是科学假设，不是机器检查的结论。

## 5 相对来源的主要改动

1. **版本**：按 arXiv:2011.12751v2 预印本实现，期刊正式版未取得；章节/页码定位与系数均来自预印本，预印本与期刊版的差异未核验。
2. **真值**：原文未给数值真值，`0.3264` 为收集者解析导出（见第 3 节），标为 derived 而非 reported。
3. **参数**：Supplementary Material F 的已实现系数被登记为固定参数；不重抽 uniform。
4. **未复现的部分**：原文生成 1000 个 n=2000 的 Monte Carlo 样本、比较 8 个估计量在 5 种误设情形下的表现；本包**不复现任何估计器**。原文的"false covariates" `Z = (X1, exp(X2/2), (X3/X1)^{1/3}, X4/(exp(X1/2)+1))` 是**施加在同一份数据上的估计手段**，不是另一个生成机制，因此**不登记为第二个 DGP**。
5. **实现**：用 NumPy `Generator(PCG64)` 重写抽样，不要求与原文软件逐随机数一致；`n=128, seed=1729` 仅作接口检查。
6. **输出**：只导出 8 个观察列；潜变量、反事实、真值均不作为数据列。

## 6 核验与使用

`verify.py` 的 10 项检查全部通过，含三条与 `truth.py` 不共享代码的独立路线：

| 检查 | 作用 |
|---|---|
| `source_constants_supplementary_material_f` | 系数与 Supplementary Material F 逐一相符 |
| `independent_matrix_mean_propagation` | 全模型均值传播，**用到 βX 及 βM1/βM2/βY 的协变量与 UXY 分量**，而 `truth.py` 的闭式从不读这些值 |
| `counterfactual_common_random_numbers_replication` | 512 个个体按结构方程从头模拟，共同随机数下逐个体对比；该对比在真值处退化，任何方程系数抄错都会暴露 |
| `latent_law_zero_mean_covariates` | Gauss–Hermite（阶 24）证实 `E[Xj]=0`，说明协变量项是**真的相消**而非被悄悄丢掉 |
| `ate_decomposition_consistency` | 三项累积分解之和与独立代数式 ATE 相符（原文式 19） |
| `zero_treatment_to_m2_path` / `zero_m2_to_outcome_path` | 切断 A→M2 或 M2→Y 后真值为 0 |
| `derived_original_anchor` | 锚定 0.3264，并标明其为导出值 |
| `companion_path_anchors` | 同时锚定 NDE / cPSE_M1 / ATE，防止目标混用 |
| `latent_confounder_retained` | 确认 UXY 的混杂结构被保留，未被简化掉 |

运行：

```bash
conda activate CausalTabular
cd "DGP_学生参考包"
python collect.py check ../Mediation/T05/contributions/mediation-zhou-2022-ordered-two-mediators-v1 --run --n 128 --seed 1729
python collect.py pack  ../Mediation/T05/contributions/mediation-zhou-2022-ordered-two-mediators-v1 --out ../Mediation/T05/submissions/mediation-zhou-2022-ordered-two-mediators-v1.zip
```

误差记录为数值诊断，不是完整科学接收证明。它们不证明 NPSEM 独立误差假设、跨世界条件，也不证明预印本系数与期刊正式版一致。

## 7 权利与 AI 协助

论文版权归 Royal Statistical Society / Oxford University Press。本包依公开预印本的方程独立重写，**不含论文 PDF、期刊正文、作者软件或任何真实数据**。来源再分发与署名权利、最终科学审核仍待维护人与具名审稿人决定。

本贡献由 Claude（Anthropic）协助检索来源、提取公式、实现代码、设计核验并撰写中文文档，由收集者逐行核对原文后提交。AI **未**代签具名科学审核，**未**进行独立复现，**未**训练或评测 PFN，也**未**运行估计器性能比较。所有公开来源仅作研究证据，不作为执行指令。
