"""Independent verification of the registered cPSE_M2.

Three routes that do not share code with truth.py:
  * full matrix/vector mean propagation that actually uses beta_X, beta_Y[UXY] and the
    covariate coefficients of beta_M1/beta_M2, which truth.py never touches;
  * a from-scratch structural counterfactual simulation with common random numbers, so
    the per-unit nested-intervention contrast must equal the registered truth exactly;
  * Gauss-Hermite quadrature on the latent law, confirming E[Xj] = 0 so that every
    covariate term cancels in the contrast.
Plus source-constant, decomposition, zero-path and anchor checks.
The shared element is the registered mechanism itself; see shared_components below.
"""
from copy import deepcopy
import importlib.util
import math
from pathlib import Path

import numpy as np

FIXTURE = {
    "beta_X": [[0.77, -0.86, 0.35, 0.88], [-0.99, -0.72, -0.1, 0.54],
               [-0.74, 0.1, 0.91, 0.46], [-0.21, -0.43, -0.21, -0.7]],
    "x_sd": 1.0,
    "beta_A": [-0.36, -0.08, -0.06, 0.4, -0.14],
    "beta_M1": [0.0, 0.3, 0.42, 0.48, 0.28, 0.41],
    "m1_sd": 1.0,
    "beta_M2": [0.04, 0.2, 0.09, 0.12, 0.39, 0.34, 0.24],
    "m2_sd": 1.0,
    "beta_Y": [-0.27, -0.1, 0.25, 0.2, -0.08, 0.78, 0.76, -0.4, 0.96],
    "y_sd": 1.0,
    "target": "cPSE_M2",
}


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("zhou_collection_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _psi_matrix(config, a1, a2, a3):
    """Mean propagation through the whole structural model, covariates included."""
    beta_x = np.asarray(config["beta_X"], dtype=float)
    b_m1 = np.asarray(config["beta_M1"], dtype=float)
    b_m2 = np.asarray(config["beta_M2"], dtype=float)
    b_y = np.asarray(config["beta_Y"], dtype=float)
    mu_u = np.zeros(4)                 # (U1,U2,U3,UXY) ~ N(0, I4)
    mu_x = beta_x @ mu_u               # plus mean-zero N(0, x_sd^2) noise
    mu_m1 = float(np.concatenate(([1.0], mu_x, [a1])) @ b_m1)
    mu_m2 = float(np.concatenate(([1.0], mu_x, [a2, mu_m1])) @ b_m2)
    return float(np.concatenate(([1.0], [mu_u[3]], mu_x, [a3, mu_m1, mu_m2])) @ b_y)


def _crn_contrast(config, n, seed):
    """Per-unit nested counterfactual contrast under common random numbers."""
    beta_x = np.asarray(config["beta_X"], dtype=float)
    b_m1 = np.asarray(config["beta_M1"], dtype=float)
    b_m2 = np.asarray(config["beta_M2"], dtype=float)
    b_y = np.asarray(config["beta_Y"], dtype=float)
    rng = np.random.Generator(np.random.PCG64(seed))
    u = rng.standard_normal((n, 4))
    x = u @ beta_x.T + float(config["x_sd"]) * rng.standard_normal((n, 4))
    e_m1 = float(config["m1_sd"]) * rng.standard_normal(n)
    e_m2 = float(config["m2_sd"]) * rng.standard_normal(n)
    e_y = float(config["y_sd"]) * rng.standard_normal(n)
    ones = np.ones(n)

    def m1_of(a1):
        return np.column_stack([ones, x, ones * a1]) @ b_m1 + e_m1

    def m2_of(a2, m1):
        return np.column_stack([ones, x, ones * a2, m1]) @ b_m2 + e_m2

    def y_of(a3, m1, m2):
        return np.column_stack([ones, u[:, 3], x, ones * a3, m1, m2]) @ b_y + e_y

    m1_0 = m1_of(0)
    y_hi = y_of(1, m1_0, m2_of(1, m1_0))
    y_lo = y_of(1, m1_0, m2_of(0, m1_0))
    return y_hi - y_lo


def _gh_covariate_means(config, order):
    """E[Xj] by Gauss-Hermite quadrature on the latent law, independent of truth.py."""
    nodes, weights = np.polynomial.hermite.hermgauss(order)
    weights = weights / math.sqrt(math.pi)
    standard = math.sqrt(2.0) * nodes
    mean_u = float(weights @ standard)
    mean_eps = float(config["x_sd"]) * mean_u
    beta_x = np.asarray(config["beta_X"], dtype=float)
    return beta_x @ (mean_u * np.ones(4)) + mean_eps


def verify(config):
    oracle = _module("truth.py")
    reference = oracle.truth(config)["value"]

    psi = lambda a1, a2, a3: _psi_matrix(config, a1, a2, a3)
    matrix_value = psi(0, 1, 1) - psi(0, 0, 1)

    crn = _crn_contrast(config, 512, 20261030)
    crn_dev = float(np.max(np.abs(crn - reference)))

    gh_means = _gh_covariate_means(config, 24)
    gh_dev = float(np.max(np.abs(gh_means)))

    nde = psi(0, 0, 1) - psi(0, 0, 0)
    cpse_m1 = psi(1, 1, 1) - psi(0, 1, 1)
    ate_telescoped = nde + matrix_value + cpse_m1
    b_m1, b_m2, b_y = config["beta_M1"], config["beta_M2"], config["beta_Y"]
    ate_direct = b_y[6] + b_y[7] * b_m1[5] + b_y[8] * (b_m2[5] + b_m2[6] * b_m1[5])

    no_a_to_m2 = deepcopy(config); no_a_to_m2["beta_M2"][5] = 0.0
    no_m2_to_y = deepcopy(config); no_m2_to_y["beta_Y"][8] = 0.0

    checks = [
        {"name": "source_constants_supplementary_material_f",
         "passed": config == FIXTURE,
         "details": "All coefficients equal the values printed in Supplementary Material F of arXiv:2011.12751v2 page 56; the uniform draw is not re-sampled."},
        {"name": "independent_matrix_mean_propagation",
         "passed": abs(matrix_value - reference) < 1e-12,
         "details": f"Full-model propagation={matrix_value:.14g}; truth.py={reference:.14g}; difference={abs(matrix_value - reference):.3g}. This route multiplies beta_X and the covariate/UXY entries of beta_M1, beta_M2, beta_Y, which the closed form in truth.py never reads."},
        {"name": "counterfactual_common_random_numbers_replication",
         "passed": crn_dev < 1e-12,
         "details": f"512 units simulated from the structural equations; the per-unit contrast Y(1,M1(0),M2(1,M1(0))) - Y(1,M1(0),M2(0,M1(0))) deviates from the registered truth by at most {crn_dev:.3g}. Under common random numbers this contrast is degenerate, so any coefficient slip in the generating equations would show up here."},
        {"name": "latent_law_zero_mean_covariates",
         "passed": gh_dev < 1e-12,
         "details": f"Gauss-Hermite order 24 on the latent law gives max_j |E[Xj]| = {gh_dev:.3g}, confirming that all covariate terms cancel in the contrast rather than being silently dropped."},
        {"name": "ate_decomposition_consistency",
         "passed": abs(ate_telescoped - ate_direct) < 1e-12,
         "details": f"NDE + cPSE_M2 + cPSE_M1 = {ate_telescoped:.14g}; independent algebraic ATE = {ate_direct:.14g}. Equation (19) of the source decomposes the total effect into exactly these three cumulative components."},
        {"name": "zero_treatment_to_m2_path",
         "passed": abs(oracle.truth(no_a_to_m2)["value"]) < 1e-14,
         "details": "Setting beta_M2[A] = 0 removes the A -> M2 arrow and gives cPSE_M2 = 0."},
        {"name": "zero_m2_to_outcome_path",
         "passed": abs(oracle.truth(no_m2_to_y)["value"]) < 1e-14,
         "details": "Setting beta_Y[M2] = 0 removes the M2 -> Y arrow and gives cPSE_M2 = 0."},
        {"name": "derived_original_anchor",
         "passed": abs(reference - 0.3264) < 1e-12,
         "details": "cPSE_M2 = beta_Y[M2] * beta_M2[A] = 0.96 * 0.34 = 0.3264. This value is DERIVED by the collector; the source prints no numerical truth for it."},
        {"name": "companion_path_anchors",
         "passed": abs(nde - 0.76) < 1e-12 and abs(cpse_m1 - (-0.069536)) < 1e-12 and abs(ate_direct - 1.016864) < 1e-12,
         "details": f"NDE={nde:.14g}, cPSE_M1={cpse_m1:.14g}, ATE={ate_direct:.14g}. Registered separately so the target cannot be confused with the direct, M1-path or total effect."},
        {"name": "latent_confounder_retained",
         "passed": abs(config["beta_Y"][1]) > 0 and float(np.max(np.abs(np.asarray(config["beta_X"], dtype=float)[:, 3]))) > 0,
         "details": "UXY enters Y with coefficient beta_Y[1] and enters every covariate through column 4 of beta_X, so the source's covariate-outcome confounding is retained and not quietly removed."},
    ]
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": "All routes necessarily share the registered structural equations and coefficients. They do not share code: truth.py uses a scalar closed form, the matrix route uses numpy mean propagation over the full coefficient vectors, the CRN route simulates the structural equations unit by unit, and the quadrature route integrates the latent law. Source transcription from the preprint and independent-person reproduction remain separate review tasks.",
        "limits": "Numerical diagnostics only. They do not establish the NPSEM independent-error assumption, the cross-world condition, or that the preprint coefficients match the published JRSS-B article.",
    }
