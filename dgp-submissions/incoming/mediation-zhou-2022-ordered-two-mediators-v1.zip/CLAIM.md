# 来源认领记录

mediation-zhou-2022-ordered-two-mediators-v1

Zhou, X. (2022). Semiparametric estimation for causal mediation analysis with multiple causally ordered mediators. Journal of the Royal Statistical Society Series B: Statistical Methodology 84(3), 794-821. DOI: 10.1111/rssb.12487.

实际阅读版本：arXiv:2011.12751v2 (2021-11-10) 预印本。期刊正式版未取得。

定位：§5 A Simulation Study，预印本 PDF 第 28 页（结构方程）；Supplementary Material F，预印本 PDF 第 56 页（系数数值）；§4.4 与式 (19)，预印本 PDF 第 32 页（cumulative PSE 定义）。页码为预印本 PDF 页码，非期刊页码 794-821。

机制区别：两个因果有序的连续中介 M1 -> M2，线性高斯结构，含一个前处理的潜在协变量-结局混杂 UXY；目标为经下游中介 M2 的 cumulative path-specific effect，不是自然间接效应、自然直接效应或总效应。

真值来源：原文未给出 cPSE_M2 的数值，本包登记的 0.3264 由收集者依 Supplementary Material F 的系数解析导出，需审稿人核对。

已在 2026-10-30 的仓库快照内查重：mediation 域仅有 nie-eric-original-v1，incoming/ 中无 mediation-* 包。未向维护人发送，待维护人认领/全库查重与具名科学审核。
