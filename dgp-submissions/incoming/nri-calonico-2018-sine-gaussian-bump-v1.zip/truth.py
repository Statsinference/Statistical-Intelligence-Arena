"""Population truth for CCF2018 supplement S.II.7 Model 1.

Estimand: m(x0) = E[Y | X = x0] at the fixed query point x0.
Because eps ~ N(0,1) with mean 0, E[Y|X=x0] = m(x0).

Model 1: m(x) = sin(4*x) + 2*exp(-64*x^2)

At x0 = 0:
    m(0) = sin(0) + 2*exp(0) = 0 + 2 = 2.0   (exact)

At x0 = +/- 2/3:
    The Gaussian bump contributes 2*exp(-64*(4/9)) = 2*exp(-256/9) < 9e-13,
    so m(+/-2/3) = sin(+/-8/3) to machine precision.

At x0 = +/- 1/3:
    Both the sine sin(+/-4/3) and the bump 2*exp(-64/9) contribute
    (bump ~ 1.63e-3).

The sine component sin(4*x0) is evaluated to machine precision; the
exponential is exact at x0=0 and to machine precision elsewhere.
estimated_error is reported as 1e-14 (IEEE 754 double rounding bound).
"""
import math


def _m_model1(x):
    """m(x) = sin(4x) + 2*exp(-64*x^2)."""
    return math.sin(4.0 * x) + 2.0 * math.exp(-64.0 * x * x)


def truth(config):
    """Return the exact population conditional mean m(x0) at the fixed query point.

    Returns
    -------
    dict with keys:
        value           : m(x0), a finite float
        estimated_error : floating-point rounding bound (<= 1e-14)
        method          : analytic derivation string
        target          : estimand description
        query_point     : x0 used
        noise_mean_contribution : noise_mean (= 0 per paper)
    """
    x0 = config["query_point"]
    noise_mean = config.get("noise_mean", 0.0)
    model = config.get("model_name", "M1")
    if model != "M1":
        raise ValueError("model_name must be M1; got " + str(model))

    m_val = _m_model1(x0)

    # Build a descriptive method string with the analytic decomposition
    sin_part = math.sin(4.0 * x0)
    bump_part = 2.0 * math.exp(-64.0 * x0 * x0)
    method = (
        "Closed-form: m(x0) = sin(4*x0) + 2*exp(-64*x0^2). "
        f"At x0={x0:.6g}: sin(4*x0)={sin_part:.16g}, "
        f"2*exp(-64*x0^2)={bump_part:.16g}, sum={m_val:.16g}. "
        "At x0=0 this is exactly 2.0 (sin(0)=0, exp(0)=1)."
    )

    value = m_val + noise_mean

    return {
        "value": value,
        "estimated_error": 1e-14,
        "method": method,
        "target": "m(x0) = E[Y | X = x0] at fixed query point x0",
        "query_point": x0,
        "noise_mean_contribution": noise_mean,
        "sin_part": sin_part,
        "bump_part": bump_part,
    }
