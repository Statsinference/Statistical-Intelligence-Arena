# NRI collection: CCF2018 Model 1 — sine plus Gaussian bump

**Status: candidate; not scientifically accepted.**

Source: Calonico, S., Cattaneo, M. D., and Farrell, M. H. (2018). On the Effect of Bias Estimation on Coverage Accuracy in Nonparametric Inference. *Journal of the American Statistical Association* 113(522), 767–779. DOI [10.1080/01621459.2017.1285776](https://doi.org/10.1080/01621459.2017.1285776). Supplement dated December 16, 2017.

## Source and reconstruction

**Supplement §S.II.7** ("Complete Simulation Results", printed p. 80, PDF p. 81): defines six regression models for the Monte Carlo study. This contribution collects Model 1.

**Main text §4** (printed p. 776, PDF p. 10): the five-point evaluation grid x ∈ {−2/3, −1/3, 0, 1/3, 2/3}.

Attribution (supplement p. 81): "Models 1 to 3 were used by Fan and Gijbels (1996) and Cattaneo and Farrell (2013)."

This model is a **CCF-family sine-plus-Gaussian-bump mean function**, structurally distinct from the Hall-Horowitz (2013) damped-sine family (g2/g3). It is registered as an independent mechanism family.

### Shared DGP structure (all models, §S.II.7)

```
Y_i = m(X_i) + eps_i,    i = 1, ..., n
X_i ~ U[-1, 1]           (iid)
eps_i ~ N(0, 1)          (iid, independent of X_i)
```

Paper simulation: n = 500, 5000 replications. This collection uses population equations only.

### Model 1 — sine plus Gaussian bump (§S.II.7)

```
m(x) = sin(4*x) + 2*exp(-64*x^2)
```

**Sine component:** sin(4x) oscillates with angular frequency 4 rad/unit; over [−1,1] it completes about 0.64 of a full period.

**Gaussian bump:** 2·exp(−64x²) is centered at x = 0 with amplitude 2 and scale parameter √(1/64) ≈ 0.125 (effective width ~1/8). The bump is negligible (< 9×10⁻¹³) for |x| ≥ 2/3.

## Target and identification

**Estimand:** `m(x₀) = E[Y | X = x₀]` at each fixed query point x₀.

Because `eps ~ N(0,1)` with `E[eps] = 0`, `E[Y|X=x₀] = m(x₀)`. No causal interpretation. This is an NRI (nonparametric regression inference) task.

**Applicable assumptions:**

- X and eps independent; E[eps] = 0.
- m(x) is smooth (C-infinity) on [−1,1]; standard kernel regularity conditions hold.
- Pointwise inference at each fixed query point; the five-point grid is **not** a simultaneous confidence band.
- No treatment, mediator, or intervention.

## Truth and independent verification

### Five-point analytic derivation

| x₀ | sin(4x₀) | 2·exp(−64x₀²) | m(x₀) |
|---|---|---|---|
| −2/3 | sin(−8/3) ≈ −0.4572726266 | 2·exp(−256/9) < 9×10⁻¹³ | ≈ **−0.4572726266349** |
| −1/3 | sin(−4/3) ≈ −0.9719379014 | 2·exp(−64/9) ≈ 0.0016319757 | ≈ **−0.9703059257** |
| 0 | sin(0) = 0 | 2·exp(0) = 2 | **2.0** (exact) |
| 1/3 | sin(4/3) ≈ +0.9719379014 | 2·exp(−64/9) ≈ 0.0016319757 | ≈ **0.9735698770** |
| 2/3 | sin(8/3) ≈ +0.4572726266 | 2·exp(−256/9) < 9×10⁻¹³ | ≈ **0.4572726266367** |

At x₀ = 0 the value is exactly representable (2.0). At other points estimated_error = 1e-14 (IEEE 754 double rounding bound).

### Key identity for independent verification

```
m(x) + m(-x) = sin(4x) + 2*exp(-64*x^2) + sin(-4x) + 2*exp(-64*x^2)
             = 4*exp(-64*x^2)
```

The sine is odd (cancels); the bump is even (doubles). This identity, computed with an independently-coded `4*exp(-64*x^2)`, is checked in verify.py.

### Independent verification routes (verify.py)

1. **Double-angle arithmetic path:** truth.py uses `sin(4x)` directly; verify.py uses `2*sin(2x)*cos(2x)` and `exp(-(8x)^2)`. Agreement to < 1e-12.
2. **Even-part identity:** m(x₀) + m(−x₀) = 4·exp(−64x₀²) checked at each query point.
3. **Exact anchor at x₀ = 0:** m(0) = 2 exactly.
4. **Bump negligibility at |x₀| = 2/3:** Gaussian bump < 9×10⁻¹³; m(±2/3) equals sin(±8/3) to that tolerance.

**Shared components:** both truth.py and verify.py call `math.sin` and `math.exp`. They differ in the path: direct evaluation vs. double-angle decomposition. Named scientific review and independent-person reproduction remain pending.

## Diversity and scope

- **dimension = 1, effective_dimension = 1.** Single covariate X.
- **nonlinear = true.** Two sources: sinusoidal oscillation sin(4x) and sharp Gaussian bump 2·exp(−64x²) near x = 0.
- **interactions = false.** Single-covariate model.
- **high_dimensional = false.**

The bump creates a strong spike at x = 0 (m(0) = 2 while sin alone would give 0 there), which is the hardest point for local polynomial estimators. Coverage at x = 0 is the central finding for M1-type functions in CCF2018 Table S.II.1 / Figure S.II.2.

## Rights and assistance

Paper copyright ASA / Taylor & Francis. No paper PDF or nprobust package code is distributed here. Equations are cited and independently implemented. Claude Code (AI assistant) extracted the equation from the PDF and wrote the Python code; a named human reviewer must verify equation transcription and independently reproduce the result.

**Open issues:**

- The supplement extraction may have stripped or distorted special characters; a named reviewer should verify `m(x) = sin(4x) + 2*exp(-64*x^2)` against the original printed PDF.
- The "sine frequency" in the supplement is rendered as `sin(4x)` in the text extraction; confirm the coefficient is 4 (not 4π or another variant).
- `reference_value` in collection.json is anchored to the default scenario `m1_x0_0` = 2.0 (exact). The checker verifies truth() against `reference_value` only for the default scenario.
