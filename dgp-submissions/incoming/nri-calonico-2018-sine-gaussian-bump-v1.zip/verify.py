"""Independent verification for CCF2018 supplement S.II.7 Model 1.

Verification strategy (independent of truth.py):
1. Second arithmetic path: uses math.cos-based identity
   sin(4x) = 2*sin(2x)*cos(2x), evaluates bump via exp(-32*(2x^2)) instead of
   exp(-64*x^2), then combines. Different operator order and intermediate steps.
2. Even-part identity: m(x) + m(-x) = 4*exp(-64*x^2)
   (sin(4x) is odd so sin(4x)+sin(-4x)=0; the bump 2*exp(-64*x^2) is even so
   both contributions add). Independently computed at each query point.
3. Exact anchor at x0=0: m(0) = sin(0) + 2*exp(0) = 0 + 2 = 2 exactly.
4. Bump negligibility at x0=+/-2/3: Gaussian bump contributes < 9e-13 there,
   so m(+/-2/3) should equal sin(8/3) / sin(-8/3) to that tolerance.

Shared components: both truth.py and verify.py evaluate sin and exp from
math module with the same declared equation. They differ in arithmetic
decomposition. Named scientific review remains pending.
"""
import math
import importlib.util
from pathlib import Path


def _load_truth():
    path = Path(__file__).with_name("truth.py")
    spec = importlib.util.spec_from_file_location("nri_sgb_truth", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ---- Independent arithmetic path ----------------------------------------

def _m1_independent(x):
    """Independent coding: use double-angle form for sin, exp via halved arg.

    sin(4x) = 2*sin(2x)*cos(2x)   [double-angle identity]
    2*exp(-64*x^2) = 2*exp(-32*(x^2+x^2)) -- rewritten as 2*exp(-(8x)^2)
    """
    two_x = 2.0 * x
    sin_part = 2.0 * math.sin(two_x) * math.cos(two_x)   # = sin(4x)
    arg = 8.0 * x                                          # (8x)^2 = 64*x^2
    bump_part = 2.0 * math.exp(-(arg * arg))               # = 2*exp(-64*x^2)
    return sin_part + bump_part


# ---- Even-part identity ---------------------------------------------------

def _even_part_independently(x):
    """Compute 4*exp(-64*x^2) directly (without calling truth.py or _m1_indep)."""
    return 4.0 * math.exp(-64.0 * x * x)


def verify(config):
    truth_module = _load_truth()
    oracle = truth_module.truth(config)
    oracle_val = oracle["value"]
    x0 = config["query_point"]
    noise_mean = config.get("noise_mean", 0.0)
    m_x0 = oracle_val - noise_mean  # isolate m(x0) from noise contribution

    checks = []

    # ---- Check 1: independent double-angle arithmetic path ----------------
    indep = _m1_independent(x0) + noise_mean
    diff1 = abs(oracle_val - indep)
    checks.append({
        "name": "independent_double_angle_path",
        "passed": diff1 < 1e-12,
        "details": (
            f"truth.py={oracle_val:.16g}; independent (double-angle)={indep:.16g}; "
            f"diff={diff1:.3g}. "
            "Uses sin(4x)=2*sin(2x)*cos(2x) and exp(-(8x)^2) instead of sin(4x) directly."
        ),
    })

    # ---- Check 2: even-part identity m(x0) + m(-x0) = 4*exp(-64*x0^2) ---
    # Evaluate m(-x0) independently (second call to truth module)
    cfg_neg = dict(config)
    cfg_neg["query_point"] = -x0
    oracle_neg = truth_module.truth(cfg_neg)
    m_neg_x0 = oracle_neg["value"] - noise_mean

    even_sum = m_x0 + m_neg_x0
    expected_even = _even_part_independently(x0)
    diff2 = abs(even_sum - expected_even)
    checks.append({
        "name": "even_part_identity",
        "passed": diff2 < 1e-12,
        "details": (
            f"m(x0)+m(-x0) = 4*exp(-64*x0^2). "
            f"m({x0:.6g})={m_x0:.16g}, m({-x0:.6g})={m_neg_x0:.16g}, "
            f"sum={even_sum:.16g}; expected={expected_even:.16g}; diff={diff2:.3g}. "
            "Confirms the odd sine cancels and the even Gaussian bump doubles."
        ),
    })

    # ---- Check 3: exact value at x0=0 -------------------------------------
    if abs(x0) < 1e-10:
        expected_zero = 2.0 + noise_mean   # sin(0)+2*exp(0)=2
        diff3 = abs(oracle_val - expected_zero)
        checks.append({
            "name": "exact_value_at_origin",
            "passed": diff3 < 1e-12,
            "details": (
                f"m(0) = sin(0)+2*exp(0) = 0+2 = 2 exactly. "
                f"oracle={oracle_val:.16g}; expected={expected_zero:.16g}; diff={diff3:.3g}."
            ),
        })

    # ---- Check 4: bump negligibility at |x0| >= 2/3 ----------------------
    if abs(abs(x0) - 2.0 / 3) < 1e-10:
        bump_at_x0 = 2.0 * math.exp(-64.0 * x0 * x0)
        pure_sine = math.sin(4.0 * x0)
        diff4 = abs(m_x0 - pure_sine)
        checks.append({
            "name": "bump_negligible_at_x0_2o3",
            "passed": bump_at_x0 < 9e-12 and diff4 < 9e-12,
            "details": (
                f"At |x0|=2/3: Gaussian bump = 2*exp(-256/9) = {bump_at_x0:.3g} < 9e-12. "
                f"m(x0)-sin(4*x0) = {diff4:.3g}. "
                "m is effectively sin(4x) with no visible bump contribution."
            ),
        })

    passed = all(c["passed"] for c in checks)
    return {
        "passed": passed,
        "checks": checks,
        "shared_components": (
            "Both truth.py and verify.py evaluate math.sin and math.exp. "
            "Paths differ: truth.py uses sin(4x) directly and exp(-64*x^2); "
            "verify.py uses sin(4x)=2*sin(2x)*cos(2x) and exp(-(8x)^2). "
            "Named scientific review and independent-person reproduction remain pending."
        ),
    }
