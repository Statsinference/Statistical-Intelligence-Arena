import math
from statistics import NormalDist

def truth(config):
    v=config['x_query'][0]
    value=config['intercept']+config['slope']*v+math.exp(-v)*(-math.log1p(-config['tau'])/config['exp_rate']-math.log(config['center_log_argument']))
    return {"value":float(value),"estimated_error":1e-12,"error_interpretation":"Floating-point and bisection diagnostic; not a rigorous uniform error bound"}
