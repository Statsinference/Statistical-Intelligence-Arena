# Conditional quantile in the Dette-Volgushev exponentially scaled exponential-error mechanism

编号 Q08 · 指数衰减尺度与偏斜指数误差。状态：本地核验后仍待科学审核；未提交 GitHub。

## 来源与精确定位

Dette, H. and Volgushev, S. (2008). Non-crossing non-parametric estimates of quantile curves. Journal of the Royal Statistical Society Series B 70(3), 609-627. DOI: https://doi.org/10.1111/j.1467-9868.2008.00651.x

实际读取：Discussion paper dated 2007-05-08, EconStor handle 10419/25003, 23 PDF pages including repository cover; not the 2008 typeset version。下载链接：https://www.econstor.eu/bitstream/10419/25003/1/53475869X.PDF

定位：Read version: discussion paper dated 2007-05-08, Section 4.2, equation (4.5), model 4; PDF page 13 including EconStor cover = printed preprint page 12. The later journal pagination 609-627 is NOT the locator for this read version.

读取 PDF 的 SHA-256：ca330751120e1c409cb7ec865c97dc0451cfdcd589d915555e76dfed1284adf5。不依赖作者源码，无代码 commit 需要引用。source_audit.json 另列版本及查重证据。

## 完整生成机制

\[
X_i\sim U(0,5),\quad E_i\sim\operatorname{Exp}(\mathrm{rate}=1),\quad X_i\perp E_i
\]

\[
Y_i=2+X_i+e^{-X_i}\{E_i-\log(2.6)\}
\]

\[
Q_\tau(x)=2+x+e^{-x}\{-\log(1-\tau)-\log(2.6)\}
\]

生成顺序：先抽协变量，再独立抽噪声，最后按显示方程构造响应。不同观察行独立；协变量和噪声按显示公式及下列实现约定独立。参数全部在 config.json。X1 到 X1 以及 Y 完全观测；无缺失、删失、标注抽样或因果处理分配。误差及混合成分只在生成器内部使用，不输出给模型。

样本量由 generate(config,n,seed) 的 n 决定；source_n 是原文样本量记录，不替代 n。随机数生成器为 NumPy PCG64，固定种子及相同依赖版本可复现；不声称与 R 或论文逐行随机数相同。所有列为等长有限数值列表。不对 Y 裁剪、截断或重新标准化；均匀分布的右端点在实现中不取，连续理论分布不受影响。

## 目标与真值

Conditional 0.9 quantile at X=2, according to the explicitly dated preprint model 4.

指数噪声分位数为 $-\log(1-\tau)$，$e^{-x}>0$，故可直接代入单调变换。条件支持下界为 $2+x-e^{-x}\log(2.6)$；CDF 在下界以下为零。

默认场景真值为 **4.18230659368814**。这是按本包目标推导的新真值；未将论文估计值当作 oracle。truth.py 返回标量以及 1e-12 的浮点/求根诊断，非严格统一误差界。数值反演使用初始区间 [-100,100] 和 60 次二分，适用于登记的固定水平。verify.py 不调用生成器，使用独立密度 Simpson 积分和 1024/2048 网格（Q01 卷积为 2048/4096），并核对对称/支持/边界特例。两条路线仍由同一 AI 编写，不等于独立研究者复现。

分位数统一定义为 $Q_\tau=\inf\{y:F(y)\ge\tau\}$。指数参数按 rate=1 解释，scale=1；尺度 e⁻ˣ 在 [0,5] 上介于 e⁻⁵ 与 1。

## 多样性及范围

One active covariate; nonlinear scale exp(-X), asymmetric exponential noise, lower-bounded conditional response. This is distinct from Gaussian sine location/scale models. high_dimensional=false 指本包维数相对于原文样本量以及 n=128 核验而言，不承诺 n 小于维数时仍属低维。多个噪声或查询场景不重复计数。标量真值核验不意味着整条分布函数带或分位曲线的覆盖率通过。所有登记场景见 config.json。

## 相对来源的改动

1. The mechanism is transcribed from the dated 2007-05-08 preprint associated with the 2008 JRSS-B publication. The preprint attributes this model to Yu and Jones (1998). This lineage is recorded to prevent duplicate counting across papers.
2. The 2008 typeset simulation formulas have not been compared line by line; no equality of all preprint and final-version formulas is asserted. Published bibliographic metadata and the actual read-version locator are kept separate.
3. Fixed x=2 and tau=0.9 define a scalar query. Independent X and E and iid rows are explicit implementation conventions. The offset is exactly log(2.6), not log(2).
4. Independent Python/NumPy implementation from mathematical formulas; no author code is redistributed. PCG64(seed) replaces unspecified/source software random-number generation. Sample size is the generate n argument; source_n only records the published sample sizes. No fitting, bootstrap, confidence-band coverage experiment or PFN training is included.

## 权利与 AI 协助

原论文归原著作权人；本包不含论文 PDF、真实个体数据或作者源码。方程被重新转写并单独实现。使用 AI 辅助提取、推导、编程、核验及排版，尚无具名科学审核人及独立复现者；不得将本地 PASS 或收件测试写为正式接收。提交人姓名由用户在 GitHub 提交说明中填写，不由 AI 代签。
