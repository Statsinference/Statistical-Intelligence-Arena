from math import comb
import numpy as np
from scipy.special import gammaln, logsumexp

def reference(c):
    # Enumerate the full Binomial support, instead of inserting its variance formula.
    M=c['micro_n'];k=np.arange(M+1);means=[];variances=[]
    for d in [0,1]:
        q=.5+c['weight_effect']*d
        logw=gammaln(M+1)-gammaln(k+1)-gammaln(M-k+1)+k*np.log(q)+(M-k)*np.log1p(-q)
        w=np.exp(logw-logsumexp(logw));v=c['separation']*(2*k/M-1);mean=float(w@v)
        means.append(mean);variances.append(float(w@((v-mean)**2)+2*c['component_var']/M))
    p=c['pi'];return dict(pi=p,theta=means[1]-means[0],m0=means[0],V=variances[1]/p+variances[0]/(1-p))
