# Zhou et al. Gaussian-mixture weight shift, empirical mean

## 来源与关系

Zhou, Y., Kurisu, D., Otsu, T. and Müller, H.-G. (2026). Geodesic difference-in-differences. Biometrika, asag054. [DOI](https://doi.org/10.1093/biomet/asag054)。定位：arXiv:2501.17436v2, Section 5.3 p.21; author simulations/mvmea.R.

**ADAPTED；不是原论文标量 DGP 的原样复现。**

- Project each observed bivariate sample to the empirical mean of its first coordinate; scalar ATT replaces Fisher–Rao geodesic ATT.
- Preserve shared individual location, mixture weights, component separation, variance, and 500 within-unit observations in the reference scenario.
- Use a Binomial count plus Gaussian average to generate that scalar statistic exactly in distribution; no Gaussian approximation to the Binomial.
- Parameter prior and negative/null weight changes are extensions.

## 数学定义与识别证明

D~Bernoulli(pi) independently of shared location xi. At baseline both mixture components have location xi. At post their locations are xi±a; mixture weight is 1/2+b d. For M within-unit draws with component variance s², Ypre=xi+E0 and Ypost(d)=xi+a(2K_d/M-1)+E1, K_d~Bin(M,1/2+b d), E0,E1~N(0,s²/M). This exactly generates the scalar empirical mean marginal distribution. Couple K_d with shared uniforms for potential outcomes if desired. X is empty; m0=0, ATT=2ab. The change variances are v0=(a²+2s²)/M and v1=[4a²(1/4-b²)+2s²]/M; V=v1/pi+v0/(1-pi). The shared xi cancels, while within-unit sampling noise is retained. n denotes independent distributions/individuals, never nM.

## 参数与家族

`config.json` 给出 3 个明确场景；`adapted_reference` 保留可保留的来源常数，不命名为 original。完整参数区间与采样分布在 `family_prior.json`，`family.sample_mechanism(seed)` 只生成固定参数，`generate(config,n,seed)` 再独立生成样本。改变场景、系数或随机种子不增加家族数。此家族的 paper lineage 为 `zhou-kurisu-otsu-muller-2026`。

## 输入与标签隔离

只使用 `fsp_adapter.model_input` 构造 X,D,delta_y。y_pre/y_post 仅供观察数据审核；特别是无协变量家族，不得擅自把 y_pre 加入 X。所有真实 propensity、m0、ATT、V、EIF、teacher 都在独立 sidecar 中。样本为空组时 teacher 明确报错，不重抽、不截断分母。

## 真值与验证

`truth.py` 不依赖当前 episode。`independent_reference.py` 用不同积分或枚举路径核验人口矩；`verify.py` 另外核验真实生成数据的处理概率、EIF 一二阶矩。更完整的重复抽样、区间覆盖率、家族抽样检查见 `audit_results.json` 与 `audit.md`。数值积分阶数差是误差诊断，不冒称严格误差上界。

## 使用

安装 requirements.txt，在本目录运行 `python -c "import json; from generator import generate; c=json.load(open('config.json'))['scenarios']['adapted_reference']; print(generate(c,5,1729))"`。

学生工具：`python collect.py check <本目录> --run --n 128 --seed 1729`；随后 `python collect.py pack <本目录> --out <新 ZIP>`。包内 `checks/report.json` 是格式及执行检查，科学审核以 `audit.md` 为准。本文档与实现由 AI 辅助完成，不伪造人工评审或独立研究者复现签名。
