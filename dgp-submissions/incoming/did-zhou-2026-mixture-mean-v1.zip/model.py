import numpy as np

def validate(c):
    assert .1 <= c['pi'] <= .9 and abs(c['weight_effect']) <= .4
    assert .25 <= c['separation'] <= 2 and .1 <= c['component_var'] <= 2
    assert 20 <= c['micro_n'] <= 1000 and isinstance(c['micro_n'],int)
    assert .2 <= c['location_sd'] <= 2

def draw(c,n,seed):
    validate(c);r=np.random.default_rng(seed);d=r.binomial(1,c['pi'],size=n)
    xi=c['location_sd']*r.normal(size=n);M=c['micro_n'];s=np.sqrt(c['component_var']/M)
    # Exact distribution of the first-coordinate empirical mean of M mixture draws.
    # At t=0 the two component locations coincide; at t=1 the component count is Binomial.
    y0=xi+s*r.normal(size=n)
    k=r.binomial(M,.5+c['weight_effect']*d)
    y1=xi+c['separation']*(2*k/M-1)+s*r.normal(size=n)
    return dict(x0=np.zeros(n),D=d,y_pre=y0,y_post=y1,delta_y=y1-y0)

def moments(c,order=None):
    validate(c);p=c['pi'];M=c['micro_n'];a=c['separation'];b=c['weight_effect'];v=c['component_var']
    v0=(a*a+2*v)/M;v1=(4*a*a*(.25-b*b)+2*v)/M
    return dict(pi=p,theta=2*a*b,V=v1/p+v0/(1-p),m0=0.)

def nuisances(c,data,pop):
    n=len(data['D']);return np.full(n,pop['pi']),np.zeros(n)
