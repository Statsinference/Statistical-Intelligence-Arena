# N01 30 维滞后窗口下的异方差可加回归

Contribution: `nri-wangyang-2007-hdadditive-v1` · `synthetic_dgp` · `nonparametric_regression` · **v1**

## Source and reconstruction

Wang, L. and Yang, L. (2007). Spline-backfitted kernel smoothing of nonlinear additive autoregression model. The Annals of Statistics 35(6), 2474-2503. DOI: 10.1214/009053607000000488.

[DOI](https://doi.org/10.1214/009053607000000488) · [固定阅读版本 math/0612677v5](https://arxiv.org/pdf/math/0612677v5)

实读 PDF SHA-256：`d293e126b31431d2c2dd6dfd7cb546c6058522035b5022ed77a3b6a9d6c53cf0`。IMS electronic reprint of the published article; the actual first-page declaration says pagination and typographic detail differ from the original.

Section starts: Section 6 on PDF p.14, Section Example 6.2 on PDF p.18. Unnumbered paragraph on PDF p.18: "Consider the nonlinear additive heteroscedastic model" (Example6.2 mean, signed heteroscedastic scale, truncated-normal design and experiment parameters). All PDF pages are 1-based pages of the fixed reading file math/0612677v5. No printed journal page is inferred by adding an offset.

**原文参数逐页登记**

- PDF p.18：d30; X coordinates standard normals truncated[-2.5,2.5]; m(X)=sum sin(pi*X_lag/2.5); signed sigma(X)=sigma0*(sqrt(d)/2)*(5-exp(L))/(5+exp(L)); L=sum(abs(X_lag))/d; sigma0=.1; n500,1000,1500,2000; 100 repetitions。

**按实际执行顺序的生成步骤**

1. **Scalar stream** — Z_s iid N(0,1) conditional on -2.5<=Z_s<=2.5, s=0..n+29-1; rejection sampling; sd=1 before truncation. One scalar truncated-normal stream; source d=30, bound=2.5.
2. **Lag window** — X_t=(Z_(t+29),Z_(t+28),...,Z_t), t=0..n-1; X1 is the most recent lag. Deterministic window; no new noise. Adjacent rows share 29 stream values.
3. **Mean and scale** — m(X)=sum_(a=1)^30 sin(pi*X_a/2.5); L=mean(abs(X_a)); sigma(X)=0.1*(sqrt(30)/2)*(5-exp(L))/(5+exp(L)). Deterministic; signed source multiplier retained. Divisor 2 is outside the radical.
4. **Innovation** — epsilon_t iid N(0,1), independent of the scalar stream and other innovations. Noise sd=1 before multiplication by sigma(X).
5. **Outcome and columns** — Y_t=m(X_t)+sigma(X_t)*epsilon_t; return X1..X30,Y in chronological window order. Conditional variance=sigma(X_t)^2; no latent/noiseless column is exported.

**抽样单位与依赖**：observation row (one simulated time index t together with its 30 covariate coordinates X1..X30)；Under the declared lag-window interpretation, rows at distance at least d=30 use disjoint innovations and covariate draws; adjacent rows share 29 coordinates. Consecutive length-30 blocks still overlap in their underlying covariate draws and are not independent. There is no statistic-independent effective sample size.

**边界与尺度**：Rejection sampling implements the truncated law without clipping. The source multiplier can be negative when L>log(5); its square is the conditional variance. Every registered query is inside [-2.5,2.5]^30.

**与来源的改动及理由**

1. Read the displayed X_{t-alpha} subscripts consistently across rows as overlapping windows of one iid truncated-normal stream. This is the declared interpretation of the source notation; no claim is made that an author implementation has been recovered.
2. Replace component-estimator comparisons by scalar m(x0)=E[Y|X=x0]; x0=(1.25,0,...,0) and the zero vector are our choices.
3. Implement truncation by rejection sampling; retain the source's signed noise multiplier without clipping.
4. For the shared-stream interpretation, use exact overlap counts for signal variance of the whole-table mean and conditional noise variance; adjacent length-d blocks are dependent, and no universal n/d effective sample size is assumed.
5. Use interface sample sizes and CPU checks without fitting the source estimators.

固定点目标由已声明条件响应律识别：高斯模型使用零条件均值的误差/随机效应，广义回归直接用指定分布的链接均值。接口 n 和查询为适配；未把 n=128 说成论文原实验样本量。

**版本关系**：The actual fixed reading PDF is an IMS electronic reprint of the published article, not a separate author-preprint draft merely because it is hosted on arXiv. The first-page declaration explicitly notes pagination and typographic differences. We use only verified section/equation/1-based PDF locators and do not claim identical publisher typesetting, exact printed-page offsets or entire-text identity. No separate author-preprint-to-formal substitution is involved for this reading source; that conditional comparison is N/A.

## Target and identification

`m(x0) = E[Y | X = x0] = sum_{alpha=1}^{30} sin(pi * x0_alpha / 2.5)`

Scalar conditional mean of Y at a fixed 30-dimensional query point x0 in the superpopulation defined by the fixed Example 6.2 DGP. It is a pointwise regression functional, not a causal effect; the query is a parameter of each scenario and is read from config by truth(config).

**登记场景与查询**

| Scenario | Parameters / query |
|:--|:--|
| `original-sigma01`（默认） | `{"sigma0": 0.1, "dimension": 30, "truncation_bound": 2.5, "sin_frequency_scale": 1.2566370614359172, "noise_sd": 1.0, "query": [1.25, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]}` |
| `origin-query` | `{"sigma0": 0.1, "dimension": 30, "truncation_bound": 2.5, "sin_frequency_scale": 1.2566370614359172, "noise_sd": 1.0, "query": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]}` |

场景中的 original-* 表示保留的来源生成参数，不代表新增查询和接口样本量属于原文实验。本包另设 origin-query 作为原模型参数下的自选查询；不复制同义场景充数。

**抽样、设计与支持条件**

- The displayed lag subscripts are interpreted as one shared iid truncated-normal stream, independent of the iid N(0,1) innovations.
- The query is fixed inside the 30-dimensional truncated-normal support.
- The noise multiplier may have either sign; conditional variance is its square and conditional mean is zero.
- Pointwise truth does not imply an estimator or coverage result; the source's unspecified cross-row sampling algorithm remains an interpretation boundary.

固定点条件均值正确，不等于点态区间或同时置信带覆盖率达标。非因果任务不套用干预/无混杂假设。

## Truth and independent verification

Closed-form m(x0)=sum sin(pi*x0_alpha/2.5); independently evaluated and checked by quadrature and Monte Carlo. Table-mean signal variance uses exact scalar-stream overlap counts; the noise part uses observed conditional innovation variance. Adjacent length-d blocks are not assumed independent. Numerical estimated_error is a floating-point allowance, not a statistical error.

`truth.tolerance=1e-08`。estimated_error 是浮点/数值路线诊断，不是严格统一误差界或统计标准误；其非负且不大于 tolerance。

**不同路线与解析特例**：逐点三角函数闭式、独立截断正态求积、另一随机数路线的 Monte Carlo；整表均值使用共享流的精确重叠计数方差。原点 m=0 是可解析锚点。

**实际共享函数与独立边界**：verify 以 truth.truth 的返回值为比较对象；调用 generator.generate 检查实际接线，调用 generator.sigma_function 与独立 tanh/Decimal 尺度比较。后两者是被测实现，不是独立参照函数；独立均值、尺度推导、求积与随机采样另写。

外部另按论文公式用 mpmath 70 位重算全部登记查询；另对各场景 generate(n=4096, seed=7312026) 实际观察列独立重构残差，不导入私有均值助手或 verify 作外部参照。N08 的源数学参照取精确 1/sqrt(3)，与配置中最短十进制权重的浮点差计入比较；阈值仍逐包取 tolerance，不靠放宽阈值通过。

## Diversity and scope

`dimension=30`，`effective_dimension=30`。All 30 covariates enter the additive sine mean. The source uses n=500,1000,1500,2000, so d=30 is multivariate but not a d>=n sparse high-dimensional design. Nonlinear=true for sine functions. Interactions=false refers to the additive conditional mean; the noise multiplier is a nonseparable nonlinear function of the aggregate L. Observed columns=31.

No treatment, label or missingness mechanism is applicable. The mean is additive; the scale is a nonlinear nonseparable function of L. No universal n/30 effective sample size is asserted. Source sample sizes 500/1000/1500/2000 are not the n=128 smoke run.

处理分配、标注、缺失与真实数据分支均不适用。未执行论文估计器、bootstrap、点态/同时覆盖率、PFN 训练、大规模压力测试或第二人独立人工复现。

## Rights and assistance

Source equations are cited and independently implemented. Paper copyright is not transferred; no paper PDF, author software, original participant data or model weights are redistributed. No external author code was used. The contributor must confirm the release licence for the independently implemented code before publication; pending review is not a grant of rights. AI assisted equation extraction, implementation, numerical checks and drafting; named human scientific review and independent-person reproduction are not claimed.

**未使用作者原始代码或补充材料代码**；因此作者软件 commit 追溯项 N/A。本包依赖以 requirements.txt 为准：标准库或 NumPy 的使用不等于移植作者代码。论文全文、页图、作者软件、权重、数据银行、凭据不随贡献包分发。

**missing / 尚待确认**

- missing(author_cross_row_algorithm): source gives lag subscripts but no separate author algorithm/seed. We explicitly choose a shared-stream overlapping-window interpretation; confirming the author algorithm would require source code or an author statement. This choice defines the implemented joint law and does not make its conditional mean unknown.
- 本人须审核 AI 协助的来源提取、代码、数值和文本，并确认独立实现代码的发布许可；pending 不是授权。
- 具名科学审核、第二人独立人工复现：未执行。
- GitHub Fork/Sync/SUBMIT DGP/Actions/PR/收录确认：本次未执行。本地 submit 不等于网络提交或项目收件。

**状态**：以最终 checks/report.json 记录本地 runnable_dgp；归档仅 awaiting_scientific_review、scientific_acceptance=false。
