"""Source equations, independent integration and correct overlapping-window variance."""
import importlib.util
import math
from decimal import Decimal, localcontext
from pathlib import Path
import numpy as np


def _module(name):
    spec = importlib.util.spec_from_file_location("wy_v2_"+name, Path(__file__).with_name(name+".py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def _corr(x, lag):
    return float(np.corrcoef(x[:-lag], x[lag:])[0,1])


def verify(config):
    g, t = _module("generator"), _module("truth")
    d, b = int(config["dimension"]), float(config["truncation_bound"])
    q = np.asarray(config["query"], dtype=float)
    freq, sigma0 = float(config["sin_frequency_scale"]), float(config["sigma0"])
    reference = float(t.truth(config)["value"])
    independent = float(np.sin(freq*q).sum())
    nodes, weights = np.polynomial.legendre.leggauss(200)
    points = b*nodes
    density = np.exp(-points**2/2)/math.sqrt(2*math.pi)/math.erf(b/math.sqrt(2))
    moment1 = float(b*np.dot(weights, np.sin(freq*points)*density))
    moment2 = float(b*np.dot(weights, np.sin(freq*points)**2*density))
    rng = np.random.default_rng(987654321)
    draws = []
    size = 0
    while size < 2000000:
        batch = rng.normal(size=2100000-size)
        batch = batch[np.abs(batch)<=b]
        draws.append(batch)
        size += len(batch)
    vals = np.sin(freq*np.concatenate(draws)[:2000000])
    mc1, mc2 = float(vals.mean()), float((vals**2).mean())
    se1 = float(vals.std(ddof=1)/math.sqrt(len(vals)))
    se2 = float((vals**2).std(ddof=1)/math.sqrt(len(vals)))

    n = 200000
    rows = g.generate(config, n, 20261028)
    x = np.column_stack([rows[f"X{j}"] for j in range(1,d+1)])
    y = np.asarray(rows["Y"])
    signal = np.sin(freq*x).sum(axis=1)
    ell = np.abs(x).mean(axis=1)
    scales = -sigma0*math.sqrt(d)/2*np.tanh((ell-math.log(5))/2)
    residual = y-signal
    # A scalar covariate draw is reused 1,2,...,d-1,d,...,d,d-1,...,1 times.
    # Thus Var(mean(signal))=Var(sin(freq*Z))*sum(counts^2)/n^2, exactly.
    overlap_square_sum = d*d*(n-d+1) + (d-1)*d*(2*d-1)/3
    signal_var_mean = (moment2-moment1**2)*overlap_square_sum/n**2
    conditional_noise_var_mean = float(np.sum(scales**2))/n**2
    table_se = math.sqrt(signal_var_mean+conditional_noise_var_mean)
    residual_se = math.sqrt(conditional_noise_var_mean)
    table_mean, residual_mean = float(y.mean()), float(residual.mean())
    table_tol = min(0.05, 4*table_se)
    residual_tol = min(0.01, 4*residual_se)
    innovations = residual/scales
    innovation_second = float(np.mean(innovations**2))
    lag1 = _corr(y[:900],1)
    lagd = _corr(y[:900],d)
    overlaps = bool(np.array_equal(x[1:900,1:],x[:899,:-1]))
    stride_independent = len(set(x[0]) & set(x[d]))==0

    ellq = math.fsum(abs(float(v)) for v in q)/d
    scale_tanh = -sigma0*math.sqrt(d)/2*math.tanh((ellq-math.log(5))/2)
    with localcontext() as context:
        context.prec = 50
        l = sum((abs(Decimal(str(v))) for v in config["query"]),Decimal(0))/Decimal(d)
        e = l.exp()
        scale_decimal = float(Decimal(str(sigma0))*Decimal(d).sqrt()/Decimal(2)*(Decimal(5)-e)/(Decimal(5)+e))
    source_ok = (d==30 and b==2.5 and sigma0==0.1 and config["noise_sd"]==1.0
                 and abs(freq-math.pi/2.5)<1e-15 and g.SIGMA_ROOT_D_DIVISOR==2.0)
    checks = [
        {"name":"source_constants_original", "passed":source_ok,
         "details":"Example 6.2 d=30, bound=2.5, sigma0=.1, frequency pi/2.5, standard-normal innovations, sqrt(d)/2 multiplier. Queries and overlapping-window interpretation are disclosed adaptations."},
        {"name":"independent_closed_form", "passed":abs(reference-independent)<1e-10,
         "details":f"Independent NumPy sum={independent:.16g}, truth={reference:.16g}."},
        {"name":"quadrature_vs_monte_carlo", "passed":abs(mc1-moment1)<min(.005,6*se1) and abs(mc2-moment2)<min(.005,6*se2),
         "details":f"GL200 E[sin]={moment1:.9g}, E[sin^2]={moment2:.9g}; independent 2m rejection draws: {mc1:.9g}, {mc2:.9g}; SEs {se1:.3g}, {se2:.3g}."},
        {"name":"serial_dependence_structure", "passed":overlaps and stride_independent,
         "details":f"Adjacent rows share d-1 shifted coordinates={overlaps}; rows d apart share none={stride_independent}; correlations lag1={lag1:.5g}, lagd={lagd:.5g}. Consecutive length-d blocks are not independent."},
        {"name":"overlap_variance_and_noise_wiring", "passed":abs(table_mean-d*moment1)<table_tol and abs(residual_mean)<residual_tol and abs(innovation_second-1)<6*math.sqrt(2/n),
         "details":f"n={n}; exact signal overlap-count variance plus observed conditional innovation variance give SE(meanY)={table_se:.9g}; meanY={table_mean:.9g}, tolerance={table_tol:.9g} (old .05 cap retained as a diagnostic, not a calibrated confidence level). Residual mean={residual_mean:.9g}, conditional SE={residual_se:.9g}, tolerance={residual_tol:.9g}. Standardized innovation second moment={innovation_second:.9g}. No iid-block assumption or generic effective sample size."},
        {"name":"heteroscedastic_scale_check", "passed":abs(scale_tanh-scale_decimal)<1e-12 and abs(g.sigma_function(q,sigma0,d)-scale_decimal)<1e-12,
         "details":f"Independent tanh scale={scale_tanh:.16g}, 50-digit Decimal={scale_decimal:.16g}; zero anchor sigma0*sqrt(d)/3={sigma0*math.sqrt(d)/3:.16g}. Signed scale is preserved; variance is its square."},
        {"name":"interpretable_anchor", "passed":abs(float(np.sin(freq*(-q)).sum())+reference)<1e-12 and float(np.sin(np.zeros(d)).sum())==0,
         "details":"Odd mean function and zero-vector anchor; no source coverage result claimed."},
    ]
    return {"passed":all(c["passed"] for c in checks), "checks":checks,
            "variance_diagnostic":{"table_se":table_se,"residual_se_conditional":residual_se,
              "signal_mean_variance_exact":signal_var_mean,"noise_mean_variance_conditional":conditional_noise_var_mean,
              "overlap_square_sum":overlap_square_sum,"table_n":n},
            "limits":"Exact signal variance is under the explicitly declared lag-window interpretation. Total variance uses the observed conditional noise contribution, not a deterministic uniform bound. Local diagnostics are not scientific acceptance."}
