"""Population conditional mean at the fixed query point; integrate/none, closed form only.

m(x0) = E[Y | X = x0] = sum_alpha sin(pi * x0_alpha / 2.5).

The heteroscedastic noise term has conditional mean zero, so it drops out of the
target. No generated row is ever used to estimate truth here.
"""
import math


def conditional_mean(query, frequency):
    """Exact additive sum, accumulated with math.fsum to remove summation-order drift."""
    return math.fsum(math.sin(frequency * float(v)) for v in query)


def truth(config):
    frequency = float(config["sin_frequency_scale"])
    query = config["query"]
    if len(query) != config["dimension"]:
        raise ValueError("query length must equal dimension")
    value = conditional_mean(query, frequency)
    # Exactly evaluated closed form; 1e-12 is a conservative bound on d-term round-off,
    # not a quadrature error estimate.
    return {"value": value, "estimated_error": 1e-12,
            "method": "Closed-form additive evaluation m(x0)=sum_alpha sin(pi*x0_alpha/2.5); exact, no quadrature",
            "error_interpretation": "Conservative floating-point round-off bound over 30 sinusoid terms; not a Monte Carlo or quadrature error estimate.",
            "target": "m(x0) = E[Y | X = x0]"}
