"""Independent link arithmetic, source design, conditional integration and observed wiring."""
import copy
import importlib.util
import math
from pathlib import Path


def _module(name):
    spec=importlib.util.spec_from_file_location('liang_checked_'+name,Path(__file__).with_name(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def _sine_series(x):
    """Independent Taylor arithmetic after argument reduction."""
    y=math.remainder(x,2*math.pi)
    if y>math.pi/2:y=math.pi-y
    elif y<-math.pi/2:y=-math.pi-y
    term=total=y
    for j in range(1,41):
        term*=-y*y/((2*j)*(2*j+1));total+=term
        if abs(term)<1e-19:break
    return total


def _cos_mean(config,z,x):
    t=sum(float(w)*float(v) for w,v in zip(config['index_weights'],z))
    a,b=float(config['a']),float(config['b'])
    return math.cos(math.pi*(t-(a+b)/2)/(b-a))+float(config['beta'])*x


def _gaussian_mean(mean,sigma,steps):
    # Integrate over [-9,9]; omitted Gaussian probability is <3e-19.
    left,right=-9.,9.;h=(right-left)/steps
    def f(e):return (mean+sigma*e)*math.exp(-e*e/2)/math.sqrt(2*math.pi)
    total=f(left)+f(right)
    for j in range(1,steps):total+=(4 if j%2 else 2)*f(left+j*h)
    return total*h/3


def verify(config):
    g,t=_module('generator'),_module('truth')
    q=config['query_z'];x=float(config['query_x'])
    a,b=float(config['a']),float(config['b']);beta=float(config['beta']);sigma=float(config['sigma'])
    index=sum(float(w)*float(v) for w,v in zip(config['index_weights'],q))
    reference=t.truth(copy.deepcopy(config))['value']
    cosine=_cos_mean(config,q,x)
    series=_sine_series(math.pi*(index-a)/(b-a))+beta*x
    anchors=[_sine_series(0.),_sine_series(math.pi),_sine_series(math.pi/2)]
    alternate=copy.deepcopy(config);alternate['query_x']=1-x
    shift=t.truth(alternate)['value']-reference
    coarse=_gaussian_mean(cosine,sigma,1600);fine=_gaussian_mean(cosine,sigma,3200)
    n=8192;rows=g.generate(copy.deepcopy(config),n,20100831)
    expected_x=[float(i%2) for i in range(n)]
    indices=[sum(float(w)*rows['Z'+str(j+1)][i] for j,w in enumerate(config['index_weights'])) for i in range(n)]
    residuals=[(rows['Y'][i]-_cos_mean(config,[rows['Z1'][i],rows['Z2'][i],rows['Z3'][i]],rows['X'][i]))/sigma for i in range(n)]
    residual_mean=sum(residuals)/n;residual_second=sum(e*e for e in residuals)/n
    z_stats=[(sum(rows['Z'+str(j)])/n,sum(v*v for v in rows['Z'+str(j)])/n) for j in range(1,4)]
    other=g.generate(copy.deepcopy(config),n,20100832)
    outside=sum(v<a or v>b for v in indices)
    constants=(sigma==.1 and beta==.3 and a==.3912 and b==1.3409
               and len(config['index_weights'])==3 and all(abs(float(w)-1/math.sqrt(3))<1e-15 for w in config['index_weights']))
    checks=[
        {'name':'source_constants_original','passed':constants,'details':'Example 4.1 / model (4.2), PDF p10: source uniforms, fixed alternating X, exact index division by sqrt(3), beta=.3, a=.3912, b=1.3409, noise sd=.1. Source n50/100/200 and 500 repetitions are distinct from the interface check.'},
        {'name':'independent_cosine_and_taylor','passed':max(abs(reference-cosine),abs(reference-series))<1e-11,'details':f'Public truth={reference:.17g}; independent phase-shift cosine={cosine:.17g}; Taylor sine={series:.17g}. No _link helper imported.'},
        {'name':'analytic_anchors','passed':abs(anchors[0])<1e-14 and abs(anchors[1])<1e-14 and abs(anchors[2]-1)<1e-14,'details':'eta(a)=eta(b)=0, eta((a+b)/2)=1. These are function anchors, not truncation/support restrictions.'},
        {'name':'linear_component_shift','passed':abs(shift-beta*(1-2*x))<1e-12,'details':f'Public truth calls at flipped X differ by {shift:.17g}; expected {beta*(1-2*x):.17g}. This is structural consistency, not independent arithmetic.'},
        {'name':'conditional_gaussian_integral','passed':abs(fine-reference)<1e-11 and abs(fine-coarse)<1e-11,'details':f'Independent Simpson Gaussian integration [-9,9], 1600/3200 intervals: {coarse:.17g}/{fine:.17g}; refinement gap {abs(fine-coarse):.3g}. Numerical agreement diagnostic, not a rigorous uniform error certificate.'},
        {'name':'source_fixed_parity_design','passed':rows['X']==expected_x and other['X']==expected_x,'details':'1-based odd rows X=0, even rows X=1; exact for n8192 and two seeds. X is deterministic; rows are independent but not identically distributed. No index column is needed to preserve list order.'},
        {'name':'actual_generator_mean_and_noise','passed':set(rows)=={'Z1','Z2','Z3','X','Y'} and abs(residual_mean)<6/math.sqrt(n) and abs(residual_second-1)<6*math.sqrt(2/n) and all(abs(m-.5)<6/math.sqrt(12*n) and abs(s-1/3)<6/math.sqrt(n) for m,s in z_stats),'details':f'Actual generate n8192 seed20100831; independent cosine residual mean={residual_mean:.8g}, second moment={residual_second:.8g}; scale .1 applied exactly once. Uniform Z moments and five observed columns checked.'},
        {'name':'full_index_support_not_truncated','passed':min(indices)>=0 and max(indices)<=math.sqrt(3)+1e-15 and outside>0,'details':f'Generated index min/max={min(indices):.8g}/{max(indices):.8g}; {outside}/{n} values outside [a,b]. The source formula applies on [0,sqrt(3)]; no invented domain clipping.'},
    ]
    return {'passed':all(c['passed'] for c in checks),'checks':checks,
            'shared_components':'Public truth is the tested value; flipped-query calls are consistency checks, and generate supplies tested observations. Independent cosine/Taylor/Simpson/residual code does not call source _link helpers. Scientific premises remain the shared paper equation and parameters.',
            'limits':'No estimator, bootstrap, interval/band coverage, online CI or named human acceptance is claimed.'}
