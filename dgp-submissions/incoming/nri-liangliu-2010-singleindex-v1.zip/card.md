# N08 部分线性单指数模型的点态条件均值

Contribution: `nri-liangliu-2010-singleindex-v1` · `synthetic_dgp` · `nonparametric_regression` · **v1**

## Source and reconstruction

Liang, H., Liu, X., Li, R. and Tsai, C.-L. (2010). Estimation and testing for partially linear single-index models. The Annals of Statistics 38(6), 3811-3836. DOI: 10.1214/10-AOS835.

[DOI](https://doi.org/10.1214/10-AOS835) · [固定阅读版本 1211.3509v1](https://arxiv.org/pdf/1211.3509v1)

实读 PDF SHA-256：`bd991194930e91106801686844f5e9f6744ec644f32a1758133b99d7141955ad`。IMS electronic reprint of the published article; the actual first-page declaration says pagination and typographic detail differ from the original.

Formula bodies: (2.1) on PDF p.3, (4.2) on PDF p.10. Section starts: Section 2 on PDF p.3, Section 2.1 on PDF p.3, Section 4 on PDF p.10, Section Example4.1 on PDF p.10, Section Table2 on PDF p.11. Unnumbered paragraph on PDF p.10: "We generated 500 realizations" (Example4.1 repetition count and sample-size grid). Unnumbered paragraph on PDF p.10: "where z1,z2,z3 are independent" (covariate laws, odd/even X, epsilon distribution, a,b and resulting alpha,beta). All PDF pages are 1-based pages of the fixed reading file 1211.3509v1. No printed journal page is inferred by adding an offset.

**原文参数逐页登记**

- PDF p.3：general PLSIM(2.1):Y=eta(Z^T alpha)+X^T beta+epsilon; epsilon mean0 finite variance independent of covariates; ||alpha||2=1,alpha1>0。
- PDF p.10：Example4.1 second model(4.2), not high-dimensional Example4.2; 500 realizations; n50,100,200; Z1,Z2,Z3 mutually independent Uniform[0,1]; X_i=0 if 1-based i odd, X_i=1 if i even; epsilon standard normal; coefficient .1 => error sd.1 and variance.01; a=.3912,b=1.3409 are affine sine-transform constants, with no truncation or restricted-domain statement; exact index=(z1+z2+z3)/sqrt3; alpha=(1,1,1)/sqrt3, displayed four-place .5774; beta=.3; m(z,x)=sin(((z1+z2+z3)/sqrt3-a)*pi/(b-a))+.3*x。
- PDF p.11：Table2 reports Example4.1 model4.2 parameter estimator accuracy; a separate high-dimensional Example4.2 starts on this page。

**按实际执行顺序的生成步骤**

1. **Continuous design** — For each row i=1..n, independently draw Z_i1,Z_i2,Z_i3 iid Uniform(0,1). Three independent source uniforms; no truncation of the resulting index.
2. **Fixed binary design** — Set X_i=0 for odd i, X_i=1 for even i (1-based row index). Deterministic source design; no Bernoulli random draw, no added index column, no new noise.
3. **Single index** — t_i=(Z_i1+Z_i2+Z_i3)/sqrt(3), with 0<=t_i<=sqrt(3). Weights 1/sqrt(3), stored as their finite JSON approximations; 0.5774 is only a four-decimal display.
4. **Mean function** — m_i=sin(pi*(t_i-0.3912)/(1.3409-0.3912))+0.3*X_i. Deterministic; a,b are phase/scale constants, not truncation limits. Sine can be negative outside [a,b].
5. **Innovation** — epsilon_i iid N(0,1), independent of all design uniforms. Source multiplier 0.1 gives noise sd=0.1 and variance=0.01; it is applied once.
6. **Response and export** — Y_i=m_i+0.1*epsilon_i; export Z1,Z2,Z3,X,Y in row order. No index t, noiseless mean or noise column is returned.

**抽样单位与依赖**：one independent observed row (Z1,Z2,Z3,X,Y), preserving 1-based row order；Independent rows with deterministic alternating X: odd rows 0, even rows 1. They are not identically distributed. Z draws and errors are independent across rows; there is no cluster/Markov dependence.

**边界与尺度**：The full generated index support is [0,sqrt(3)], and the sine formula is used over that entire support. No clipping/rejection at a=0.3912 or b=1.3409. All registered Z queries lie in [0,1]^3, X is 0/1, and the selected queries happen to have t in [a,b]; that does not restrict the generator domain. Fixed X alternation is represented by the existing numeric column and row order.

**与来源的改动及理由**

1. Retain model (4.2), independent U(0,1) Z coordinates, source 1-based fixed odd/even X=0/1, exact index formula (Z1+Z2+Z3)/sqrt(3), beta=.3, a=.3912, b=1.3409 and error sd=.1. Weights are stored as finite JSON approximations to 1/sqrt(3); .5774 in the source is its four-decimal display.
2. Select four fixed complete queries (Z1,Z2,Z3,X) and target their scalar conditional response means. These queries are contribution choices, not source experiment parameters.
3. Use the requested interface row count rather than only source n=50/100/200. Preserve alternating X in numeric list order; a separate index column is unnecessary. Source 500 estimator repetitions, profile least squares, SCAD and tests are not executed.

固定点目标由已声明条件响应律识别：高斯模型使用零条件均值的误差/随机效应，广义回归直接用指定分布的链接均值。接口 n 和查询为适配；未把 n=128 说成论文原实验样本量。

**版本关系**：The actual fixed reading PDF is an IMS electronic reprint of the published article, not a separate author-preprint draft merely because it is hosted on arXiv. The first-page declaration explicitly notes pagination and typographic differences. We use only verified section/equation/1-based PDF locators and do not claim identical publisher typesetting, exact printed-page offsets or entire-text identity. No separate author-preprint-to-formal substitution is involved for this reading source; that conditional comparison is N/A.

## Target and identification

`eta(z0'alpha) + x0*beta = E[Y | Z = z0, X = x0]`

The scalar conditional mean at the scenario's fixed covariate query (z0, x0). The nonparametric component is evaluated at the single-index value t0 = z0'alpha with alpha = (1,1,1)/sqrt(3); the linear component contributes x0*beta. This is a pointwise target, not a curve-level or band target.

**登记场景与查询**

| Scenario | Parameters / query |
|:--|:--|
| `index-mid-x0`（默认） | `{"sigma": 0.1, "beta": 0.3, "a": 0.3912, "b": 1.3409, "index_weights": [0.5773502691896258, 0.5773502691896258, 0.5773502691896258], "query_z": [0.2, 0.5, 0.9], "query_x": 0}` |
| `index-mid-x1` | `{"sigma": 0.1, "beta": 0.3, "a": 0.3912, "b": 1.3409, "index_weights": [0.5773502691896258, 0.5773502691896258, 0.5773502691896258], "query_z": [0.2, 0.5, 0.9], "query_x": 1}` |
| `index-low-x0` | `{"sigma": 0.1, "beta": 0.3, "a": 0.3912, "b": 1.3409, "index_weights": [0.5773502691896258, 0.5773502691896258, 0.5773502691896258], "query_z": [0.3, 0.4, 0.5], "query_x": 0}` |
| `index-high-x1` | `{"sigma": 0.1, "beta": 0.3, "a": 0.3912, "b": 1.3409, "index_weights": [0.5773502691896258, 0.5773502691896258, 0.5773502691896258], "query_z": [0.68, 0.75, 0.8], "query_x": 1}` |

场景中的 original-* 表示保留的来源生成参数，不代表新增查询和接口样本量属于原文实验。index-* 为原模型参数下自选查询；不复制同义场景充数。

**抽样、设计与支持条件**

- For each row, Z1,Z2,Z3 are independent Uniform(0,1); uniforms and zero-mean Gaussian errors are independent across rows.
- X is fixed by the 1-based row index: odd rows 0, even rows 1. Rows are independent but not identically distributed; no stochastic Bernoulli design or causal treatment assignment is introduced.
- With fixed design X, the common regression function is m(z,x)=sin(pi*((z1+z2+z3)/sqrt(3)-a)/(b-a))+beta*x. Independent centred errors identify this function in both X groups.
- The source formula uses the full index support [0,sqrt(3)]; a=.3912 and b=1.3409 are phase/scale constants, not clipping, truncation or domain limits.
- Complete queries fix Z1,Z2,Z3 and X in config. All queries have valid Z in [0,1]^3 and binary X. The n>=2 interface check has both fixed X levels; this is pointwise mean verification, not a confidence-band result.

固定点条件均值正确，不等于点态区间或同时置信带覆盖率达标。非因果任务不套用干预/无混杂假设。

## Truth and independent verification

Closed-form evaluation of sin((t0-a)*pi/(b-a)) with t0 = z0'alpha plus x0*beta at the fixed query.

`truth.tolerance=1e-08`。estimated_error 是浮点/数值路线诊断，不是严格统一误差界或统计标准误；其非负且不大于 tolerance。

**不同路线与解析特例**：独立余弦移相与 Taylor 正弦路线、Gaussian Simpson 条件积分、端点/中点解析锚点、线性分量差值；另直接调用 generate 重构实际残差，核对奇偶 X 和区间外索引，避免只验证 truth 而遗漏生成律。

**实际共享函数与独立边界**：verify 读取 truth.truth 作为被比对象，改变 query_x 的两次公开 truth 调用属于结构一致性检查；调用 generator.generate 获取被测实际表。参照均值用独立余弦移相与 Taylor 级数，不调用 generator/truth 的 _link；噪声积分及残差重构独立实现。共享科学前提为原文公式/参数。

外部另按论文公式用 mpmath 70 位重算全部登记查询；另对各场景 generate(n=4096, seed=7312026) 实际观察列独立重构残差，不导入私有均值助手或 verify 作外部参照。N08 的源数学参照取精确 1/sqrt(3)，与配置中最短十进制权重的浮点差计入比较；阈值仍逐包取 tolerance，不靠放宽阈值通过。

## Diversity and scope

`dimension=4`，`effective_dimension=4`。Four observed input covariates Z1,Z2,Z3,X all affect the full conditional mean; dimension=effective_dimension=4 as the student guide defines active covariates. The continuous nonparametric component has one structural index, a separate notion from the number of active covariates. With k=pi/(b-a), mixed derivatives across distinct Z coordinates are -k^2*w_j*w_l*sin(k*(t-a)), generally nonzero, so the mean has nonadditive Z-Z interactions. X enters only as beta*X, with no X-Z interaction. d=4 is small relative to source n50/100/200. The index t is not an exported column.

Four observed input covariates (Z1,Z2,Z3,X), all active in the complete mean, hence dimension=effective_dimension=4 under the guide. The continuous nonlinear part depends on one index; this structural dimension is a separate concept. For j!=l among three Z, the mixed second derivative is generally nonzero. X enters linearly/additively with no X-Z interaction. Source n=50,100,200 and 500 repetitions are not reproduced by the n=128 interface check.

处理分配、标注、缺失与真实数据分支均不适用。未执行论文估计器、bootstrap、点态/同时覆盖率、PFN 训练、大规模压力测试或第二人独立人工复现。

## Rights and assistance

Source equations are cited and independently implemented. Paper copyright is not transferred; no paper PDF, author software, original participant data or model weights are redistributed. No external author code was used. The contributor must confirm the release licence for the independently implemented code before publication; pending review is not a grant of rights. AI assisted equation extraction, implementation, numerical checks and drafting; named human scientific review and independent-person reproduction are not claimed.

**未使用作者原始代码或补充材料代码**；因此作者软件 commit 追溯项 N/A。本包依赖以 requirements.txt 为准：标准库或 NumPy 的使用不等于移植作者代码。论文全文、页图、作者软件、权重、数据银行、凭据不随贡献包分发。

**missing / 尚待确认**

- 当前已声明生成律不存在未给定的必要数值参数；这不等于作者算法、许可或科学接收已获确认。
- 本人须审核 AI 协助的来源提取、代码、数值和文本，并确认独立实现代码的发布许可；pending 不是授权。
- 具名科学审核、第二人独立人工复现：未执行。
- GitHub Fork/Sync/SUBMIT DGP/Actions/PR/收录确认：本次未执行。本地 submit 不等于网络提交或项目收件。

**状态**：以最终 checks/report.json 记录本地 runnable_dgp；归档仅 awaiting_scientific_review、scientific_acceptance=false。
