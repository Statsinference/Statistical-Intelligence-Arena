"""Closed-form pointwise conditional mean for the declared single-index law."""
import math


def _link(t, lower, upper):
    return math.sin((t - lower) * math.pi / (upper - lower))


def truth(config):
    lower = float(config["a"])
    upper = float(config["b"])
    if not (math.isfinite(lower) and math.isfinite(upper) and lower < upper):
        raise ValueError("a and b must be finite with a < b")
    weights = [float(w) for w in config["index_weights"]]
    query = [float(v) for v in config["query_z"]]
    if len(weights) != 3 or len(query) != 3:
        raise ValueError("index_weights and query_z must each have three entries")
    if not all(0.0 <= v <= 1.0 for v in query):
        raise ValueError("query_z must lie in [0,1]^3")
    query_x = float(config["query_x"])
    if query_x not in (0.0, 1.0):
        raise ValueError("query_x must be 0 or 1")
    t0 = weights[0] * query[0] + weights[1] * query[1] + weights[2] * query[2]
    value = _link(t0, lower, upper) + float(config["beta"]) * query_x
    return {
        "value": value,
        "estimated_error": 1e-12,
        "method": "Closed-form sine link at the single-index value plus the linear component",
        "target": "eta(query_z'alpha) + query_x*beta = E[Y | Z=query_z, X=query_x]",
    }
