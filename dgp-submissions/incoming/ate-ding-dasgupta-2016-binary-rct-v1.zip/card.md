# Ding–Dasgupta binary potential-outcome RCT: finite-population ATE

**Status:** runnable candidate; awaiting scientific review.

## Source and exact scope

Ding, P. and Dasgupta, T. (2016), “A Potential Tale of Two-by-Two Tables From Completely Randomized Experiments,” *Journal of the American Statistical Association* 111(513), 157–168, DOI 10.1080/01621459.2014.995796. The actually read version is arXiv:1501.02389v1 (2015-01-10), 39-page PDF. Target source sections: Section 2.1–2.2 (PDF pp. 4–5) and Section 6, Table 5 (PDF pp. 18–19).

The source describes a fixed finite population with binary potential outcomes and a completely randomized treatment assignment. For Table 5, the four cell counts are ordered as `(N11,N10,N01,N00)` for `(Y(1),Y(0))=(1,1),(1,0),(0,1),(0,0)`. Cases 1–12 are encoded as separate scenarios. The source's main-text Table 5 includes `N=200`; the 12 source count configurations are in `config.json`.

The ATE definition in Section 2.1 is unnumbered prose/equation: `tau = N^{-1} sum_i (Y_i(1)-Y_i(0)) = (N10-N01)/N`. Equation (1) nearby is a variance expression, not the ATE definition. Treatment assignment is complete randomization with fixed treated/control totals; the observed outcome is `Y_i=A_iY_i(1)+(1-A_i)Y_i(0)`. No baseline covariates, continuous noise, or regression model are introduced.

## Explicit adaptations and unresolved source details

1. **User-approved 1:1 assumption:** set `N1=N0=100` in each `N=200` scenario. The inspected source text does not verify that Table 5 uses this allocation. This is an adaptation, not an original-paper parameter.
2. **Required function interface adaptation:** `generate(config,n,seed)` samples `n` units without replacement from the fixed N=200 schedule, then assigns exactly `n/2` to treatment and the rest to control by complete randomization. The source's fixed-population randomization is not described as this extra SRS sample stage. This two-stage interface allows the prescribed `n=128` smoke test while retaining the source finite-population target. `n` must be even.
3. Only main-text Table 5 Cases 1–12 are included. Supplementary Appendix E Cases 13–19 are not included in this contribution.
4. Publisher full text was inaccessible during source audit. Final-version PDF page and equation-number mapping, any final-version changes, and a code repository/commit remain unverified.

## Generation order

1. Fix a finite population of `N=200` units. Its potential outcomes are fixed, binary attributes; there is no random error term.
2. Assign the four potential-outcome types in the configured counts: `N11,N10,N01,N00`, summing to 200. The joint potential-outcome association is induced by these cell counts; the table is the complete dependence specification.
3. Implementation adaptation: draw `n` units by simple random sampling without replacement from the finite population.
4. Implementation/user allocation assumption: uniformly choose `n/2` of the sampled units for `A=1`; set the rest to `A=0`. This is complete randomization on the sampled subset, with negative dependence among assignment indicators.
5. Reveal only `Y=A*Y(1)+(1-A)*Y(0)`. `generate` returns only observed columns `A,Y`; potential outcomes and cell membership are never returned.

There are no covariates, interactions, nonlinear regression terms, or additive noise. Sampling unit is an individual experimental unit. There is no interference; cross-unit assignment dependence arises from the fixed treatment total.

## Estimand, assumptions, and truth

Target: finite-population ATE / causal risk difference for intervention `A=1` versus `A=0`, `tau=N^{-1}sum_i[Y_i(1)-Y_i(0)]`. Under the four-cell table, `tau=(N10-N01)/N`. The truth is exact rational arithmetic from fixed counts; `estimated_error=0`. This is not NIE, NDE, or a mediation functional.

Design-based interpretation assumes consistency, well-defined treatment, SUTVA/no interference, and complete randomization. The finite population and potential outcomes are fixed. No observational no-unmeasured-confounding assumption is invoked. The extra SRS stage is solely an implementation adaptation for the required variable-n smoke interface.

`verify.py` independently checks the four-cell partition, computes the risk difference as the difference of the two potential-outcome marginal risks, compares it with the discordant-cell identity, and checks the zero-effect special case `N10=N01`. This is an independent algebraic route, but not an independent human reproduction or proof of the paper's scientific claims.

## Rights, review, and assistance

No source PDF, original author code, restricted data, credentials, model weights, or PFN assets are included. Code was independently written for this collection. Paper rights remain with the publisher/authors; maintainers must review redistribution/quotation and the compact table transcription. AI assistance was used for source extraction, implementation, and local diagnostics. No named scientific review has occurred.
