"""Exact finite-population ATE calculation."""
def truth(config):
    N = int(config["N"])
    n10, n01 = int(config["N10"]), int(config["N01"])
    if N <= 0 or sum(int(config[k]) for k in ("N11", "N10", "N01", "N00")) != N:
        raise ValueError("Invalid finite-population cell counts")
    value = (n10 - n01) / N
    return {"value": value, "estimated_error": 0.0,
            "method": "Exact finite-population cell-count identity: tau=(N10-N01)/N; no numerical approximation.",
            "target": "Finite-population ATE for intervention A=1 versus A=0."}
