"""Independent algebraic checks of the finite-population estimand."""
def verify(config):
    N = int(config["N"])
    n11, n10, n01, n00 = (int(config[k]) for k in ("N11", "N10", "N01", "N00"))
    checks = []
    total_ok = (n11 + n10 + n01 + n00 == N and min(n11,n10,n01,n00) >= 0)
    checks.append({"name":"four-cell partition sums to N with nonnegative counts", "passed":bool(total_ok),
                   "details":f"counts={(n11,n10,n01,n00)}, N={N}"})
    # Independently calculate the two potential-outcome marginal means.
    mean_y1 = (n11 + n10) / N
    mean_y0 = (n11 + n01) / N
    tau_marginal = mean_y1 - mean_y0
    tau_discordant = (n10 - n01) / N
    checks.append({"name":"ATE agrees via marginal potential-outcome risks and discordant cells",
                   "passed":abs(tau_marginal-tau_discordant) <= 1e-15,
                   "details":f"risk difference={tau_marginal:.16g}; discordant-cell contrast={tau_discordant:.16g}"})
    # A null-effect special case: equal numbers of the two discordant types.
    zero_case = (n10 == n01)
    checks.append({"name":"zero-effect special case when N10 equals N01",
                   "passed":(not zero_case) or abs(tau_marginal) <= 1e-15,
                   "details":f"N10={n10}, N01={n01}, ATE={tau_marginal:.16g}"})
    return {"passed":all(c["passed"] for c in checks), "checks":checks}
