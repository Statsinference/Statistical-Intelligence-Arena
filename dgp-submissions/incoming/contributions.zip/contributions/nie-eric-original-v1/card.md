# NIE collection example: Section 3 mediation DGP

**Collection example; named scientific acceptance is pending. No PFN is trained or evaluated here.**

Source: Tchetgen Tchetgen and Shpitser (2012), *The Annals of Statistics* 40(3), 1816–1845, DOI [10.1214/12-AOS990](https://doi.org/10.1214/12-AOS990). [Electronic reprint](https://arxiv.org/abs/1210.4654), Section 3, PDF p.13, Model.X/E/M/Y. The natural indirect effect is defined in equation (1), PDF p.2.

## Source fidelity and adaptation

The six observed columns are `[X1,X2,X3,A,M,Y]`. Rename source exposure `E` to `A`. Keep all Section 3 observed-data equations and parameters unchanged. The source simulation concerns natural **direct** effects; this example changes the target to the **NIE**, explicitly:

`theta_aa' = E[Y(a,M(a'))]`, `theta_NIE = theta_11 - theta_10`.

Both outcome interventions use A=1. The mediator distribution changes from A=0 to A=1. This is not theta_10 alone, an ATE, or a comparison between two independently fitted mediation functionals.

## Original equations

1. X1 ~ Bernoulli(.4).
2. X2 | X1 ~ Bernoulli(.3 + .4 X1).
3. X3 | X1,X2 ~ Normal(-.024 - .4 X1 + .4 X2, 1).
4. logit P(A=1|X) = .4 + X1 - X2 + .1 X3 - 1.5 X1 X3.
5. logit P(M=1|A,X) = .5 - X1 + .5 X2 - .9 X3 - 1.5 X1 X3 + A.
6. Y = 1 + .2 X1 + .3 X2 + 1.4 X3 - 2.5 A - 3.5 M + 5 A M + epsilon; epsilon ~ Normal(0,1), independently.

Sampling unit: independent individuals. There is no interference or clustering. The high-dimensional tag is **false**: there are only three baseline covariates. Interactions are present in X1*X3 and A*M. The nonlinear tag refers to logistic links; the continuous outcome mean is linear in its specified features.

## Identification and population truth

The intended interpretation requires consistency, treatment and mediator exchangeability, the required cross-world condition, no treatment-induced mediator–outcome confounder, and positivity. These are scientific assumptions, not conclusions from machine checks. Positivity holds pointwise for finite Gaussian covariates, but there is no claimed uniform overlap bound on the unbounded covariate support.

Let q_a(x) be the mediator probability and b=beta_M+beta_AM=1.5. Then

`NIE = b * E_X[q_1(X) - q_0(X)] = 0.2366199013...`.

The oracle enumerates X1/X2 and integrates conditional Gaussian X3 by Gauss–Hermite quadrature. The verifier uses separately implemented composite Simpson integration, checks order refinement, and checks two zero-path special cases. Its numerical error estimate is not a theorem about all configurations. Both implementations necessarily share the declared DGP, so source reconstruction and independent-person reproduction remain separate review tasks.

## Data, scope and rights

`generator.py` returns observed variables only; population truth is a separate file/function. No latent, counterfactual, EIF or oracle column is returned as a learner input. `config.json` contains one original fixed scenario, not a hyperdistribution. Repeated seeds or parameters do not create additional mechanism families.

This is an independently written reconstruction, not a redistribution of the paper PDF or the authors' software. Paper copyright belongs to IMS; source redistribution/attribution rights and final scientific review remain pending. Source equations have been checked against the local electronic reprint, but no named human acceptance is claimed.

No classical estimator, bootstrap, foundation-model training or formal CI coverage is required to complete this collection check. Those remain later benchmark work.

## 本次规范归档说明（2026-10-23）

本贡献来自现有学生包示例，保留贡献 ID、mechanism_family_id、四个科学文件及观察 schema。仅新增来源版本/哈希、示例归档溯源、环境、认领状态与中文报告。不把它当作新机制，也不把示例的检查记录直接当作本次结果；本次重新运行 n=128、seed=1729 并在 ZIP 解包后复跑。

原论文 §3 研究 NDE，本包目标为 NIE=E[Y(1,M(1))−Y(1,M(0))]。生成器使用 Python 标准库 random.Random，不是本批其他贡献使用的 NumPy PCG64；NumPy 只用于数值积分。科学代码沿用学生包，不声称是本次重新原创实现。原 examples 文件夹保持不变。
