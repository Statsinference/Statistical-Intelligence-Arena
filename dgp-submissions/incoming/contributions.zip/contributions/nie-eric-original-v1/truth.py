"""Population NIE; integrate the law, never estimate truth from generated rows."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss


def _integrate(config, order):
    z, weights = hermgauss(order)
    weights = weights / math.sqrt(math.pi)
    c = config["mediator_coefficients"]
    gamma = config["mediator_treatment_coefficient"]
    yc = config["outcome_coefficients"]
    b = yc[5] + yc[6]
    total = 0.0
    for x1 in (0, 1):
        p1 = config["x1_probability"] if x1 else 1 - config["x1_probability"]
        p2 = config["x2_coefficients"][0] + config["x2_coefficients"][1] * x1
        for x2 in (0, 1):
            prob = p1 * (p2 if x2 else 1 - p2)
            xc = config["x3_coefficients"]
            x3 = xc[0] + xc[1] * x1 + xc[2] * x2 + math.sqrt(2) * config["x3_sd"] * z
            l0 = c[0] + c[1] * x1 + c[2] * x2 + c[3] * x3 + c[4] * x1 * x3
            q0 = np.exp(-np.logaddexp(0.0, -l0))
            q1 = np.exp(-np.logaddexp(0.0, -(l0 + gamma)))
            total += prob * float(weights @ (b * (q1 - q0)))
    return float(total)


def truth(config):
    low, high = _integrate(config, 64), _integrate(config, 128)
    return {"value": high, "estimated_error": abs(high - low) + 1e-14,
            "method": "X1/X2 enumeration and Gauss-Hermite orders64/128",
            "error_interpretation": "Observed quadrature convergence estimate, not a rigorous uniform error bound.",
            "target": "theta_NIE = theta_11 - theta_10"}
