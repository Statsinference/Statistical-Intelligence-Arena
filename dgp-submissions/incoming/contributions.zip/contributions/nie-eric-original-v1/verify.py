"""Separate Simpson integration + source fixtures + null-path special cases."""
from copy import deepcopy
import math
from pathlib import Path
import importlib.util


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("nie_collection_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _simpson(config, steps):
    # Independent code/abscissae and tanh logistic; shares the declared mechanism.
    # Integrate standard Gaussian z in [-10,10]. Truncation is bounded below.
    total = 0.0
    h = 20.0 / steps
    for x1 in (0, 1):
        p1 = config["x1_probability"] if x1 else 1 - config["x1_probability"]
        p2 = config["x2_coefficients"][0] + config["x2_coefficients"][1] * x1
        for x2 in (0, 1):
            c, xc = config["mediator_coefficients"], config["x3_coefficients"]
            mu = xc[0] + xc[1] * x1 + xc[2] * x2
            integral = 0.0
            for j in range(steps + 1):
                z = -10.0 + j * h
                x3 = mu + config["x3_sd"] * z
                l0 = c[0] + c[1] * x1 + c[2] * x2 + c[3] * x3 + c[4] * x1 * x3
                change = 0.5 * (math.tanh((l0 + config["mediator_treatment_coefficient"]) / 2)
                                - math.tanh(l0 / 2))
                weight = 1 if j in (0, steps) else (4 if j % 2 else 2)
                integral += weight * change * math.exp(-z * z / 2) / math.sqrt(2 * math.pi)
            total += p1 * (p2 if x2 else 1 - p2) * h * integral / 3
    yc = config["outcome_coefficients"]
    return total * (yc[5] + yc[6])


def verify(config):
    oracle = _module("truth.py")
    fixture = {"x1_probability": .4, "x2_coefficients": [.3, .4],
               "x3_coefficients": [-.024, -.4, .4], "x3_sd": 1.,
               "treatment_coefficients": [.4, 1., -1., .1, -1.5],
               "mediator_coefficients": [.5, -1., .5, -.9, -1.5],
               "mediator_treatment_coefficient": 1.,
               "outcome_coefficients": [1., .2, .3, 1.4, -2.5, -3.5, 5.],
               "outcome_noise_sd": 1.}
    reference, estimated = oracle.truth(config), _simpson(config, 4096)
    coarse = _simpson(config, 2048)
    no_a = deepcopy(config); no_a["mediator_treatment_coefficient"] = 0.0
    no_m = deepcopy(config); no_m["outcome_coefficients"][6] = -no_m["outcome_coefficients"][5]
    checks = [
        {"name": "source_constants_original", "passed": config == fixture,
         "details": "Original Section3 Model.X/E/M/Y coefficients, including both X1*X3 and A*M interactions; NIE target is a declared adaptation."},
        {"name": "independent_population_integration", "passed": abs(reference["value"] - estimated) < 1e-9,
         "details": f"Gauss-Hermite={reference['value']:.14g}; independent Simpson={estimated:.14g}; difference={abs(reference['value']-estimated):.3g}."},
        {"name": "integration_convergence", "passed": reference["estimated_error"] < 1e-9 and abs(estimated - coarse) < 1e-9,
         "details": f"GH64/128 error estimate={reference['estimated_error']:.3g}; Simpson2048/4096 difference={abs(estimated-coarse):.3g}; not a rigorous quadrature error bound."},
        {"name": "derived_original_anchor", "passed": abs(reference["value"] - .2366199013) < 1e-9,
         "details": "NIE=.2366199013 is derived for this adaptation, not a source-paper reported NDE result."},
        {"name": "zero_treatment_to_mediator_path", "passed": abs(oracle.truth(no_a)["value"]) < 1e-12,
         "details": "Setting the treatment coefficient in M to zero gives NIE=0."},
        {"name": "zero_treated_mediator_contrast", "passed": abs(oracle.truth(no_m)["value"]) < 1e-12,
         "details": "Setting beta_M+beta_AM=0 gives NIE=0."}
    ]
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "shared_components": "Both implementations share the documented scientific equations and config, not quadrature nodes or integration implementation; source fixtures are reconstructed and still need named scientific review.",
            "gaussian_truncation_bound": abs(config["outcome_coefficients"][5] + config["outcome_coefficients"][6]) * math.erfc(10 / math.sqrt(2))}
