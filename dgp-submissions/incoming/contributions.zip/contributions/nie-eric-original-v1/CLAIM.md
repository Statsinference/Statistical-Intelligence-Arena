# 既有示例归档

本条从学生包 examples/dgp_collection/nie-eric-original-v1 规范归档，保留原 ID 与机制 family；不是新发现的 DGP，不应在机制库中与原示例重复计数。未联系维护人，具名审核与独立人员复现待完成。
