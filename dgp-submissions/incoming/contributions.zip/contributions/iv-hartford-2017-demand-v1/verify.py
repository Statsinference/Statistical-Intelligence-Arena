"""Independent quadrature, scalar equations, source fixtures and null controls."""
from copy import deepcopy
import math
import numpy as np
from generator import generate
from truth import truth

SOURCE = {'rho':0.8,'price_low':20.0,'price_high':21.0}

def _integrate(config, order):
    q,w = np.polynomial.legendre.leggauss(order)
    t = 5*(q+1)
    # Separate expression and both intervention means; no truth closed form used.
    psi = ((t-5)**4)/300 + 2*np.exp(-((t-5)/0.5)**2) + t/5 - 4
    means = []
    for p in (config['price_low'], config['price_high']):
        terms = []
        for s in range(1,8):
            mu = 100 + 10*s*psi + p*(s*psi-2)
            terms.append(float(w @ mu)/14)
        means.append(math.fsum(terms))
    return {'order':order,'low_mean':means[0],'high_mean':means[1],'contrast':means[1]-means[0]}

def verify(config):
    original=deepcopy(config); target=truth(config)['value']
    results=[_integrate(config,n) for n in (64,128)]
    quadrature_error=max(abs(r['contrast']-target) for r in results)
    checks=[{'name':'independent_intervention_mean_quadrature','passed':quadrature_error < 1e-10,'maximum_absolute_difference':quadrature_error,'results':results},
            {'name':'source_scenario_fixture','passed':config == SOURCE,'expected':SOURCE}]
    n,seed=257,314159
    got=generate(config,n,seed)
    rng=np.random.Generator(np.random.PCG64(seed))
    t=rng.uniform(0,10,n); s=rng.integers(1,8,n)
    z=rng.standard_normal(n);v=rng.standard_normal(n);w=rng.standard_normal(n)
    p_ref=[];y_ref=[]
    for ti,si,zi,vi,wi in zip(t,s,z,v,w):
        q=2*((ti-5)**4/600+math.exp(-4*(ti-5)**2)+ti/10-2)
        pi=25+(zi+3)*q+vi
        p_ref.append(pi)
        y_ref.append(100+10*si*q+(si*q-2)*pi+config['rho']*vi+math.sqrt(1-config['rho']**2)*wi)
    err=max(float(np.max(np.abs(np.asarray(got['P'])-p_ref))),float(np.max(np.abs(np.asarray(got['Y'])-y_ref))))
    observed_match=all(np.array_equal(got[k],a) for k,a in [('T',t),('S',s),('Z',z)])
    checks.append({'name':'scalar_source_row_reconstruction','passed':observed_match and err < 2e-12,'max_absolute_error':err,'n':n,'seed':seed})
    zero={**config,'price_high':config['price_low']}; reverse={**config,'price_low':config['price_high'],'price_high':config['price_low']}
    checks.append({'name':'null_and_reverse_interventions','passed':truth(zero)['value']==0 and abs(truth(reverse)['value']+target)<1e-12 and abs(_integrate(zero,64)['contrast'])<1e-12})
    # Integrate the shared latent error independently of Z: a conditional-moment fixture.
    x,wg=np.polynomial.hermite.hermgauss(7)
    residual=math.fsum(float(wa*wb*(config['rho']*math.sqrt(2)*a+math.sqrt(1-config['rho']**2)*math.sqrt(2)*b)/math.pi) for a,wa in zip(x,wg) for b,wb in zip(x,wg))
    checks.append({'name':'conditional_mean_zero_error_quadrature','passed':abs(residual)<1e-12,'value':residual,'scope':'For every fixed T,S,Z, integrate independent V,W; does not numerically prove completeness.'})
    checks.append({'name':'endogeneity_parameter_does_not_change_structural_truth','passed':truth({**config,'rho':0.0})['value']==target})
    checks.append({'name':'config_not_mutated','passed':original==config})
    return {'passed':all(c['passed'] for c in checks),'checks':checks,'independence_note':'Quadrature and scalar equations are separately coded, while deterministic RNG family and external NumPy library are shared. Same-AI checks are not independent-person replication.'}
