"""Analytic population structural price contrast; no fitted estimates."""
import math
from generator import validate_config

def truth(config: dict) -> dict:
    validate_config(config)
    # E[S]=4; E[psi(T)]=-31/12 + sqrt(pi)*erf(10)/10.
    slope = -37/3 + 2*math.sqrt(math.pi)*math.erf(10)/5
    return {'value':(config['price_high']-config['price_low'])*slope,
            'estimated_error':0.0,'method':'Analytic integration of polynomial plus Gaussian bump; floating-point rounding is not included in approximation error.',
            'unit':'raw outcome per configured continuous price contrast'}
