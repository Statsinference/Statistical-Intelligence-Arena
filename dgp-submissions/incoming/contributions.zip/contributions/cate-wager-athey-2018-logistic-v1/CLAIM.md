# 认领与去重待办

贡献 ID：`cate-wager-athey-2018-logistic-v1`。

The two CATE contributions share the same tau(x). This mechanism has random assignment and m=0; the AoS combined mechanism instead has X3-dependent e(x) and m(x). They are distinct observed-data mechanisms with a shared signal lineage, not two independent treatment-effect functions. Final mechanism-family deduplication is pending.

尚未联系维护人；认领人、科学审核人、另一位独立复现人均未登记。此文件仅为可提交的认领草稿，不代表项目已收件或接收。AI 内部校验不能代替具名审核。
