# 固定查询点 CATE：随机处理下的平滑 logistic 乘积异质效应

## 来源与贡献边界

Wager, S. and Athey, S. (2018). Estimation and Inference of Heterogeneous Treatment Effects using Random Forests. Journal of the American Statistical Association 113(523), 1228-1242. DOI: 10.1080/01621459.2017.1319839.

固定版本：[原文](https://arxiv.org/abs/1510.04342v4)。定位：arXiv:1510.04342v4 PDF p.20, Section 5.1, common model and equation (28); p.22 Table 2 for d=6. 具体 PDF SHA-256 见 source_audit.json。论文 PDF 不放入提交包；作者程序未使用，因此不声明作者代码版本复现。

The two CATE contributions share the same tau(x). This mechanism has random assignment and m=0; the AoS combined mechanism instead has X3-dependent e(x) and m(x). They are distinct observed-data mechanisms with a shared signal lineage, not two independent treatment-effect functions. Final mechanism-family deduplication is pending.

## 完整机制与参数

独立个体，X_j 独立 Uniform(0,1)，j=1,...,6；epsilon 独立 Normal(0,1)。

```text
e(X)=0.5; A|X ~ Bernoulli(e(X))
m(X)=0
tau(X)=s(X1)*s(X2), s(u)=1+1/[1+exp(-20*(u-1/3))]
Y = m(X) + (A - 0.5) * tau(X) + epsilon
```

Beta(2,4) 在这里指密度函数 20*x*(1-x)^3，既不是 Beta 随机协变量，也不是其 CDF。m 是两臂条件均值的平均，不是混杂处理下的 E[Y|X]。源机制的 normal 噪声方差为 1。d=6 是原文已展示维度；源实验 n=5000，本次仅 n=128 做接口检查，不复现估计器实验。

只输出 X1,...,X6,A,Y；不输出倾向分数、tau、潜在结果或噪声。有效维度为 2，剩余维度为无关协变量，不宣称高维混杂。

## 目标、识别与真值

固定查询点 x*=[0.3333333333333333, 0.3333333333333333, 0.5, 0.5, 0.5, 0.5]。连续条件均值确定该点的 CATE；s(1/3)=3/2，所以真值为 9/4=2.25。接口只交付该点的标量，不能解释成已提供完整 CATE 函数估计接口。

识别依赖一致性、无干扰、条件可交换性、重叠性与完整观测。生成器的处理随机化与结果噪声独立，落实可交换性。随机机制 e=1/2；Beta 密度机制 e 的全局范围为 [1/4,199/256]。后者最大值在活动协变量=1/4 处取得。

真值解析计算，estimated_error=0 表示无数值积分或蒙特卡洛近似，并非浮点误差严格等于零。truth tolerance=1e-10；独立核验阈值 1e-12。

## 适配与验证

- Preserve the source mechanism with dimension=6, noise variance=1; rename source W as A.
- The collection interface requires a scalar. Target tau(x_star) at the fixed query [0.3333333333333333, 0.3333333333333333, 0.5, 0.5, 0.5, 0.5]; retain the full source tau(x) in the generator. This query and its value 2.25 are defined here, not a scalar result reported by the paper.
- Use Python/NumPy PCG64, row-major X, independent uniform-threshold assignment and normal noise; distributional reconstruction, not identical R random samples.
- Use n=128, seed=1729 for a CPU interface check instead of the source estimator study (source n=5000). No estimator is fitted.
- effect_scale=1 is the source mechanism; 0 and -1 only serve internal verification controls, not additional contributions.
- The source fixes marginal Gaussian potential-outcome laws but does not require a cross-world coupling. A single independent noise produces the observed law; a shared-error potential-outcome representation is only a mathematical completion, not an asserted original coupling.

固定 x* 下分别对两个处理臂的 Y 积分，用 Gauss–Hermite 5/9 阶计算 arm means，再从 Cov(A,Y|x*)/Var(A|x*) 恢复 CATE；另外核对 mu1-mu0。 独立实现用展开的 Beta 多项式与 tanh 形式计算 logistic，未调用生成器的均值函数或 truth 闭式。另以 257 行、seed=314159 逐行标量重建观察数据；检查零效应、正负效应对称、非零敏感性、均值零噪声不变性及输入不变性。CATE 还检查改变查询点只改变目标而不改变采样。

共享部分包括原文方程、配置、Python/NumPy 和同一 PCG64 抽样顺序；这是一轮 AI 辅助内部核验，不是另一位研究者独立复现。

## 复现命令

在包含 collect.py 的学生包根目录运行：

```powershell
& .\.venv\Scripts\python.exe collect.py check contributions/cate-wager-athey-2018-logistic-v1 --run --n 128 --seed 1729
& .\.venv\Scripts\python.exe collect.py pack contributions/cate-wager-athey-2018-logistic-v1 --out submissions/cate-wager-athey-2018-logistic-v1.zip
```

依赖仅 NumPy，具体检查环境见 environment.json。固定种子在记录环境中可复现；不声明与 R 随机流相同。源码有任何改动后须重检并重新打包。

## 权利、AI 与待审核事项

新写 Python 依据被引用方程实现，未打包论文 PDF 或作者源码，不替第三方授予许可；正式分发许可仍待审核。Codex 参与检索、公式核对、代码和中文说明。未虚构人工阅读证明、具名科学审核人或独立复现人。

当前为候选贡献，check 通过只意味着格式与运行检查通过。待维护人认领查重、科学审核和独立人员复现；未训练 PFN，未拟合估计器，未进行 CI coverage 或正式 benchmark 接收。
