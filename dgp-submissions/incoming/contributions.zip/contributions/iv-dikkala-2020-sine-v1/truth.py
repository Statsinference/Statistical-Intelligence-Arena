"""Population structural response contrast, in unstandardized source units."""
import math
from generator import validate_config

def truth(config: dict) -> dict:
    validate_config(config)
    return {'value':math.sin(config['treatment_high'])-math.sin(config['treatment_low']),
            'estimated_error':0.0,'method':'Analytic sin(b)-sin(a); centered latent errors have zero mean. Floating-point rounding excluded from approximation error.'}
