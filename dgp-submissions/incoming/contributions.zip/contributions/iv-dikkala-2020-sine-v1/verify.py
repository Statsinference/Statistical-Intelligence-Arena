"""Independent integral truth check, source-code scale fixtures, and row reconstruction."""
from copy import deepcopy
import math
import numpy as np
from generator import generate
from truth import truth
SOURCE={'instrument_strength':0.6,'instrument_sd':2.0,'confounder_sd':2.0,'treatment_noise_sd':0.1,'outcome_noise_sd':0.1,'treatment_low':0.0,'treatment_high':0.5}

def _integral(config,n):
    a,b=config['treatment_low'],config['treatment_high']
    step=(b-a)/n
    total=math.cos(a)+math.cos(b)
    total+=math.fsum((4 if i%2 else 2)*math.cos(a+i*step) for i in range(1,n))
    return total*step/3

def verify(config):
    before=deepcopy(config);value=truth(config)['value']
    estimates=[_integral(config,n) for n in (512,1024)]
    checks=[{'name':'independent_integral_of_cosine','passed':max(abs(x-value) for x in estimates)<1e-11,'n_intervals':[512,1024],'integrals':estimates,'max_absolute_error':max(abs(x-value) for x in estimates)},
            {'name':'source_code_scale_fixture','passed':config==SOURCE,'expected':SOURCE,'normal_parameter_convention':'All scale parameters are standard deviations, following NumPy author code.'}]
    n,seed=257,314159;got=generate(config,n,seed)
    rng=np.random.Generator(np.random.PCG64(seed))
    z=rng.normal(0,config['instrument_sd'],n);u=rng.normal(0,config['confounder_sd'],n)
    delta=rng.normal(0,config['treatment_noise_sd'],n);zeta=rng.normal(0,config['outcome_noise_sd'],n)
    a=config['instrument_strength'];p=[];y=[]
    for zi,ui,di,ei in zip(z,u,delta,zeta):
        pi=a*zi+(1-a)*ui+di;p.append(pi);y.append(math.sin(pi)+ui+ei)
    err=max(float(np.max(np.abs(np.asarray(got['P'])-p))),float(np.max(np.abs(np.asarray(got['Y'])-y))))
    checks.append({'name':'scalar_source_row_reconstruction','passed':np.array_equal(got['Z1'],z) and err<1e-12,'max_absolute_error':err,'n':n,'seed':seed})
    zero={**config,'treatment_high':config['treatment_low']};reverse={**config,'treatment_low':config['treatment_high'],'treatment_high':config['treatment_low']}
    checks.append({'name':'null_and_reverse_interventions','passed':truth(zero)['value']==0 and _integral(zero,512)==0 and abs(truth(reverse)['value']+value)<1e-12})
    nodes,weights=np.polynomial.hermite.hermgauss(7)
    residual=math.fsum(float(wi*wj*(math.sqrt(2)*config['confounder_sd']*xi+math.sqrt(2)*config['outcome_noise_sd']*xj)/math.pi) for xi,wi in zip(nodes,weights) for xj,wj in zip(nodes,weights))
    checks.append({'name':'conditional_residual_mean_zero','passed':abs(residual)<1e-12,'value':residual,'scope':'At every fixed Z, integrate U and zeta; this is a moment check, not an empirical proof of completeness.'})
    checks.append({'name':'nuisance_scales_do_not_change_structural_truth','passed':truth({**config,'instrument_strength':0.2,'outcome_noise_sd':0.3})['value']==value})
    # Gaussian first-stage relevance and confounding from separately evaluated moments.
    relevance=a*config['instrument_sd']**2
    endogeneity=(1-a)*config['confounder_sd']**2
    checks.append({'name':'source_nonzero_relevance_and_endogeneity','passed':relevance>0 and endogeneity>0,'cov_P_Z':relevance,'cov_P_structural_error':endogeneity})
    checks.append({'name':'config_not_mutated','passed':before==config})
    return {'passed':all(c['passed'] for c in checks),'checks':checks,'independence_note':'Truth uses sine evaluation, verification integrates cosine. Scalar row implementation is separately coded but shares NumPy RNG; no independent-person reproduction is claimed.'}
