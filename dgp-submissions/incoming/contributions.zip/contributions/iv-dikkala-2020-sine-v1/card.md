# Gaussian sine IV：非线性结构响应与潜在混杂

## 来源与定位
Dikkala, Lewis, Mackey & Syrgkanis (2020), *Minimax Estimation of Conditional Moment Models*, NeurIPS 33:12248–12262。
论文：https://proceedings.neurips.cc/paper/2020/hash/8fcd9e5482a62a5fa130468f4cf641ef-Abstract.html 。补充 Appendix J，印刷第 48 页（补充 PDF 第 33 页），sine 函数及 DGP；Figure 15（印刷第 50 页）给出 nx=nz=1、α=.6。
作者源码：https://github.com/microsoft/AdversarialGMM ，固定 commit `691fbe0761ee5b40dbc4e38317946a7193186af2`，`mliv/dgps.py` 53–54、154–163 行。

## 机制
相互独立生成 Z~N(0,SD=2)、U~N(0,SD=2)、δ,ζ~N(0,SD=.1)。

P=.6Z+.4U+δ；Y=sin(P)+U+ζ。

P 与结构误差 U+ζ 共享 U，因此内生；Z 只经 P 影响 Y。仅输出 Z1,P,Y。无基线协变量（dimension=0），一维工具与处理不计入基线维数；不输出 U、δ、ζ、sin(P) 或真值列。

## 明确的适配与来源差异
本贡献为 `adapted_from_source`，采用作者代码 Gaussian-location 分支、Gaussian **标准差** 2 和 .1。原文写 N(0,2)、N(0,.1)，常规读法可能是方差；代码则把 2、.1 传给 NumPy 的 scale。这里使用代码尺度，明确避免冒称方差为 2/.1 的精确复现。

作者代码还对 Y 按本次样本均值、标准差变换，并对 h0 使用同一变换。本贡献取消这一步，保留原始结构单位，使总体真值不依赖样本、iid 接口不受共同样本统计量影响。PCG64 与源码全局随机流不同。只做小样本核验，不训练 AGMM 或比较估计器。

## 目标与真值
θ=E[Y(do(P=.5))−Y(do(P=0))]=h0(.5)−h0(0)=sin(.5)≈0.479425538604203。

这是固定连续处理干预的结构对比，不是二元 ATE，不是观察条件回归差异。因 E[U]=E[ζ]=0，真值与工具强度和噪声方差无关。解析近似误差 0 不包含浮点舍入。

## 识别与核验
假设 iid、无干扰、一致性、Z 与 U/δ/ζ 独立、排除限制、非零第一阶段。条件矩 E[Y−sin(P)|Z]=0；合适可积函数类下需要 Gaussian 卷积单射性/完备性，不能将 moment check 说成一般识别证明。α=.6 时 Cov(P,Z)=2.4，Cov(P,U+ζ)=1.6。

`verify.py` 独立计算 ∫₀^.5 cos(t)dt 的 Simpson 积分（512、1024 小区间），并核验 257 行标量来源方程、原代码标准差配置、同点零效应/逆向效应、Gauss–Hermite 结构残差均值、尺度不改变目标、配置未被修改。机器检验不等同于论文科学接收。

复现：工具包根目录 `.venv\Scripts\python.exe collect.py check contributions/iv-dikkala-2020-sine-v1 --run --n 128 --seed 1729`。

## 权利、AI 与状态
代码为根据方程新写，作者仓库 MIT；不随贡献打包论文或原仓库文件。OpenAI Codex 于 2026-10-23 协助检索、审查差异、编程和文档。待维护人查重、具名科学审核、另一人独立复现和权利复核；尚未发送，不宣称 accepted。此机制与非线性需求机制的第一阶段、响应面及协变量结构不同；改变 α/噪声仍只属于同一 family。
