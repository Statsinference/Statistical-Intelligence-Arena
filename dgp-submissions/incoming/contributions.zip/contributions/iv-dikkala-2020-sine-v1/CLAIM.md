# 认领与查重草稿

机制：Dikkala et al. 2020 Gaussian-location + sine response（raw units、作者代码SD）。任务 IV。当前待维护人查重，未联系维护人或填写具名认领人。相同机制的强度/噪声参数变体只登记场景。
