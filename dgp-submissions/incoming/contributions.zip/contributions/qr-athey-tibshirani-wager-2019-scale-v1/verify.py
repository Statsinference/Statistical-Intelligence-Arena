"""Independent CDF inversion/quadrature, source row reconstruction, controls."""
from __future__ import annotations
from copy import deepcopy
import math
import numpy as np
from generator import generate
from truth import truth

SOURCE_CONFIG = {'dimension': 40, 'scale_shift': 1.0, 'quantile': 0.9, 'x_query': [0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]}
TOLERANCE = 1e-11


def _location_scale(config: dict) -> tuple[float, float]:
    # Re-express the two conditional distributions as an explicit branch.
    if config["x_query"][0] <= 0:
        return 0.0, 1.0
    return 0.0, 1.0 + config["scale_shift"]


def _cdf(y: float, config: dict) -> float:
    location, scale = _location_scale(config)
    return math.erfc(-(y - location) / (scale * math.sqrt(2.0))) / 2.0


def _inverse_by_bisection(config: dict) -> float:
    location, scale = _location_scale(config)
    lower, upper = location - 10.0 * scale, location + 10.0 * scale
    for _ in range(100):
        midpoint = (lower + upper) / 2.0
        if _cdf(midpoint, config) < config["quantile"]:
            lower = midpoint
        else:
            upper = midpoint
    return (lower + upper) / 2.0


def _density_integral(y: float, config: dict, order: int) -> float:
    location, scale = _location_scale(config)
    z = (y - location) / scale
    nodes, weights = np.polynomial.legendre.leggauss(order)
    lower = -10.0
    transformed = lower + (nodes + 1.0) * (z - lower) / 2.0
    return float(np.dot(weights, np.exp(-transformed**2 / 2.0)) *
                 (z - lower) / (2.0 * math.sqrt(2.0 * math.pi)))


def _reconstruct(config: dict) -> dict:
    n, seed = 257, 314159
    observed = generate(config, n, seed)
    rng = np.random.Generator(np.random.PCG64(seed))
    x = rng.uniform(-1.0, 1.0, size=(n, 40))
    noise = rng.standard_normal(n)
    expected = []
    for row, epsilon in zip(x, noise):
        if row[0] <= 0:
            expected.append(float(epsilon))
        else:
            expected.append(float(epsilon) + config["scale_shift"] * float(epsilon))
    error = float(np.max(np.abs(np.asarray(observed["Y"]) - expected)))
    x_ok = all(np.array_equal(observed[f"X{j+1}"], x[:, j]) for j in range(40))
    return {"name": "scalar_source_equation_reconstruction", "passed": bool(x_ok and error < TOLERANCE),
            "max_outcome_absolute_error": error, "n": n, "seed": seed,
            "left_rows": int(np.sum(x[:, 0] <= 0)), "right_rows": int(np.sum(x[:, 0] > 0))}


def verify(config: dict) -> dict:
    before = deepcopy(config)
    value = truth(config)["value"]
    direct_residual = abs(_cdf(value, config) - config["quantile"])
    inverse_difference = abs(_inverse_by_bisection(config) - value)
    coarse = _density_integral(value, config, 64)
    fine = _density_integral(value, config, 128)
    grid_error = 0.0
    for first_coordinate in [-0.5, 0.0, 0.5]:
        for q in [0.1, 0.5, 0.9]:
            variant = {**config, "quantile": q, "x_query": [first_coordinate] + [0.0] * 39}
            grid_error = max(grid_error, abs(_cdf(truth(variant)["value"], variant) - q))
    median_config = {**config, "quantile": 0.5}
    median_expected = 0.0
    null_config = {**config, "scale_shift": 0.0}
    null_left = {**null_config, "x_query": [-0.5] + [0.0] * 39}
    null_right = {**null_config, "x_query": [0.5] + [0.0] * 39}
    nuisance = {**config, "x_query": [config["x_query"][0]] + [0.75] * 39}
    unchanged = {**config, "quantile": 0.1, "x_query": [-0.5] + [0.25] * 39}
    source_rows = generate(config, 64, 271828)
    unchanged_rows = generate(unchanged, 64, 271828)
    null_rows = generate(null_config, 64, 271828)
    rng = np.random.Generator(np.random.PCG64(271828))
    rng.uniform(-1.0, 1.0, size=(64, 40))
    null_expected = rng.standard_normal(64)
    checks = [
        {"name": "source_parameter_fixture", "passed": config == SOURCE_CONFIG,
         "details": "GRF Figure 2 scale shift, p=40; q=.9 is a paper quantile; fixed query is our scalar adapter."},
        {"name": "independent_erfc_cdf_and_bisection", "passed": direct_residual < TOLERANCE and inverse_difference < TOLERANCE,
         "cdf_residual": direct_residual, "inverse_absolute_difference": inverse_difference},
        {"name": "independent_gaussian_density_quadrature", "passed": abs(fine-config["quantile"]) < TOLERANCE and abs(fine-coarse) < TOLERANCE,
         "order64_cdf": coarse, "order128_cdf": fine, "cdf_residual": abs(fine-config["quantile"]),
         "refinement_difference": abs(fine-coarse), "omitted_standard_normal_lower_tail": "Phi(-10) < 8e-24"},
        _reconstruct(config),
        {"name": "both_branches_boundary_and_three_source_quantiles", "passed": grid_error < TOLERANCE,
         "max_cdf_residual": grid_error, "x1_grid": [-0.5, 0.0, 0.5], "quantile_grid": [0.1, 0.5, 0.9]},
        {"name": "median_control", "passed": abs(truth(median_config)["value"]-median_expected) < TOLERANCE,
         "expected_median": median_expected},
        {"name": "zero_shift_control", "passed": truth(null_left)["value"] == truth(null_right)["value"] and
         np.array_equal(null_rows["Y"], null_expected), "details": "Remove the shift: both branches are standard normal, including actual generated outcomes."},
        {"name": "inactive_coordinates_do_not_change_quantile", "passed": truth(nuisance)["value"] == value},
        {"name": "query_and_quantile_do_not_change_training_data", "passed": source_rows == unchanged_rows},
        {"name": "config_not_mutated", "passed": config == before},
    ]
    return {"passed": all(bool(check["passed"]) for check in checks), "checks": checks,
            "shared_components": "CDF uses erfc and bisection; quadrature independently integrates the normal density. Both avoid NormalDist.inv_cdf. Scalar row reconstruction shares PCG64 draws and source law; all checks share input config and the paper. This is not independent-person reproduction.",
            "scope": "DGP and truth checks only; no quantile estimator fit or confidence-interval experiment."}
