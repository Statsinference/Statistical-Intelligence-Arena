"""Explicit, additive local extension for the 2026-10-21 student toolkit.

Run with the toolkit root as the only argument. Does not execute contributions.
"""
import argparse
import hashlib
import json
from pathlib import Path


def enable(root):
    root = Path(root).resolve()
    old = b'FAMILIES = {"ate", "cate", "mediation", "iv", "proximal", "did_sc"}'
    new = old[:-1] + b', "quantile_regression"}'
    core = root / "collection/core.py"
    schema = root / "collection/schemas/collection.schema.json"
    raw = core.read_bytes()
    schema_raw = schema.read_bytes()
    contract = json.loads(schema_raw)
    enum = contract["properties"]["family"]["enum"]
    if new in raw and "quantile_regression" in enum:
        return {"changed": False, "extension": "quantile-regression-family-v1"}
    if raw.count(old) != 1 or "quantile_regression" in enum:
        raise ValueError("Unexpected toolkit state; no files changed. Review compatibility manually.")
    if set(enum) != {"ate", "cate", "mediation", "iv", "proximal", "did_sc"}:
        raise ValueError("Unexpected family enumeration; no files changed.")
    old_enum = b'"family": {"enum": ["ate", "cate", "mediation", "iv", "proximal", "did_sc"]}'
    new_enum = old_enum[:-2] + b', "quantile_regression"]}'
    if schema_raw.count(old_enum) != 1:
        raise ValueError("Unexpected schema formatting; no files changed.")
    changes = [(core, raw, raw.replace(old, new)),
               (schema, schema_raw, schema_raw.replace(old_enum, new_enum))]
    audit = {"extension": "quantile-regression-family-v1", "base_schema_version": "1.0",
             "official_base_compatible": False, "scientific_acceptance": False, "files": []}
    evidence = root / "extensions/quantile_regression"
    evidence.mkdir(parents=True, exist_ok=True)
    for path, before, after in changes:
        backup = evidence / (path.name + ".original.txt")
        if backup.exists() and backup.read_bytes() != before:
            raise ValueError("Existing backup differs; no file will be overwritten.")
    for path, before, after in changes:
        (evidence / (path.name + ".original.txt")).write_bytes(before)
        path.write_bytes(after)
        audit["files"].append({"path": path.relative_to(root).as_posix(),
                               "before_sha256": hashlib.sha256(before).hexdigest(),
                               "after_sha256": hashlib.sha256(after).hexdigest()})
    (evidence / "extension_audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    return {"changed": True, **audit}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("toolkit_root", type=Path)
    print(json.dumps(enable(parser.parse_args().toolkit_root), indent=2))
