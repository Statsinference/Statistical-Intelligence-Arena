# 条件分位数回归：本地类别扩展

学生包 2026-10-21 原版只接受 ate/cate/mediation/iv/proximal/did_sc。用户本轮明确要求条件 Quantile Regression，因此增加 `quantile_regression` 枚举；基础结构仍是 schema 1.0，扩展标识为 `quantile-regression-family-v1`。这不是原版官方支持，也不代表维护人已接受该任务扩展。

仅修改 `collection/core.py` 的 family 集合与 `collection/schemas/collection.schema.json` 的 family enum。其他元数据、observed-only、真值、重现性、哈希和打包检查保留。分位数是条件分布目标，不是因果效应；每个配置固定 q 与查询点，以返回原接口要求的标量真值。

在另一份原版学生包上，请先审阅脚本，然后显式启用（将路径替换为当地路径）：

```powershell
python enable_quantile_family.py "D:\path\to\DGP_student_toolkit"
```

脚本不执行贡献代码、不联网、不更改贡献文件；保留原文件备份及修改前后 SHA-256。重复启用无改动。未启用扩展的原版检查器将拒绝 QR 包，这是预期的兼容限制。两个 QR ZIP 都带有本脚本与本说明，不需把整个学生工具包重打包。
