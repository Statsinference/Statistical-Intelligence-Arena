"""Closed-form conditional quantile, numerically evaluated at a fixed query."""
from __future__ import annotations
from statistics import NormalDist
from generator import validate


def truth(config: dict) -> dict:
    validate(config)
    z = NormalDist().inv_cdf(config["quantile"])
    value = config["mean_shift"] * (config["x_query"][0] > 0) + z
    return {"value": float(value), "estimated_error": 1e-13,
            "method": "0.8*I(x1>0)+Phi_inverse(q); statistics.NormalDist.inv_cdf evaluation",
            "error_note": "Closed-form distributional identity. 1e-13 is a numerical precision allowance for the registered q=.9, not a rigorous uniform error bound or sampling error.",
            "quantile": config["quantile"], "x_query": list(config["x_query"]),
            "target_type": "conditional outcome quantile; not a causal effect"}
