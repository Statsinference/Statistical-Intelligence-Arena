# 待认领与去重

ID：`qr-athey-tibshirani-wager-2019-mean-v1`；mechanism family：`athey-tibshirani-wager-2019-quantile-mean-shift`。

来源：Athey、Tibshirani、Wager（2019），AoS，arXiv:1610.01271v4，第19页Figure 2，均值跳变机制。

目标：固定x*=(0.5,0,…,0)的条件90%分位数；非因果效应。图2另一个机制改变不同的条件分布成分，分开登记。认领人尚未指定，未联系维护人，未取得正式接收回执。须核对库内是否已有同一机制。类别需要明确的quantile-regression-family-v1扩展。

具名科学审核、独立人员复现与许可确认待完成。AI不代签以上角色。
