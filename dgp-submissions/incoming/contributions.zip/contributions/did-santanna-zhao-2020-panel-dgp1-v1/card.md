# Sant’Anna–Zhao (2020) 面板 DGP1

## 来源与定位
Sant’Anna, P. H. C. and Zhao, J. (2020), *Doubly robust difference-in-differences estimators*, Journal of Econometrics 219(1), 101–122. DOI: https://doi.org/10.1016/j.jeconom.2020.06.003 。采用作者网站 2020-05-05 版（35 页），PDF 第 20 页 §4.1 DGP1 及上下文；网址、哈希见 source_audit.json。第 19 页原实验 n=1000；本包 n=128 仅检查接口。来源文字与公式已由 AI 逐页核对，不代表具名人工审核。

## 原始方程、参数和观察数据
X~N(0,I4)，令 T=(exp(X1/2), 10+X2/(1+exp(X1)), (0.6+X1X3/25)^3, (20+X2+X4)^2)，Z_j=(T_j-E T_j)/sd(T_j)。
f(Z)=210+27.4Z1+13.7(Z2+Z3+Z4)，g(Z)=0.75(-Z1+0.5Z2-0.25Z3-0.1Z4)，D=1{U<=sigmoid(g(Z))}。
v=D f(Z)+eta，Y_pre=f(Z)+v+epsilon0，Y_1(d)=2 f(Z)+v+epsilon1(d)，Y_post=Y_1(D)。eta、epsilon0、epsilon1(0)、epsilon1(1) 是相互独立标准正态，与 X 和 U~U(0,1) 独立。v 本身与 D,Z 不独立，其独立的是创新 eta。

一行一个个体，仅输出 Z1-Z4,D,Y_pre,Y_post。前后两期共享 v，不能展开后把 2n 行当独立样本；原始 X、v、误差和反事实不导出。四个 Z 都影响分配与预后；总维数与有效维数均为 4，无高维标签。

## 目标、识别与真值
ATT=E[Y_1(1)-Y_1(0)|D=1]=0。切换 post-treatment d 时，组别 D 与该人的潜在固定效应 v 保持固定，不能重算 v=d f(Z)+eta。潜在结果差仅为 epsilon1(1)-epsilon1(0)，条件均值为 0；有限样本效应差不必恰等于 0。
基线无提前处理，未处理变化的条件均值为 f(Z)，对 D=0,1 相同，因此满足给定 Z 的平行趋势；无条件平行趋势一般不成立。另需一致性、无干扰和组间支持。logistic 在有限 Z 上有严格正概率，但不宣称整个无界支持存在统一 overlap 下界。

## 标准化与适配
总体均值是 (exp(1/8),10,0.21888,402)；总体方差是 (exp(1/2)-exp(1/4), 0.29337903585809294, 0.0019832832,3208)。第二项来自 E[sigmoid(-N)^2] 的 120 节点 Gauss–Hermite 积分，其他项为正态矩公式；这不是逐样本标准化。verify 用独立 Simpson 及正态矩积分类比核验，数值差是精度诊断而非严格全局误差证书。ATT 的解析值不受此标准化常数的数值误差影响。
保留原始 att_shift=0；verify 内的非零 shift 仅是单位响应和符号测试，不能称原论文新场景。使用 NumPy PCG64 等分布实现，不重现作者 R 随机流。原文还有 DGP2-DGP4，本包只收 DGP1。

## 核验与复跑
在学生包根目录运行 `.\.venv\Scripts\python.exe collect.py check contributions/did-santanna-zhao-2020-panel-dgp1-v1 --run --n 128 --seed 1729`。检查全部场景、同种子复现、异种子变化、列/值范围及真值；verify 独立积分 potential means、条件平行趋势、标量原公式重建、标准化常数和非零效应控制。独立是代码/数学路线层面的交叉检查，不是独立人员复现。结果以 checks/report.json 为准。

## 权利、AI 与未完成事项
由 OpenAI Codex 协助来源阅读、推导、写 Python 和报告。没有复制论文 PDF、作者源代码或受限数据进入贡献 ZIP。论文版权归权利人，正式公开许可仍需维护人审查。认领、科学审核与另一人复现尚未完成；没有训练模型、估计置信区间或重新运行原文 estimator 比较，不能把机器 PASS 说成科学接收。
