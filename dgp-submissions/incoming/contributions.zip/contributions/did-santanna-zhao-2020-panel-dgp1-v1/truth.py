"""Population ATT, holding the realized unit's latent effect fixed."""
import math


def truth(config):
    shift = float(config["att_shift"])
    if not math.isfinite(shift):
        raise ValueError("att_shift must be finite")
    return {"value": shift, "estimated_error": 0.0,
            "method": "E[epsilon_1(1)-epsilon_1(0)|D=1]=0; common v cancels",
            "scope": "population ATT; original registered shift=0"}
