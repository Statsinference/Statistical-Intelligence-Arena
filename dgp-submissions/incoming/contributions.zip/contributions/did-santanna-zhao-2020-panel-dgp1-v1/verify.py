"""Independent quadrature, scalar source reconstruction and controlled responses."""
import copy
import math
from itertools import product
import numpy as np
from generator import generate, MEAN, SD
from truth import truth


def _normalizers():
    # A different integration rule from the generator's Gauss--Hermite constant.
    grid = np.linspace(-10, 10, 8193)
    integrand = np.exp(-grid**2/2)/(math.sqrt(2*math.pi)*(1+np.exp(grid))**2)
    h = grid[1]-grid[0]
    s2 = float(h/3*(integrand[0]+integrand[-1]+4*integrand[1:-1:2].sum()+2*integrand[2:-1:2].sum()))
    nd, wt = np.polynomial.hermite.hermgauss(80)
    nd, wt = nd*math.sqrt(2), wt/math.sqrt(math.pi)
    # Tensor integration only for raw Z3 and Z4, which are low-degree polynomials.
    nodes, weights = np.polynomial.hermite.hermgauss(5)
    a, b = np.meshgrid(nodes*math.sqrt(2), nodes*math.sqrt(2))
    w = np.outer(weights, weights)/math.pi
    z3, z4 = (.6+a*b/25)**3, (20+a+b)**2
    means = np.array([np.dot(wt,np.exp(nd/2)),10,np.sum(w*z3),np.sum(w*z4)])
    variances = np.array([np.dot(wt,(np.exp(nd/2)-means[0])**2),s2,
                          np.sum(w*(z3-means[2])**2),np.sum(w*(z4-means[3])**2)])
    error = float(max(np.max(np.abs(means-MEAN)),np.max(np.abs(np.sqrt(variances)-SD))))
    return {"name":"population_normalization_independent_integrals","passed":error<1e-10,
            "max_absolute_error":error,"simpson_var_ztilde2":s2,
            "tail_probability_bound_for_z2_integral":1.6e-23,
            "note":"Tail bound only; discretization diagnosed, not a certified full error bound."}


def _scalar_rows(config):
    n, seed = 67, 321987
    data = generate(config,n,seed)
    rng = np.random.default_rng(seed)
    xs = rng.normal(size=(n,4)); uniforms=rng.random(n)
    eta=rng.normal(size=n); e0=rng.normal(size=n); e1=rng.normal(size=(n,2))
    errors=[]; arms=[]
    # Independently express source moments, rather than read generator constants.
    mus=[math.exp(1/8),10,.6**3+3*.6/625,20**2+2]
    vars_=[math.exp(.5)-math.exp(.25),.29337903585809305,
           9*.6**4/625+15*.6**2*9/625**2-9*.6**2/625**2+225/625**3,
           2*2**2+4*20**2*2]
    for i, x in enumerate(xs):
        raw=[math.exp(x[0]/2),10+x[1]/(1+math.exp(x[0])),
             (.6+x[0]*x[2]/25)**3,(20+x[1]+x[3])**2]
        z=[(v-m)/math.sqrt(s) for v,m,s in zip(raw,mus,vars_)]
        f=210+27.4*z[0]+13.7*z[1]+13.7*z[2]+13.7*z[3]
        score=.75*(-z[0]+.5*z[1]-.25*z[2]-.1*z[3])
        d=int(uniforms[i]<=1/(1+math.exp(-score))); arms.append(d)
        v=d*f+eta[i]
        ypre=f+v+e0[i]; ypost=2*f+v+e1[i,d]+d*config['att_shift']
        errors += [abs(data['Y_pre'][i]-ypre),abs(data['Y_post'][i]-ypost)]
        errors += [abs(data[f'Z{j+1}'][i]-z[j]) for j in range(4)]
    error=max(errors)
    return {"name":"scalar_source_equation_reconstruction","passed":error<1e-10 and data['D']==arms,
            "max_absolute_error":float(error),"n":n,"seed":seed}


def _potential_integrals(config):
    # Separately implemented potential outcomes at different prognostic values.
    # Both treatment states keep group membership and v fixed.
    nodes,w = np.polynomial.hermite.hermgauss(5)
    nodes=nodes*math.sqrt(2); w=w/math.sqrt(math.pi)
    contrasts=[]; trend_errors=[]
    for f in (-40.,0.,210.,450.):
        mu0=[]; mu1=[]; delta=[]
        for g in (0,1):
            terms0=[]; terms1=[]; changes=[]
            for i,j in product(range(5),repeat=2):
                latent=g*f+nodes[i]
                before=f+latent+nodes[j]
                after0=f+f+latent+nodes[j]
                after1=2*f+latent+nodes[j]+config['att_shift']
                weight=w[i]*w[j]
                terms0.append(weight*after0); terms1.append(weight*after1)
                changes.append(weight*(after0-before))
            mu0.append(math.fsum(terms0)); mu1.append(math.fsum(terms1)); delta.append(math.fsum(changes))
        contrasts.append(mu1[1]-mu0[1])
        trend_errors.extend([abs(v-f) for v in delta])
    err=max(abs(x-truth(config)['value']) for x in contrasts)
    return [{"name":"independent_post_potential_mean_quadrature","passed":err<1e-10,
             "max_absolute_error":err,"note":"Mean integration only; quadrature coupling is irrelevant to means, generator uses independent potential errors."},
            {"name":"conditional_parallel_trends_both_groups","passed":max(trend_errors)<1e-10,
             "max_absolute_error":max(trend_errors)}]


def verify(config):
    before=copy.deepcopy(config)
    checks=[{"name":"original_source_parameters","passed":config=={'dimension':4,'att_shift':0.0}},
            _normalizers(),_scalar_rows(config),*_potential_integrals(config)]
    base=generate(config,53,771)
    for shift in (-1.,1.):
        c={**config,'att_shift':shift}; altered=generate(c,53,771)
        error=float(np.max(np.abs(np.array(altered['Y_post'])-base['Y_post']-shift*np.array(base['D']))))
        unchanged=all(base[k]==altered[k] for k in base if k!='Y_post')
        checks.append({'name':f'controlled_nonzero_shift_{shift:+g}','passed':unchanged and error<1e-10 and truth(c)['value']==shift and all(x['passed'] for x in _potential_integrals(c)), 'max_row_error':error})
    checks.append({'name':'config_not_mutated','passed':before==config})
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'independence_scope':'Separate scalar equations and Simpson/GH math routes; shared NumPy RNG and same-agent work are disclosed, not independent-person replication.'}
