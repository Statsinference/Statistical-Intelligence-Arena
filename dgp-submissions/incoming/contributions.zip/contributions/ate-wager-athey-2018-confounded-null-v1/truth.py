"""Analytic scalar estimand, not an estimated finite-sample group difference."""
from __future__ import annotations

import math

from generator import validate_config


def truth(config: dict) -> dict:
    validate_config(config)
    value = config["effect_shift"]
    return {"value": float(value), "estimated_error": 0.0,
            "method": 'Analytic ATE: tau(x)=0 everywhere. Independent verification integrates observed-arm IPW moments with Gauss-Legendre and normal Gauss-Hermite; naive population group difference is -1/3.',
            "error_interpretation": "No integration or Monte Carlo approximation; usual IEEE floating-point rounding is not a certified zero error bound."}
