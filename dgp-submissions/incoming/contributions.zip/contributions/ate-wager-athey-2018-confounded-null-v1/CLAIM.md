# 认领与去重待办

贡献 ID：`ate-wager-athey-2018-confounded-null-v1`。

Source equation (27) has tau(x)=0 and X1-driven confounding. It is separate from equation (28)'s randomized logistic product and the AoS combined setting; a changed estimand alone is not counted as a new family. It is also distinct from the prior Nie-Wager Setup A submission.

尚未联系维护人；认领人、科学审核人、另一位独立复现人均未登记。此文件仅为可提交的认领草稿，不代表项目已收件或接收。AI 内部校验不能代替具名审核。
