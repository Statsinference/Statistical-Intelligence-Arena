"""Independent normal-mean/moment integration and scalar source reconstruction."""
from __future__ import annotations

from copy import deepcopy
import math

import numpy as np

from generator import generate
from truth import truth

SOURCE_CONFIG = {'dimension': 5, 'noise_sd': 1.0, 'effect_shift': 0.0}
MODE = 'null'
TOL = 1e-12


def _source_components(config: dict, row) -> tuple[float, float, float]:
    """Separate scalar equations; does not call generator internals or truth."""
    if MODE == "randomized":
        e, m = 0.5, 0.0
    else:
        z = float(row[0 if MODE == "null" else 2])
        # Independently expand the Beta(2,4) density polynomial.
        density = 20*z - 60*z*z + 60*z**3 - 20*z**4
        e, m = (1+density)/4, 2*z-1
    if MODE == "null":
        effect = float(config["effect_shift"])
    else:
        # tanh is algebraically equivalent to the paper's exponential logistic.
        first = 1.5 + 0.5*math.tanh(10*(float(row[0])-1/3))
        second = 1.5 + 0.5*math.tanh(10*(float(row[1])-1/3))
        effect = config["effect_scale"]*first*second
    return float(e), float(m), float(effect)


def _conditional_moment_truth(config: dict, order: int) -> dict:
    """Integrate Y under both arms, then solve Cov(A,Y)/Var(A) at x_star.

    Gauss-Hermite exactly integrates affine normal outcomes in exact arithmetic.
    We sum each arm mean separately; no closed-form truth is reused.
    """
    x = config["query_point"]
    e, m, effect = _source_components(config, x)
    nodes, weights = np.polynomial.hermite.hermgauss(order)
    arm_means = []
    for a in (0, 1):
        arm_means.append(math.fsum(float(weight) / math.sqrt(math.pi) *
            (m + (a-0.5)*effect + math.sqrt(2)*config["noise_sd"]*float(node))
            for node, weight in zip(nodes, weights)))
    ey = (1-e)*arm_means[0] + e*arm_means[1]
    eay = e*arm_means[1]
    return {"order": order, "arm_means": arm_means, "propensity": e,
            "contrast": arm_means[1]-arm_means[0],
            "covariance_ratio": (eay-e*ey)/(e*(1-e))}


def _population_moment_truth(config: dict, order: int) -> dict:
    """Independent 1D integration (inactive X integrate to one).

    Integrate observed-arm weighted means and the IPW population contrast, not
    the constant returned by truth(). Separate arm outcome means are integrated
    over symmetric Gaussian nodes, then over the source Uniform confounder.
    """
    nodes, weights = np.polynomial.legendre.leggauss(order)
    errors, normal_weights = np.polynomial.hermite.hermgauss(5)
    treated, control, probabilities, ipw = [], [], [], []
    for z, weight in zip((nodes+1)/2, weights/2):
        row = [float(z)] + [0.5]*(config["dimension"]-1)
        e, m, effect = _source_components(config, row)
        mu = []
        for a in (0, 1):
            mu.append(math.fsum(float(w)/math.sqrt(math.pi)*
                (m+(a-0.5)*effect+math.sqrt(2)*config["noise_sd"]*float(v))
                for v, w in zip(errors, normal_weights)))
        treated.append(float(weight)*e*mu[1])
        control.append(float(weight)*(1-e)*mu[0])
        probabilities.append(float(weight)*e)
        ipw.append(float(weight)*(e*mu[1]/e-(1-e)*mu[0]/(1-e)))
    pa = math.fsum(probabilities)
    return {"order": order, "treatment_prevalence": pa,
            "ipw_ate": math.fsum(ipw),
            "observed_treated_mean": math.fsum(treated)/pa,
            "observed_control_mean": math.fsum(control)/(1-pa),
            "naive_difference": math.fsum(treated)/pa-math.fsum(control)/(1-pa)}


def _row_reconstruction(config: dict) -> dict:
    n, seed = 257, 314159
    observed = generate(config, n, seed)
    rng = np.random.Generator(np.random.PCG64(seed))
    x = rng.uniform(0, 1, size=(n, config["dimension"]))
    uniforms, errors = rng.random(n), rng.standard_normal(n)
    a_expected, y_expected = [], []
    for row, uniform, error in zip(x, uniforms, errors):
        e, m, effect = _source_components(config, row)
        a = int(uniform < e)
        mu0, mu1 = m-effect/2, m+effect/2
        a_expected.append(a)
        y_expected.append((mu1 if a else mu0) + config["noise_sd"]*float(error))
    difference = float(np.max(np.abs(np.asarray(observed["Y"])-y_expected)))
    return {"name": "scalar_source_row_reconstruction", "passed": bool(
            observed["A"] == a_expected and difference < TOL and all(
                np.array_equal(observed[f"X{j+1}"], x[:, j]) for j in range(config["dimension"]))),
            "n": n, "seed": seed, "max_outcome_error": difference}


def _controls(config: dict) -> list[dict]:
    key = "effect_shift" if MODE == "null" else "effect_scale"
    null_config = {**config, key: 0.0}
    positive_config = {**config, key: 1.0}
    negative_config = {**config, key: -1.0}
    zero, plus, minus = [generate(c, 64, 271828) for c in (null_config, positive_config, negative_config)]
    y0, yp, ym = [np.asarray(d["Y"]) for d in (zero, plus, minus)]
    residual = float(np.max(np.abs(yp+ym-2*y0)))
    common = all(zero[k] == plus[k] == minus[k] for k in zero if k != "Y")
    oracle = _population_moment_truth if MODE == "null" else _conditional_moment_truth
    field = "ipw_ate" if MODE == "null" else "covariance_ratio"
    positive, negative, null = [oracle(c, 7)[field] for c in (positive_config, negative_config, null_config)]
    expected_positive = 1.0 if MODE == "null" else 2.25
    return [
        {"name": "null_effect_control", "passed": bool(abs(null) < TOL and truth(null_config)["value"] == 0)},
        {"name": "nonzero_sensitivity_and_sign_reversal", "passed": bool(common and residual < TOL
            and abs(positive-expected_positive) < TOL and abs(negative+expected_positive) < TOL
            and abs(truth(positive_config)["value"]-positive) < TOL
            and abs(truth(negative_config)["value"]-negative) < TOL),
         "max_row_symmetry_error": residual, "positive_moment_value": positive, "negative_moment_value": negative},
        {"name": "mean_zero_noise_invariance", "passed": all(
            abs(oracle({**config, "noise_sd": sd}, 7)[field]-truth(config)["value"]) < TOL
            for sd in (0.0, 2.0))},
    ]


def verify(config: dict) -> dict:
    before = deepcopy(config)
    expected = truth(config)["value"]
    checks = [{"name": "source_parameter_and_target_fixture", "passed": config == SOURCE_CONFIG,
               "details": ("The target is the population ATE of the source zero-effect design."
                           if MODE == "null" else "The fixed query is explicitly a collection adaptation; it was not a paper-reported scalar result.")}]
    if MODE == "null":
        coarse, fine = [_population_moment_truth(config, order) for order in (5, 9)]
        diff, refine = abs(fine["ipw_ate"]-expected), abs(fine["ipw_ate"]-coarse["ipw_ate"])
        checks.append({"name": "independent_population_ipw_integration", "passed": diff < TOL and refine < TOL,
                       "coarse": coarse, "fine": fine, "absolute_difference": diff, "refinement_difference": refine})
        checks.append({"name": "confounding_fixture_noncausal_naive_difference", "passed": bool(
            abs(fine["treatment_prevalence"]-0.5) < TOL and abs(fine["naive_difference"]+1/3) < TOL),
            "expected_naive_difference": -1/3, "actual_naive_difference": fine["naive_difference"],
            "details": "E_beta(2,4)[X]=1/3 implies E[m e]=-1/12; group means -1/6 and +1/6 although ATE=0."})
    else:
        coarse, fine = [_conditional_moment_truth(config, order) for order in (5, 9)]
        diff, refine = abs(fine["covariance_ratio"]-expected), abs(fine["covariance_ratio"]-coarse["covariance_ratio"])
        checks.append({"name": "independent_conditional_normal_moment_integration", "passed": bool(
            diff < TOL and refine < TOL and abs(fine["contrast"]-expected) < TOL),
            "coarse": coarse, "fine": fine, "absolute_difference": diff, "refinement_difference": refine})
        query_change = {**config, "query_point": [0.5]*config["dimension"]}
        checks.append({"name": "query_changes_target_not_sampling", "passed": bool(
            generate(query_change, 19, 41) == generate(config, 19, 41)
            and abs(truth(query_change)["value"]-_conditional_moment_truth(query_change, 7)["covariance_ratio"]) < TOL
            and truth(query_change)["value"] != expected)})
    grid = np.linspace(0.0, 1.0, 1001)
    p = np.full_like(grid, 0.5) if MODE == "randomized" else (1+20*grid*(1-grid)**3)/4
    lower, upper = (0.5, 0.5) if MODE == "randomized" else (0.25, 199/256)
    checks.extend([
        {"name": "source_propensity_overlap", "passed": bool(
            np.min(p) >= lower and np.max(p) <= upper+TOL),
         "analytic_lower": lower, "analytic_upper": upper,
         "details": "Beta(2,4) density attains 135/64 at x=1/4; randomized design has e=1/2."},
        _row_reconstruction(config), *_controls(config),
        {"name": "config_not_mutated", "passed": before == config},
    ])
    return {"passed": all(item["passed"] for item in checks), "checks": checks,
            "shared_components": "Same cited equations, config, Python/NumPy, PCG64 sequence. Truth shares input validation only. Verification implements scalar expanded beta polynomial/tanh algebra and separate outcome-moment quadrature. This is AI-assisted internal verification, not independent-person reproduction.",
            "scope": "DGP and scalar truth consistency only. No estimator fit, CI evaluation or scientific acceptance."}
