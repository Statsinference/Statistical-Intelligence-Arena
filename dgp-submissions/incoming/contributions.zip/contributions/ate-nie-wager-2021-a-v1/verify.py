"""Separate potential-mean integration, scalar source reconstruction, and controls."""
from __future__ import annotations

from copy import deepcopy
from itertools import product
import math

import numpy as np

from generator import generate
from truth import truth


SOURCE_CONFIG = {"dimension": 6, "noise_sd": 1.0, "propensity_trim": 0.1, "effect_scale": 1.0}
NUMERIC_TOLERANCE = 1e-12


def _integrated_potential_means(config: dict, order: int) -> dict:
    """Separately implement mu1/mu0 and integrate over all six covariates.

    No generator response equation or truth closed form is reused. Tensor
    Gauss--Legendre exactly integrates the contrast polynomial in exact arithmetic.
    Individual nonlinear arm means remain numerical approximations.
    """
    nodes, weights = np.polynomial.legendre.leggauss(order)
    grid = list(zip((nodes + 1.0) / 2.0, weights / 2.0))
    treated_terms, control_terms = [], []
    for point in product(grid, repeat=6):
        x = [float(item[0]) for item in point]
        weight = math.prod(float(item[1]) for item in point)
        baseline = math.sin(math.pi*x[0]*x[1]) + 2*x[2]**2 - 2*x[2] + 0.5 + x[3] + x[4]/2
        half_contrast = config["effect_scale"] * (x[0] + x[1]) / 4
        treated_terms.append(weight * (baseline + half_contrast))
        control_terms.append(weight * (baseline - half_contrast))
    treated, control = math.fsum(treated_terms), math.fsum(control_terms)
    return {"order": order, "nodes": order**6, "mu1_integral": treated,
            "mu0_integral": control, "contrast": treated - control}


def _scalar_reconstruction(config: dict) -> dict:
    """Check actual generated rows against scalar source equations and draw order."""
    n, seed = 257, 314159
    observed = generate(config, n, seed)
    rng = np.random.Generator(np.random.PCG64(seed))
    x = rng.uniform(0.0, 1.0, size=(n, 6))
    uniforms, errors = rng.random(n), rng.standard_normal(n)
    expected_a, expected_y, propensities = [], [], []
    for row, uniform, error in zip(x, uniforms, errors):
        signal = math.sin(math.pi * row[0] * row[1])
        probability = max(config["propensity_trim"], min(signal, 1 - config["propensity_trim"]))
        a = int(uniform < probability)
        # Expanded potential means make treatment-centering errors visible.
        base = signal + 2*row[2]**2 - 2*row[2] + 0.5 + row[3] + row[4]/2
        mu0 = base - config["effect_scale"] * (row[0] + row[1]) / 4
        mu1 = base + config["effect_scale"] * (row[0] + row[1]) / 4
        expected_a.append(a)
        expected_y.append((mu1 if a else mu0) + config["noise_sd"] * error)
        propensities.append(probability)
    error = float(np.max(np.abs(np.asarray(observed["Y"]) - expected_y)))
    x_match = all(np.array_equal(observed[f"X{j+1}"], x[:, j]) for j in range(6))
    return {"name": "scalar_source_equation_reconstruction", "passed": bool(
        x_match and observed["A"] == expected_a and error < NUMERIC_TOLERANCE),
        "max_outcome_absolute_error": error, "n": n, "seed": seed,
        "lower_clip_rows": propensities.count(config["propensity_trim"]),
        "upper_clip_rows": propensities.count(1 - config["propensity_trim"])}


def _special_cases(config: dict) -> list[dict]:
    zero = {**config, "effect_scale": 0.0}
    reverse = {**config, "effect_scale": -config["effect_scale"]}
    plus, null, minus = (generate(c, 64, 271828) for c in (config, zero, reverse))
    y_plus, y_null, y_minus = (np.asarray(d["Y"]) for d in (plus, null, minus))
    expected_change = (np.asarray(plus["A"]) - 0.5) * config["effect_scale"] * (
        np.asarray(plus["X1"]) + np.asarray(plus["X2"])) / 2
    null_difference = float(np.max(np.abs(y_plus - y_null - expected_change)))
    reverse_difference = float(np.max(np.abs(y_plus + y_minus - 2*y_null)))
    common_rows = all(plus[k] == null[k] == minus[k] for k in plus if k != "Y")
    return [
        {"name": "zero_effect_control", "passed": bool(
            common_rows and null_difference < NUMERIC_TOLERANCE and truth(zero)["value"] == 0
            and abs(_integrated_potential_means(zero, 3)["contrast"]) < NUMERIC_TOLERANCE),
         "max_row_error": null_difference, "expected_ate": 0.0},
        {"name": "effect_sign_reversal", "passed": bool(
            reverse_difference < NUMERIC_TOLERANCE and truth(reverse)["value"] == -truth(config)["value"]
            and abs(_integrated_potential_means(reverse, 3)["contrast"] + truth(config)["value"]) < NUMERIC_TOLERANCE),
         "max_row_error": reverse_difference, "expected_ate": -truth(config)["value"]},
        {"name": "noise_and_assignment_do_not_change_population_ate", "passed": all(
            truth(variant)["value"] == truth(config)["value"] for variant in
            ({**config, "noise_sd": 0.0}, {**config, "noise_sd": 2.0}, {**config, "propensity_trim": 0.2})),
         "details": "Only noise or treatment assignment changes; the intervention means and population stay fixed."},
    ]


def verify(config: dict) -> dict:
    """Validate the registered original cell; variants below are internal controls."""
    before = deepcopy(config)
    analytic = truth(config)["value"]
    coarse, fine = (_integrated_potential_means(config, order) for order in (3, 5))
    difference = abs(fine["contrast"] - analytic)
    refinement = abs(fine["contrast"] - coarse["contrast"])
    checks = [
        {"name": "source_parameter_fixture", "passed": config == SOURCE_CONFIG,
         "details": "Setup A, d=6, sigma=1, eta=0.1; scale=1 preserves the source effect function."},
        {"name": "independent_six_dimensional_potential_mean_integration",
         "passed": difference < NUMERIC_TOLERANCE and refinement < NUMERIC_TOLERANCE,
         "analytic_ate": analytic, "fine": fine, "coarse": coarse,
         "absolute_difference": difference, "order_refinement_difference": refinement},
        _scalar_reconstruction(config),
        *_special_cases(config),
        {"name": "config_not_mutated", "passed": config == before},
    ]
    return {"passed": all(check["passed"] for check in checks), "checks": checks,
            "shared_components": "Independent algebra and quadrature; common source equations, config, Python/NumPy and PCG64 draw sequence. truth shares only input validation with generator. Not independent-person reproduction.",
            "scope": "DGP/source consistency only; no estimator fit, CI coverage, or scientific acceptance."}
