# 维护人认领／查重草稿（尚未发送）

- 拟贡献 ID：`ate-nie-wager-2021-a-v1`；任务 `ate`；机制 `nie-wager-2021-setup-a`。
- 来源：[Nie & Wager, Biometrika 2021](https://doi.org/10.1093/biomet/asaa076)。
- 方程版本：[arXiv v4](https://arxiv.org/abs/1712.04912v4)，Section 6.1，PDF pp.15–16，Setup A。
- 固定场景：d=6、σ=1；总体 ATE=0.5，由机制推导。
- 主要适配：CATE 机制用于 ATE 目标，W 改名 A，Python/NumPy 等分布抽样。
- 待维护人确认：同一 Setup A 是否已被他人以 ATE/CATE 收集；不能因任务改名重复计为新机制。
- 认领人：未指定。提交者填写真实姓名；科学审核、独立人员复现与许可决定待完成。

本文件是随包提供的草稿，不表示已经联系维护人或得到认领批准。
