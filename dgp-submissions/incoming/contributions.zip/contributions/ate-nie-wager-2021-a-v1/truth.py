"""Population ATE; does not estimate the target from a generated sample."""
from generator import validate_config


def truth(config: dict) -> dict:
    """E[Y(1)-Y(0)] = effect_scale * E[(X1+X2)/2] = effect_scale/2."""
    validate_config(config)
    return {
        "value": float(config["effect_scale"] / 2.0),
        "estimated_error": 0.0,
        "method": "Exact population expectation under independent Uniform(0,1) covariates",
        "derivation": "mu1(X)-mu0(X)=effect_scale*(X1+X2)/2; E[X1]=E[X2]=1/2",
        "error_interpretation": "No quadrature or Monte Carlo error; the registered value 0.5 is exactly representable. Not a general floating-point error bound.",
    }
