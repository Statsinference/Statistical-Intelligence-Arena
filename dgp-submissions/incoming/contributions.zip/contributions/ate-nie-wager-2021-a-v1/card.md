# ATE 示例：Nie–Wager Setup A

贡献 ID：`ate-nie-wager-2021-a-v1`。一个 mechanism family，一个登记场景。
目标：超总体 ATE；解析真值 **0.5**。本卡用于 DGP 收集，科学审核尚待完成。

## 1. 来源与逐项核对

Nie, X. and Wager, S. (2021). *Quasi-oracle estimation of heterogeneous treatment effects*.
**Biometrika 108(2), 299–319**，[DOI](https://doi.org/10.1093/biomet/asaa076)。
本次实际读取的方程版本是 [arXiv:1712.04912v4](https://arxiv.org/abs/1712.04912v4)，
修订日期 2020-08-06。下文页码均是该 PDF 页码，不是期刊页码。

| 核对项 | 本贡献采用的内容 | 原始位置 |
|---|---|---|
| 原论文目标 | CATE 函数 τ(x) | PDF p.2，Section 2 |
| 观察数据方程 | Y=b(X)+(W−0.5)τ(X)+σε | PDF p.15，Section 6.1 末段，未编号方程 |
| X、b、e、τ | Setup A 的分布和完整函数 | PDF p.16 首段；作者 `run_simu.R` L25–32 |
| 参数格点 | d=6、σ=1；η=0.1 | PDF p.18 Figure 3 caption；`start.sh` L3–6；η 见 Setup A |
| A、Y 的随机抽样 | Bernoulli 分配，独立标准正态误差 | `run_simu.R` L75–77 |
| 采样单位 | 独立同分布的个体 | PDF p.2 的数据设定 |
| 本贡献 ATE | E[τ(X)]=0.5，本次解析推导 | 下节；不是声称原文报告了这个 ATE 结果 |

作者代码以提交 `6806396960e672214e2ef36e16c76bbb58ef9114` 固定：
[机制与采样](https://github.com/xnie/rlearner/blob/6806396960e672214e2ef36e16c76bbb58ef9114/experiments_for_paper/run_simu.R#L25)、[参数网格](https://github.com/xnie/rlearner/blob/6806396960e672214e2ef36e16c76bbb58ef9114/experiments_for_paper/start.sh#L3)。
PDF 与作者文件的 SHA-256 见 `source_audit.json`。未运行作者的 R 估计器实验。

发现一个不影响本场景的来源差异：arXiv v4 图注的最大噪声列为 3，作者脚本与附录表有 4；
本贡献固定选择双方一致的 σ=1，不补猜其他格点。当前所选机制没有缺失的必要参数。

## 2. 完整机制与观察列

对每个个体 i 独立抽样，六个协变量分量也相互独立：

\[
X_{ij}\sim\operatorname{Uniform}(0,1),\quad j=1,\ldots,6,
\qquad U_i\sim\operatorname{Uniform}(0,1),\quad\epsilon_i\sim N(0,1).
\]

U、ε 与 X 相互独立。定义：

\[
b(x)=\sin(\pi x_1x_2)+2(x_3-0.5)^2+x_4+0.5x_5,
\]
\[
e(x)=\max\{0.1,\min[\sin(\pi x_1x_2),0.9]\},\qquad
\tau(x)=(x_1+x_2)/2,
\]
\[
A_i=\mathbf1\{U_i<e(X_i)\},\qquad
Y_i=b(X_i)+(A_i-0.5)\tau(X_i)+\epsilon_i.
\]

`generate(config,n,seed)` 返回八个等长数值列表：`X1,X2,X3,X4,X5,X6,A,Y`。
X1、X2 同时影响处理与结局，是混杂变量和效应修饰变量；X3–X5 只影响结局；X6 无作用。
U、ε、e、b、τ、Y(0)、Y(1) 与总体 ATE 均不作为模型输入列输出。

注意：b(X) 是两个处理臂条件均值的中点，不是一般意义的 E[Y|X]。
这里 E[Y|X]=b(X)+(e(X)−0.5)τ(X)。把生成器中的 0.5 改成 e(X) 会改变观察数据机制，
即使处理效应差仍相同，也不能算原方程复现。

## 3. ATE、识别条件与推导

明确干预方向为处理 1 减处理 0，目标总体是原有的六维均匀分布：

\[
\theta_{ATE}=E\{Y(1)-Y(0)\}
=E\{\mu_1(X)-\mu_0(X)\}
=E\{(X_1+X_2)/2\}=\tfrac12.
\]

其中 μ₁=b+τ/2，μ₀=b−τ/2。可用共同的独立 ε 定义两个潜在结局；
这是相容的结构实现，ATE 只依赖两臂边缘条件均值，不依赖未观察的潜在结局相关性。

识别依赖一致性、无个体间干扰、给定 X 的处理可交换性及 positivity。
本机制通过独立处理随机数与结局误差实现可交换性，并有 0.1≤e(X)≤0.9。
观察分布下可写成 E_X[E(Y|A=1,X)−E(Y|A=0,X)]。
这些是机制的构造条件，不是机器检查从现实数据证明的结论。

总体 ATE=0.5；某一次样本的平均 τ(X_i) 通常不恰好为 0.5。
观察组均值差 E[Y|A=1]−E[Y|A=0] 也不是这里的真值，不能拿它替代 oracle。

## 4. 场景、改动和属性

`config.json` 只登记 `original_d6_sigma1`：dimension=6、noise_sd=1、propensity_trim=0.1、effect_scale=1。
前两项是论文格点选择，trim 是原方程，scale=1 不改变 τ。
所有来源固定系数写在方程与代码中，不存在未登记的拟合参数。

改动逐项披露：将 W 改名 A；将输出目标由 CATE 函数改为总体 ATE；
用 Python/NumPy PCG64 重新实现等分布抽样；使用 n=128、seed=1729 做接口检查。
不声称与 R 使用同一种子可得到逐行相同数据，也不声称复现论文的估计器结果。

`verify.py` 内部用 scale=0、scale=−1 检查零效应和方向，用不同 noise_sd/trim 做不变性检查。
这些是测试特例，未登记成额外场景，更不计为额外 DGP family。
如果正式增加场景，必须更新配置、卡片和核验 fixture，并让官方 checker 检查全部场景后另存 ZIP。

总维数为 6，有效维数为 5；在 n=128 的检查规模下不标高维。
交互来自 sin(πX1X2) 及 A×X1、A×X2；非线性还包括 X3 的平方项和 propensity 的截断。
该例覆盖二元处理、连续结局、完整观测、无干扰的 iid 机制；不涵盖 IV、面板、缺失、未测混杂。
给定总体 overlap 不保证每个极小样本都出现两组；生成器不因单臂样本重新抽样。

## 5. 真值与尽量独立的核验

`truth.py` 使用解析期望，不调用样本均值。`estimated_error=0` 表示没有积分或 Monte Carlo 误差；
登记值 0.5 可被二进制浮点精确表示，不是对任意程序和参数作零舍入误差保证。

`verify.py` 包含七项具名检查：

1. 将配置与原文固定参数 fixture 比较。
2. 用另一套标量形式分别构造 μ₁、μ₀，在 [0,1]⁶ 上做 3 阶与 5 阶张量 Gauss–Legendre 积分，再相减。
3. 另写逐行标量方程，核对 257 行生成结果，包括两端 propensity 截断、A 的分配与 Y 的中心化。
4. 零效应特例：ATE=0，观察结局相对原始场景的改变量与机制一致。
5. 反转效应：ATE=−0.5，配对结局满足相应对称关系。
6. 改变结局噪声或分配概率时，总体 ATE 保持不变。
7. 调用前后的配置一致，避免原地修改输入。

积分路线不复用生成器的响应曲面或 truth 的闭式表达式。两臂均值本身是非线性积分近似；
相减后的 integrand 为一次多项式，在精确算术下可被该积分规则精确积分。
独立核验固定容差为 1e−12，官方真值容差为 1e−10；检查后不因失败放宽。
共享环节包括原文解释、参数、NumPy/Python，以及逐行重建使用的 PCG64 抽样序列。
truth 与 generator 共享输入验证。这里的“独立路线”不等于独立人员复现。
运行数值见 `checks/report.json`，只记录实际执行结果。

## 6. 权利、AI 协助与未决事项

本实现由 OpenAI Codex（GPT-6 系列，精确构建标识未提供）于 2026-10-22 辅助完成，
包括来源检索、数学核对、代码、中文说明与本地检查。没有代填真人阅读或审核签名。
本次没有向项目维护人发送消息；认领人、跨项目查重、具名科学复核、独立人员复现和正式接收均待办理。

论文版权属于其权利人；作者 R 仓库附 GPL-3.0 许可文本。
提交 ZIP 不含论文 PDF、作者 R 文件、真实个体数据、模型权重或训练银行。
新写实现的正式发布许可及相关权利由贡献者和维护人确认，本卡不替第三方授予许可。

机器 PASS 仅证明所列格式和有界检查通过；不证明论文全实验复现、CI 覆盖率、模型优劣或科学接收。
本阶段不训练 PFN、不做 bootstrap、不运行完整 benchmark。
