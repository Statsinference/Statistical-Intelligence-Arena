"""Analytic scalar estimand, not an estimated finite-sample group difference."""
from __future__ import annotations

import math

from generator import validate_config


def truth(config: dict) -> dict:
    validate_config(config)
    x = config["query_point"]
    first = 1.0 + 1.0 / (1.0 + math.exp(-20.0*(x[0]-1.0/3.0)))
    second = 1.0 + 1.0 / (1.0 + math.exp(-20.0*(x[1]-1.0/3.0)))
    value = config["effect_scale"]*first*second
    return {"value": float(value), "estimated_error": 0.0,
            "method": 'Analytic CATE at fixed query: s(1/3)=3/2, so tau(x_star)=9/4. Independent verification integrates arm means with Gauss-Hermite and solves the conditional covariance moment.',
            "error_interpretation": "No integration or Monte Carlo approximation; usual IEEE floating-point rounding is not a certified zero error bound."}
