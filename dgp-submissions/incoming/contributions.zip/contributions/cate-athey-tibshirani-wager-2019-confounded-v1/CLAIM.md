# 认领与去重待办

贡献 ID：`cate-athey-tibshirani-wager-2019-confounded-v1`。

This is the source paper's explicitly combined setting: the logistic product tau(x) from Wager-Athey (2018) plus X3-dependent e(x) and m(x). It shares tau with the randomized CATE contribution, but changes assignment and outcome confounding structure. Final mechanism-family deduplication is pending.

尚未联系维护人；认领人、科学审核人、另一位独立复现人均未登记。此文件仅为可提交的认领草稿，不代表项目已收件或接收。AI 内部校验不能代替具名审核。
