"""Independent analytic and shape checks for the cubic wave NRI target.

Uses the expanded polynomial form as the independent route, entirely separate
from the factored form used in truth.py. Also checks:
  - Endpoint special cases (analytic)
  - The universal truth at x*=0.5 (p_s(0.5)=0.5 for all s)
  - Range [0,1] on a dense grid (clamping tolerance ±1e-12)
  - Monotonicity on a dense grid, with explicit note for s>0.5 stress scenarios
  - Derivative check: critical points exist iff s>0.5
  - Default-scenario anchor: s=0.5, x*=0.5 -> 0.5

These checks do NOT call truth.py; they share only the declared DGP formula.
"""
import math


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _p_wave_factored(x, s):
    """Factored form: p_s(x) = 0.5 - (2s-1)(x-0.5) + 8s(x-0.5)^3."""
    d = x - 0.5
    return 0.5 - (2.0 * s - 1.0) * d + 8.0 * s * d * d * d


def _p_wave_expanded(x, s):
    """Expanded polynomial: p_s(x) = 8s*x^3 - 12s*x^2 + (4s+1)*x.

    This is the independent route: derived by expanding (x-0.5)^3 and
    collecting terms; does not call truth.py or the factored implementation.
    """
    return 8.0 * s * x**3 - 12.0 * s * x**2 + (4.0 * s + 1.0) * x


def _dp_wave(x, s):
    """Derivative: p_s'(x) = -(2s-1) + 24s*(x-0.5)^2."""
    return -(2.0 * s - 1.0) + 24.0 * s * (x - 0.5) ** 2


# ---------------------------------------------------------------------------
# Main verify function
# ---------------------------------------------------------------------------

def verify(config):
    s = float(config["s"])
    x_star = float(config["x_star"])

    # Independent route: expanded polynomial (does not call truth.py)
    expanded_val = _p_wave_expanded(x_star, s)
    # Factored route (re-implemented here; same formula as truth.py but
    # separate code path for consistency check)
    factored_val = _p_wave_factored(x_star, s)

    # Dense grid checks
    grid = [i / 1000.0 for i in range(1001)]
    factored_vals = [_p_wave_factored(x, s) for x in grid]
    expanded_vals = [_p_wave_expanded(x, s) for x in grid]

    # Agreement between two polynomial representations on dense grid
    max_poly_diff = max(abs(f - e) for f, e in zip(factored_vals, expanded_vals))

    # Range: analytic p_s([0,1]) in [0,1]; clamp tolerance ±1e-12 for float noise
    in_range = all(-1e-12 <= v <= 1.0 + 1e-12 for v in factored_vals)

    # Monotonicity: s<=0.5 should be monotone; s>0.5 is expected non-monotone
    monotone = all(
        factored_vals[i] <= factored_vals[i + 1] + 1e-12
        for i in range(len(factored_vals) - 1)
    )
    should_be_monotone = (s <= 0.5 + 1e-9)

    # Critical points of p_s: p_s'(x)=0 => (x-0.5)^2 = (2s-1)/(24s)
    has_real_critical_points = (s > 0.5 + 1e-9)
    if has_real_critical_points:
        disc = (2.0 * s - 1.0) / (24.0 * s)
        xc_right = 0.5 + math.sqrt(disc)
        xc_left = 0.5 - math.sqrt(disc)
        # Confirm derivative sign changes at these critical points
        dp_at_midpoint = _dp_wave(0.5, s)  # should be negative for s>0.5
        dp_critical_ok = dp_at_midpoint < 0
    else:
        xc_right = xc_left = None
        dp_at_midpoint = _dp_wave(0.5, s)  # should be >=0 for s<=0.5
        dp_critical_ok = dp_at_midpoint >= -1e-14  # flat at s=0.5 exactly

    checks = [
        {
            "name": "independent_expanded_polynomial_route",
            "passed": abs(factored_val - expanded_val) <= 2e-14,
            "details": (
                f"factored=0.5-(2s-1)*d+8s*d^3 = {factored_val:.17g}; "
                f"expanded=8s*x^3-12s*x^2+(4s+1)*x = {expanded_val:.17g}; "
                f"difference={abs(factored_val - expanded_val):.3g}."
            ),
        },
        {
            "name": "two_polynomial_forms_agree_on_grid",
            "passed": max_poly_diff <= 2e-14,
            "details": (
                f"Max |factored-expanded| over 1001-point grid = {max_poly_diff:.3g}; "
                "confirms algebraic equivalence of the two representations."
            ),
        },
        {
            "name": "universal_midpoint_truth",
            "passed": abs(factored_val - 0.5) <= 1e-14,
            "details": (
                f"p_s(0.5) = 0.5 for all s because (x-0.5) and (x-0.5)^3 vanish at x=0.5; "
                f"computed {factored_val:.17g}."
            ),
        },
        {
            "name": "endpoint_p_at_0",
            "passed": abs(_p_wave_factored(0.0, s)) <= 1e-14,
            "details": (
                f"p_s(0) = 0.5 - (2s-1)*(-0.5) + 8s*(-0.5)^3 = "
                f"0.5 + 0.5*(2s-1) - s = s - s = 0; "
                f"computed {_p_wave_factored(0.0, s):.3g}."
            ),
        },
        {
            "name": "endpoint_p_at_1",
            "passed": abs(_p_wave_factored(1.0, s) - 1.0) <= 1e-14,
            "details": (
                f"p_s(1) = 0.5 - (2s-1)*(0.5) + 8s*(0.5)^3 = "
                f"0.5 - 0.5*(2s-1) + s = 1; "
                f"computed {_p_wave_factored(1.0, s):.6g}."
            ),
        },
        {
            "name": "conditional_probability_support",
            "passed": in_range,
            "details": (
                f"Wave probabilities lie within [-1e-12, 1+1e-12] on a 1001-point grid "
                f"(float boundary noise tolerated); "
                f"min={min(factored_vals):.6g}, max={max(factored_vals):.6g}."
            ),
        },
        {
            "name": "monotonicity_or_stress_flag",
            "passed": True,  # always pass: monotone scenarios are verified; stress noted
            "details": (
                f"s={s}: should_be_monotone={should_be_monotone}, "
                f"actually_monotone={monotone}. "
                + (
                    "Monotonicity holds as expected on the dense grid."
                    if monotone
                    else (
                        f"Non-monotone stress scenario (s>0.5): critical points at "
                        f"x={xc_left:.4f} and x={xc_right:.4f}; "
                        "source monotone-band coverage theorem does NOT apply here."
                    )
                )
            ),
        },
        {
            "name": "monotonicity_consistent_with_scenario_flag",
            "passed": (should_be_monotone == monotone) or (not should_be_monotone and not monotone),
            "details": (
                f"s={s:.1f}: s<=0.5 expects monotone, s>0.5 expects non-monotone; "
                f"observed monotone={monotone}; consistent={should_be_monotone == monotone}. "
                "Note: s=0.5 is borderline (p'(0.5)=0 exactly; monotone on grid)."
            ),
        },
        {
            "name": "derivative_sign_at_midpoint",
            "passed": dp_critical_ok,
            "details": (
                f"p_s'(0.5) = -(2s-1) = {dp_at_midpoint:.6g}; "
                + (
                    "negative confirms non-monotone (local min at midpoint) for s>0.5."
                    if has_real_critical_points
                    else "nonnegative confirms monotone (derivative >=0 at x=0.5) for s<=0.5."
                )
            ),
        },
    ]

    # Default-scenario anchor: s=0.5, x*=0.5
    if abs(s - 0.5) < 1e-9 and abs(x_star - 0.5) < 1e-9:
        checks.append({
            "name": "default_s05_x05_anchor",
            "passed": abs(factored_val - 0.5) <= 1e-14 and abs(expanded_val - 0.5) <= 1e-14,
            "details": (
                f"s=0.5, x*=0.5: factored={factored_val:.17g}, "
                f"expanded={expanded_val:.17g}; both equal 0.5 exactly."
            ),
        })

    # Linear special case: at s=1 the cubic coefficient dominates; p_1(0.5)=0.5 still
    if abs(s - 1.0) < 1e-9:
        p_quarter = _p_wave_factored(0.25, 1.0)
        p_three_quarter = _p_wave_factored(0.75, 1.0)
        # By symmetry: p_1(0.5-d) + p_1(0.5+d) = 1 (antisymmetry about (0.5, 0.5))
        symm_ok = abs(p_quarter + p_three_quarter - 1.0) <= 1e-14
        checks.append({
            "name": "s10_antisymmetry_about_midpoint",
            "passed": symm_ok,
            "details": (
                f"s=1: p_1(0.25)+p_1(0.75) should =1 by antisymmetry of (x-0.5)^3; "
                f"p(0.25)={p_quarter:.6g}, p(0.75)={p_three_quarter:.6g}, "
                f"sum={p_quarter + p_three_quarter:.17g}."
            ),
        })

    # General antisymmetry check: p_s(0.5-d) + p_s(0.5+d) = 1 for all s, d
    for test_d in (0.1, 0.2, 0.3, 0.4):
        if 0.0 <= 0.5 - test_d and 0.5 + test_d <= 1.0:
            lo = _p_wave_factored(0.5 - test_d, s)
            hi = _p_wave_factored(0.5 + test_d, s)
            symm_val = abs(lo + hi - 1.0)
            checks.append({
                "name": f"antisymmetry_d{int(test_d*10):02d}",
                "passed": symm_val <= 1e-14,
                "details": (
                    f"p_s({0.5-test_d:.1f})+p_s({0.5+test_d:.1f})=1 by antisymmetry "
                    f"of odd powers about x=0.5; sum={lo+hi:.17g}, err={symm_val:.3g}."
                ),
            })

    return {
        "passed": all(c["passed"] for c in checks),
        "checks": checks,
        "shared_components": (
            "The expanded polynomial route is algebraically derived from the factored form "
            "but implemented as a separate code path; both share the declared DGP equations "
            "and config parameters, not the implementation. truth.py is not called. "
            "Source reconstruction and independent-person reproduction remain separate review tasks."
        ),
        "scope": (
            "These checks cover the scalar analytic truth and source shape conditions. "
            "Scenarios s>0.5 are explicitly flagged as non-monotone stress scenarios "
            "where the source's monotone-band coverage theorem does not apply. "
            "Point-wise checks do not establish simultaneous confidence-band coverage."
        ),
    }
