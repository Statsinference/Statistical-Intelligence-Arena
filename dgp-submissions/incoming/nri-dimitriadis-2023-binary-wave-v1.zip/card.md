# Cubic wave binary regression DGP: nri-binary-wave-v1

**Status: candidate; not scientifically accepted.**

Source: Dimitriadis, T., Dümbgen, L., Henzi, A., Puke, M. and Ziegel, J. (2023).
Honest calibration assessment for binary outcome predictions.
*Biometrika* 110(3), 663–680. DOI [10.1093/biomet/asac068](https://doi.org/10.1093/biomet/asac068).
[arXiv:2203.04065v2](https://arxiv.org/abs/2203.04065) (2022-11-02), PDF p.8, Section 5, item 5 (Wave).

**[*] Caveat on source version**: The DGP was checked against arXiv preprint v2 (2022-11-02).
Differences between the preprint and the final Biometrika publication have **not** been verified.
The replication repository https://github.com/marius-cp/replication_DDHPZ22 has no pinned commit.
Maintainer review of the formal version is required before scientific acceptance.

---

## Source fidelity and adaptation

The two observed columns are `X` and `Y`. The DGP as stated in arXiv v2 PDF p.8, §5, item 5 (Wave):

- `X ~ Uniform[0, 1]`
- `Y | X ~ Bernoulli(p_s(X))`
- Wave function (factored): `p_s(x) = 0.5 − (2s−1)(x−0.5) + 8s(x−0.5)^3`, `s ∈ {0, 0.1, ..., 1}`
- Equivalent expanded form: `p_s(x) = 8s·x^3 − 12s·x^2 + (4s+1)·x`

The source paper studies **simultaneous confidence bands** for monotone regression functions.
This contribution changes the target to the **scalar NRI query** `E[Y | X = 0.5] = p_s(0.5)`,
which is required by the collection interface. No confidence band, bootstrap, or coverage
result is reproduced.

**Adaptation: exclusion of s = 0.** At `s = 0` the wave function reduces to
`p_0(x) = 0.5 + (x − 0.5) = x`, the diagonal line. This is algebraically identical to the
`s = 0` endpoint of the monomial template (`p_s(x) = x^{1−s}` gives `x` at `s = 0`) and to
the `s = 0` endpoints of the s-shape, kink, and step templates. To avoid registering a
duplicate mechanism family, `s = 0` is excluded; scenarios start at `s = 0.1`.

---

## Original equations

1. `X_i ~ Uniform[0, 1]` independently.
2. `p_s(x) = 0.5 − (2s−1)(x−0.5) + 8s(x−0.5)^3` (factored cubic in `d = x − 0.5`).
3. `Y_i | X_i = x ~ Bernoulli(p_s(x))` independently.

**Special values** (exact, analytic):
- `p_s(0) = 0` for all `s` (since `0.5 + (2s−1)·0.5 − s = s − s = 0`)
- `p_s(0.5) = 0.5` for all `s` (since `d = 0` kills both the linear and cubic terms)
- `p_s(1) = 1` for all `s` (since `0.5 − (2s−1)·0.5 + s = 1`)
- `s = 0` reduces to `p_0(x) = x` (linear diagonal; excluded as duplicate)

**Antisymmetry**: `p_s(0.5 − d) + p_s(0.5 + d) = 1` for all `s, d`, because the wave is an
odd function of `d = x − 0.5` plus the constant `0.5`.

**Derivative**: `p_s'(x) = −(2s−1) + 24s(x−0.5)^2`.
- `s ≤ 0.5`: `p_s'(x) ≥ 0` on `[0,1]` → **monotone nondecreasing** (source assumption holds)
- `s = 0.5`: `p_s'(0.5) = 0` exactly (flat inflection at midpoint; still monotone)
- `s > 0.5`: `p_s'(0.5) = −(2s−1) < 0` → **non-monotone**; two critical points at
  `x = 0.5 ± sqrt((2s−1)/(24s))` (local max then local min). These are **stress scenarios**.

Sampling unit: independent individuals. No interference, clustering, or panel structure.
`dimension = 1`, `effective_dimension = 1` (single covariate X). No interaction terms.
`nonlinear = true` (cubic polynomial in `d`; nonlinear for `s > 0`).

---

## Target and identification

**Estimand**: `m_s(x*) = E[Y | X = x*] = p_s(x*)` at fixed query `x* = 0.5`.

This is a conditional Bernoulli probability evaluated under the known DGP.
It is a **noncausal** regression target: no intervention, no mediator, no treatment is defined.

**Applicable assumptions**:
- iid observations (no clustering, panel, or network dependence)
- `X ~ Uniform[0, 1]`; the fixed query `x* = 0.5` lies in the open support
- `Y | X ~ Bernoulli(p_s(X))` for the declared `s`
- **Monotonicity** (required by the source band method) holds **only for `s ≤ 0.5`**.
  Scenarios `s = 0.6, ..., 1.0` are **non-monotone stress scenarios**: the source's
  simultaneous-band coverage theorem under monotonicity does **not** apply, and no
  monotone-band coverage is claimed for them. They are retained for benchmark
  stress testing of methods that assume monotonicity.
- No causal identification, exchangeability, or interference assumption is needed or claimed

---

## Truth and independent verification

For the query `x* = 0.5`:

```
d = x* − 0.5 = 0
p_s(0.5) = 0.5 − (2s−1)·0 + 8s·0^3 = 0.5
```

This holds for **every** `s`; the truth at the default query is `0.5` regardless of scenario.

**Default scenario** `s = 0.5`: `p_{0.5}(0.5) = 0.5` exactly.
`0.5` is exactly representable in IEEE 754 binary64, so there is no floating-point
representation error.

**All 10 scenario truth values** at `x* = 0.5` (all identical):

| Scenario | s | p_s(0.5) | Monotone? |
|---|---|---|---|
| s01 | 0.1 | 0.5 | yes |
| s02 | 0.2 | 0.5 | yes |
| s03 | 0.3 | 0.5 | yes |
| s04 | 0.4 | 0.5 | yes |
| **s05** | **0.5** | **0.5** | yes (borderline, flat at 0.5) |
| s06 | 0.6 | 0.5 | **no (stress)** |
| s07 | 0.7 | 0.5 | **no (stress)** |
| s08 | 0.8 | 0.5 | **no (stress)** |
| s09 | 0.9 | 0.5 | **no (stress)** |
| s10 | 1.0 | 0.5 | **no (stress)** |

**Independent verification route** (`verify.py`): evaluates the **expanded polynomial form**
`8s·x^3 − 12s·x^2 + (4s+1)·x` as a separate code path from `truth.py`'s factored form.
Checks:
1. Factored vs expanded agree at `x*` and on a 1001-point grid (algebraic equivalence)
2. Universal midpoint truth `p_s(0.5) = 0.5`
3. Endpoint special cases `p_s(0) = 0`, `p_s(1) = 1`
4. Range `[−1e-12, 1+1e-12]` on dense grid (float boundary noise tolerated)
5. Monotonicity on grid, with explicit stress flag for `s > 0.5`
6. Derivative sign at midpoint confirms monotone (s≤0.5) vs non-monotone (s>0.5)
7. Antisymmetry `p_s(0.5−d) + p_s(0.5+d) = 1` for several `d`
8. Default anchor `s=0.5, x*=0.5 → 0.5`

**Shared components**: both `truth.py` and `verify.py` share the declared DGP equations
and config; they use different polynomial representations (factored vs expanded) but are
algebraically derived from the same source formula. An independent human reproduction
is required for scientific acceptance.

---

## Diversity and scope

- **Total dimension**: 1 (covariate X only)
- **Effective dimension**: 1 (X is the only predictor; no irrelevant variables added)
- **High-dimensional**: false
- **Interactions**: false (single variable, no cross-terms)
- **Nonlinear**: true (cubic polynomial in `d = x − 0.5`; nonlinear for `s > 0`)
- **Monotonicity**: holds for `s ≤ 0.5` (source-assumption-valid); violated for `s > 0.5`
  (stress scenarios, retained but not claimed for monotone-band coverage)
- **s = 0**: excluded as degenerate `p(x) = x` (duplicate of other templates' `s = 0`)
- **Unsupported settings**: `x_star` must be in `(0,1)`; `s = 0` excluded
- **Source simultaneous bands**: the source targets the whole curve under monotonicity;
  this collection registers only the scalar point query at `x* = 0.5` (point-wise check ≠
  band coverage). The non-monotone stress scenarios are out of scope for the source's theorem.

---

## Rights and assistance

Paper copyright belongs to Biometrika/Oxford/authors. No paper PDF or replication repository
code is redistributed. Equations are cited and independently reimplemented from the arXiv v2 text.

AI assistance (Claude Code / Claude Opus 5.5) was used to extract equations, write and debug
all Python code, and draft this card; all content reflects the contributor's declared source
description and the cited DGP formula. Scientific acceptance requires maintainer verification
of the formal Biometrika version.

**Unresolved issues / open gaps**:
- [*] Formal Biometrika (2023) DGP vs. arXiv v2 differences not checked
- No fixed replication code commit; GitHub commit hash pending maintainer review
- `item 5 (Wave)` numbering within §5 inferred from sibling contributions; not confirmed from unopened PDF
- Source coverage/band experiments not reproduced; only scalar smoke check run
- Non-monotone stress scenarios (s > 0.5) are retained for benchmark stress testing;
  no monotone-band coverage is claimed for them
