"""Analytic scalar NRI truth for the selected wave scenario.

Wave function: p_s(x) = 0.5 - (2s-1)(x-0.5) + 8s(x-0.5)^3.
Equivalent expanded form: p_s(x) = 8s*x^3 - 12s*x^2 + (4s+1)*x.

Truth at x* = 0.5: both (x-0.5) and (x-0.5)^3 vanish there, so
    p_s(0.5) = 0.5   for every s in (0, 1].

This is an exact analytic result; the floating-point value is 0.5 (exact in IEEE 754).
The estimated_error is dominated by 2 * machine_epsilon from float arithmetic.

Independent audit route: evaluated via the expanded polynomial 8s*x^3-12s*x^2+(4s+1)*x
at x=0.5. Both routes give 0.5 exactly, confirming no rounding ambiguity at this query.
"""
import math
import sys


def _validate(config):
    if not isinstance(config, dict):
        raise ValueError("config must be a scenario dictionary")
    s = config.get("s")
    x_star = config.get("x_star")
    if isinstance(s, bool) or not isinstance(s, (int, float)) or not math.isfinite(float(s)):
        raise ValueError("s must be a finite numeric value")
    s_f = float(s)
    if not (0.0 < s_f <= 1.0 + 1e-12):
        raise ValueError("s must lie in (0, 1]")
    if isinstance(x_star, bool) or not isinstance(x_star, (int, float)) or not math.isfinite(float(x_star)):
        raise ValueError("x_star must be a finite numeric value")
    if not 0.0 < float(x_star) < 1.0:
        raise ValueError("x_star must be an interior point of (0, 1) for NRI scalar query")


def truth(config):
    """Return p_s(x_star) = E[Y | X = x_star] for the wave DGP.

    Derivation
    ----------
    Factored form: p_s(x) = 0.5 - (2s-1)(x-0.5) + 8s(x-0.5)^3.
    At x* = 0.5: d = x* - 0.5 = 0, so p_s(0.5) = 0.5 + 0 + 0 = 0.5.

    This holds for every s; it does not depend on the value of s.

    For x* != 0.5 the truth is a general cubic, computed via the factored form
    for numerical stability and audited via the expanded form.

    Note: 0.5 is exactly representable in IEEE 754 binary64, so there is no
    rounding error in the stored float for the default x*=0.5 query.
    """
    _validate(config)
    s = float(config["s"])
    x_star = float(config["x_star"])

    # Primary route: factored form (numerically stable near x=0.5)
    d = x_star - 0.5
    value = 0.5 - (2.0 * s - 1.0) * d + 8.0 * s * d * d * d

    # Independent audit: expanded polynomial form 8s*x^3 - 12s*x^2 + (4s+1)*x
    value2 = 8.0 * s * x_star**3 - 12.0 * s * x_star**2 + (4.0 * s + 1.0) * x_star

    estimated_error = abs(value - value2) + 2.0 * sys.float_info.epsilon

    return {
        "value": float(value),
        "estimated_error": float(estimated_error),
        "method": (
            "Analytic: p_s(0.5)=0.5 for all s because (x-0.5) and (x-0.5)^3 vanish "
            "at x=0.5. Primary route: factored form 0.5-(2s-1)*d+8s*d^3. "
            "Independent audit: expanded polynomial 8s*x^3-12s*x^2+(4s+1)*x."
        ),
        "error_interpretation": (
            "For x*=0.5 both routes return 0.5 exactly (0.5 is IEEE 754 exact). "
            "estimated_error = |factored - expanded| + 2*machine_epsilon. "
            "Not a confidence-band or coverage error bound."
        ),
        "target": "m_s(x_star) = E[Y | X=x_star] = p_s(x_star), NRI point query",
        "query": {"x_star": x_star, "s": s},
        "monotone_scenario": s <= 0.5,
    }
