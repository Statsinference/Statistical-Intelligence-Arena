"""Independent quadrature and observation-probability checks."""
import math
def verify(config):
    k=20000
    integral=sum(math.cos(2*(-1+(i+0.5)*2/k))/k for i in range(k))
    p=lambda x:1/(1+math.exp(-x))
    checks=[
      {'name':'source_scenario','passed':config['mode']=='cosine_logistic','details':'AoS 2009, Section 6.2 nonlinear MAR scenario.'},
      {'name':'independent_quadrature','passed':abs(integral-math.sin(2)/2)<1e-9,'details':f'Numerical mean={integral:.12g}.'},
      {'name':'mean_observation_probability','passed':abs(p(-1)+p(1)-1)<1e-12 and p(0)==0.5,'details':'Symmetry gives E[R]=0.5.'},
      {'name':'finite_mask_value','passed':math.isfinite(float(config['missing_outcome_placeholder'])),'details':'Missing outcome is masked.'}
    ]
    return {'passed':all(c['passed'] for c in checks),'checks':checks}
