# Cosine response mean with logistic MAR

Müller, U. U. (2009). Estimating linear functionals in nonlinear regression with responses missing at random. The Annals of Statistics 37(5A), 2245-2277. DOI: 10.1214/08-AOS642.

Müller (2009), AoS §6.2 nonlinear regression, journal p. 2269 / PDF p. 25; Table 1, p. 2270 / PDF p. 26 confirms the response-mean target. Section 1 states epsilon is independent of X, has mean zero, and missingness is MAR. Select the paper’s nonlinear cos(2X) setting, not its linear 2X setting. E(Y)=sin(2)/2. The paper does not supply this evaluated numerical truth; it follows exactly by integration. X is always observed; R=1 indicates observed Y. Each call returns one iid sample. R=0 has a zero placeholder, not a measured Y. Original article PDF is kept outside this ZIP. Machine checks do not constitute scientific review.
