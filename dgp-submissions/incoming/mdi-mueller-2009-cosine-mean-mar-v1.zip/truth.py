"""Exact integral of the source's cosine regression function."""
import math
def truth(config):
    if config['mode']!='cosine_logistic':
        raise ValueError('invalid scenario')
    return {'value':math.sin(2)/2,'estimated_error':0.0,'method':'Uniform(-1,1) integral of cos(2x); mean-zero independent error','target':'Full-data E(Y)'}
