"""Population CATE at the declared query points.

The target is never estimated from generated rows: it is evaluated from the
declared mechanism.  The query points are part of the estimand definition and are
repeated in card.md and collection.json.
"""
import math

QUERY_POINTS = {
    "primary": {
        "X1": 0.2,
        "X2": 0.3,
        "X3": 0.5,
        "X4": 0.5,
        "X5": 0.5
    },
    "secondary": {
        "X1": 0.9,
        "X2": 0.8,
        "X3": 0.5,
        "X4": 0.5,
        "X5": 0.5
    }
}


def tau_at(x):
    """CATE surface of the mechanism, evaluated at one query point."""
    return (
        0.5 * (x["X1"] + x["X2"])
    )


def truth(config):
    scale = float(config["tau_scale"])
    primary = tau_at(QUERY_POINTS["primary"]) * scale
    secondary = tau_at(QUERY_POINTS["secondary"]) * scale
    return {
        "value": primary,
        "estimated_error": 1e-12,
        "method": "Closed form: the surface is linear in X1, X2, so tau(x0) = (x1 + x2)/2 exactly; cross-checked by a second typing and by the realised outcome column.",
        "target": "tau(x0) at QUERY_POINTS['primary'], evaluated from the declared mechanism",
        "value_at_secondary_query": secondary,
        "scale_used": scale,
    }
