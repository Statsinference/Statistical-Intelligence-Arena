"""Analytic scalar population CDF; never computed from a generated sample."""
import math
from generator import validate


def truth(config):
    validate(config)
    q = config["query"]
    location = config["amplitude"] * math.sin(config["frequency"] * q["x"])
    z = q["y"] - location
    if z <= -1.0:
        value = 0.0
    elif z <= 0.0:
        value = 0.5 * (1.0 + z) ** 2
    elif z < 1.0:
        value = 1.0 - 0.5 * (1.0 - z) ** 2
    else:
        value = 1.0
    return {
        "value": value,
        "estimated_error": 1e-14,
        "method": "Closed-form triangular density integral at y-2*sin(3.1416*x)",
        "target": "P(Y <= y_query | X = x_query), continuous conditional-law version",
        "query": dict(q), "location": location, "residual_threshold": z,
        "error_interpretation": "No integration or Monte Carlo error. 1e-14 is a floating-point roundoff allowance, audited against 80-digit Decimal sine and density integration in verify.py; it is not a certified bound on every platform's libm.",
    }
