"""Independent Decimal density integration, exact cases, and RNG diagnostics.

The reference integral does not call the oracle CDF, sine, or validator.
Both routes share the declared mathematical model and scenario parameters.
"""
from copy import deepcopy
from decimal import Decimal, localcontext
import math
import random
from generator import generate
from truth import truth


def _sin_decimal(x):
    # |3.1416*x| < 3.1416. After the initial terms this alternating series
    # decreases; the next term controls its truncation error.
    term = total = x
    for k in range(1, 200):
        term *= -x * x / Decimal((2 * k) * (2 * k + 1))
        total += term
        if abs(term) < Decimal("1e-75"):
            return total
    raise ArithmeticError("Decimal sine series failed to converge")


def _density_integral(config, steps):
    """Integrate the shifted Y density with Simpson, splitting at the mode.

    Each segment is linear, hence exact quadrature in real arithmetic.
    Decimal and Taylor sine are separate from the oracle float/libm path.
    """
    if steps < 2 or steps % 2:
        raise ValueError("Simpson steps must be positive and even")
    with localcontext() as ctx:
        ctx.prec = 80
        d = lambda v: Decimal(str(v))
        x, y = d(config["query"]["x"]), d(config["query"]["y"])
        mu = d(config["amplitude"]) * _sin_decimal(d(config["frequency"]) * x)
        lower, upper = mu - 1, min(y, mu + 1)
        if upper <= lower:
            return Decimal(0)
        cuts = [lower] + ([mu] if lower < mu < upper else []) + [upper]
        result = Decimal(0)
        for a, b in zip(cuts, cuts[1:]):
            h = (b - a) / steps
            terms = []
            for j in range(steps + 1):
                t = a + h * j
                density = max(Decimal(0), Decimal(1) - abs(t - mu))
                weight = 1 if j in (0, steps) else (4 if j % 2 else 2)
                terms.append(weight * density)
            result += h * sum(terms) / 3
        return +result


def verify(config):
    checks = []

    def record(name, passed, details):
        checks.append({"name": name, "passed": bool(passed), "details": details})

    fixture = {"amplitude": 2.0, "frequency": 3.1416,
               "x_distribution": "symmetric_triangular", "x_support": [-1.0, 1.0],
               "x_mode": 0.0, "noise_distribution": "symmetric_triangular",
               "noise_support": [-1.0, 1.0], "noise_mode": 0.0,
               "query": {"x": 0.1, "y": 1.0}}
    record("source_constants_and_declared_query", config == fixture,
           "Example 1 parameters including literal 3.1416; x=.1 is source-linked; fixed y=1 is the scalar adaptation.")
    oracle = truth(config)
    coarse, fine = _density_integral(config, 32), _density_integral(config, 64)
    difference = abs(Decimal.from_float(oracle["value"]) - fine)
    record("independent_decimal_density_integration", difference < Decimal("1e-12"),
           {"reference_decimal": str(fine), "oracle": oracle["value"],
            "absolute_difference": str(difference), "tolerance": 1e-12})
    record("roundoff_allowance_audit", difference <= Decimal(str(oracle["estimated_error"])),
           {"difference": str(difference), "declared_estimated_error": oracle["estimated_error"]})
    record("decimal_integration_refinement", abs(fine - coarse) < Decimal("1e-65"),
           {"steps": [32, 64], "difference": str(abs(fine - coarse)),
            "interpretation": "Linear segments: quadrature is exact in real arithmetic; no universal numerical error certificate."})

    # At x=0 the sine vanishes. Rational anchors cover both branches,
    # support boundaries, and thresholds outside support.
    anchors = []
    for y, expected in [(-2, 0), (-1, 0), (-0.5, 0.125), (0, 0.5),
                        (0.5, 0.875), (1, 1), (2, 1)]:
        probe = deepcopy(config)
        probe["query"] = {"x": 0.0, "y": y}
        got, independent = truth(probe)["value"], _density_integral(probe, 32)
        anchors.append({"y": y, "expected": expected, "value": got,
                        "integral": str(independent)})
    record("analytic_x_zero_anchors",
           all(abs(r["value"] - r["expected"]) < 1e-14 and
               abs(Decimal(r["integral"]) - Decimal(str(r["expected"]))) < Decimal("1e-65")
               for r in anchors), anchors)

    # Verifier cases are not additional contributed scenarios or families.
    branch_max, monotone = Decimal(0), True
    for x in (-0.8, 0.1, 0.7):
        values = []
        for y in (-4.0, -2.0, -0.5, 0.0, 0.5, 1.0, 2.0, 4.0):
            probe = deepcopy(config)
            probe["query"] = {"x": x, "y": y}
            v = truth(probe)["value"]
            branch_max = max(branch_max, abs(Decimal.from_float(v) - _density_integral(probe, 32)))
            values.append(v)
        monotone &= all(0 <= v <= 1 for v in values) and values == sorted(values)
    record("shifted_support_and_cdf_branches", branch_max < Decimal("1e-12") and monotone,
           {"max_absolute_difference": str(branch_max), "monotonicity_and_range": monotone,
            "scope": "CDF identities only; no simultaneous confidence-band validation."})

    before_config, before_rng = deepcopy(config), random.getstate()
    data = generate(config, 65536, 271828)
    replay = generate(config, 32, 1729)
    record("generator_interface_reproducibility_and_purity",
           set(data) == {"X", "Y"} and all(isinstance(v, list) and len(v) == 65536 for v in data.values())
           and replay == generate(config, 32, 1729)
           and replay != generate(config, 32, 1730)
           and before_rng == random.getstate() and config == before_config,
           "Only X,Y; same-seed replay; different-seed change; unchanged config and global random state.")
    xs = data["X"]
    # Reconstructed residuals are only used internally, never exported.
    es = [y - 2.0 * math.sin(3.1416 * x) for x, y in zip(xs, data["Y"])]
    record("joint_and_conditional_support",
           all(math.isfinite(x) and -1 <= x <= 1 for x in xs)
           and all(math.isfinite(y) and -3 <= y <= 3 for y in data["Y"])
           and all(-1.0 - 1e-14 <= e <= 1.0 + 1e-14 for e in es),
           "X in [-1,1], Y in [-3,3], residual in [-1,1]; 1e-14 residual allowance covers floating subtraction.")
    n, alpha = len(xs), 1e-6
    dkw = math.sqrt(math.log(2 / alpha) / (2 * n))
    for name, values in (("X", xs), ("reconstructed_noise", es)):
        errors = [abs(sum(v <= cut for v in values) / n - expected)
                  for cut, expected in [(-0.5, 0.125), (0.0, 0.5), (0.5, 0.875)]]
        mean = math.fsum(values) / n
        second = math.fsum(v * v for v in values) / n
        record("triangular_law_" + name,
               max(errors) < dkw and abs(mean) < 2 * dkw and abs(second - 1 / 6) < dkw,
               {"mean": mean, "second_moment": second, "max_cdf_error_at_knots": max(errors),
                "cdf_tolerance_DKW": dkw, "mean_tolerance_Hoeffding": 2 * dkw,
                "second_moment_tolerance_Hoeffding": dkw, "per_diagnostic_alpha": alpha, "n": n})
    moment = math.fsum(x * e for x, e in zip(xs, es)) / n
    joint_negative = sum(x <= 0 and e <= 0 for x, e in zip(xs, es)) / n
    record("x_noise_independence_diagnostics",
           abs(moment) < 2 * dkw and abs(joint_negative - 0.25) < dkw,
           {"E_X_epsilon_empirical": moment, "joint_negative_fraction": joint_negative,
            "interpretation": "Fixed-seed moments and quadrant frequency support code review of separate draws; they do not prove independence."})
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "shared_components": "Oracle and generator share input validation and binary64 math.sin. Decimal reference uses separately coded density integration and Taylor sine, but shares the model and config. RNG diagnostics use the generator under test and share libm for residual reconstruction. AI-assisted verification is not independent-person reproduction.",
            "scope": "One scalar target; no estimator fitting, CI coverage, MADE replication, or simultaneous bands."}
