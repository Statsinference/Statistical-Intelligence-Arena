# Hall–Wolff–Yao (1999)：正弦回归与三角误差的条件 CDF

状态：本地候选贡献；运行检查结果见 checks/report.json。类型 `synthetic_dgp`；family `quantile_distribution`（QDI）；mechanism family `hall-wolff-yao-1999-example1-sine-triangular`；贡献 ID `qdi-hall-wolff-yao-1999-sine-triangular-v1`。本轮为正式版来源修订 `formal-source-revision-20261101`，暂不加入最终 QDI task-v1，等待主复核后的确切 ZIP 哈希采纳指令。认领／查重、具名科学审核、他人独立复现与项目接收仍待完成。

## Source and reconstruction

主来源：Hall, Peter; Wolff, Rodney C. L.; Yao, Qiwei (1999). *Methods for Estimating a Conditional Distribution Function*. Journal of the American Statistical Association, 94(445), 154–163，March 1999。[正式 DOI](https://doi.org/10.1080/01621459.1999.10473832)。符合本轮四刊范围；仅收集 Section 3.1 Example 1 的一个机制。固定目标 `F(1|0.1)` 是原条件分布估计任务的标量适配。

读取日期：2026-11-01。**当前实际采用正式发表版**，亲自渲染查看 PDF 第 1、2、4、5、6、7 页，核对封面、题名与版权、Section 3.1、Example 1 及续文、Figure 1、Figure 2(d)、Section 4 C1–C4 和 Remark 1。正式版共 11 页：PDF 第 1 页为出版社封面，PDF 第 2 页对应期刊第 154 页。封面的 “Published online: 17 Feb 2012” 是网络上线日期，不替代 March 1999 的期刊发表日期，不改变贡献 ID。

| 版本角色 | 本地文件名 | 页数 | SHA-256 |
|---|---|---:|---|
| 主来源：正式发表版 | `Methods for Estimating a Conditional Distribution Function(正式版）.pdf` | 11 | `b190e55de32305fe9ca68d5ea91f6142fa7253c707eb20f87351477797bca297` |
| 对照：LSE 作者接受稿 | `Methods_for_estimating_a_conditional_distribution_function(LSERO).pdf` | 24 | `0e33b5db722650d23356bfc9e90bac408a8c32132ef5b32d3bef909d8dc1b99a` |

两个 PDF 均保留在用户提供的原位置，不放进贡献 ZIP。接受稿通过页面图像核查（其正文文本编码损坏），本轮查看页为 1、8、9、10、11、16、17。

| 核对内容 | 正式版定位与结果 | 接受稿对照定位 |
|---|---|---|
| citation／年份／版权 | 封面 PDF 第 1 页；正文 PDF 第 2 页／期刊第 154 页：1999，94(445)，154–163；©1999 American Statistical Association | PDF 第 1 页封面；标为 Accepted version |
| 章节与生成公式 | §3.1 Simulation Studies，Example 1 第一段，PDF 第 4 页／期刊第 156 页右栏；DGP 方程**未编号**。同页左栏编号 (4) 属于带宽准则，不是该 DGP | §3.1 PDF 第 8 页／内部第 6 页；Example 1 PDF 第 11 页／内部第 9 页，方程同样未编号 |
| X 分布 | Example 1 第一段，密度 `1-abs(u)`、支持 `[-1,1]`；众数 0 由密度导出 | PDF 第 11 页／内部第 9 页；所查密度与支持一致 |
| 误差分布及独立性 | 同段：X 与误差是两组彼此独立、各自内部独立且有共同分布的序列；因此样本对 iid。单位噪声尺度；均值 0、方差 1/6 是导出量 | PDF 第 11 页／内部第 9 页；所查分布与独立性一致 |
| 响应与常数 | `Y_i=2*sin(3.1416*X_i)+epsilon_i`；振幅 2、literal 3.1416、误差系数 1，不能替换为 pi | PDF 第 11 页／内部第 9 页；所查方程与常数一致 |
| 原实验第一阶段 | PDF 第 4 页／期刊第 156 页：400 个 n=600 样本；网格步长 x=.067、y=.054 | PDF 第 11 页／内部第 9 页；所查设置一致 |
| 原实验第二阶段／查询 | PDF 第 5 页／期刊第 157 页右栏：200 个 n=600 样本，x=-.5,.1,.7，bootstrap 重复 40 次 | PDF 第 11 页／内部第 9 页；所查设置一致 |
| Figure 1 | PDF 第 5 页／期刊第 157 页左栏；真实条件分布、600 个样本点、回归曲线 `2*sin(3.1416*x)` 和 MADE 图注 | PDF 第 9 页／内部第 7 页；所查曲线公式与样本量一致 |
| Figure 2(d) | PDF 第 6 页／期刊第 158 页，x=.1 的条件分布曲线 | PDF 第 10 页／内部第 8 页，对应同一查询 |
| 正则性 | §4 C1–C4 与 Remark 1，PDF 第 7 页／期刊第 159 页；核、带宽为估计器条件 | PDF 第 16–17 页／内部第 14–15 页；所查条件及其讨论一致 |
| estimand／真值 | 本贡献固定 `P(Y<=1|X=.1)`；x=.1 与原文相关，唯一阈值 y=1 是任务适配；真值 0.8090161307517588 由三角 CDF 推导，并非论文报告的单点数值 | 接受稿也支持同一生成律，不改变目标与推导 |

**比较范围**：本次所查生成方程、参数、密度、支持、独立性、上述实验设置、图注与引用的局部正则条件一致；两个版本排版和页码不同。此结论仅覆盖已逐项检查的片段，不声称全文所有内容或图像完全相同。旧版“正式全文未读／正式版未对照／需用户提供正式 PDF”的当前缺口现已关闭；2026-10-31 的网页 403 只保留为历史访问记录。

2026-11-01 补充材料与代码检索范围：

| 来源／动作 | 本轮结果及边界 |
|---|---|
| [LSE 记录](https://eprints.lse.ac.uk/6631/)，重定向 researchonline.lse.ac.uk/id/eprint/6631 | 页面可读，所见下载为接受稿；未定位对应官方代码／补充链接。在线 PDF 点击返回 Cache miss；本地接受稿已读取。 |
| [Qiwei Yao 发表列表](https://stats.lse.ac.uk/q.yao/qyao.links/publicationsAll.html)，对应 1999 条目 | 所见只有论文 PDF 链接；跟随链接打开 [jasa99.pdf](https://stats.lse.ac.uk/q.yao/qyao.links/paper/jasa99.pdf)，网页工具识别为 23 页论文，非新补充材料或代码来源。 |
| 准确题名加 `code supplement Hall Wolff Yao` 检索 | 未定位明确对应的官方代码或补充材料；不以检索未命中推断不存在。 |
| DOI 直接打开 | 仍返回 403，搜索结果可见出版社书目信息；正式 PDF 已本地取得并阅读，因此该访问失败不再构成正式版来源缺口。 |
| 出版社 `/doi/suppl/10.1080/01621459.1999.10473832` | 工具不可达；不能由此断言没有补充。 |

原作者代码／commit、补充材料、原 RNG／seed 仍为上述范围内 **missing／未定位**；不编造 commit、不宣称作者没有公开材料。仅按原文已明确的机制实现。

原文机制完整写为：

```text
f_T(u) = (1-|u|) 1{-1 <= u <= 1}
X_i iid ~ f_T, epsilon_i iid ~ f_T
{X_i} independent of {epsilon_i}
Y_i = 2*sin(3.1416*X_i) + epsilon_i
```

`config.json` 只有 `original_mechanism_fixed_cdf`。此场景保留原文所有分布与参数，并在场景名及元数据里说明目标适配。无新增噪声、交互、协变量或 dependence。`generate(config,n,seed)` 的 config 是该场景参数对象，n 是观测对行数。论文 n=600 可由调用者传入；本轮规定的 n=128、seed=1729 仅用于接口检查。

相对于原文的 adaptations：

1. 将条件分布曲面／整条曲线的估计问题固定为 `P(Y<=1|X=0.1)`；不复现 MADE、带宽、bootstrap 或置信区间比较。
2. 使用调用者指定的 n、整数 seed 和 Python 局部 `random.Random(seed)`。论文原 RNG／种子 **missing**，不能复现 Figure 1 的逐个点。
3. 用独立均匀变量差实现三角律。若 U,V 独立 Uniform(0,1)，`U-V` 的密度由两个单位区间的重叠长度得到 `1-|u|`。每行使用四次独立抽样分别生成 X 和误差，这是等分布的实现选择，不是从原文抄取的采样算法。

## Target and identification

非因果标量目标：

```text
theta = F_{Y|X=0.1}(1) = P(Y <= 1 | X = 0.1)
m(x) = 2*sin(3.1416*x)
F(y|x) = G(y-m(x)), G 为三角误差 CDF
```

条件概率并非从样本中挑出恰好 X=0.1 的行计算。连续 X 满足 `P(X=0.1)=0`，条件分布一般仅几乎处处确定；此任务采用上述独立加性模型指定的、随 x 连续的条件分布版本。连续性与查询点附近正的设计密度使这个点值有明确含义。没有因果干预方向，也不需要处理可交换性、无混杂、跨世界或中介假设。

抽样与观察条件：样本对 iid；X、Y 全部观察；没有截断选择、测量误差、标签缺失或外部预测器。X 与 Y 在同一行相关，这是回归机制本身，不是跨样本依赖。原文 Example 2 的 AR 结构不属于本机制，未移入本包。

局部正则性：`f_X(0.1)=0.9`。本次 `z=1-m(0.1)` 严格位于 (0,1)，故条件密度 `1-z=0.6180353861199878` 为正，且 `0<theta<1`。查询邻域避开三角密度的折点与边界，`F(1|x)` 在此邻域光滑。三角密度在众数处有折点，在端点趋于 0；不主张全域任意阶光滑性，也不主张整个支持上密度有统一正下界。

正式版 Section 4（PDF 第 7 页／期刊第 159 页）的 C1 涉及固定点的正设计密度、内部概率与 x 方向的局部导数；本查询满足这些局部性质。C3 的绝对正则性在 iid 机制下成立（非零滞后混合系数为 0）。C2 为核条件，C4 为带宽的渐近条件；本包不拟合估计器，未选择核／带宽，因而不把它们作为本包已通过的检查。原文 Remark 1 还讨论了允许 Gaussian kernel 的扩展。可解析真值与机器 PASS 不意味着任何估计方法的推断理论或 coverage 已成立。

## Truth and independent verification

由密度归一化及积分可得：

```text
G(z) = 0                         if z <= -1
       (1+z)^2 / 2               if -1 < z <= 0
       1 - (1-z)^2 / 2           if 0 < z < 1
       1                         if z >= 1
```

固定查询：

```text
m(0.1) = 2*sin(0.31416) = 0.6180353861199878...
z = 1 - m(0.1) = 0.3819646138800122...
theta = 1 - (1-z)^2/2
      = 1 - 2*sin(0.31416)^2
      = 0.8090161307517588...  (binary64)
```

`truth.py` 从生成律直接计算，不依赖样本、不使用 Monte Carlo；返回 value、estimated_error、method、query、location、residual_threshold 和解释。`estimated_error=1e-14` 表示预先设定的浮点舍入容差预算，不是积分误差或形式化跨平台上界；`collection.json` 的绝对真值检查 tolerance 固定为 `1e-12`。此容差不是为获取 PASS 而事后调整。

`verify.py` 使用以下核验路线：

- **独立的数值路线**：80 位 Decimal 运算，独立 Taylor 正弦级数（项小于 1e-75 时停止），直接在 Y 的支持 `[m-1,m+1]` 上积分密度 `1-|y-m|`，不调用 truth 的分段 CDF 或 `math.sin`。在众数 m 处分段做 Simpson，32／64 个子区间细化；各段为一次函数，理想实数运算下积分精确。检查与真值差 <1e-12、差落入声明的 1e-14 舍入预算、细化差 <1e-65。
- **可解析特例**：x=0 时 m=0；阈值 -2,-1,-0.5,0,0.5,1,2 的真值分别为 0,0,1/8,1/2,7/8,1,1。这些是独立有理数基准，不是把 truth 的输出当预期值。二者分别与解析程序及密度积分对照。
- **CDF 分支与支持**：在额外的内部核验查询上检查单调性、[0,1] 范围及平移支持两侧与独立积分一致。它们仅是实现测试，不登记为新场景，也不是同时置信带验证。
- **生成器诊断**：固定 n=65536、seed=271828 的内部样本；检验 X／重建误差的均值 0、二阶矩 1/6、CDF 锚点及联合负象限概率 1/4、乘积均值 0。误差重建仅在 verifier 内进行，绝不输出为模型列。CDF 误差阈值 `d=sqrt(log(2/alpha)/(2N))`，alpha=1e-6；均值和乘积矩阈值 2d、平方矩及象限频率阈值 d 来自有界变量 Hoeffding 界。这是固定种子的分布诊断，不以经验样本定义真值，也不以有限检查证明独立性。
- **接口与可复现性**：检查 X∈[-1,1]、Y∈[-3,3]、重建误差∈[-1,1]；只返回 X/Y 列；同种子一致、不同种子变化；不修改 config 或全局 random 状态。重建误差端点比较只留 1e-14 的浮点减法余量。

独立性的限度必须明确：truth 与 generator 共享输入验证器和 binary64 `math.sin`；高精度积分独立实现计算，却仍共享来源方程、参数和同一作者的理解。生成器诊断直接测试本生成器，并共享 libm 以重建残差；参数 fixture 只能发现配置漂移，不能自行证明原文抄录无误。此轮由同一 AI 协助完成，不冒充另一名人员的独立复现。

## Diversity and scope

`dimension=1`、`effective_dimension=1`，二者都指唯一输入协变量 X；Y 不算输入维数。`high_dimensional=false`。`nonlinear=true` 的依据是 `2*sin(3.1416 X)`；`interactions=false`，没有任何协变量乘积项。误差加性、同方差、有界支持且对称；非重尾。推断目标为固定条件 CDF，未选择分位水平，不生成整张 oracle 曲面或个体真值列。

生成器采用标准库，仅暴露 `{'X': [数值...], 'Y': [数值...]}`，长度为 n；无 NaN/null、潜变量、真实噪声、nuisance 或 individual effects。`requirements.txt` 无第三方依赖；Python >=3.10。检查 report 的环境字段记录实际 Python 版本。

复现命令（从含原版 collect.py 的根目录运行；只执行已审阅的贡献代码）：

```bash
python collect.py check contributions/qdi-hall-wolff-yao-1999-sine-triangular-v1
python collect.py check contributions/qdi-hall-wolff-yao-1999-sine-triangular-v1 --run --n 128 --seed 1729
python collect.py pack contributions/qdi-hall-wolff-yao-1999-sine-triangular-v1 --out submissions/qdi-hall-wolff-yao-1999-sine-triangular-v1-formal-source-revision-20261101.zip
```

不带 `--scenario`，检查全部已登记场景。最终机器结果见包内 `checks/report.json`，样本证据只含少量 X/Y 行和表格哈希，见 `checks/sample.json`；逐文件哈希见 `MANIFEST.json`。不要把 n=65536 的内部诊断误认为主检查要求的 n=128，二者目的不同。源文件若有修改，必须重新 check 后重新 pack。

## Rights and assistance

正式版 PDF 第 2 页／期刊第 154 页列出 ©1999 American Statistical Association。PDF 第 1 页封面指向 [Full Terms & Conditions of access and use](https://www.tandfonline.com/action/journalInformation?journalCode=uasa20)；此处记录封面指向，不将该链接当作开放代码许可证，也不声称已取得未见作者代码的许可。LSE 接受稿封面另说明权利保留。本包仅引用并独立实现数学机制，不含 PDF、原图、作者软件、真实敏感记录、凭据、权重或数据银行。本实现的项目复用许可由贡献者／维护团队确认。

Codex 协助源页核对、推导、代码审阅和执行检查，不冒充具名人类科学审阅或独立复现。本轮只修订 collection.json 与本卡片的来源、定位、版本对照、权利及未决记录；generator.py、truth.py、verify.py、config.json、schema.csv、requirements.txt 与基线逐字节一致，目标、生成律与容差不变。收集工具从学生参考包重新复制原版，核心哈希与基线一致，未修补放行规则。

历史基线 ZIP SHA-256：`cd40cfddd7f6c9e66c16e0f2681b9649fec73b810629db466c62e299b5b370c9`，21623 字节、11 个成员；旧 ZIP 与原贡献目录保留不覆盖。新包使用独立目录和带 `formal-source-revision-20261101` 的文件名。包外报告记载实际命令、环境、检查结果、ZIP 哈希与审计。

当前未决事项：

1. 官方补充材料、作者代码／commit、原 RNG／seed 在上述检索范围内未定位；若以后取得，应单独核对。当前生成机制参数无缺失，正式版取得与所选机制对照已经完成。
2. 维护人认领／查重、具名科学审核、他人独立复现、项目接收仍 pending。工具产生的 awaiting_scientific_review／scientific_acceptance=false 只表示本地候选包状态，不构成维护端收件回执。
3. 本次新包先供主复核，等待确切哈希采纳指令后才可复制进最终 QDI task-v1。未上传、未创建 PR、未向维护人发送消息，也未运行 PFN、bootstrap 或 coverage；点态真值核验不等于同时置信带验证。
