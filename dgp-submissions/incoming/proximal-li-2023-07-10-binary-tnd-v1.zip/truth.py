import math

def truth(config):
    return {"value":float(config['beta']),"estimated_error":0.,"method":"The constant risk multiplier exp(beta) is preserved after averaging over baseline variables","target":"source-population causal log RR (before selection)","auxiliary":{"RR":math.exp(config['beta']),"VE":1-math.exp(config['beta'])},"error_interpretation":"The log RR is analytic. Numerical integration errors are reported by verify."}
