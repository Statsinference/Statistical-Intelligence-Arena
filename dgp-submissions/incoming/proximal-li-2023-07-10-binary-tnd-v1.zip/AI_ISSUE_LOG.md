# AI 问题与处理记录

机制 ID：proximal-li-2023-07-10-binary-tnd-v1

记录日期：2026-10-31。AI 工具：OpenAI Codex。状态：candidate；尚未获得具名科学接收。

本记录涵盖当前对话可确认的文献公式整理、实现一致性检查、提交格式检查和修复工作，
不声明完成正式刊印版的逐页比对、具名人工科学审核或另一人的独立复现。

| 编号 | 问题或边界 | 处理措施 | 当前记录与验证依据 |
|---|---|---|---|
| AI-01 | 此前提交缺少独立的权利与 AI 协助说明 | 在 card.md 增加中英双标题专节及具体机制 ID，披露许可未确认及 AI 使用范围 | 章节和 ID 已写入；本文件与卡片一并进入 MANIFEST 哈希清单 |
| AI-02 | 卡片缺少明确候选状态 | 在标题后加入模板规定的英文 Status 行，并在权利节再次说明尚未科学接收 | 文本检查；collection.json 和 MANIFEST 继续保持 scientific_acceptance=false |
| AI-03 | 此前出现 card.md 内容与旧检查清单哈希不一致 | 所有卡片及日志写定后，重新执行全部场景 check --run，再由 pack 生成新 ZIP | 执行结果见 checks/report.json；逐文件哈希见 MANIFEST.json；不手工伪造 passed 或替换旧哈希 |
| AI-04 | 原 RAR 多目录合集不能直接作为单机制上传包 | 使用学生参考包 pack 接口生成单机制 ZIP，根目录直接包含 collection.json、card.md、checks/ 与 MANIFEST.json | 本包由 pack_collection 生成，另用 inspect_archive 检查目录、成员清单和 SHA-256 |
| AI-05 | 报告及索引需对应最终 ZIP 字节 | 打包后从实际 ZIP 计算 SHA-256，更新 SHA256SUMS、CSV/JSON 索引、README 和报告第3.3节 | 外层交付清单及报告采用同一最终索引；报告不进入本机制 ZIP |
| AI-06 | 所读版本与正式刊印版尚未逐页对照 | 保留 source_evidence.json 的读取版本、来源定位和版本边界，不宣称终刊逐页核验完成 | 未决；参数转录责任在贡献者，版本核对需继续完成 |
| AI-07 | 贡献认领、跨任务去重和科学接收尚未完成 | 继续保留 candidate/pending 状态，不把程序通过写成正式接收 | 未决；由维护人安排，近端中介的 T09 归属亦以其决定为准 |
| AI-08 | 代码与文档的公开分发许可尚未确认 | 在卡片明确披露；没有由 AI 代签、授予额外许可或补造授权证明 | 未决；贡献者与维护人确认 |
| AI-09 | 文本读取会规范化 Windows 换行，不能与 ZIP 原始字节直接作字符串等值比较 | 验包时对 ZIP 成员与源文件使用原始字节比较，并按 SHA-256 核对 | 属于交付验证脚本修正，不改变科学实现；最终字节一致性由验包记录确认 |

## 核验范围

检查器以 n=128、seed=1729 运行本贡献的全部登记场景；本次不更改生成器、参数配置、
真值函数、verify 逻辑、schema 或来源证据。可复查的运行输出和样本分别位于
checks/report.json、checks/sample.json。程序执行结果不替代论文转录的人工负责核对。

本日志描述已做的文本修改和所执行的核验流程；最终是否通过以随包的机器记录为准。
若任何检查失败，不能据本日志声称通过，须保留失败记录并修复后重新检查和打包。

## AI-10 PR #11 线上生成方程字段修复 2026-10-31

PR #11 的 Actions 报 Missing generating equations in collection.json。生成方程原已写在 card.md，但 collection.json 没有 equations 字段。本次将卡片中完整生成过程（含分布、参数、噪声、独立性、选择规则及 TND 场景范围）原文转录为 JSON 根级 equations 字符串数组，未改动科学方程或实现。重新执行全场景 check --run、schema 校验、目录方程导出检查和 pack/inspect_archive；checks/ 与 MANIFEST 由工具重新生成。本地结果不代表线上检查、去重或科学接收通过。
