# Binary negative-control proxies in test-negative design

Status: candidate; not scientifically accepted.

## 文献来源

Li K Q, Shi X, Miao W, Tchetgen Tchetgen E. *Double Negative Control Inference in Test-Negative Design Studies of Vaccine Effectiveness*. Journal of the American Statistical Association, 2024, 119(547):1859–1870. DOI: [10.1080/01621459.2023.2220935](https://doi.org/10.1080/01621459.2023.2220935)。

读取材料为作者仓库 `KenLi93/TND_methods` 中 `TND-manuscript-supplement.pdf`，固定 commit [`ba9dc3c581390fcefce0ca4cdabf65688a91a455`](https://github.com/KenLi93/TND_methods/tree/ba9dc3c581390fcefce0ca4cdabf65688a91a455)，PDF 第25页，Section I，Table S.1 的二元代理块。该定位对应补充材料 PDF 页码。任务类别为 `proximal`；`collection.json` 的 `source_relation` 为 `adapted_from_source`。

ID 日期说明：`proximal-li-2023-07-10-binary-tnd-v1` 中的 `2023-07-10` 沿用论文 online-first（在线优先发表）日期；`source.year=2024` 按正式卷期的发表年份登记。ID 日期、正式卷期年份和所读版本日期分别记录，含义不同。


## 二元数据生成方程

以来源总体中的独立个体为单位，令 `U` 表示未观测二元混杂，`D` 表示其他疾病指示，`S` 为纳入检验阴性样本的指示。各二元节点按顺序使用独立的均匀随机数生成：

1. `U ~ Bernoulli(0.5)`。
2. `Z | U ~ Bernoulli(0.2 + 0.4U)`。
3. `A | U ~ Bernoulli(0.2 + 0.4U)`。
4. `Y | A,U ~ Bernoulli(exp(η0 + βA - 0.693U))`，其中 `η0=ln(0.01)`。
5. `W | U ~ Bernoulli(0.02 - 0.01U)`。
6. `D | U ~ Bernoulli(0.02 - 0.015U)`。
7. `S | Y,D,W,U ~ Bernoulli(max(Y,D,W) × (0.1 + 0.4U))`。

只保留 `S=1` 的记录，观察列为 `A,Z,W,Y`；内部变量为 `U,D,S`，不写入模型输入数据表。二元节点的支持集均为 `{0,1}`。分配概率及疾病风险通过方程计算，生成器不裁剪概率。


## 登记场景

四个场景均固定 `η0=log(0.01)`，只改变处理效应 `β∈{log(0.2), log(0.5), log(0.7), 0}`。
默认场景为 `table-eta001-rr050`；下表与 config.json 一一对应。

| 场景 ID | RR=exp(β) | β 的设定与数值 |
|---|---:|---|
| `table-eta001-rr020` | 0.2 | `log(0.2)` = -1.6094379124341 |
| `table-eta001-rr050` | 0.5 | `log(0.5)` = -0.6931471805599453 |
| `table-eta001-rr070` | 0.7 | `log(0.7)` = -0.3566749439387324 |
| `table-eta001-rr100` | 1.0 | `0` = 0 |

每套 TND 的四个参数场景仍属于同一个 mechanism family，不按场景增加 DGP 数量。

## 因果目标和识别条件

目标为来源总体选择前的 `βlogRR = log(E[Y(1)] / E[Y(0)])`。由于所有 `U` 水平的风险均含同一乘子 `exp(βA)`，有

`E[Y(a)] = exp(η0+βa) × E[exp(-0.693U)]`，故 `βlogRR=β`。

对应疫苗有效性辅助量为 `VE=1-exp(β)`。识别条件采用一致性、无干扰、给定潜在 `U` 的交换性、处理正性、代理排除限制以及二元代理的秩与桥函数条件。选择机制在 `Y,D,W,U` 给定后定义，目标总体为选择前的来源总体。

## 真值及独立核验

`truth.py:truth` 解析返回 `β`，`estimated_error=0`，另返回 `RR=exp(β)` 与 `VE=1-exp(β)`。`verify.py:verify` 枚举 `U,A,Z,W,Y,D` 六个二元变量计算总体风险和 `S=1` 的选择概率，核对四个场景的风险比、零效应特例、二元处理桥恒等式与入选样本矩。观测样本均值采用 `n=4096` 的固定种子抽样进行诊断；解析枚举与随机抽样分别实现。

## 属性与接口范围

该机制没有观测基线 `X`；基线总维数和有效维数均为0，`U` 为二元潜变量。结局风险使用对数链接，选择概率含 `max(Y,D,W)` 与 `U` 的乘积结构。代码仅向下游返回经选择的4列观测数据。
## 接口、观测数据与数值处理

`generator.py:generate(config, n, seed)` 接收 `config.json` 中指定场景的参数字典、正整数 `n` 和非负整数 `seed`。随机数由 NumPy 的 `Generator(PCG64(seed))` 产生。同一随机种子复现同一观测数组。`schema.csv` 给出所有变量的类型与可观测性。概率由相应分布表达式计算；当概率非有限或不在 `[0,1]` 范围内时，生成函数抛出异常，不执行概率裁剪。所有配置保存在 `config.json`，主要函数位于 `generator.py`、`truth.py` 和 `verify.py`，依赖范围位于 `requirements.txt`。

## 权利与 AI 协助 / Rights and assistance

Status: candidate；尚未获得具名科学接收，本卡片不构成科学审核结论。

### 来源与权利

本机制（proximal-li-2023-07-10-binary-tnd-v1）的论文、补充材料及作者原始代码的相关权利归各自权利人所有；
具体来源、读取版本与公式定位见本卡片「文献来源」及 source_evidence.json。

本贡献包仅包含依据所列生成机制独立重写的实现、参数配置与核验记录，未附带论文或补充材料全文、
作者原始代码、真实个体数据或模型权重。引用文献不表示取得相关材料的额外再分发授权。
本贡献代码的公开分发许可与适用范围由贡献者与项目维护人确认，目前尚未确认。

### AI 协助与核验

本贡献在整理过程中使用 OpenAI Codex 辅助：从所读版本中提取公式与参数、核对公式与实现的一致性、
整理贡献包结构与逐文件哈希、运行学生参考包检查器（n=128，seed=1729）并重新打包。
AI 未逐页对照正式刊印版与所读版本的差异；参数转录、识别假设与真值推导由贡献者负责核对。
可复查的执行记录见 checks/report.json 与 checks/sample.json；问题及处理记录见 AI_ISSUE_LOG.md。

本地检查通过仅表示所执行的格式、运行与数值核验通过，不等同于具名科学审核、
另一人的独立复现或项目正式接收。

### 未决事项

- 贡献认领与重复机制核查（维护人）
- 所读预印本／补充材料与正式刊印版尚未逐页对照
- 具名科学审核与另一人的独立复现
- 代码与文档的公开分发许可
