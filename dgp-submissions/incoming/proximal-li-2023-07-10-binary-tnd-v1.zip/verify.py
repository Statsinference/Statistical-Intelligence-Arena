import itertools
import numpy as np
from numpy.polynomial.hermite import hermgauss
from numpy.polynomial.legendre import leggauss
from generator import generate, _draw
from truth import truth


def verify(config):
    checks=[]
    def equal(name,observed,expected,tol=1e-10):
        error=float(np.max(np.abs(np.asarray(observed)-np.asarray(expected))))
        checks.append({"name":name,"passed":bool(np.isfinite(error) and error<=tol),"details":{"max_absolute_error":error,"tolerance":float(tol)}})
    def mc(name,values,expected):
        v=np.asarray(values);se=float(v.std(ddof=1)/np.sqrt(v.size))
        equal(name,v.mean(),expected,max(1e-12,6*se))
    c=config
    expected=dict(SOURCE_ANCHOR)
    if 'beta' in expected:expected['beta']=c['beta']
    checks.append({"name":"fixed_source_parameter_anchor","passed":c==expected,"details":"Config matches the fixed parameter transcription. This catches later edits but cannot detect an error in the original transcription."})
    # Exact integration by binary enumeration, independently from generator.
    risks=[]
    for a in [0,1]:
        risk=0.
        for u in [0,1]:
            for y in [0,1]:
                p=np.exp(c['eta0']+c['beta']*a-.693*u)
                risk+=.5*y*(p if y else 1-p)
        risks.append(risk)
    equal('enumerated_population_log_RR',np.log(risks[1]/risks[0]),truth(c)['value'])
    null_risks=[sum(.5*np.exp(c['eta0']-.693*u) for u in [0,1]) for a in [0,1]]
    equal('null_effect_special_case',np.log(null_risks[1]/null_risks[0]),0)
    for a,u in itertools.product([0,1],repeat=2):
        pz=.2+.4*u;pa=.2+.4*u
        q0,q1=(.625,3.75) if a==0 else (20/3,-5/3)
        equal('binary_bridge_'+str(a)+str(u),((1-pz)*q0+pz*q1)*(pa if a else 1-pa),1)
    totals=np.zeros(5)
    for u,a,z,w,y,d in itertools.product([0,1],repeat=6):
        probabilities=[.5,.2+.4*u,.2+.4*u,.02-.01*u,np.exp(c['eta0']+c['beta']*a-.693*u),.02-.015*u]
        mass=np.prod([p if val else 1-p for val,p in zip([u,a,z,w,y,d],probabilities)])
        mass*=max(y,d,w)*(.1+.4*u)
        totals+=mass*np.array([1,a,z,w,y])
    sample=generate(c,4096,314163)
    for name,expected in zip(['A','Z','W','Y'],totals[1:]/totals[0]):
        se=np.sqrt(expected*(1-expected)/4096)
        equal('selected_mean_'+name,np.mean(sample[name]),expected,6*se)
    checks.append({'name':'enumerated_selection_probability','passed':bool(0<totals[0]<1),'details':{'probability':float(totals[0])}})
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'shared_components':'Every check uses the same transcribed source model. The structural, enumeration and quadrature calculations run separately from the generator; sample-moment tests call it. Independent review of the source transcription is still required.',
            'limits':'Finite grids and simulation checks cannot establish identification, behavior in the tails, or estimator coverage. Tolerances were set in advance. Null-path tests are diagnostic cases, not new scenarios.'}

SOURCE_ANCHOR = {'u_probability': 0.5, 'z_probability': [0.2, 0.4], 'a_probability': [0.2, 0.4], 'eta0': -4.605170185988091, 'beta': -0.6931471805599453, 'y_u': -0.693, 'w_probability': [0.02, -0.01], 'd_probability': [0.02, -0.015], 's_probability': [0.1, 0.4], 'selected_sample': True, 'max_candidates': 100000000}
