"""Independent exact Gaussian cubature and source-constant checks."""
import math

def verify(config):
    fixture = {"covariate_sd": 1.0, "outcome_noise_sd": 1.0,
               "observation_logit_coefficients": [1.0, -3.0, 2.0],
               "missing_outcome_placeholder": 0.0, "paper_sample_size": 500,
               "paper_simulation_repetitions": 1000}
    nodes = (-math.sqrt(3.0), 0.0, math.sqrt(3.0))
    weights = (1/6, 2/3, 1/6)
    sx = float(config["covariate_sd"])
    cubature = sum(w1*w2*(sx*(z1+z2))**3
                   for z1,w1 in zip(nodes,weights)
                   for z2,w2 in zip(nodes,weights))
    c = config["observation_logit_coefficients"]
    logits = (c[0], c[0]+c[1], c[0]+c[2])
    checks = [
        {"name":"source_constants","passed":config == fixture,
         "details":"Section 4 first simulation: standard Gaussian X; cubic mean; variance 1; logit 1-3X1+2X2^2; n=500, 1000 repeats."},
        {"name":"independent_gaussian_cubature","passed":abs(cubature)<1e-12,
         "details":f"3x3 Gaussian rule integrates cubic exactly: {cubature:.17g}."},
        {"name":"observation_logit_spot_checks",
         "passed":all(abs(a-b)<1e-12 for a,b in zip(logits,(1,-2,3))),
         "details":"Logits at (0,0),(1,0),(0,1) are 1,-2,3."},
        {"name":"placeholder_finite","passed":math.isfinite(float(config["missing_outcome_placeholder"])),
         "details":"Unobserved full Y is never an exported column."}
    ]
    return {"passed":all(x["passed"] for x in checks),"checks":checks,
            "shared_components":"Cubature shares published equations, but not truth.py's symmetry calculation."}
