"""Analytic full-data population truth, independent of generated rows."""
import math

def truth(config):
    sx, sy = float(config["covariate_sd"]), float(config["outcome_noise_sd"])
    if not (math.isfinite(sx) and sx > 0 and math.isfinite(sy) and sy > 0):
        raise ValueError("standard deviations must be finite and positive")
    return {"value": 0.0, "estimated_error": 0.0,
            "method": "Exact odd moment of centered Gaussian X1+X2",
            "target": "Full-data E(Y)"}
