# MAR mean response with cubic outcome regression

**Candidate MDI mechanism; local validation is not scientific acceptance.**

Hu, Follmann and Qin (2010), “Semiparametric dimension reduction estimation for mean response with missing data,” *Biometrika* 97(2):305–319, DOI [10.1093/biomet/asq005](https://doi.org/10.1093/biomet/asq005). The [open article](https://pmc.ncbi.nlm.nih.gov/articles/PMC3412576/) gives the mechanism in Section 4, “Simulation studies,” first simulation, paragraph beginning “In the first simulation.” This is journal p. 311, PDF p. 7 of the 15-page PMC article PDF. A local review copy is at `/Users/xu/Desktop/PEN/论文资料/Hu_Follmann_Qin_2010_Biometrika_Missing_Data.pdf`; it is outside the contribution package.

For each iid individual, X1 and X2 are independent N(0,1). Given X, Y is N((X1+X2)^3,1). Let R=1 mean Y is observed. Conditional on X, R is independent of Y and has probability

```text
pi(X) = 1 - 1/[1+exp(1-3 X1+2 X2^2)] = expit(1-3 X1+2 X2^2).
```

This is MAR given fully observed X. Positivity holds at every finite X, but not uniformly over the unbounded Gaussian support. The target is the full-data superpopulation mean theta=E(Y), not the complete-case mean. X1+X2 is centered Gaussian, so its third moment is zero, and independent outcome noise has mean zero. Therefore theta=0 is **derived from the equations**, not a value quoted from the paper.

The paper's estimator experiment repeats n=500 sampling 1000 times. This contribution implements one sample per call; the smoke test uses n=128 and does not reproduce estimator comparisons. Working selection/outcome models are estimator specifications, not separate DGPs.

The returned columns are X1, X2, R, Y_observed. If R=1, Y_observed=Y; if R=0, Y_observed=0 is a **placeholder**, not a measured response. Methods must mask Y_observed with R. The unobserved full Y is never exported. This finite-value encoding is the interface adaptation; the underlying source distributions remain fixed. Both covariates are active. The cubic contains X1^2 X2 and X1 X2^2 interactions; the observation logit includes X2^2. This is nonlinear and two dimensional, not high dimensional.

Truth uses odd-moment symmetry. Independent verification uses a 3-by-3 Gaussian quadrature rule exact for cubic polynomials, checks source constants and spot-checks selection logits. It does not test estimator coverage or confer scientific approval. No paper PDF, author software, or real data is redistributed in the contribution. AI assisted source extraction, implementation and drafting; the PMC section and PDF p. 7 were cross-checked. Named source and rights review remain pending.
