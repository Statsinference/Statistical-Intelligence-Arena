"""Population CATE at the declared query points.

The target is never estimated from generated rows: it is evaluated from the
declared mechanism.  The query points are part of the estimand definition and are
repeated in card.md and collection.json.
"""
import math

QUERY_POINTS = {
    "primary": {
        "X1": 0.3333333333333333,
        "X2": 0.3333333333333333,
        "X3": 0.25,
        "X4": 0.5,
        "X5": 0.5
    },
    "secondary": {
        "X1": 0.8,
        "X2": 0.2,
        "X3": 0.6,
        "X4": 0.5,
        "X5": 0.5
    }
}


def tau_at(x):
    """CATE surface of the mechanism, evaluated at one query point."""
    return (
        (1.0 + 1.0 / (1.0 + math.exp(-20.0 * (x["X1"] - 1.0 / 3.0)))) * (1.0 + 1.0 / (1.0 + math.exp(-20.0 * (x["X2"] - 1.0 / 3.0))))
    )


def truth(config):
    scale = float(config["tau_scale"])
    primary = tau_at(QUERY_POINTS["primary"]) * scale
    secondary = tau_at(QUERY_POINTS["secondary"]) * scale
    return {
        "value": primary,
        "estimated_error": 1e-12,
        "method": "Closed form: tau(x0) = s(x1) s(x2) with s the source sigmoid; the confounding variables do not enter the effect, so the value can be compared directly with the randomised sibling contribution.",
        "target": "tau(x0) at QUERY_POINTS['primary'], evaluated from the declared mechanism",
        "value_at_secondary_query": secondary,
        "scale_used": scale,
    }
