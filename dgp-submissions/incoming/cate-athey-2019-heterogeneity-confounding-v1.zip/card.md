# Athey-Tibshirani-Wager (2019) third setting: heterogeneity and confounding combined

**Contribution `cate-athey-2019-heterogeneity-confounding-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `athey-2019-heterogeneity-confounding`

## Source and reconstruction

- Citation: Athey, S., Tibshirani, J. and Wager, S. (2019). Generalized random forests. The Annals of Statistics 47(2), 1148-1178. DOI: 10.1214/18-AOS1709.
- Venue / year: The Annals of Statistics, 2019
- Link: https://arxiv.org/abs/1610.01271
- **Exact locator**: Section 6.2 'Example: Causal Forests', arXiv:1610.01271v4 (5 Apr 2018) PDF pp.22-23: the section opens on p.22; the working equations tau(x) and e(x) = (1/4)(1 + beta_{2,4}(x3)), m(x) = 2 x3 - 1, the sentence defining the third setting ('We also consider a third setting with both heterogeneity and confounding, that combines tau(.) from the first setting with m(.) and e(.) from the second') and Table 1 all appear on p.23. The settings are unnumbered prose, so the locator gives page + paragraph instead of an equation number.
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **X1-X5**: `Xj ~ Uniform(0,1) independently, j = 1..5`
2. **Treatment**: `P(A=1|X) = 0.25 (1 + 20 X3 (1-X3)^3)`
3. **Baseline**: `m(X) = 2 X3 - 1`
4. **Heterogeneity**: `tau(X) = s(X1) s(X2), s(u) = 1 + 1/(1 + exp(-20 (u - 1/3)))`
5. **Outcome**: `Y = m(X) + A tau(X) + eps, eps ~ Normal(0,1)`

Sampling unit: individual · dependence: independent and identically distributed

Fixed parameters: sigmoid steepness 20 and centre 1/3; beta density shape (2,4); baseline slope 2 and intercept -1; noise variance 1.

### Adaptations relative to the source

- Ambient dimension fixed at p = 5 instead of the source's p in {10, 20}; the third setting needs only X1, X2 (effect) and X3 (confounding).
- The source writes Y ~ N(m(X) + (W - 0.5) tau(X), 1); this package uses A in {0,1} and Y = m(X) + A tau(X) + eps with eps ~ N(0,1). The CATE is unchanged.
- The effect surface is identical to cate-wager-2018-sigmoid-product-v1 because the source builds the third setting by reusing tau from its first setting; the difference between the two contributions is the confounding structure, which is the point of this row of Table 1.
- The source aggregates over 60 replications with B = 2000 trees; no forest is fitted here.

## Target and identification

- Symbol: `tau(x0) = E[Y(1) - Y(0) | X = x0]`
- Definition: Conditional average treatment effect at the declared query points for the combined setting: sigmoid-product heterogeneity on X1, X2 together with a beta-density propensity and a linear baseline on X3.
- Query points (part of the estimand): `primary`: (X1 = 0.3333333333333333, X2 = 0.3333333333333333, X3 = 0.25, X4 = 0.5, X5 = 0.5); `secondary`: (X1 = 0.8, X2 = 0.2, X3 = 0.6, X4 = 0.5, X5 = 0.5)

Identification assumptions:

- SUTVA: one version of treatment, no interference
- Unconfoundedness: treatment depends on X3, which also enters the baseline m(X) = 2 X3 - 1, so the design is observational
- Overlap: 0.25 <= e(X) <= 0.777 because 20 u (1-u)^3 peaks at u = 1/4
- Homoscedastic Gaussian noise with unit variance

This is the row of Table 1 where confounding and heterogeneity are both present. Compared with the randomised sibling, the effect surface is identical and only the assignment mechanism changes, which isolates the cost of confounding.

## Truth and independent verification

Additive outcome: the contrast equals tau(x) because m(X) and the noise cancel. At x1 = x2 = 1/3 the sigmoids equal 1.5, so tau = 2.25 regardless of X3.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and confirms end-to-end that the realised
outcome column of `generator.py` carries the declared surface (arm-contrast shift
equals the mean of tau over treated rows, at identical seed). Both routes share the
declared mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 5 (effective 3) · high dimensional: False · interactions: True · nonlinear: True
- Because the effect does not depend on X3 while the assignment does, any bias is pure confounding bias, not effect heterogeneity. No uniform overlap beyond [0.25, 0.777]; the unsupported region is empty by construction.

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| X1 | covariate | float | 0.0 | 1.0 | true |
| X2 | covariate | float | 0.0 | 1.0 | true |
| X3 | covariate | float | 0.0 | 1.0 | true |
| X4 | covariate | float | 0.0 | 1.0 | true |
| X5 | covariate | float | 0.0 | 1.0 | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by the Institute of Mathematical Statistics. No PDF or author code is redistributed.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: p is fixed at 5; the source's p in {10, 20} grid is not reproduced.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
