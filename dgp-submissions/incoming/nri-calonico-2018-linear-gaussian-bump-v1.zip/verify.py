"""Independent verification for CCF2018 supplement S.II.7 Models 2 and 4.

Verification strategy (independent of truth.py):
1. Evaluates m(x0) via a second, differently-coded arithmetic path.
2. Checks a zero-bump special case: setting bump_amplitude=0 gives m(x)=linear*x,
   so m(0)=0 regardless of model (linear_coeff*0 = 0).
3. For Model 2, also checks the analytic exact value 2.0 at x0=0.
4. For Model 4, checks against math.sqrt-based formula 5/sqrt(2*pi).
5. Checks that truth(config) and the independent computation agree to < 1e-12.

Both implementations share the declared DGP equations and config; they do not
share code paths (different operator order, decomposed vs. composed arithmetic).
Named scientific review and independent-person reproduction remain pending.
"""
import math
import importlib.util
from copy import deepcopy
from pathlib import Path


def _load_truth():
    path = Path(__file__).with_name("truth.py")
    spec = importlib.util.spec_from_file_location("nri_lgb_truth", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _phi_independent(z):
    """Independent coding of standard Gaussian density (different operator order)."""
    two_pi = 2.0 * math.pi
    return math.exp(-(z ** 2) / 2.0) / math.sqrt(two_pi)


def _m_model2_independent(config, x):
    """Independent path: decompose exp argument, use ** instead of *."""
    a = config["linear_coeff"]
    A = config["bump_amplitude"]
    w = config["bump_width_sq"]
    c = config["bump_center"]
    diff = x - c
    return a * x + A * math.exp(-(w * (diff ** 2)))


def _m_model4_independent(config, x):
    """Independent path: use decomposed phi and different multiplication order."""
    a = config["linear_coeff"]
    A = config["bump_amplitude"]
    s = config["phi_scale"]
    c = config["bump_center"]
    z = s * x - s * c           # different factoring
    phi_z = _phi_independent(z)
    return x * a + A * phi_z    # swapped multiplication order


def _compute_independent(config, x0):
    model = config.get("model_name", "M2")
    if model == "M2":
        return _m_model2_independent(config, x0)
    elif model == "M4":
        return _m_model4_independent(config, x0)
    else:
        raise ValueError("Unknown model_name: " + str(model))


def verify(config):
    truth_module = _load_truth()
    oracle = truth_module.truth(config)
    oracle_val = oracle["value"]
    x0 = config["query_point"]
    model = config.get("model_name", "M2")

    checks = []

    # --- Check 1: independent arithmetic path agrees with oracle ---
    indep_val = _compute_independent(config, x0) + config.get("noise_mean", 0.0)
    diff1 = abs(oracle_val - indep_val)
    checks.append({
        "name": "independent_arithmetic_path",
        "passed": diff1 < 1e-12,
        "details": (
            f"truth.py={oracle_val:.16g}; independent path={indep_val:.16g}; "
            f"difference={diff1:.3g}. "
            "Different operator order and factoring; both share declared equations."
        ),
    })

    # --- Check 2: zero-bump -> linear response, m(0) = 0 ---
    # At x0=0, m(0) = linear_coeff*0 + bump_contribution = bump_contribution
    # Setting bump_amplitude=0 gives m(0) = 0 (with noise_mean=0).
    zero_bump = deepcopy(config)
    zero_bump["bump_amplitude"] = 0.0
    zero_bump_val = _compute_independent(zero_bump, 0.0) + zero_bump.get("noise_mean", 0.0)
    checks.append({
        "name": "zero_bump_gives_zero_at_origin",
        "passed": abs(zero_bump_val) < 1e-15,
        "details": (
            f"Setting bump_amplitude=0: m(0) = linear_coeff*0 = 0. "
            f"Got {zero_bump_val:.3g}. "
            "Special case: confirms bump term is the only source of nonlinearity at x0=0."
        ),
    })

    # --- Check 3: model-specific exact value at x0=0 ---
    if model == "M2":
        # m(0) = 2*0 + 2*exp(-64*0) = 2*exp(0) = 2.0
        expected = float(config["bump_amplitude"] * math.exp(0.0))
        diff3 = abs(oracle_val - expected - config.get("noise_mean", 0.0))
        checks.append({
            "name": "model2_exact_value_at_origin",
            "passed": diff3 < 1e-12,
            "details": (
                f"m(0) = bump_amplitude * exp(0) = {config['bump_amplitude']} exactly. "
                f"Oracle={oracle_val:.16g}; expected={expected:.16g}; diff={diff3:.3g}."
            ),
        })
    elif model == "M4":
        # m(0) = 0 + 5*phi(0) = 5/sqrt(2*pi)
        expected = config["bump_amplitude"] / math.sqrt(2.0 * math.pi)
        actual = oracle_val - config.get("noise_mean", 0.0)
        diff3 = abs(actual - expected)
        checks.append({
            "name": "model4_exact_value_at_origin",
            "passed": diff3 < 1e-12,
            "details": (
                f"m(0) = bump_amplitude/sqrt(2*pi) = {config['bump_amplitude']}/sqrt(2pi)"
                f" = {expected:.16g}. "
                f"Oracle={actual:.16g}; diff={diff3:.3g}."
            ),
        })

    # --- Check 4: symmetry of Gaussian bump at x0=0 (bump_center=0 case) ---
    # For both models, phi or exp(-w*x^2) is symmetric, so m(delta) - m(-delta)
    # = 2*linear_coeff*delta for small delta (exact for the linear part).
    c = config.get("bump_center", 0.0)
    if abs(c) < 1e-10:  # only when bump is centered at 0
        delta = 0.1
        m_pos = _compute_independent(config, delta)
        m_neg = _compute_independent(config, -delta)
        lc = config["linear_coeff"]
        # m(delta) - m(-delta) = 2*linear_coeff*delta exactly (bump part cancels)
        expected_diff = 2.0 * lc * delta
        actual_diff = m_pos - m_neg
        diff4 = abs(actual_diff - expected_diff)
        checks.append({
            "name": "symmetric_bump_antisymmetric_residual",
            "passed": diff4 < 1e-12,
            "details": (
                f"Bump centered at 0: m(delta)-m(-delta) = 2*linear_coeff*delta "
                f"= {expected_diff:.6g}. Got {actual_diff:.6g}; diff={diff4:.3g}. "
                "Confirms bump symmetry and linear-term separation."
            ),
        })

    passed = all(c["passed"] for c in checks)
    return {
        "passed": passed,
        "checks": checks,
        "shared_components": (
            "Both truth.py and verify.py use the declared DGP equations from the source. "
            "They differ in operator order, factoring, and phi implementation. "
            "A named independent reviewer should verify transcription against the paper PDF."
        ),
    }
