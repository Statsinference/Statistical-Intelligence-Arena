# NRI collection: CCF2018 Models 2 and 4 — linear plus Gaussian bump

**Status: candidate; not scientifically accepted.**

Source: Calonico, S., Cattaneo, M. D., and Farrell, M. H. (2018). On the Effect of Bias Estimation on Coverage Accuracy in Nonparametric Inference. *Journal of the American Statistical Association* 113(522), 767–779. DOI [10.1080/01621459.2017.1285776](https://doi.org/10.1080/01621459.2017.1285776). Supplement dated December 16, 2017.

## Source and reconstruction

**Supplement §S.II.7** ("Complete Simulation Results", printed p. 80, PDF p. 81): defines six regression models for the Monte Carlo study. This contribution collects Models 2 and 4.

**Main text §4** (printed p. 776, PDF p. 10): representative simulation for Model 5 (a more complex bump); sets the evaluation grid x ∈ {−2/3, −1/3, 0, 1/3, 2/3}.

### Shared DGP structure (all models, §S.II.7)

```
Y_i = m(X_i) + eps_i,    i = 1, ..., n
X_i ~ U[-1, 1]           (iid)
eps_i ~ N(0, 1)          (iid, independent of X_i)
```

Paper simulation uses n = 500, 5000 replications. This collection uses the population equations only; no coverage simulation is run here.

### Model 2 — linear plus Gaussian bump (§S.II.7)

```
m(x) = 2x + 2 * exp(-64 * x^2)
```

Source attribution: "Models 1 to 3 were used by Fan and Gijbels (1996) and Cattaneo and Farrell (2013)." (supplement p. 81). Parameter values (2, 2, 64) read directly from the printed expression.

### Model 4 — linear plus scaled Gaussian density (§S.II.7)

```
m(x) = x + 5 * phi(10x),    phi(z) = exp(-z^2/2) / sqrt(2*pi)
```

Source attribution: "Models 4 to 6 are from Hall and Horowitz (2013), with some originally studied by Berry et al. (2002)." (supplement p. 81). Parameter values (1, 5, 10) read directly from the printed expression.

### Evaluation grid (§4 / §S.II.7)

x ∈ {−2/3, −1/3, 0, 1/3, 2/3}. This contribution registers x₀ = 0 as the fixed scalar query point for the NRI estimand. This is the point of maximum bump curvature; it is also where coverage distortions are most severe in the paper's simulation.

## Target and identification

**Estimand:** m(x₀) = E[Y | X = x₀] at the fixed query point x₀ = 0.

Because eps has mean 0 by the paper's parameterisation (noise_mean = 0), E[Y | X = x₀] = m(x₀). No causal interpretation applies. This is a nonparametric regression inference (NRI) task; the target is the conditional mean, not a treatment effect, marginal effect, or causal contrast.

**Applicable assumptions:**

- X and eps are independent; E[eps] = 0 (direct from the DGP specification).
- m(x) is smooth on [−1, 1] (Gaussian bump is C-infinity); standard regularity conditions for local polynomial regression hold.
- Inference is pointwise at the single fixed query x₀ = 0; this is **not** a simultaneous confidence band over the evaluation grid.
- No treatment, mediator, instrumental variable, or interference structure.

## Truth and independent verification

### Model 2 at x₀ = 0

```
m(0) = 2 * 0 + 2 * exp(-64 * 0^2)
     = 0     + 2 * exp(0)
     = 2 * 1
     = 2.0   (exact)
```

No approximation; truth.py returns 2.0 with estimated_error = 1e-14 (float rounding bound).

### Model 4 at x₀ = 0

```
m(0) = 0 + 5 * phi(0)
     = 5 * exp(0) / sqrt(2*pi)
     = 5 / sqrt(2*pi)
     ≈ 1.9947114020071635   (to 16 significant figures)
```

5/sqrt(2*pi) is irrational; we evaluate via math.sqrt and math.exp. truth.py reports estimated_error = 1e-14 (2 ULP bound for IEEE 754 double).

### Independent verification routes (verify.py)

1. **Independent arithmetic path:** truth.py uses `math.exp(-w*(x-c)**2)`; verify.py uses `math.exp(-(w*(diff**2)))` with `diff = x-c` and reordered multiplications. Both return the same value to < 1e-12.
2. **Zero-bump special case:** setting bump_amplitude = 0 gives m(0) = 0 (linear_coeff × 0 = 0). This tests that the bump term is isolated correctly.
3. **Model 2 exact anchor:** m(0) = bump_amplitude × exp(0) = bump_amplitude exactly.
4. **Model 4 exact anchor:** m(0) = bump_amplitude / sqrt(2π) via an independent sqrt formula.
5. **Symmetric-bump antisymmetric residual:** for bump_center = 0, m(δ) − m(−δ) = 2 × linear_coeff × δ exactly (the symmetric bump cancels). Checked at δ = 0.1.

**Shared components:** both truth.py and verify.py use the declared DGP equations and config object. They differ in operator order and phi decomposition. A named reviewer must independently verify the transcription against the paper's printed equations.

## Diversity and scope

- **dimension = 1, effective_dimension = 1.** One covariate X fully determines E[Y|X]; no high-dimensional structure, no interactions, no irrelevant padding.
- **nonlinear = true.** The Gaussian bump exp(−64x²) (M2) or phi(10x) (M4) creates high curvature near x = 0. Away from the bump, m(x) is nearly linear.
- **interactions = false.** Single-covariate model; no cross terms.
- **high_dimensional = false.** Three obvious senses: p = 1 covariate, effective_dimension = 1, and the bump creates local but not global complexity.
- The bump width (≈ 1/8 for M2, ≈ 1/10 for M4) is the primary difficulty for nonparametric estimators at x₀ = 0; coverage distortions reported in the paper are worst at that point.

## Rights and assistance

Paper copyright ASA / Taylor & Francis. The supplement is from the published version (December 16, 2017 date on supplement). No paper PDF, nprobust R/STATA package code, or the authors' original simulation scripts are distributed here. Equations are cited and independently implemented from the printed supplement. Claude Code (AI assistant) extracted equations from the PDF and wrote the Python code; a named human reviewer must verify equation transcription and independently reproduce the result. Source redistribution rights and scientific acceptance require maintainer review.

**Open issues:**

- The supplement PDF extraction is text-mode and the Greek letter φ in Model 4 was rendered as `\036` in raw extraction; equation verified by context and surrounding Models 3/5 formulas. Named reviewer should confirm `phi(10x)` against original PDF.
- The collection registers x₀ = 0 as the scalar query point; the paper's full evaluation grid has 5 points. Multi-point simultaneous band evaluation is not supported by the current interface scalar truth.
