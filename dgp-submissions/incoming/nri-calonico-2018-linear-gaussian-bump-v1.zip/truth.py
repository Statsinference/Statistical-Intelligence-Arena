"""Population truth for CCF2018 supplement S.II.7 Models 2 and 4.

Estimand: m(x0) = E[Y | X = x0] at the fixed query point x0.
The DGP is Y = m(X) + eps, eps ~ N(0, noise_sd^2) with mean noise_mean.
Because E[eps] = noise_mean (= 0 per the paper's parameterisation),
E[Y | X = x0] = m(x0) + noise_mean = m(x0).

Both models have closed-form regression functions, so truth(config)
evaluates m(x0) analytically and returns machine-precision results.

Model 2 at x0 = 0:
    m(0) = 2*0 + 2*exp(-64*0) = 2

Model 4 at x0 = 0:
    m(0) = 0 + 5*phi(0) = 5/sqrt(2*pi) ≈ 1.9947114020071635

estimated_error is 0 for purely algebraic closed-form evaluation
(finite float arithmetic; actual rounding < 2 ULP, reported as 1e-14).
"""
import math


def _phi(z):
    """Standard Gaussian density phi(z) = exp(-z^2/2) / sqrt(2*pi)."""
    return math.exp(-0.5 * z * z) / math.sqrt(2.0 * math.pi)


def truth(config):
    """Return the exact population conditional mean m(x0) for the active scenario.

    Returns
    -------
    dict with keys:
        value           : m(x0), a finite float
        estimated_error : upper bound on floating-point rounding, <= 1e-14
        method          : brief description
        target          : 'm(x0) = E[Y | X = x0]'
        query_point     : the fixed x0 used
    """
    x0 = config["query_point"]
    noise_mean = config.get("noise_mean", 0.0)
    model = config.get("model_name", "M2")

    if model == "M2":
        # m(x) = linear_coeff*x + bump_amplitude*exp(-bump_width_sq*(x-bump_center)^2)
        a = config["linear_coeff"]
        A = config["bump_amplitude"]
        w = config["bump_width_sq"]
        c = config["bump_center"]
        exponent = -w * (x0 - c) ** 2
        m_val = a * x0 + A * math.exp(exponent)
        method = ("Closed-form: m(x0) = linear_coeff*x0 + "
                  "bump_amplitude*exp(-bump_width_sq*(x0-bump_center)^2). "
                  "At x0=0: m(0) = 0 + 2*exp(0) = 2.0 exactly.")
    elif model == "M4":
        # m(x) = linear_coeff*x + bump_amplitude*phi(phi_scale*(x-bump_center))
        a = config["linear_coeff"]
        A = config["bump_amplitude"]
        s = config["phi_scale"]
        c = config["bump_center"]
        z = s * (x0 - c)
        m_val = a * x0 + A * _phi(z)
        method = ("Closed-form: m(x0) = linear_coeff*x0 + "
                  "bump_amplitude*phi(phi_scale*(x0-bump_center)), "
                  "phi(z) = exp(-z^2/2)/sqrt(2*pi). "
                  "At x0=0: m(0) = 0 + 5*phi(0) = 5/sqrt(2*pi).")
    else:
        raise ValueError("Unknown model_name: " + str(model) + "; expected M2 or M4")

    # E[Y|X=x0] = m(x0) + noise_mean (= m(x0) when noise_mean=0 per paper)
    value = m_val + noise_mean

    return {
        "value": value,
        "estimated_error": 1e-14,
        "method": method,
        "target": "m(x0) = E[Y | X = x0] at the fixed query point x0",
        "query_point": x0,
        "noise_mean_contribution": noise_mean,
    }
