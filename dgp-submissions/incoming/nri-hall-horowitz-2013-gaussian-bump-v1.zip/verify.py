"""Fourier inversion checks the Gaussian bump without calling regression_mean.

All checks are contributor-supplied, not independent-person scientific review.
Input validation and the standard-library RNG are shared explicitly.
"""
import copy
import math
import random
from generator import generate
from truth import truth

TOLERANCE = 1e-12
PEAK_VALUE = 1.9947114020071633896997302996719
QUERIES = (-0.3, -0.15, 0.0, 0.15, 0.3)


def simpson(function, left, right, intervals):
    step = (right - left) / intervals
    weighted = [function(left), function(right)]
    weighted.extend((4 if i % 2 else 2) * function(left + i * step)
                    for i in range(1, intervals))
    return math.fsum(weighted) * step / 3.0


def fourier_mean(x, intervals=2048):
    """phi(t)=1/pi * integral_0^infinity exp(-u^2/2) cos(t*u) du."""
    integral = simpson(lambda u: math.exp(-u*u/2) * math.cos(10*x*u),
                       0.0, 10.0, intervals)
    return x + 5.0 * integral / math.pi


def truth_checks(config):
    probes = sorted(set((-1.0, -0.9, -0.3, -0.15, -0.1, 0.0,
                         0.1, 0.15, 0.3, 0.9, 1.0, config['query_x'])))
    errors, convergence = [], []
    for x in probes:
        low, high = fourier_mean(x, 1024), fourier_mean(x, 2048)
        errors.append(abs(high - truth({**config, 'query_x': x})['value']))
        convergence.append(abs(high - low))
    tail_bound = 5 * math.exp(-50) / (10 * math.pi)
    special = [abs(truth({**config, 'query_x': 0})['value'] - PEAK_VALUE)]
    for x in (0.1, 0.15, 0.3, 0.9, 1.0):
        positive = truth({**config, 'query_x': x})['value']
        negative = truth({**config, 'query_x': -x})['value']
        special.append(abs(positive - negative - 2*x))
    return [
        {'name': 'independent_fourier_inversion_truth',
         'passed': max(errors + convergence) < TOLERANCE,
         'max_absolute_error': max(errors), 'max_grid_difference': max(convergence),
         'intervals': [1024, 2048], 'probe_count': len(probes),
         'analytic_truncation_bound': tail_bound,
         'note': 'The bound is for the discarded Fourier tail only; grid refinement is a numerical diagnostic, not a certified total error bound.'},
        {'name': 'exact_peak_and_odd_difference_identities',
         'passed': max(special) < TOLERANCE, 'max_absolute_error': max(special),
         'identities': ['g(0)=5/sqrt(2*pi)', 'g(x)-g(-x)=2*x']},
    ]


def moment_check(config):
    mean = fourier_mean(config['query_x'])
    sigma = config['noise_sd']
    density = lambda z: math.exp(-z*z/2) / math.sqrt(2*math.pi)
    mass = simpson(density, -10.0, 10.0, 4096)
    integrated_mean = simpson(lambda z: (mean + sigma*z)*density(z), -10.0, 10.0, 4096)
    variance = simpson(lambda z: (sigma*z)**2*density(z), -10.0, 10.0, 4096)
    errors = [abs(mass - 1), abs(integrated_mean - truth(config)['value']), abs(variance - sigma*sigma)]
    return {'name': 'conditional_density_mean_variance_and_mass',
            'passed': max(errors) < TOLERANCE, 'max_absolute_error': max(errors),
            'normal_tail_cutoff': 10, 'simpson_intervals': 4096}


def generator_checks(config):
    n, seed = 37, 281013
    global_state = random.getstate()
    data = generate(config, n, seed)
    rng = random.Random(seed)
    x = [rng.uniform(-1, 1) for _ in range(n)]
    errors = [rng.gauss(0, config['noise_sd']) for _ in range(n)]
    means = [fourier_mean(value) for value in x]
    replay_error = max(abs(actual - expected - error)
                       for actual, expected, error in zip(data['Y'], means, errors))
    baseline = generate({**config, 'noise_sd': 1.0}, n, seed)
    scale_error = 0.0
    for sigma in (0.2, 0.5, 1.0):
        scaled = generate({**config, 'noise_sd': sigma}, n, seed)
        scale_error = max(scale_error, max(abs((v-m) - sigma*(b-m))
                          for v, b, m in zip(scaled['Y'], baseline['Y'], means)))
    return [
        {'name': 'source_law_replay_using_fourier_mean',
         'passed': data['X'] == x and replay_error < TOLERANCE,
         'n': n, 'seed': seed, 'max_outcome_error': replay_error,
         'shared_components': 'Same standard-library RNG/draw order; mean computed by a different numerical route.'},
        {'name': 'three_source_noise_scales', 'passed': scale_error < TOLERANCE,
         'max_residual_scaling_error': scale_error, 'noise_sd': [1.0, 0.5, 0.2]},
        {'name': 'query_changes_target_not_observations',
         'passed': all(generate({**config, 'query_x': q}, n, seed) == data for q in QUERIES)},
        {'name': 'local_rng_leaves_global_state_unchanged', 'passed': global_state == random.getstate()},
        {'name': 'observed_only_columns_support_and_finiteness',
         'passed': set(data) == {'X', 'Y'} and all(-1 <= v <= 1 for v in data['X'])
         and all(len(values) == n and all(math.isfinite(v) for v in values) for values in data.values())},
    ]


def rejection_check(config):
    bad_configs = [{**config, 'query_x': 1.01}, {**config, 'query_x': float('nan')},
                   {**config, 'noise_sd': 0}, {**config, 'noise_sd': 0.7},
                   {**config, 'noise_sd': True}, {**config, 'extra': 1}]
    rejected = []
    for parameters in bad_configs:
        for hook in (lambda: truth(parameters), lambda: generate(parameters, 5, 10)):
            try:
                hook()
                rejected.append(False)
            except ValueError:
                rejected.append(True)
    for n, seed in [(0, 1), (1.2, 1), (True, 1), (5, None)]:
        try:
            generate(config, n, seed)
            rejected.append(False)
        except ValueError:
            rejected.append(True)
    return {'name': 'invalid_configuration_or_sampling_inputs_rejected',
            'passed': all(rejected), 'cases': len(rejected)}


def verify(config):
    before = copy.deepcopy(config)
    checks = truth_checks(config) + [moment_check(config)] + generator_checks(config)
    checks += [rejection_check(config), {'name': 'configuration_unchanged', 'passed': before == config}]
    return {'passed': all(item['passed'] for item in checks), 'checks': checks,
            'scope': 'Source DGP and scalar oracle checks only; no CI coverage experiment or independent-person reproduction.'}
