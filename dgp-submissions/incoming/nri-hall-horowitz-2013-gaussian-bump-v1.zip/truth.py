"""Analytic conditional-mean oracle; not a prediction interval or fitted estimate."""
import math
from generator import validate_config


def truth(config):
    validate_config(config)
    x = config['query_x']
    normal_density = math.exp(-0.5 * (10.0 * x)**2) / math.sqrt(2.0 * math.pi)
    return {
        'value': x + 5.0 * normal_density,
        'estimated_error': 0.0,
        'method': 'Analytic E[Y|X=x]=x+5*phi(10*x); E[epsilon|X]=0.',
        'error_note': 'Zero numerical integration error; ordinary floating-point rounding remains.',
    }
