# NRI：Hall–Horowitz（2013）线性趋势上的高斯窄峰

贡献 ID：`nri-hall-horowitz-2013-gaussian-bump-v1`。任务 family：`nonparametric_regression`。
一套机制、15 个场景（3 个原文噪声标准差 × 5 个标量查询点）。

## 来源与精确定位

Hall, P. & Horowitz, J. (2013). *A simple bootstrap method for constructing nonparametric confidence bands for functions*.
The Annals of Statistics **41(4)**, 1892–1921. [DOI](https://doi.org/10.1214/13-AOS1137)。
直接阅读版本：[arXiv:1309.4864v1，2013-09-19，IMS 电子重印本](https://arxiv.org/pdf/1309.4864v1)。

| 内容 | 此版本定位 |
|---|---|
| Y=g(X)+epsilon、条件均值解释 | §2.1，式 (2.1)，PDF 第 4 页 |
| g1、phi 定义、X、误差、三个 sigma 和 n | §3.1，PDF 第 13 页，已渲染核对公式 |
| 评价区域 [-0.9,0.9] | §3.1–3.2，PDF 第 14–15 页 |
| 1000 次模拟与表格 | §3.2，PDF 第 15 页；Tables 1–3 第 16–17 页 |
| 0、±0.15、±0.3 的覆盖讨论 | §3.2，PDF 第 21 页 |

期号核对：重印本首页写 No.1，与 DOI/Crossref 和 arXiv 摘要页的 **No.4** 不一致；采用后两者一致的期号。
本卡页码仅指电子重印本，不能直接换算成期刊页码。出版社最终排版 PDF 未取得，未声称核对其逐页一致性。

## 完整 DGP

\[
X_i\overset{iid}{\sim}U[-1,1],\quad
\varepsilon_i\overset{iid}{\sim}N(0,\sigma^2),\quad
Y_i=g_1(X_i)+\varepsilon_i,
\]
\[
g_1(x)=x+5\phi(10x)
=x+\frac{5}{\sqrt{2\pi}}e^{-50x^2},\qquad
\sigma\in\{1,0.5,0.2\}.
\]

phi 是标准正态**密度**，不是 CDF；`phi(10x)` 前不能再乘密度变换因子 10。
本实现明确取 X 与 epsilon 独立、个体间独立。原文 §2.1 写误差零条件均值、§3.1 写独立正态误差和均匀设计；同一段未另给完整联合分布，独立产品实现已列入 adaptations。
生成器仅输出 X、Y。误差和 g1(X) 留在内部；不输出 oracle、预测真值或潜变量列。

输入只有一个 X，总维度与有效维度均为 1。非线性来自高斯窄峰，无跨变量交互、无无关变量、无异方差。
虽然用于仿真的真函数有闭式表达，统计任务仍是允许未知函数的非参数回归；评测方法不应获得 oracle 公式或隐藏配置。

## 推断目标与场景

\[
\theta(x_0)=E(Y\mid X=x_0)=g_1(x_0).
\]

采用连续条件均值版本，避免把概率零的事件当作普通条件概率直接相除。每个场景固定一个 x0，目标是条件均值 CI，不是单个未来 Y 的预测区间。
默认 `source_sd100_query_zero`：sigma=1、x0=0，真值为
\(5/\sqrt{2\pi}=1.9947114020071634\ldots\)。

| 场景维度 | 取值与来源 |
|---|---|
| noise_sd | 1、0.5、0.2，原文 §3.1 的三个标准差（方差为 1、0.25、0.04） |
| query_x | -0.3、-0.15、0、0.15、0.3，贡献选取的标量查询集合，位置来自 §3.2 讨论 |
| n | `generate` 的独立参数；指南检查 n=128；原文模拟 n=100、200、400 |

全部噪声设置保留；15 个场景不是 15 个独立 DGP。五点均为设计内部点，未登记边界场景。
原文评价区域 R=[-0.9,0.9]；完整数值绘图网格在已读正文中未给出，本贡献不猜测。
原文研究的是 pointwise bands（§1.1），本贡献没有实施同时置信带或原论文覆盖率实验。
原文 Table 1 列 n=100 的三个噪声设置，Tables 2–3 仅展示 n=200、400、sigma=1。

## 真值与可解释核验

因为 E(epsilon|X)=0，直接得到 theta(x0)=g1(x0)，与 sigma 无关。`truth.py` 解析计算，无数值积分误差，`estimated_error=0` 不表示浮点运算绝对精确；容差固定 1e-12。

`verify.py` 使用高斯傅里叶反演：
\[
\phi(t)=\pi^{-1}\int_0^\infty e^{-u^2/2}\cos(tu)\,du.
\]
在 [0,10] 用 1024/2048 分段复合 Simpson 积分重建高斯峰，分别比较解析真值和网格细化差异。
峰项被截去的积分尾部有上界 \(5e^{-50}/(10\pi)\)；这只界定截断误差，网格差不是完整严格误差界。
另核验 g(0)=5/sqrt(2pi)、g(x)-g(-x)=2x、条件正态密度的质量/均值/方差、用积分均值重放生成样本、三个原文 sigma 的残差缩放、query 不改样本、局部 RNG、不泄露观察列及错误输入拒绝。
端点 ±1 仅为验证探针，不冒称原文登记的边界实验。

解析式和傅里叶积分是不同计算路径；输入检查与 Python RNG 共用，重复采样不构成人员独立性。全部仍由同一 AI 协助贡献过程完成，等待另一人独立复现。

## 复现与提交

使用 **20261027 统计任务扩展版**学生包，从含 collect.py 的根目录运行：

```powershell
python -m pip install -r contributions/nri-hall-horowitz-2013-gaussian-bump-v1/requirements.txt
python collect.py check contributions/nri-hall-horowitz-2013-gaussian-bump-v1
python collect.py check contributions/nri-hall-horowitz-2013-gaussian-bump-v1 --run --n 128 --seed 1729
python collect.py pack contributions/nri-hall-horowitz-2013-gaussian-bump-v1 --out submissions/nri-hall-horowitz-2013-gaussian-bump-v1.zip
```

贡献自身只需 Python>=3.10 标准库，无第三方依赖。局部 `random.Random(seed)`，先 n 次 uniform，再 n 次 gauss；跨 Python 版本不承诺随机数位级兼容，实际测试版本见检查证据与外部交付记录。
查询改变不应改变同 seed 下的数据。原文未提供此随机数流，因此不声称重现论文的模拟样本。
原始 20261021 学生包不支持 NRI；扩展版已内置该 family，本包不携带也不需要修改收集器的补丁。

ZIP 根目录直接放八项必需材料、来源核对、运行环境、checks/ 和 MANIFEST.json，不再套一层 ID 文件夹。
打包后若修改源码，必须重检并使用新的 ZIP 文件名。`collect.py submit ZIP --inbox 本地目录` 仅为本地收件测试，不能替代向维护人移交。

## 去重、权利与待审核事项

同篇 g2 与已有 `nri-calonico-2018-asymmetric-sine-v1` 公式相同，不新建重复贡献。g3 是原文明确说明的 g2 截取缩放版，本次不另收，不声称已收齐该文全部设计。
g1 的更早来源由原文指向 Horowitz–Spokoiny（2001），本轮未单独核验；以 Hall–Horowitz 的已读规范为锚点。跨论文同源设计需在维护端分组，不能靠换 citation 充当 held-out-family。
局部目录未发现已收 g1；全项目认领/查重和具名科学审核均待维护人确认，未向任何外部服务提交。

论文版权归 IMS。本 ZIP 不含原文 PDF、作者代码、模型权重、数据银行或外部个人数据。代码按引用方程重新实现；项目发布许可由维护人处理，不能推断作者代码可重发布。
AI 协助：OpenAI Codex，2026-10-28；文献查找、公式转写、代码实现、核验与打包。没有代签人类已读、具名审核或独立复现。
本地 PASS 只覆盖格式、运行、标量真值及哈希证据，不代表科学接收、线上 CI 通过或 PFN 性能结论。
按本次要求不生成 report；规范所需 card 与 checks 仍保留。
