"""Independent algebra/profile checks for the source-grounded DGP."""
import math
import numpy as np


def _profile_independent(config):
    # Deliberately derive each profile separately from the generator's implementation.
    p = int(config["p"])
    multiplier = int(config["index_multiplier"])
    raw = np.zeros(p, dtype=float)
    for j in range(p):
        k = (multiplier * j) % p
        kind = config["beta_y_model"]
        if kind == "dense":
            raw[j] = 1.0 / math.sqrt(k + 1.0)
        elif kind == "harmonic":
            raw[j] = 1.0 / (10.0 + k)
        elif kind == "moderately_sparse":
            if k < 10:
                raw[j] = 10.0
            elif k < 100:
                raw[j] = 1.0
        elif kind == "very_sparse":
            raw[j] = 1.0 if k < 10 else 0.0
        else:
            raise ValueError("Unknown beta_y_model")
    return raw / np.sqrt(np.sum(raw * raw)) * float(config["beta_y_norm"])


def _logistic_scalar(x):
    # Scalar form is implemented separately from generator.py's vectorized routine.
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


def verify(config):
    p = int(config["p"])
    rho = float(config["rho"])
    beta = _profile_independent(config)
    idx = [(int(config["index_multiplier"]) * j) % p for j in range(p)]
    unique_indices = len(set(idx))
    active = int(np.count_nonzero(np.abs(beta) > 0.0))
    if config["beta_y_model"] in ("dense", "harmonic"):
        expected_active = p
    elif config["beta_y_model"] == "moderately_sparse":
        expected_active = 100
    else:
        expected_active = 10

    # Verify the Gaussian innovation recursion has the requested first-lag relation.
    # For standard independent innovations, Cov(X_j, X_{j+1}) = rho and each variance = 1.
    var_recursion = rho * rho + (1.0 - rho * rho)
    covariance_relation = rho

    # Check the original treatment link orientation at two scalar predictors.
    p0 = _logistic_scalar(0.0)
    pplus = _logistic_scalar(1.0)
    pminus = _logistic_scalar(-1.0)

    # Analytic potential-outcome contrasts evaluated at arbitrary covariate vectors.
    tau = float(config["treatment_effect"])
    probes = np.vstack([
        np.zeros(p),
        np.linspace(-1.0, 1.0, p),
        np.sin(np.arange(p, dtype=float) / 17.0)
    ])
    contrast = (probes @ beta + tau) - (probes @ beta)
    zero_tau = 0.0
    zero_contrast = (probes @ beta + zero_tau) - (probes @ beta)

    checks = [
        {"name":"source_parameter_grid", "passed": p == 2000 and int(config["n_reference"]) == 600 and rho in (0.5, 0.9) and float(config["beta_y_norm"]) == 1.0 and int(config["source_replications"]) == 400, "details":f"p={p}, n_reference={config['n_reference']}, rho={rho}, ||beta_Y||={np.linalg.norm(beta):.15g}, source replications={config['source_replications']}."},
        {"name":"index_shift_is_permutation", "passed": unique_indices == p, "details":f"map j -> 23*j mod p (zero-based) has {unique_indices} unique positions out of {p}; gcd(23,2000)=1."},
        {"name":"beta_profile_norm_and_support", "passed": abs(float(np.linalg.norm(beta)) - float(config["beta_y_norm"])) < 1e-12 and active == expected_active, "details":f"independent profile norm={np.linalg.norm(beta):.15g}, active coefficient count={active}, expected={expected_active}."},
        {"name":"AR1_variance_and_lag_covariance_identity", "passed": abs(var_recursion - 1.0) < 1e-12 and abs(covariance_relation-rho) < 1e-12, "details":f"innovation recursion gives marginal variance rho^2+(1-rho^2)={var_recursion:.15g} and lag-one covariance rho={covariance_relation}."},
        {"name":"logistic_treatment_orientation", "passed": abs(p0-0.5)<1e-15 and pplus>p0>pminus and 0<pminus<pplus<1, "details":f"expit(0)={p0:.6g}, expit(1)={pplus:.6g}, expit(-1)={pminus:.6g}; matches P(W=1|X)=expit(sum first 100 X / 40)."},
        {"name":"analytic_ate_independent_route", "passed": bool(np.allclose(contrast, tau, atol=1e-12, rtol=0.0)), "details":f"independent potential-outcome contrast across 3 deterministic X vectors equals tau={tau}; no call to truth.py."},
        {"name":"zero_effect_special_case", "passed": bool(np.allclose(zero_contrast, 0.0, atol=1e-12, rtol=0.0)), "details":"When the structural treatment-effect coefficient is set to zero, the potential-outcome contrast is exactly zero."}
    ]
    return {"passed": all(x["passed"] for x in checks), "checks": checks,
            "shared_components": "The verifier independently reconstructs the coefficient map, scalar logistic link and algebraic contrasts; it necessarily shares the documented model equations and parameter values. It is not an independent-person scientific reproduction.",
            "notes": "The covariance check is an algebraic identity of the Gaussian AR(1) recursion rather than a large Monte Carlo check; no large simulation, bootstrap, PFN training or coverage experiment is run."}
