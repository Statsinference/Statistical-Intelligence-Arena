# ATE collection card: Section 5.2 moderately sparse two-stage setting

**Status: candidate; automated checks do not constitute scientific acceptance.** This is contribution v4 in a related set: v1-v3 use other simulation mechanisms from the same article. The mechanism family is defined by the original paper's index-shifted two-stage simulation, not by random seeds.

## Source and reconstruction

Athey, S., Imbens, G. W. and Wager, S. (2018), “Approximate residual balancing: Debiased inference of average treatment effects in high dimensions,” *Journal of the Royal Statistical Society: Series B (Statistical Methodology)*, 80(4), 597–623. DOI: [10.1111/rssb.12268](https://doi.org/10.1111/rssb.12268). The read electronic reprint is a 27-page PDF at [this source copy](https://file-lianxh.oss-cn-shenzhen.aliyuncs.com/Refs/Spring2024/Athey_2018_Approximate_Residual_Balancing.pdf); the publisher landing page is [Wiley](https://rss.onlinelibrary.wiley.com/doi/10.1111/rssb.12268).

Primary locator: Section 5.2, the unnumbered paragraph titled “moderately sparse two-stage” (PDF viewer page 22/27, printed p. 618): the index-shift instruction and the logistic treatment assignment. The outcome coefficient profiles are given by the equation labeled `eq:betas` in Section 5.2 (PDF viewer page 21/27, printed p. 617). Table 4 and its footnote (PDF viewer page 23/27, printed p. 619) specify rho = 0.5 and 0.9, n = 600, p = 2000, ||beta_Y||_2 = 1, and 400 simulation replications. These equations are not separately numbered in the rendered reprint; the section/paragraph locators are used. The source paragraph itself gives the harmonic shifted-index example as beta_j proportional to 1/[10 + {23(j-1) mod p}].

The source's `balanceHD` R software is referenced by the paper, but no author-code commit was checked out or used here. Publisher-listed supplementary information is described as proofs; its PDF was inaccessible during this pass (HTTP 403), so supplementary content is not claimed to have been read.

## Original DGP, in generation order

1. For each individual i, draw X_i from a p=2000 dimensional Gaussian with mean zero and AR(1) covariance Sigma_jk = rho^|j-k|. Table 4 evaluates rho = 0.5 and 0.9. This is dependence among coordinates within an individual; individuals are independently sampled.
2. The article says the outcome coefficient profiles beta_Y are selected from the profiles defined earlier in Section 5.2, but with their indices permuted by multiplication by 23 modulo p. For j=1,...,p, define k_j = 23(j-1) mod p and use the appropriate unshifted profile at k_j. Normalize every profile to ||beta_Y||_2 = 1, as stated in Table 4:
   - dense: raw_j = 1/sqrt(1+k_j);
   - harmonic: raw_j = 1/(10+k_j);
   - moderately sparse: raw_j = 10 when k_j<10, 1 when 10<=k_j<100, and 0 otherwise;
   - very sparse: raw_j = 1 when k_j<10 and 0 otherwise.
   Set beta_Y = raw / ||raw||_2. The article's explicitly given harmonic example is reproduced by this zero-based representation. Since gcd(23,2000)=1, this map permutes all p indices. The four profile forms are one mechanism's scenarios, not four new mechanism families.
3. Draw treatment W_i conditionally on X_i from the well-specified logistic model
   P(W_i=1 | X_i) = expit(sum_{j=1}^{100} X_ij / 40).
   Equivalently, W_i ~ Bernoulli[1/{1 + exp(-sum_{j=1}^{100} X_ij/40)}]. This is not the latent-theta treatment model from the preceding “sparse two-stage” setting; this contribution preserves the changed logistic assignment given specifically for the moderately sparse setting.
4. Draw epsilon_i2 ~ Normal(0,1) and set Y_i = X_i^T beta_Y + 0.5 W_i + epsilon_i2.

Scenario grid: beta profile in {dense, harmonic, moderately_sparse, very_sparse} times rho in {0.5,0.9}, for 8 total declared scenarios. Source reference scale: n=600, p=2000, ||beta_Y||_2=1, R=400 repetitions. The local required smoke test uses n=128 and does not replace the reference sample-size setting.

## Target and identification

The target is the population ATE under interventions W=1 versus W=0, holding each individual's X and the same outcome disturbance fixed. The structural potential outcomes are interpreted as Y_i(w) = X_i^T beta_Y + 0.5 w + epsilon_i2. Thus Y_i(1)-Y_i(0)=0.5 for every X_i and epsilon_i2, so ATE = E[Y_i(1)-Y_i(0)] = 0.5. This truth is derived analytically and is not an estimator or a reported Monte Carlo estimate.

The intended identifying story requires consistency, independent outcome noise given the covariates/treatment mechanism, and conditional exchangeability given all X. The article gives epsilon_i1/epsilon_i2 as independent standard Gaussian in the prior sparse two-stage model, but the moderately sparse paragraph writes its treatment assignment directly as logistic and specifies the outcome noise via the prior setup; it does not enumerate every cross-independence relation in that paragraph. The implementation independently samples the outcome error, conditional on the full X and W-generating process; this is recorded as an implementation assumption awaiting scientific confirmation. For every finite X, the logistic propensity is in (0,1), but X has unbounded Gaussian support, so we do not claim a uniform overlap bound away from 0 and 1. There is no interference.

## Implementation adaptations and checks

- The source's AR(1) Gaussian vector is generated through a Gaussian innovation recursion with the exact covariance Sigma_jk = rho^|j-k|. It is distribution-equivalent but uses a different random-number construction.
- The 23-mod-p index shift is source-defined, not an invented feature. The code expresses it with zero-based internal indices and then applies the source's L2 normalization.
- `generator.py` returns X1,...,X2000,W,Y only. The coefficient vector, propensity values, outcome error and potential outcomes are never returned.
- `truth.py` returns ATE = 0.5 and estimated_error = 0 because the contrast is exact algebraically. `verify.py` independently reconstructs the coefficient profiles and checks the norms, support counts, index permutation, logistic orientation, analytic treatment contrast and a zero-effect special case. It shares the declared equations/configuration with the generator, so it is not independent-person reproduction.

## Diversity and scope

Total covariate dimension p=2000 and reference n=600, hence p>n. Active outcome coefficients vary by beta profile: dense=2000, harmonic=2000, moderately sparse=100, very sparse=10. The treatment assignment depends directly on the first 100 covariates; because the Gaussian coordinates are correlated, other coordinates can also carry information about them. The nonlinear tag refers to the logistic propensity function; no interaction product is specified. No nuisance/oracle columns, individual effects, counterfactual outcomes, PFN training data bank, or model weights are included.

## Rights and assistance

The paper is cited and no paper PDF or author software is included. An independent code implementation and AI-assisted equation transcription were used. Author-code commit is missing because that code was not used. Publisher supplementary PDF could not be opened (403) during this pass. Remaining items for the maintainer/scientific reviewer: confirm the outcome-error independence convention, index shift interpretation, source page mapping, and whether the supplementary proofs provide any additional simulation clarifications. This package remains awaiting scientific review; machine PASS does not imply scientific acceptance.
