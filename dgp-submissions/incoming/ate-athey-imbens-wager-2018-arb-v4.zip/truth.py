"""Analytic population ATE for the linear additive outcome model."""
import math


def truth(config):
    tau = float(config["treatment_effect"])
    if not math.isfinite(tau):
        raise ValueError("treatment_effect must be finite")
    return {
        "value": tau,
        "estimated_error": 0.0,
        "method": "analytic structural contrast",
        "derivation": "Under do(W=1) and do(W=0), hold the same X and outcome error fixed: [X^T beta_Y + tau + epsilon] - [X^T beta_Y + epsilon] = tau. The source fixes tau=0.5, so ATE=0.5.",
        "target": "ATE = E[Y(1)-Y(0)] for intervention W=1 versus W=0 in the declared superpopulation",
        "error_interpretation": "Exact algebraic contrast; no numerical integration or Monte Carlo approximation is used."
    }
