import numpy as np
from scipy.special import log_ndtr
from numpy.polynomial.hermite import hermgauss

def validate(c):
    assert .1 <= c['pi'] <= .9 and c['bound']==3
    assert .6 <= c['scale'] <= 2 and .4 <= c['scale']+c['scale_effect'] <= 3
    assert abs(c['shift']) <= 2 and .4 <= c['location_sd'] <= 1.5

def truncated_mean(mu,s,bound):
    mu=np.asarray(mu);s=np.asarray(s)
    a=(-bound-mu)/s;b=(bound-mu)/s
    # Log probability differences avoid Gaussian tail underflow; no outcome clipping.
    hi=np.where(a>0,log_ndtr(-a),log_ndtr(b))
    lo=np.where(a>0,log_ndtr(-b),log_ndtr(a))
    logZ=hi+np.log(-np.expm1(lo-hi))
    pa=-a*a/2-.5*np.log(2*np.pi);pb=-b*b/2-.5*np.log(2*np.pi)
    sign=np.sign(pa-pb)
    with np.errstate(divide='ignore'):
        logdiff=np.maximum(pa,pb)+np.log(-np.expm1(-np.abs(pa-pb)))
    h=mu+s*sign*np.exp(logdiff-logZ)
    if not np.all(np.isfinite(h)) or np.any(np.abs(h)>bound+1e-9):
        raise FloatingPointError('Truncated-normal moment numerical failure; sample not retried')
    return h

def draw(c,n,seed):
    validate(c);r=np.random.default_rng(seed);d=r.binomial(1,c['pi'],size=n)
    mu0=c['location_sd']*r.normal(size=n)
    mu1=c['shift']+c['location_sd']*r.normal(size=n)
    y0=truncated_mean(mu0,c['scale'],c['bound'])
    y1=truncated_mean(mu1,c['scale']+c['scale_effect']*d,c['bound'])
    return dict(x0=np.zeros(n),D=d,y_pre=y0,y_post=y1,delta_y=y1-y0)

def moments(c,order=120):
    validate(c);z,w=hermgauss(order);z=z*np.sqrt(2)*c['location_sd'];w=w/np.sqrt(np.pi)
    h0=truncated_mean(z,c['scale'],c['bound'])
    h10=truncated_mean(c['shift']+z,c['scale'],c['bound'])
    h11=truncated_mean(c['shift']+z,c['scale']+c['scale_effect'],c['bound'])
    mean=lambda x:float(w@x)
    var=lambda x:float(w@((x-mean(x))**2))
    p=c['pi'];v0=var(h0)+var(h10);v1=var(h0)+var(h11)
    return dict(pi=p,theta=mean(h11)-mean(h10),V=v1/p+v0/(1-p),m0=mean(h10)-mean(h0))

def nuisances(c,data,pop):
    n=len(data['D']);return np.full(n,pop['pi']),np.full(n,pop['m0'])
