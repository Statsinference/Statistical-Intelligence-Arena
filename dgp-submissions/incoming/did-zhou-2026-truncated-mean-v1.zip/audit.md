# FSP Proposal 逐机制审核：did-zhou-2026-truncated-mean-v1

审核日期：2026-11-04。执行者：Codex AI 辅助文献、数学与代码审核。依据 Proposal SHA256 `612e5acd9f55540d3c3ddd2447a859ce4e4e9de6618b81a721e66324f8f8d5e8`。

**结论：TRAIN_VALID（限本包 ADAPTED 定义、声明的 X、参数区间及 oracle 接口）。** 这不是原文未改编机制的结论，也不是人工评审签名、外部接收凭证或已经加入训练 registry 的声明。

| 审核项 | 结论与证据 |
|---|---|
| 文献来源 | 指定四刊范围内；见 source_audit.json 的版本、定位、代码核对状态及差异 |
| 两期同单位面板 / 总体 ATT | PASS；观察单位与潜在结果定义见 card.md |
| IID 单位 | PASS；每行独立抽样；没有固定组数或跨行共同随机冲击 |
| CPT / No anticipation / No interference | PASS；card.md 给出结构性证明；不以蒙特卡洛结果代替识别证明 |
| 真实 e(X) / pi / overlap | PASS；明确声明 X；整个参数域 e∈[0.1,0.9] |
| m0 / ATT / finite positive V | PASS；解析或数值人口矩，独立路径交叉核验 |
| SN-DR / EIF | PASS；先通过简单正态 reference 检查，再通过手工归一化公式核对、置换与一二阶矩检验 |
| 空组及极端值 | 明确失败，无分母截断、重抽样或静默筛掉 episode；本次重复抽样空组为 0 |
| 输入隔离 | PASS；使用 fsp_adapter.model_input，只返回 X、D、delta_y；不将 nuisance、真值或机制参数传入模型 |
| 家族参数化 | PASS；独立机制种子、样本种子，配置化先验，30 个随机参数点通过数值核验 |
| 数据拆分 | 必须按 source_lineage_id 隔离论文；同一机制下换 seed 不是新家族 |

默认场景 ATT=-0.34870671284，pi=0.25，V=6.12459383211。**V 是 EIF 的人口方差，teacher 的一阶方差目标是 V/n。**

## 固定机制重复抽样

每个场景、每个 n 独立生成 1,600 个 episode。预先在验证脚本中设定：均值误差不超过 5 个 Monte Carlo SE；nVar(T)/V 与 1 的距离不超过 max(0.12,4 MCSE)；95% oracle 区间覆盖率与 0.95 的差不超过 0.025。全部命名场景和全部 n 均执行，未挑选有利结果。

| 场景 | n | 重复数 | Bias | nVar(T)/V | 95%区间覆盖率 | 空组数 |
|---|---:|---:|---:|---:|---:|---:|
| adapted_reference | 128 | 1600 | -0.014933 | 1.0151 | 0.9456 | 0 |
| adapted_reference | 512 | 1600 | 0.00053044 | 0.9090 | 0.9556 | 0 |
| adapted_reference | 2048 | 1600 | -0.0026952 | 0.9518 | 0.9587 | 0 |
| negative_shift | 128 | 1600 | 0.0050424 | 1.1009 | 0.9331 | 0 |
| negative_shift | 512 | 1600 | 0.0019305 | 0.9912 | 0.9556 | 0 |
| negative_shift | 2048 | 1600 | 0.00087239 | 1.0164 | 0.9487 | 0 |
| null_scale_effect | 128 | 1600 | -0.0020197 | 1.0346 | 0.9513 | 0 |
| null_scale_effect | 512 | 1600 | -0.00023322 | 1.0179 | 0.9513 | 0 |
| null_scale_effect | 2048 | 1600 | 0.00030242 | 0.9992 | 0.9569 | 0 |

完整 MCSE、Wilson 区间、每次检验与 30 套参数记录见 audit_results.json。不同 n 的经验方差无需单调；有限模拟也不证明任意 n 的覆盖率恰好为 95%。连续参数域的因果合法性来自结构和区间约束；数值检查仅抽查。

## 适用范围及限制

- 仅审核该标量适配版本；source_relation=adapted_from_source。与来源差异必须随包保留。
- 默认及所有已命名场景通过；随机先验域内若更改分布、X、噪声依赖或数值算法，需要重新审核。
- 四个家族无有效协变量，按 x0=0 表示；它们提供噪声、分布及处理作用的变化，不能代替高维条件趋势家族。
- 三个 Zhou 家族共享一篇论文，不能用于“按论文独立”的三份外部证据，不能跨论文级 OOD 拆分。
- 不估计未知 nuisance，不复现原论文估计器或论文表格；oracle 区间用于标签审核。
- 无作者代码可验证时已如实写明，以明确的数学机制作来源，不编造 repository 或 commit。

复跑：安装 requirements.txt 后运行 `python validate_package.py .`。collect.py 的格式执行检查另见 checks/report.json；该检查本身不授予科学验收。
