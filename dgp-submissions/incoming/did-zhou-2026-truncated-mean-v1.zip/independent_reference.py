import numpy as np
from scipy.integrate import quad
from numpy.polynomial.legendre import leggauss

def reference(c):
    # Independent inner density quadrature over the bounded outcome, outer adaptive normal integration.
    nodes,weights=leggauss(100);y=c['bound']*nodes;weights=weights*c['bound']
    def h(mu,s):
        logp=-(y-mu)**2/(2*s*s);q=weights*np.exp(logp-np.max(logp))
        return float(q@y/q.sum())
    def mv(shift,scale):
        norm=lambda t:np.exp(-t*t/2)/np.sqrt(2*np.pi)
        mean=quad(lambda t:h(shift+c['location_sd']*t,scale)*norm(t),-12,12,epsabs=1e-10,limit=200)[0]
        var=quad(lambda t:(h(shift+c['location_sd']*t,scale)-mean)**2*norm(t),-12,12,epsabs=1e-10,limit=200)[0]
        return mean,var
    a,va=mv(0,c['scale']);b,vb=mv(c['shift'],c['scale']);d,vd=mv(c['shift'],c['scale']+c['scale_effect'])
    p=c['pi'];return dict(pi=p,theta=d-b,m0=b-a,V=(va+vd)/p+(va+vb)/(1-p))
