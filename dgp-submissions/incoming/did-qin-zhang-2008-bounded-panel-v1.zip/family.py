"""Draw a fixed mechanism, then sample independent episodes with generator.generate."""
from pathlib import Path
import hashlib,json
import numpy as np
from model import validate

def sample_mechanism(seed,prior=None):
    base=Path(__file__).resolve().parent
    configs=json.loads((base/'config.json').read_text(encoding='utf-8'))
    c=dict(configs['scenarios'][configs['default_scenario']])
    specification=json.loads((base/'family_prior.json').read_text(encoding='utf-8'))
    if prior is None: prior=specification['parameters']
    r=np.random.default_rng(seed)
    for k,spec in prior.items():
        if 'choices' in spec:
            c[k]=spec['choices'][int(r.integers(len(spec['choices'])))]
        elif 'uniform' in spec:
            c[k]=float(r.uniform(*spec['uniform']))
        elif 'vector_uniform' in spec:
            c[k]=[float(r.uniform(*interval)) for interval in spec['vector_uniform']]
        else: raise ValueError('Unsupported prior specification')
    validate(c)
    canonical=json.dumps(c,sort_keys=True,separators=(',',':'),allow_nan=False)
    return dict(family_id=specification['family_id'],source_lineage_id=specification['source_lineage_id'],
                mechanism_id=hashlib.sha256(canonical.encode()).hexdigest(),parameters=c,mechanism_seed=seed)
