"""Population truth; independent of the episode and its sampling seed."""
from model import moments

def truth(config):
    hi=moments(config,120);lo=moments(config,80)
    err={k:abs(hi[k]-lo[k]) for k in hi}
    if max(err.values())>1e-7:
        raise ArithmeticError('Oracle convergence tolerance failed')
    return dict(value=hi['theta'],estimated_error=max(err['theta'],1e-12),
                **hi,numerical_errors=err,
                error_note='Quadrature order difference is an error diagnostic, not a rigorous bound; independent_reference.py is cross-checked separately.')
