import numpy as np
from scipy.special import expit
from numpy.polynomial.hermite import hermgauss

def validate(c):
    assert c['model'] in ('linear','quadratic')
    assert 0.1 <= c['epsilon'] < 0.5 and 0.25 <= c['sigma'] <= 2
    assert len(c['beta']) == 3 and all(abs(b) <= 1 for b in c['beta'])
    assert abs(c['tau0']) <= 3 and abs(c['tau_x']) <= 1

def propensity(c,z,b):
    return c['epsilon']+(1-2*c['epsilon'])*expit(c['beta'][0]+c['beta'][1]*b+c['beta'][2]*z)

def trend(c,z,b):
    level = 3*b+2*z if c['model']=='linear' else 3*b*b+2*z*z
    return level-b

def draw(c,n,seed):
    validate(c)
    r=np.random.default_rng(seed)
    z=r.normal(size=n); b=1+.6*z+r.normal(size=n)
    d=r.binomial(1,propensity(c,z,b))
    y0=b
    y1=b+trend(c,z,b)+d*(c['tau0']+c['tau_x']*z)+c['sigma']*b*r.normal(size=n)
    return dict(x1=z,x2=b,D=d,y_pre=y0,y_post=y1,delta_y=y1-y0)

def moments(c,order=80):
    validate(c)
    z,w=hermgauss(order);z=z*np.sqrt(2);w=w/np.sqrt(np.pi)
    zz,uu=np.meshgrid(z,z,indexing='ij'); ww=w[:,None]*w[None,:]
    b=1+.6*zz+uu;p=propensity(c,zz,b);tau=c['tau0']+c['tau_x']*zz
    pi=float(np.sum(ww*p));theta=float(np.sum(ww*p*tau)/pi)
    V=float(np.sum(ww*(p/(1-p)*c['sigma']**2*b*b+p*(tau-theta)**2))/pi**2)
    return dict(pi=pi,theta=theta,V=V)

def nuisances(c,data,pop):
    z=np.asarray(data['x1']);b=np.asarray(data['x2'])
    return propensity(c,z,b),trend(c,z,b)
