import numpy as np
from scipy.integrate import quad
from scipy.special import expit

def reference(c):
    # Independent 1-D conditional Gaussian integration, not the 2-D Hermite oracle.
    b0,b1,b2=c['beta'];a=b0+b1;cz=.6*b1+b2;s=np.hypot(cz,b1)
    mz=cz/s if s else 0.;mb=(.6*cz+b1)/s if s else 0.
    vz=1-mz*mz;vb=1.36-mb*mb
    normal=lambda t:np.exp(-t*t/2)/np.sqrt(2*np.pi)
    p=lambda t:c['epsilon']+(1-2*c['epsilon'])*expit(a+s*t)
    integ=lambda f:quad(lambda t:f(t)*normal(t),-12,12,epsabs=1e-11,epsrel=1e-11,limit=200)[0]
    pi=integ(p);theta=integ(lambda t:p(t)*(c['tau0']+c['tau_x']*mz*t))/pi
    V=integ(lambda t:p(t)/(1-p(t))*c['sigma']**2*((1+mb*t)**2+vb)+p(t)*((c['tau0']+c['tau_x']*mz*t-theta)**2+c['tau_x']**2*vz))/pi**2
    return dict(pi=pi,theta=theta,V=V)
