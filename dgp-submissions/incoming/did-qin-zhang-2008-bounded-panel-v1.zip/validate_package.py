"""Meaningful Proposal validation, run once in an isolated process per package."""
from pathlib import Path
import sys,json,hashlib,math,time
import numpy as np

folder=Path(sys.argv[1]).resolve();sys.path.insert(0,str(folder))
from model import draw,moments,nuisances,validate
from generator import generate
from truth import truth
from verify import verify
from independent_reference import reference
from family import sample_mechanism
from fsp_adapter import model_input,oracle_sidecar

def digest(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()

def wilson(k,n):
    z=1.959963984540054;p=k/n;den=1+z*z/n
    mid=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [mid-half,mid+half]

def repeated(c,pop,n,reps,seed):
    estimates=[];empty=0
    for b in range(0,reps,40):
        B=min(40,reps-b);o=draw(c,n*B,seed+b)
        d=o['D'].reshape(B,n);dy=o['delta_y'].reshape(B,n)
        e,m=nuisances(c,o,pop);e=e.reshape(B,n);m=m.reshape(B,n)
        w=(1-d)*e/(1-e);den1=d.sum(axis=1);den0=w.sum(axis=1)
        good=(den1>0)&(den0>0);empty+=int((~good).sum())
        # Do not resample. If any empty group occurs the audit fails, and count is reported.
        vals=(d*(dy-m)).sum(axis=1)[good]/den1[good]-(w*(dy-m)).sum(axis=1)[good]/den0[good]
        estimates.extend(vals.tolist())
    a=np.asarray(estimates);err=a-pop['theta'];var=float(a.var(ddof=1));R=len(a)
    covered=int((np.abs(err)<=1.959963984540054*np.sqrt(pop['V']/n)).sum())
    se=float(a.std(ddof=1)/np.sqrt(R));ratio=n*var/pop['V']
    ratio_mcse=float(n/pop['V']*np.sqrt(max(0,np.mean((a-a.mean())**4)-var**2)/R))
    return dict(n=n,requested_repetitions=reps,usable_repetitions=R,empty_groups=empty,
                mean=float(a.mean()),bias=float(err.mean()),mean_mcse=se,
                scaled_variance=n*var,V=pop['V'],variance_ratio=ratio,ratio_mcse=ratio_mcse,
                coverage=covered/R,coverage_wilson95=wilson(covered,R),
                mean_zero_within_5mcse=abs(float(err.mean()))<5*se,
                asymptotic_variance_check=abs(ratio-1)<max(.12,4*ratio_mcse),
                coverage_check=abs(covered/R-.95)<.025)

def scalar_teacher_reference(o,c,pop):
    side=oracle_sidecar(c,o,pop);d=np.asarray(o['D']);dy=np.asarray(o['delta_y'])
    e,m=nuisances(c,o,pop)
    a=[float(dy[i]-m[i]) for i in range(len(d)) if d[i]==1]
    bw=[float(e[i]/(1-e[i])) for i in range(len(d)) if d[i]==0]
    by=[float(dy[i]-m[i]) for i in range(len(d)) if d[i]==0]
    val=sum(a)/len(a)-sum(w*y for w,y in zip(bw,by))/sum(bw)
    return abs(val-side['teacher'])<1e-11

def reference_teacher_test():
    # Run production adapter against an independent simple normal reference DGP.
    # Temporarily replace nuisance evaluation only, preserving teacher/EIF implementation.
    import fsp_adapter
    original=fsp_adapter.nuisances
    fsp_adapter.nuisances=lambda c,o,p:(np.full(len(o['D']),.4),np.full(len(o['D']),.7))
    try:
        rng=np.random.default_rng(993);d=rng.binomial(1,.4,1000);eps=rng.normal(size=1000)
        y=.7+1.2*d+eps;o={'x0':np.zeros(1000),'D':d,'delta_y':y}
        side=fsp_adapter.oracle_sidecar({},o,dict(pi=.4,theta=1.2,V=25/6))
        expected=1.2+eps[d==1].mean()-eps[d==0].mean()
        expected_psi=np.where(d==1,eps/.4,-eps/.6)
        return abs(expected-side['teacher'])<1e-12 and np.allclose(expected_psi,side['psi'],atol=1e-12)
    finally:fsp_adapter.nuisances=original

def main():
    start=time.time();cfg=json.loads((folder/'config.json').read_text());manifest=json.loads((folder/'collection.json').read_text())
    result=dict(contribution_id=manifest['contribution_id'],audit_date='2026-11-04',
                auditor='Codex AI-assisted source/causal/code review with executed numerical checks',
                reference_teacher_passed=bool(reference_teacher_test()),scenarios=[],family_prior=[])
    passed=result['reference_teacher_passed']
    for index,(name,c) in enumerate(cfg['scenarios'].items()):
        ref=reference(c);tr=truth(c);check=verify(c)
        before=digest(c);o=generate(c,128,1729);inp=model_input(o);side=oracle_sidecar(c,o,ref)
        permutation=np.random.default_rng(3).permutation(128);op={k:np.asarray(v)[permutation] for k,v in o.items()}
        contract=dict(seed_replay=digest(o)==digest(generate(c,128,1729)),different_seed=digest(o)!=digest(generate(c,128,1730)),
                      configuration_unchanged=before==digest(c),teacher_matches_scalar_formula=scalar_teacher_reference(o,c,ref),
                      permutation_invariant=abs(side['teacher']-oracle_sidecar(c,op,ref)['teacher'])<1e-11,
                      observed_schema=set(o)==set(['x1','x2','D','delta_y','y_pre','y_post'] if 'x1' in o else ['x0','D','delta_y','y_pre','y_post']),
                      model_input_exact=set(inp)=={'X','D','delta_y'} and inp['X'].shape[1]==(2 if 'x1' in o else 1),
                      difference_consistent=bool(np.allclose(np.asarray(o['y_post'])-np.asarray(o['y_pre']),o['delta_y'])))
        empty_o={k:list(v) for k,v in o.items()};empty_o['D']=[0]*128
        try:oracle_sidecar(c,empty_o,ref);contract['empty_group_explicit_failure']=False
        except ValueError:contract['empty_group_explicit_failure']=True
        rep=[repeated(c,ref,n,1600,781000+10000*index+10*n) for n in [128,512,2048]]
        scenario_pass=all(contract.values()) and check['passed'] and all(x['empty_groups']==0 and x['mean_zero_within_5mcse'] and x['asymptotic_variance_check'] and x['coverage_check'] for x in rep)
        passed=passed and scenario_pass
        result['scenarios'].append(dict(scenario=name,parameters=c,oracle=tr,independent=ref,verify=check,contract=contract,repeated_sampling=rep,passed=bool(scenario_pass)))
        print(name,'PASS' if scenario_pass else 'FAIL',[(r['n'],round(r['variance_ratio'],3),round(r['coverage'],3)) for r in rep],flush=True)
    for k in range(30):
        sample=sample_mechanism(32000+k);c=sample['parameters'];ref=reference(c);tr=truth(c)
        errs={name:abs(ref[name]-tr[name]) for name in ref}
        o=generate(c,256,91000+k);e,m=nuisances(c,o,ref)
        good=max(errs.values())<1e-7 and ref['V']>0 and np.isfinite(ref['V']) and np.all((e>=.1)&(e<=.9))
        # Fresh same mechanism seed must recover identical parameters; sample seed is separate.
        good=good and sample==sample_mechanism(32000+k)
        result['family_prior'].append(dict(mechanism_id=sample['mechanism_id'],mechanism_seed=sample['mechanism_seed'],parameters=c,oracle=ref,max_oracle_difference=max(errs.values()),passed=bool(good)))
        passed=passed and good
    result['passed']=bool(passed);result['elapsed_seconds']=time.time()-start
    result['limitations']=['1600 repetitions per n per named scenario; not proof of exact finite-sample coverage.',
        '30 parameter draws per family are a numerical sample, not exhaustive validation of a continuous prior; structural proofs cover declared bounds.',
        'No human reviewer signature or external reproducibility claim; no registry integration or model training.',
        'Declared X must be preserved. Population V/n is a first-order target, not exact finite-sample variance.',
        'Source-projection estimands differ from geodesic effects; distinct mechanisms share one paper lineage.']
    (folder/'audit_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+'\n',encoding='utf-8')
    print('OVERALL',result['passed'],'elapsed',round(result['elapsed_seconds'],2),flush=True)
    return 0 if passed else 1

if __name__=='__main__':raise SystemExit(main())
