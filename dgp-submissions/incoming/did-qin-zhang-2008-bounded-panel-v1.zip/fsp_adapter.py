"""Model input projection and oracle sidecar. Never silently retry empty groups."""
import numpy as np
from model import moments,nuisances

def model_input(observed):
    names=['x1','x2'] if 'x1' in observed else ['x0']
    return {'X':np.column_stack([observed[k] for k in names]),
            'D':np.asarray(observed['D']), 'delta_y':np.asarray(observed['delta_y'])}

def oracle_sidecar(config,observed,population=None):
    pop=moments(config,120) if population is None else population
    e,m=nuisances(config,observed,pop)
    d=np.asarray(observed['D']);y=np.asarray(observed['delta_y']);r=e/(1-e)
    n1=float(d.sum());cw=(1-d)*r;den=float(cw.sum())
    if n1==0 or den==0:
        raise ValueError('EMPTY_GROUP: teacher undefined; no resampling or denominator clipping')
    residual=y-m
    teacher=float(np.dot(d,residual)/n1-np.dot(cw,residual)/den)
    psi=d/pop['pi']*(residual-pop['theta'])-(1-d)/pop['pi']*r*residual
    return dict(teacher=teacher,e=e,m0=m,ATT=pop['theta'],pi=pop['pi'],V=pop['V'],psi=psi,
                n_treated=int(n1),control_weight_sum=den)
