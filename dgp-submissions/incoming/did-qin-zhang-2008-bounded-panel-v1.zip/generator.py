"""Public collector entrypoint: observed data only; local NumPy RNG."""
from model import draw

def generate(config,n,seed):
    if not isinstance(n,int) or n<1:
        raise ValueError('n must be a positive integer')
    return {k:v.tolist() for k,v in draw(config,n,seed).items()}
