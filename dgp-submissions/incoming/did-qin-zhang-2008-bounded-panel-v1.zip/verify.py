"""Independent population route plus Monte Carlo against the implemented generator."""
import numpy as np
from model import draw,moments,nuisances
from independent_reference import reference

def verify(config):
    ref=reference(config);oracle=moments(config,120)
    discrepancies={k:abs(ref[k]-oracle[k]) for k in ref}
    checks=[dict(name='independent_population_integration_or_enumeration',passed=max(discrepancies.values())<1e-7,errors=discrepancies)]
    n=80000;data=draw(config,n,20261104);d=data['D'];e,m=nuisances(config,data,ref)
    resid=data['delta_y']-m
    psi=d/ref['pi']*(resid-ref['theta'])-(1-d)/ref['pi']*e/(1-e)*resid
    checks.append(dict(name='generator_EIF_zero_mean',passed=abs(float(psi.mean()))<6*np.sqrt(ref['V']/n),mean=float(psi.mean())))
    checks.append(dict(name='generator_EIF_second_moment',passed=abs(float(np.mean(psi**2))/ref['V']-1)<.08,ratio=float(np.mean(psi**2)/ref['V'])))
    score=d-e;se=float(np.std(score)/np.sqrt(n))
    checks.append(dict(name='assignment_calibration',passed=abs(float(score.mean()))<6*se,mean=float(score.mean())))
    checks.append(dict(name='configured_overlap',passed=bool(np.all((e>=.1)&(e<=.9)))))
    for check in checks: check['passed']=bool(check['passed'])
    return dict(passed=all(x['passed'] for x in checks),checks=checks)
