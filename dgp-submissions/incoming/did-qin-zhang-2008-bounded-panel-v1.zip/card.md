# Qin–Zhang baseline-selected heteroskedastic panel, bounded assignment

## 来源与关系

Qin, J. and Zhang, B. (2008). Empirical-Likelihood-Based Difference-in-Differences Estimators. JRSS-B 70(2), 329–349. [DOI](https://doi.org/10.1111/j.1467-9868.2007.00638.x)。定位：Section 4, models 1–2 and Tables 1–2; Section 2 defines baseline and post outcomes.

**ADAPTED；不是原论文标量 DGP 的原样复现。**

- True assignment changed from expit(eta) to epsilon+(1-2*epsilon)*expit(eta); this is a changed DGP, not fitted-weight clipping.
- Disambiguate overloaded Y0/Y1 notation as baseline B and post potential outcomes mu_d(B,Z)+sigma*B*error.
- Set sigma=1 in the reference scenario explicitly as an implementation choice; not claimed as a verified table-specific original value.
- A heterogeneous-effect scenario and configurable parameter prior are extensions.

## 数学定义与识别证明

Let Z,U,E be independent standard normals, B=1+0.6Z+U, X=(Z,B). Draw D conditional on X using the bounded probability in model.py. Set Ypre=B and Ypost(d)=3B+2Z+d(tau0+tau_x Z)+sigma B E (replace 3B+2Z by 3B²+2Z² in the quadratic scenario). Therefore m0 is the post control mean minus B; E[E|X,D]=0 proves CPT. Baseline is unaffected by intervention. The ATT is E[e(X)tau(X)]/pi, including selection into treatment. The variance is E[e sigma²B²/(1-e)+e(tau-ATT)²]/pi². Gaussian moments and bounded e imply finite positive V. The outcome mean polynomial cancels under oracle residualization; it still matters for nuisance learning.

## 参数与家族

`config.json` 给出 3 个明确场景；`adapted_reference` 保留可保留的来源常数，不命名为 original。完整参数区间与采样分布在 `family_prior.json`，`family.sample_mechanism(seed)` 只生成固定参数，`generate(config,n,seed)` 再独立生成样本。改变场景、系数或随机种子不增加家族数。此家族的 paper lineage 为 `qin-zhang-2008`。

## 输入与标签隔离

只使用 `fsp_adapter.model_input` 构造 X,D,delta_y。y_pre/y_post 仅供观察数据审核；特别是无协变量家族，不得擅自把 y_pre 加入 X。所有真实 propensity、m0、ATT、V、EIF、teacher 都在独立 sidecar 中。样本为空组时 teacher 明确报错，不重抽、不截断分母。

## 真值与验证

`truth.py` 不依赖当前 episode。`independent_reference.py` 用不同积分或枚举路径核验人口矩；`verify.py` 另外核验真实生成数据的处理概率、EIF 一二阶矩。更完整的重复抽样、区间覆盖率、家族抽样检查见 `audit_results.json` 与 `audit.md`。数值积分阶数差是误差诊断，不冒称严格误差上界。

## 使用

安装 requirements.txt，在本目录运行 `python -c "import json; from generator import generate; c=json.load(open('config.json'))['scenarios']['adapted_reference']; print(generate(c,5,1729))"`。

学生工具：`python collect.py check <本目录> --run --n 128 --seed 1729`；随后 `python collect.py pack <本目录> --out <新 ZIP>`。包内 `checks/report.json` 是格式及执行检查，科学审核以 `audit.md` 为准。本文档与实现由 AI 辅助完成，不伪造人工评审或独立研究者复现签名。
