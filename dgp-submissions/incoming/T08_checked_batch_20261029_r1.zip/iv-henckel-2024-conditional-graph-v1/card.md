# Conditional instruments in the source G1 graph

Status: adapted source mechanism, awaiting named scientific review.

## Source and reconstruction
Henckel, Buttenschoen and Maathuis (2024), *Graphical tools for selecting conditional instrumental sets*, Biometrika 111(3):771-788, DOI 10.1093/biomet/asad066. Actual read: full author arXiv:2208.03697 PDF including supplement, Section 2 eq (1), Figure 1(a), Section 5 PDF pp 11-13, supplement E PDF p 41. Current arXiv page labels may differ from publication pagination. Publisher PDF retrieval was blocked; publication exact-match is unverified. Graph and sampler were independently checked against author efficientCIS commit 2882bded6c57aeaf8da9df8561da329e71dd932c: SimulationStudy/Main/G1a.R lines 31-42 (expanded graph), 93-95 (parameter generation), HelperFunctions/functions.R lines 66-78 (sampler), 100-121 and 197-209 (Gaussian/uniform generation). Source files and hashes remain outside the ZIP.

Expanded topological node order: A,C,L1,B,D,L2,X,M,Y. The R source's B is parent-by-child because matrix() fills columns; the contribution stores child-by-parent, as confirmed by source t(B) covariance/uniform paths. Latent L1 creates D<->X and latent L2 creates X<->Y. M is the source code's node e.

All errors are mutually independent, mean zero. Root A,C,L1,L2 consist only of their errors. Remaining equations, with full numeric coefficients in config.json:

- A <- epsilon_A
- C <- epsilon_C
- L1 <- epsilon_L1
- B <- (-0.78408214029946133)*C + epsilon_B
- D <- (0.2011394215552596)*A + (0.40685244250001207)*L1 + (0.60072810314434222)*B + epsilon_D
- L2 <- epsilon_L2
- X <- (1.4038923130557954)*L1 + (-1.0690158213970873)*B + (-1.8992312433635747)*L2 + epsilon_X
- M <- (0.35800137127747389)*X + epsilon_M
- Y <- (-0.79585700972545459)*C + (-0.71641682995974743)*L2 + (-0.52749259051598618)*X + (1.4218960031282049)*M + epsilon_Y

The source samples each node error variance Uniform(0.1,1) and each edge coefficient with independent sign ±1 and magnitude Uniform(0.1,2). Each latent root is sampled under those same rules. Gaussian errors have variance v; uniform errors have support [-sqrt(3v),sqrt(3v)]. No truncation or extra centering occurs. Independent individuals are generated conditional on a fixed parameter vector.

Adaptations: one new PCG64 seed-1729 draw replaces the source's 100 R seed-5 random SEMs. Each numeric coefficient/variance is recorded in config.json; no claim is made to reproduce one of the paper's original numeric runs. Gaussian and uniform are two scenarios of the same family. M is an explicit renaming. Hook n replaces paper n=50,500. L1,L2 never appear in observed output. The complete sampler rebuild record is outside the package in build_contribution.py.

## Target and assumptions
tau = d E[Y|do(X=x)]/dx = E[Y|do(X=1)]-E[Y|do(X=0)] = b[Y,X]+b[M,X]b[Y,M] = -0.018451871582129575. It is the **total** effect, not the direct edge alone and not a LATE. Population is the frozen SEM's iid individuals. Consistency and no interference apply. The conditional instrument tuple (A,B,D) given C is the source's optimal tuple. Conditional exclusion and exogeneity are graphical properties of this SEM. Relevance is verified from the induced covariance. Post-treatment M must not be adjusted for when estimating this total effect. The schema labels A,B,D as candidate instruments used jointly with C; these labels do not assert marginal validity of every individual instrument.

## Truth and independent verification
truth.py sums the two causal paths. verify.py propagates a unit do-intervention through the topological graph, then separately derives the complete population covariance using (I-B)^-1 diag(v) (I-B)^-T and checks Cov(Z,Y-tau X|C)=0 and nonzero Cov(Z,X|C). The two routes share the audited config and structural equations but do not call each other. Independent analytical/numerical tests also check generated covariance, no latent output and reproducibility. Gaussian and uniform errors have the same analytic covariance and target. Error estimate 0 denotes an exact algebraic target, subject to floating-point rounding. Small CPU checks do not establish coverage.

## Diversity, rights and assistance
This family differs from invalid-instrument majority/plurality designs: conditional graphical validity, latent-root confounding and an explicit mediated total effect. Four observed baseline variables are active jointly; M is post-treatment rather than a baseline covariate. No nonlinear terms or high-dimensional claim. Public paper metadata gives CC BY 4.0; author code license not identified, so it is not redistributed in the contribution. The simulator was written independently from equations and graph. AI assisted extraction, coding and checks; named human scientific acceptance is pending. Publication-PDF exact-match and maintainer family recognition remain open. No external submission was made.

## Scientific review revision R1: comparison with registered IV drafts

Compared the five actual registry draft generators/records on 2026-10-29, registry blob `3fa452e91c0c61403fc8921190555d4f97053f5e`. All are draft/unverified; this is a proposed structural comparison, not proof of eight accepted families. Source equations and observation rules, not different paper titles, seeds or coefficient values, drive the judgement.

| Existing draft | Provisional comparison | Scientific reason |
|---|---|---|
| Athey2019 | distinct_family_candidate | A latent-variable linear DAG with conditional instrumental set, observed adjustment C and mediator M differs from binary one-sided uptake and effect-modifying X. |
| Ding2017 | distinct_family_candidate | Continuous graph-based conditional IV with mediated total effect differs from no-X binary latent probability tables. |
| Kang2016 | related_structurally_different_candidate | Both use linear equations, but Henckel specifies a DAG with latent common causes, valid conditional IV set (A,B,D) / C and an observed mediator. The target sums X->Y and X->M->Y paths; Kang has direct invalid Z effects and a single unmediated treatment coefficient. This is an identification/graph difference, not just new coefficients. |
| Dikkala2020 | distinct_family_candidate | Conditional linear DAG and mediated total effect differ from a nonlinear sine structural response with Gaussian shared confounding. |
| Hartford2017 | distinct_family_candidate | Conditional-IV DAG and mediated total effect differ from nonlinear demand/price equations and their effect-modifying observed covariates. |

The full 8-by-5 matrix and evidence receipts are retained in `literature/batch_20261029/revision_01/`; only this contribution's comparison is included here. Final scientific acceptance, family count and target eligibility are maintainer decisions.
