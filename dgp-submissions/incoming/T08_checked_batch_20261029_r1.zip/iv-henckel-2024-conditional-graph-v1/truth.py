"""Total effect is a sum over the two directed X-to-Y paths."""
def truth(config):
    b = config['coefficients']
    return {'value':b[8][6]+b[7][6]*b[8][7], 'estimated_error':0.0,
            'method':'analytic directed path sum', 'target':'total effect of X on Y'}
