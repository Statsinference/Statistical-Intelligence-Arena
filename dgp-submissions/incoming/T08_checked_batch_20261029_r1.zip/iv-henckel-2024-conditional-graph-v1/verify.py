"""Independent do-recursion and population conditional IV calculations."""
import numpy as np

def verify(config):
    b = np.asarray(config['coefficients'],dtype=float)
    q = np.linalg.inv(np.eye(9)-b)
    sigma = q@np.diag(config['error_variances'])@q.T
    def intervention(x):
        v = np.zeros(9)
        for i in range(9):
            v[i] = x if i==6 else b[i]@v
        return v[8]
    effect = float(intervention(1)-intervention(0))
    # Residual covariance conditional on C (index 1).
    cov = sigma-np.outer(sigma[:,1],sigma[1,:])/sigma[1,1]
    instr = [0,3,4]
    zx = cov[instr,6]
    zy = cov[instr,8]
    residual = zy-effect*zx
    checks = [
        {'name':'causal_path_sum_vs_do_recursion','passed':bool(abs(effect-(b[8,6]+b[7,6]*b[8,7]))<1e-12),'details':{'do_effect':effect}},
        {'name':'conditional_iv_population_identity','passed':bool(np.max(np.abs(residual))<1e-10),'details':{'max_abs_cov_Z_YminusTauX_givenC':float(np.max(np.abs(residual)))}},
        {'name':'conditional_relevance','passed':bool(np.linalg.norm(zx)>1e-8),'details':{'norm_cov_ZX_givenC':float(np.linalg.norm(zx))}},
        {'name':'dag_variances_and_no_oracle','passed':bool(np.allclose(b,np.tril(b,-1)) and np.all(np.asarray(config['error_variances'])>0)),'details':'Positive latent-root variances and acyclic structural matrix.'},
    ]
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'independence_note':'Shares source coefficients with truth; distinct recursion and covariance derivation, no truth.py import.'}
