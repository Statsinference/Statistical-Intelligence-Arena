"""Eq. (12) latent continuous-exposure structural coefficient."""
def truth(config):
    return {"value":float(config["beta"]),"estimated_error":0.0,
            "method":"Y(d+1)-Y(d)=alpha_YZ=1 on the source linear/log-time scale"}
