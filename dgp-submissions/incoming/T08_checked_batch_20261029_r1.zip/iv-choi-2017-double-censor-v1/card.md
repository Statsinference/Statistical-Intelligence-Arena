# Double-censored continuous IV
Choi, Byeong Yeob; Fine, Jason P.; Brookhart, M. Alan (2017). *On two-stage estimation of structural instrumental variable models*. Biometrika104(4):881–899. DOI https://doi.org/10.1093/biomet/asx056.
Read PMC author manuscript https://pmc.ncbi.nlm.nih.gov/articles/PMC5793491/. Section4 Case1B Eq12 (Equation35.gif) and Eq13 (Equation36.gif), all-ones parameter paragraph, covariate truncation and censor distributions. Section3.2 defines outcome min/event indicator; Section3.3 defines left exposure censoring via sign reversal. Original equation GIFs were visually inspected, with contact sheets in local source audit CHOI2017; they are excluded from ZIP. No author code used: commit not applicable.

## Complete generation law
Individuals iid. V1,V2 are instruments; W1,W2 measured confounders; U latent confounder. Each is standard Normal truncated to [-2,2], with independent draws explicitly adopted as the reading of the source's standard-normal covariates. This is conditioning, not clipping. Epsilon and delta are independent standard Normals, independent of all covariates. All intercepts and regression coefficients in Eq12/13 are1:
D=1+V1+V2+W1+W2+U+delta;
Y=1+D+W1+W2+U+epsilon.
The source denotes exposure Z and instruments V; Python uses D to keep the IV role unambiguous. This renaming changes no law.

Independent censoring thresholds C_Y~Uniform(0,cy), C_D~Uniform(-7,cz). Observe Y_observed=min(Y,C_Y), Y_event=I(Y<=C_Y); D_observed=max(D,C_D), D_exact=I(D>=C_D). Ties have probability0 and use these inclusive conventions.
Source Section3.2 calls C_Y log censoring time. Work entirely on the source linear/log-time scale. Negative Y or exposure is allowed. No exp transform, positive-value clamp, deletion of censored units or imputation of latent values is used.
Output exactly V1,V2,W1,W2,D_observed,D_exact,Y_observed,Y_event. U, eps/delta, true D,Y and censor thresholds are absent. At a censored unit, its observed boundary conveys only the limit, not its latent event/exposure.

## Calibrated constants: explicit adaptation
Source specifies desired20% right outcome/left exposure censoring but not numerical cy/cz. They are independently derived here, not claimed printed source constants:
cy=13.249945942133955; cz=2.629814945797971.
With iid truncated normals Tj, D=1+sum_{j=1}^5 Tj+delta; Y=2+T1+T2+2T3+2T4+2T5+delta+epsilon.
For a Gaussian G~N(mu,s²) conditional on covariate sum, exact Gaussian first-truncated moments compute rY(c)=E[clip(Y/c,0,1)] and rD(c)=E[clip((c-D)/(c+7),0,1)]. Solve rY=.2 and rD=.2 with Brent roots.
Independent audit script uses midpoint quadrature of each bounded truncated-normal density, FFT convolution, then analytic Gaussian integration. At8192 bins per width4, rates numerically .2 to floating precision. Endpoints change by1.06e-8 and5.25e-9 between4096 and8192 bins; differences are diagnostics, not rigorous integration error bounds. The actual rates are independently checked by two Monte Carlo implementations at7 standard errors. Frozen constants retain this small calibration error rather than pretending exact source endpoints.

## Target and identification
alpha_YZ=1 is the structural slope of true exposure in the source's linear outcome Eq12: Y(d+1)-Y(d)=1; the superpopulation effect on this scale is1. This is not the contrast on exp(Y) event-time scale, not a complier LATE, and not a regression slope of censored Y on censored D.
Relevance: Cov(V1,D)=Var(V1)>0. Exclusion: V affects Y only through D. Instruments are independent of W,U and innovations under explicit independent draws. U creates unmeasured exposure/outcome confounding. Independent censoring is retained in the observation model. Monotonicity is unnecessary for this continuous homogeneous structural target. Generation/truth checks do not establish all AFT/rank-estimator regularity assumptions or CI validity.

## Independent verification and source distinctions
truth returns1 from the intervention contrast. verify uses rejection-normal sampling (generator uses inverse-CDF truncation), expanded reduced-form equations, independent seeds, and tests known truncated-normal latent means/covariances, the population IV moment and arbitrary counterfactual contrasts.
It compares observed means/second moments for all columns against the public generator and checks both censoring rates near.2 in each implementation at7 estimated standard errors, n131072 each. These are diagnostics, not named independent-person reproduction.
The family differs structurally from full-data Kang/Lin/Guo and binary-compliance Athey/Ding/Wang: treatment itself and outcome are censored in opposite directions, so observed IV inputs require limits/indicators and cannot expose full latent D/Y. One source_case1b_calibrated scenario, not two families for left/right censoring.

## Adaptations, rights and status
Independent covariate/threshold draws made explicit where source prose does not enumerate full joint dependence; no fabricated non-unit regression coefficients. Caller n/seed; independent NumPy/SciPy law implementation; source sample sizes and fitting/resampling omitted.
Biometrika Trust copyright2017. PMC access is not a license grant. ZIP contains no article, equation image, author code or real data; rights for intended use remain review items. Codex assisted source audit, calibration, implementation and tests. Machine PASS is runnable_dgp, not scientific acceptance; named review and maintainer family decision remain pending.

## Scientific review revision R1: comparison with registered IV drafts

Compared the five actual registry draft generators/records on 2026-10-29, registry blob `3fa452e91c0c61403fc8921190555d4f97053f5e`. All are draft/unverified; this is a proposed structural comparison, not proof of eight accepted families. Source equations and observation rules, not different paper titles, seeds or coefficient values, drive the judgement.

| Existing draft | Provisional comparison | Scientific reason |
|---|---|---|
| Athey2019 | distinct_family_candidate | Continuous latent exposure/outcome with measured W, excluded V and dual censoring differ from binary one-sided uptake and complete continuous outcome. |
| Ding2017 | distinct_family_candidate | Continuous latent linear/log-scale variables with left/right censoring differ from fully binary response tables. |
| Kang2016 | family_boundary_requires_maintainer_decision | Choi uses valid excluded V conditional on measured W, a shared latent U, and observation Dobs=max(D,C_D), Yobs=min(Y,C_Y) plus indicators. Its latent triangular equations are still linear, so an ontology based only on complete-data structural equations may merge it with a broad linear-IV family. A separate contribution is justified only if incomplete-observation mechanisms/validity structure count; calibrated censoring endpoints alone do not establish a new family. |
| Dikkala2020 | distinct_family_candidate | Double-censored latent linear/log-scale law differs from complete-data nonlinear sine response. |
| Hartford2017 | distinct_family_candidate | Measured adjustment, valid excluded V and dual censoring differ from a fully observed nonlinear demand model with correlated price noise. |

The full 8-by-5 matrix and evidence receipts are retained in `literature/batch_20261029/revision_01/`; only this contribution's comparison is included here. Final scientific acceptance, family count and target eligibility are maintainer decisions.
