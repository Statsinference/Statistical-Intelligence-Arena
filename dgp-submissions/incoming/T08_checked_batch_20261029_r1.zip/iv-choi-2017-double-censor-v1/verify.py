"""Independent rejection sampling, source moments and censoring diagnostics."""
import importlib.util
from pathlib import Path
import math
import numpy as np


def _reject(rng,n):
    result=[]
    remaining=n
    while remaining:
        x=rng.normal(size=remaining*2+16)
        kept=x[abs(x)<=2][:remaining]
        result.extend(kept)
        remaining-=len(kept)
    return np.asarray(result)


def verify(config):
    source={"beta":1,"cy":13.249945942133955,"cz":2.629814945797971,
            "covariate_truncation":2,"target_censoring_rate":.2}
    checks=[{"name":"source coefficients and calibrated endpoint fixtures",
             "passed":config==source}]
    n=131072
    rng=np.random.default_rng(20171026)
    v1,v2,w1,w2,u=(_reject(rng,n) for _ in range(5))
    delta,eps=rng.normal(size=(2,n))
    # Independently expand Eq12 after substitution of Eq13.
    d=1+v1+v2+w1+w2+u+delta
    y=2+v1+v2+2*w1+2*w2+2*u+delta+eps
    cy=rng.random(n)*config["cy"]
    cd=-7+(config["cz"]+7)*rng.random(n)
    independent=np.column_stack([v1,v2,w1,w2,np.where(d<cd,cd,d),
                  (d>=cd).astype(int),np.where(y>cy,cy,y),(y<=cy).astype(int)])
    var_t=1-4*math.exp(-2)/math.sqrt(2*math.pi)/(math.erf(2/math.sqrt(2)))
    moments=np.column_stack([d-1,y-2,(d-1)**2-(5*var_t+1),
                    (y-2)**2-(14*var_t+2),(d-1)*(y-2)-(8*var_t+1),
                    v1*(y-d)])
    mz=float(np.max(abs(moments.mean(axis=0))/(moments.std(axis=0,ddof=1)/np.sqrt(n))))
    checks.append({"name":"independent latent means covariance and valid-IV moment",
        "passed":mz<7,"details":{"n":n,"seed":20171026,"maximum_z":mz,
        "diagnostic_iv_ratio":float(np.mean(v1*y)/np.mean(v1*d)),"threshold":7}})
    # Direct counterfactual contrast at arbitrary U/epsilon avoids using truth().
    contrast=[(1+(t+1)+w+u0+e)-(1+t+w+u0+e)
              for t,w,u0,e in ((-9,3,.4,2),(0,-2,-.2,-3),(12,0,1,7))]
    checks.append({"name":"source-scale unit intervention contrast",
                   "passed":max(abs(z-1) for z in contrast)<1e-14})
    spec=importlib.util.spec_from_file_location("choi2017_public_generator",Path(__file__).with_name("generator.py"))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    public=mod.generate(config,n,20171201)
    keys=["V1","V2","W1","W2","D_observed","D_exact","Y_observed","Y_event"]
    obs=np.column_stack([public[k] for k in keys])
    # Test each mean and second moment against an independent sampler, using
    # variance of the actual transformed variables, not Gaussian formulas.
    aa=np.column_stack([obs,obs**2])
    bb=np.column_stack([independent,independent**2])
    se=np.sqrt(aa.var(axis=0,ddof=1)/n+bb.var(axis=0,ddof=1)/n)
    maxz=float(np.max(abs(aa.mean(axis=0)-bb.mean(axis=0))/se))
    checks.append({"name":"public observed-law vs independent rejection sampler",
                   "passed":maxz<7,"details":{"maximum_z":maxz,"threshold":7}})
    for label,data in (("public",obs),("independent",independent)):
        rates=[float(1-data[:,5].mean()),float(1-data[:,7].mean())]
        zmax=max(abs(r-.2)/math.sqrt(.2*.8/n) for r in rates)
        checks.append({"name":label+" left/right censor rates near source20percent",
            "passed":zmax<7,"details":{"exposure_left":rates[0],"outcome_right":rates[1],"maximum_z":zmax,"threshold":7}})
    checks.append({"name":"observed-only and censor support",
        "passed":set(public)==set(keys) and bool(np.max(abs(obs[:,:4]))<=2)
            and float(obs[:,4].min())>=-7 and float(obs[:,6].max())<=config["cy"]})
    return {"passed":all(c["passed"] for c in checks),"checks":checks}
