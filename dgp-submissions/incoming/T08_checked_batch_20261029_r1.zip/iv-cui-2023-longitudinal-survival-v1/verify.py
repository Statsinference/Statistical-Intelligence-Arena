"""Independent quadrature/root and survival hazard checks."""
import math
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import ndtr

def verify(config):
    psi=config['psi'];v=config['visit_time'];rate=config['baseline_hazard']
    def cumulative(t,a0,a1):
        first=quad(lambda _:math.exp(psi*a0),0,min(t,v),epsabs=1e-12)[0]
        second=quad(lambda _:math.exp(psi*a1),v,t,epsabs=1e-12)[0] if t>v else 0
        return first+second
    def survival(t,a0,a1):return math.exp(-rate*cumulative(t,a0,a1))
    max_inversion_error=0.
    for a0,a1 in [(0,0),(0,1),(1,0),(1,1)]:
        for latent_time in [.01,.2,.8,1.1,2.5,5.]:
            root=brentq(lambda t:cumulative(t,a0,a1)-latent_time,0,20,xtol=1e-13)
            q0=math.exp(psi*a0);q1=math.exp(psi*a1)
            closed=latent_time/q0 if latent_time<=v*q0 else v+(latent_time-v*q0)/q1
            max_inversion_error=max(max_inversion_error,abs(root-closed))
    # Estimate hazards independently from exact marginal survival functions.
    dt=1e-4
    log_ratios=[]
    for t in [.25,.75,1.25,1.75]:
        h0=-math.log(survival(t+dt,0,0)/survival(t-dt,0,0))/(2*dt)
        h1=-math.log(survival(t+dt,1,1)/survival(t-dt,1,1))/(2*dt)
        log_ratios.append(math.log(h1/h0))
    # Compliance contrast must not vary with U, at both treatment models.
    differences=[]
    for l in [-2.,0.,2.]:
        delta=ndtr(.2*l)
        for u in [-3.,0.,3.]:
            p0=ndtr(.2*l-.8*u)*(1-delta);p1=p0+delta
            differences.append(abs((p1-p0)-delta))
    checks=[
        {'name':'piecewise_inverse_vs_quadrature_root','passed':max_inversion_error<1e-10,'details':{'max_abs_time_error':max_inversion_error}},
        {'name':'marginal_survival_log_hazard_ratio','passed':max(abs(x-psi) for x in log_ratios)<1e-8,'details':{'numerical_log_hazard_ratios':log_ratios}},
        {'name':'independent_compliance_type','passed':bool(max(differences)<1e-14),'details':'Probability contrast p(A=1|Z=1)-p(A=1|Z=0)=Phi(.2L), independent of U.'},
        {'name':'source_boundary_and_variance','passed':config['visit_time']==1 and config['administrative_time']==2 and config['censor_uniform_max']==4 and config['error_sd']==.5 and rate==1,'details':'Source main-text visit/censor times, exponential rate and Gaussian error SD retained.'},
    ]
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'independence_note':'Does not import generator or truth. Uses quadrature/root and marginal survival instead of generator inverse. Shared source transformation and config remain.'}
