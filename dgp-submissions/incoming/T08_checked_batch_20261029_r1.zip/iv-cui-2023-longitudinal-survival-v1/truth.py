"""Population marginal structural Cox parameter, not an observed Cox fit."""
def truth(config):
    return {'value':float(config['psi']),'estimated_error':0.0,
            'method':'analytic marginal structural hazard coefficient',
            'target':'log causal hazard ratio for current treatment under fixed regimes'}
