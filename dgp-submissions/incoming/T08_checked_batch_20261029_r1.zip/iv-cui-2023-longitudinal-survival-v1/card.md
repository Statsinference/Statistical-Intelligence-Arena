# Time-varying IV and censored marginal structural survival

Status: adapted observation representation of a source-complete mechanism; scientific review pending.

## Actual sources and locators
Cui, Y., Michael, H., Tanser, F. and Tchetgen Tchetgen, E. (2023 issue; advance publication2021), *Instrumental variable estimation of the marginal structural Cox model for time-varying treatments*, Biometrika110(1):101-118, DOI10.1093/biomet/asab062. Read the published full-text PMC9919489 HTML Sections2-4 and visually inspect all original simulation formula images. Section4.2 eq(8) is image Equation24.gif; the next unnumbered accelerated-time integral is Equation25.gif. **Asset filenames do not denote equation numbers25 or26.** Section4.3 ordered list specifies all numerical laws in ImEquation185-209.gif. No PDF page locator is asserted because the read version is HTML. Paper and source GIFs stay outside the contribution ZIP.

Supplementary PDF endpoints returned HTML challenges; supplemental sensitivity scenarios/proof have not been read. A coauthor homepage was checked for code; no Cox-paper implementation was recovered, and the distinct iv-msmm project was not substituted. Main-text generation is complete and the mathematical survival transformation is independently verified.

## Ordered source mechanism and parameters
For each iid person draw baseline no-treatment failure T00~Exponential(rate1). Draw mutually independent errors epsilon1,...,epsilon4~N(0,.5^2), independent uniform random numbers for each Bernoulli draw and independent Ctilde~Uniform(0,4). Phi denotes standard-normal CDF. Generate

    L0=1.5T00+epsilon1; U0=1.5T00+epsilon2
    Z0~Bernoulli(Phi(-.5+.2L0))
    Delta0=Phi(.2L0)
    A0~Bernoulli(Phi(.2L0-.8U0)*(1-Delta0)+Z0*Delta0)
    L1=L0-U0+1.5A0+T00+epsilon3
    U1=.5L0-U0+A0+T00+epsilon4
    Z1~Bernoulli(Phi(-1+.2L1+.2A0+.2Z0))
    Delta1=Phi(.2L1)
    A1~Bernoulli(Phi(.2L1-.8U1)*(1-Delta1)+Z1*Delta1).

Every treatment probability is a convex combination of Phi(.2L-.8U) and Z, so lies in[0,1]. No invented coefficient, probability clipping or treatment truncation is used. U0,U1,T00 and all structural errors are internal.

Treatments remain A0 on(0,1] and A1 after1. Source Section4.2 defines T00=int_0^T exp(psi*a(s))ds. Let q0=exp(psi*A0),q1=exp(psi*A1). Thus T=T00/q0 when T00<=q0; otherwise T=1+(T00-q0)/q1. This inverse is exact and preserves the fact that failure before1 depends only on past A0. The two source scenarios are psi=-1 and psi=0, one family. Generate C=min(Ctilde,2), Y=min(T,C), event=I(T<=C). C is independent of the complete natural history. For psi0, T=T00 exactly regardless of treatment. No estimator is fitted.

## Observed numeric representation and adaptation
One person is one wide-table row. Output L0,Z0,A0,Y,event and R1=I(Y>=1). Output L1,Z1,A1 only while R1=1; use numeric zero placeholders otherwise. R1 is observed risk/availability status, not a latent/oracle label. Users must apply R1 before interpreting second-visit values; zero placeholders do not mean treatment0 after death/dropout. No exact failure T for a censored person, future treatment, latent T00/U or counterfactual labels are exposed. Observed Y is bounded by administrative time2. The complete latent natural history may be computed internally to obtain T but is not returned.

This numeric mask representation is the principal adaptation from source longitudinal history data to the current table contract. Additional adaptations are exact numerical inversion and seeded NumPy sampling with hook n instead of source n2000,4000,8000. The scalar target and two source settings are retained. No missing scientific parameters are filled by convention. Error SD .5 must not be mistaken for variance .5.

## Target, truth and identification
The target is the population marginal structural Cox log hazard ratio psi for current binary treatment under fixed regimes: lambda_Ta(t)=exp(psi*a(t)), baseline hazard1. It is neither a LATE nor an observed regression coefficient, risk difference or survival difference. For fixed a, P(Ta>t)=P(T00>int_0^t exp(psi*a(s))ds)=exp(-int_0^t exp(psi*a(s))ds). Differentiation yields the source marginal hazard, hence log hazard ratio psi. Regime histories can be compared at the same time with current treatment1 versus0; this model posits no past-treatment coefficient.

IV assumptions follow source Section3.1: consistency, no interference, latent sequential randomization, sequential relevance, exclusion, instrument independence and positivity, independent compliance type and independent censoring. Conditional on observed pre-treatment history, Z is randomized independently of U/T00 by construction. Z0 may affect future L1 through A0 and Z1 through Z0, but all effects on failure are mediated by the treatment history. The treatment-probability contrast between Z1 andZ0 at visit j equals Phi(.2L_j), independent of U_j; it is strictly positive mathematically. No uniform overlap bound is claimed in Gaussian tails. Ordinary sequential ignorability given observed L alone fails because U affects treatment and survival.

## Verification and scope
truth.py returns the source analytic psi. verify.py independently computes the accelerated-time integral by adaptive quadrature, inverts it by bracketed root solving and compares the closed form; computes hazard ratios numerically from marginal survival functions; and checks the compliance contrast over different U values. Shared source equations/config mean this is not another researcher's independent replication. Target error0 is algebraic up to floating-point rounding; finite numerical checks use reported tolerances. Separate tests check censoring proportions against source approximate40%/30%, null scenario survival law, no post-observation future leakage, probability bounds, reproducibility and a second-visit treatment perturbation.

Two observed active covariate measurements L0,L1 constitute dimension2 in this wide representation; L1 is time-varying and affected by A0, not a second baseline covariate. One family differs structurally from point-treatment IV, including Wang2018's independent-compliance condition: here there are endogenous time-varying treatments, feedback and censored survival. This distinction needs maintainer acceptance and should not be counted solely by the shared assumption.

## Rights, AI and pending issues
Article copyright Author(s)2021 and OUP standard publication terms; no blanket source redistribution permission assumed. Paper/assets are not bundled. The simulator is independently written from mathematical equations. AI assisted source transcription, implementation and checks. Named scientific review and acceptance, original author RNG/code recovery and supplementary sensitivity scenarios remain pending. Numerical finite table encoding is documented; users need a survival/longitudinal estimator that respects masking, not an ordinary point-IV routine. No external upload occurred.

## Scientific review revision R1: comparison with registered IV drafts

Compared the five actual registry draft generators/records on 2026-10-29, registry blob `3fa452e91c0c61403fc8921190555d4f97053f5e`. All are draft/unverified; this is a proposed structural comparison, not proof of eight accepted families. Source equations and observation rules, not different paper titles, seeds or coefficient values, drive the judgement.

| Existing draft | Provisional comparison | Scientific reason |
|---|---|---|
| Athey2019 | distinct_family_candidate | Two-stage IV/uptake histories, baseline failure time transformation and censored survival differ from a single-stage one-sided uptake outcome. |
| Ding2017 | distinct_family_candidate | Longitudinal IV, a continuous event time and at-risk masking differ from fully binary one-stage tables. |
| Kang2016 | distinct_family_candidate | Two-time marginal structural Cox survival law, time-varying latent confounding and censoring differ from complete-data linear invalid-IV regression. |
| Dikkala2020 | distinct_family_candidate | Piecewise cumulative-hazard inversion with dynamic histories differs from a one-stage sine response. |
| Hartford2017 | distinct_family_candidate | Dynamic failure-time and at-risk observation law differs from a one-stage continuous demand response. |

The full 8-by-5 matrix and evidence receipts are retained in `literature/batch_20261029/revision_01/`; only this contribution's comparison is included here. Final scientific acceptance, family count and target eligibility are maintainer decisions.
