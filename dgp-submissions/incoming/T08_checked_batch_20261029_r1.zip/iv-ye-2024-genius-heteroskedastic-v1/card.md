# GENIUS heteroskedastic exposure with pleiotropic SNPs

Status: adapted source mechanism; scientific acceptance pending.

## Sources actually read
Ting Ye, Zhonghua Liu, Baoluo Sun and Eric Tchetgen Tchetgen (2024), *GENIUS-MAWII: for robust Mendelian randomization with many weak invalid instruments*, JRSS-B 86(4):1045-1067, DOI 10.1093/jrsssb/qkae024. Full published article HTML from PMC11398887 was downloaded and read, especially Section 2 models (4),(5), Section 6.1 unnumbered A/Y mechanism and four settings before Table 1. MathML contains square roots that plain text omits; equations were cross-checked in the full author arXiv:2107.06238 PDF pp 22-23. Its integrated supplement Section 2 pp 48-50 was read (covariate and LD extensions are not implemented). Published supplement ZIP direct download returned an HTML challenge; integrated author supplement was available. Archived source files are outside this contribution.

Author package fixed commit f4b2335ec107b1de29f1ef3d747585b8e3e82665, R/mr.genius.R lines 21-37 was inspected. Its data_gen() uses different all-one first-stage and direct coefficients, U variance 1 and different heteroskedastic scaling. It does **not** reproduce published Section 6.1. We therefore use the published equations, not the package demonstration generator. This discrepancy is documented, not silently reconciled.

## Complete mechanism
Freeze m=100 SNP coefficients first. Independently draw phi_gamma_j,phi_delta_j~N(0,1) once; gamma_j=phi_gamma_j sqrt(h2/(1.5m)), delta_j=phi_delta_j kappa sqrt(h2/(1.5m)); h2=.2,kappa=1. For each iid individual, draw independently Z_j~Binomial(2,.5), U~N(0,.48), epsilon_A~N(0,.32), epsilon_Y~N(0,.32), where the second normal parameter denotes **variance**, not SD. All disturbances are independent of all SNPs. Generate

    A = gamma^T Z + U + (1+delta^T Z) epsilon_A
    Y = .4 A + alpha^T Z + U + epsilon_Y.

The heteroskedastic multiplier may be negative; it multiplies a centered Gaussian draw and is not clipped or passed as a negative standard deviation. No bounded treatment or outcome is imposed. SNP support is 0,1,2 with probabilities .25,.5,.25. U and disturbances are never observed output.

S1 alpha=0. S2 alpha_j~N(sqrt(tau0_squared),tau0_squared), tau0_squared=.2/150. S3 alpha=gamma/2. The four scenarios have S1/S2/S3 counts 100/0/0,60/20/20,10/90/0,10/0/90. These are scenarios of one family. Directly check all realized arrays in config.json; no source-unspecified numeric coefficients are passed off as the original realized values.

Adaptations: new explicitly seeded NumPy PCG64 seed1729 gamma/delta draw; alpha draws also frozen, with consecutive SNP type blocks. The publication specifies coefficient laws but not the original realized vector or labels, and persistence of the S2 alpha draw is not specified as explicitly as phi. Freezing and block labels are transparent choices, not claims of exact original RNG recovery. All scenarios share the same gamma/delta. Hook n may differ from the original 10000/100000. No estimator comparison is included. Rebuild script and source artifacts stay outside the ZIP.

## Target and identification
beta=.4 is the constant structural slope of A on Y, the derivative dE[Y|do(A=a)]/da and the unit intervention contrast E[Y(do(A=1))-Y(do(A=0))] in this frozen coefficient population. It is not a LATE. Consistency, iid sampling and no interference apply. In S1 SNPs satisfy classical exclusion; S2/S3 intentionally violate exclusion by direct pleiotropy. A textbook all-valid-IV assumption would be false in these scenarios. GENIUS instead requires no Z-by-U interactions in the conditional means of A and Y and leverages the nonconstant exposure residual variance; these assumptions hold by construction.

Write R_A=A-E[A|Z]=U+s(Z)epsilon_A and R_Y=Y-E[Y|Z]=beta R_A+U+epsilon_Y, s(Z)=1+delta^T Z. Then E[R_A(R_Y-beta R_A)|Z]=Var(U)=.48, constant in Z. Hence E[(Z_j-1)R_A(R_Y-beta R_A)]=0, while

    E[(Z_j-1)R_A^2] = .32 delta_j (1+sum_k delta_k).

The latter is nonzero for this frozen draw; verify checks the full vector. This demonstrates identification via heteroskedastic residual moments despite direct effects. Small n=128 is a format/runtime check, and does not show many-weak-IV asymptotics or valid confidence intervals.

## Truth and independent verification
truth.py reads the causal slope beta. verify.py independently evaluates paired do-interventions and integrates the three-point SNP support using exact moments of the other SNPs, then evaluates the GENIUS moment ratio. Analytic central-moment identity and quadrature must agree. These checks share source equations, config and beta, so they are independent derivations rather than an independent researcher's replication. Additional tests inspect generated SNP frequencies and covariance, use common-random-number zero-beta contrasts, and check generator output and nuisance arrays. Estimated error zero is algebraic, subject to floating-point arithmetic.

## Scope, rights and AI
No baseline covariates: dimension=effective_dimension=0; there are 100 candidate SNPs. The interaction delta^T Z epsilon_A creates a quadratic conditional variance, not nonlinear outcome mean or high-dimensional baseline confounding. The mechanism is structurally distinct from majority/plurality invalid-IV linear homoskedastic families, including existing Kang and Lin designs. It should not be split by invalid fraction into four family counts.

Published article has OUP standard publication rights; no paper or author code is redistributed in this package. Author R DESCRIPTION reports GPL>=2; this numerical implementation was independently written from equations. AI assisted source extraction, coding and tests. Original realized coefficients and estimator table reproduction remain unverified; they are unnecessary for this explicitly adapted fixed-draw contribution. Named scientific review, maintainer distinctness acceptance and external submission are pending.

## Scientific review revision R1: comparison with registered IV drafts

Compared the five actual registry draft generators/records on 2026-10-29, registry blob `3fa452e91c0c61403fc8921190555d4f97053f5e`. All are draft/unverified; this is a proposed structural comparison, not proof of eight accepted families. Source equations and observation rules, not different paper titles, seeds or coefficient values, drive the judgement.

| Existing draft | Provisional comparison | Scientific reason |
|---|---|---|
| Athey2019 | distinct_family_candidate | Genetic counts with heteroskedastic continuous exposure and pleiotropic effects differ from binary one-sided noncompliance. |
| Ding2017 | distinct_family_candidate | Many binomial genetic IVs and continuous A/Y differ from a single binary IV and binary response probability-table law. |
| Kang2016 | related_structurally_different_candidate | Both allow invalid IV direct effects, but Ye has Z-dependent exposure noise (1+Z delta)*epsilon_A and a heteroskedastic residual identification route, whereas inspected Kang has homoskedastic correlated errors. Binomial versus Gaussian Z, m, beta and invalid counts alone are not the independence argument; family scope still needs maintainer approval. |
| Dikkala2020 | distinct_family_candidate | Many discrete pleiotropic IVs with heteroskedastic exposure noise differ from a single-IV sine-response law. |
| Hartford2017 | distinct_family_candidate | Genetic heteroskedastic/pleiotropic model differs from time/emotion-dependent demand and correlated price/outcome innovations. |

The full 8-by-5 matrix and evidence receipts are retained in `literature/batch_20261029/revision_01/`; only this contribution's comparison is included here. Final scientific acceptance, family count and target eligibility are maintainer decisions.
