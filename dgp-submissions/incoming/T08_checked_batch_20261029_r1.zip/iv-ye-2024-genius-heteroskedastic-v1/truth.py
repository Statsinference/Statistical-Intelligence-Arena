"""Constant causal slope of the outcome structural equation."""
def truth(config):
    return {'value':float(config['beta']),'estimated_error':0.0,
            'method':'analytic unit intervention contrast','target':'E[Y(do(A=1))-Y(do(A=0))]'}
