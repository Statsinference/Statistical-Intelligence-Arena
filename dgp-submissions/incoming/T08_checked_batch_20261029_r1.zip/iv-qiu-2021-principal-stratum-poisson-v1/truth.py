"""Eq. (38): common subgroup effects cancel unit by unit."""
def truth(config):
    return {"value":float(config["alpha0"]),"estimated_error":0.0,
            "method":"Y(1)-Y(0)=alpha0 since Gaussian and Poisson terms are shared"}
