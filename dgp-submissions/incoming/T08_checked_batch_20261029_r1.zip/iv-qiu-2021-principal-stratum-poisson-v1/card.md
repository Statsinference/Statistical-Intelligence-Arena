# Principal-stratum Poisson confounding under a monotone binary IV
Qiu, Y., Tao, J., and Zhou, X.-H. (2021). *Inference of Heterogeneous Treatment Effects using Observational Data with High-Dimensional Covariates*. JRSS-B 83(5), 1016–1043. DOI https://doi.org/10.1111/rssb.12469.
Read publisher HTML https://academic.oup.com/jrsssb/article/83/5/1016/7056069: Section 2 Assumption 1 and Eq.(1) define IV-identified LCSTE; Section 6 preceding DGP2 gives X,Z,D; DGP2 Eq.(38) and following paragraph give outcome law/constants. The equation's MathML matrix was inspected: BOTH potential outcomes receive the same K11 always-taker and K00 never-taker additions. This detail is not inferable from flattened text alone. No author software used; commit not applicable.

## Source law and generation order
iid individuals, with no clusters/interference. p=200, selected from source grid 50,100,200,300,400,500; source n=200 or 400, while hook accepts n. All coefficients and scenarios below come from Section 6 DGP2.
X~Normal_p(0,Sigma), Sigma_jk=1*0.5^|j-k|. The multiplier sigma0=1 is covariance, not a standard deviation. gamma1_j=gamma2_j=j^-2, beta_j=2*j^-2 for j=1,...,p.
Z|X~Bernoulli(expit(X'gamma1)).
Draw e_d0,e_d1 iid N(0,1), independently of X and Z conditional X. D0=I(X'gamma2-1+e_d0>=0); D1*=I(X'gamma2+1+e_d1>=0); D1=max(D1*,D0); D=ZD1+(1-Z)D0. The max operation removes defiers. Treating D1* as D1 would be scientifically wrong.
Draw e0~N(0,1), independent of treatment errors. Draw K11~Poisson(lambda11), K00~Poisson(lambda00). Let B=X'beta+e0+K11*I(D0=1)+K00*I(D1=0). Y0=B, Y1=1+B, and Y=DY1+(1-D)Y0.
lambda00=0.5 and lambda11=0.5,0.75,1,1.25 produce four source scenarios in ONE family. No interactions are enabled. Original paper also considers interaction terms; they are omitted explicitly, not silently averaged.

Independent Poisson innovations independent of all other draws are the explicit simulation reading used here. Source prose does not separately itemize their whole joint coupling, and no author-code comparison is claimed; record this as an adaptation/review item. The identical shifts cancel from the treatment contrast for any coupling. NumPy local PCG64 and stationary AR(1) implement the distribution without sample-by-sample author-software equivalence.

Only X1,...,X200,Z,D,Y are returned. Internal treatment potentials, principal stratum, noises, Poisson values, propensity, effect and truth are absent. All p covariates enter both first stage and baseline outcome with nonzero weak-sparsity coefficients; these are not decorative nuisance columns.

## Estimand and identification
Source alpha0=1 is the target. Eq.(38) gives Y1-Y0=1 unit by unit; hence LCSTE(x)=1 for compliers at every x and LATE=1. Source Section 6 explicitly reports alpha0 and says DDML estimates the same average effect without interaction. This contribution therefore needs no invented fixed-x or policy functional.
Although the title emphasizes heterogeneity, Section 2 defines conditional IV identification on compliers, not ordinary strong-ignorability CATE. Classification as IV is justified scientifically; maintainers still decide taxonomy and family acceptance.
Conditional independence of Z, exclusion, consistency, monotonicity and positive instrument/first-stage probabilities identify LATE. Gaussian X has unbounded support; expit(t) is pointwise strictly positive, but no uniform overlap constant is claimed. D and Y are confounded by unobserved principal-stratum intercept shifts.

## Verification
truth returns alpha0=1 analytically with zero numerical error. verify independently enumerates stratum probabilities PA=Phi(t-1), PC=(1-PA)*Phi(t+1), PN=(1-PA)*(1-Phi(t+1)); it computes conditional outcome/first-stage means under Z=0/1 and their Wald ratio. Gaussian tails can make finite arithmetic differences tiny; checks restrict PC>1e-9 and predeclare tolerance 1e-6 for this diagnostic. This does not alter truth tolerance.
All three strata and arbitrary distinct Poisson shifts are used in a deterministic potential-outcome cancellation check. A public-generator sample of 65536 in eight chunks, fixed seeds 20261029..20261036, checks E[(Z-expit(t))*(Y-D-2t)]=0 at threshold 7 estimated standard errors. It also checks first-five-component Gaussian means/second moments against independently constructed covariance. Statistical diagnostics are not source acceptance or CI coverage.
AR(1) recurrence is an exact Gaussian covariance construction. It avoids creating and factorizing a 200x200 covariance repeatedly, and implements sigma0 as variance.

## Family and rights
This family is structurally distinct from Athey2019's latent compliance outcome system: max-repaired two-threshold treatment potentials, high-dimensional weak-sparsity conditional instrument model, and additive Poisson shifts common to both potential outcomes in always/never strata. It is not linear correlated continuous treatment with invalid instruments (Kang/Lin/Guo). Different lambda values remain scenarios.
Publisher labels paper CC BY-NC 4.0, authors/Wiley/RSS. No paper, author code, OHIE data or full source text in ZIP. Independent Python and attribution only; rights for planned use and named scientific acceptance remain pending. Codex assisted audit, implementation and testing; automatic PASS is not scientific acceptance.

## Scientific review revision R1: comparison with registered IV drafts

Compared the five actual registry draft generators/records on 2026-10-29, registry blob `3fa452e91c0c61403fc8921190555d4f97053f5e`. All are draft/unverified; this is a proposed structural comparison, not proof of eight accepted families. Source equations and observation rules, not different paper titles, seeds or coefficient values, drive the judgement.

| Existing draft | Provisional comparison | Scientific reason |
|---|---|---|
| Athey2019 | related_structurally_different_candidate | Both use IV compliance and continuous outcomes, but Qiu generates two independent normal thresholds then D1=max(D1star,D0), two-sided noncompliance, and principal-stratum Poisson shifts in both potential outcomes; Athey uses one-sided A=ZQ with compliance depending on outcome noise. High p or a changed truth alone is not the claimed difference. |
| Ding2017 | distinct_family_candidate | High-dimensional Gaussian X, threshold compliance and continuous outcomes with Poisson stratum shifts differ from a no-X fully binary finite-table model. |
| Kang2016 | distinct_family_candidate | Binary monotone treatment and latent principal-stratum outcome shifts differ from a continuous linear first stage with direct invalid-IV effects. |
| Dikkala2020 | distinct_family_candidate | Binary principal-stratum treatment and Poisson-shift outcomes differ from a continuous sine-response IV law. |
| Hartford2017 | distinct_family_candidate | Threshold compliance with stratum-confounded continuous outcome differs from nonlinear demand with continuous price and time/emotion covariates. |

The full 8-by-5 matrix and evidence receipts are retained in `literature/batch_20261029/revision_01/`; only this contribution's comparison is included here. Final scientific acceptance, family count and target eligibility are maintainer decisions.
