"""Independent stratum enumeration and public-generator IV diagnostics."""
import importlib.util
import math
from pathlib import Path
import numpy as np


def verify(config):
    p = int(config["p"])
    checks = [{"name":"source constants",
        "passed":config=={"p":200,"alpha0":1,"sigma0":1,"rho_x":.5,
                         "zeta":1,"lambda00":.5,"lambda11":config["lambda11"],"interaction":False}
                  and config["lambda11"] in (.5,.75,1.,1.25)}]
    # Conditional on t=X'gamma: independent threshold normals give these strata.
    grid = np.linspace(-6,6,601)
    phi = lambda a: .5*(1+math.erf(a/math.sqrt(2)))
    wald = []
    for t in grid:
        pa = phi(t-1)
        pc = (1-pa)*phi(t+1)
        pn = (1-pa)*(1-phi(t+1))
        # Enumerate both Z states; E[Y|stratum,D] known from Poisson means.
        ed0, ed1 = pa, pa+pc
        ey0 = 2*t + pa*(1+config["lambda11"]) + pn*config["lambda00"]
        ey1 = 2*t + pa*(1+config["lambda11"]) + pn*config["lambda00"]+pc
        if pc > 1e-9:
            wald.append((ey1-ey0)/(ed1-ed0))
    err = float(np.max(np.abs(np.asarray(wald)-1)))
    checks.append({"name":"conditional Wald by principal-stratum enumeration",
                   "passed":err<1e-6,"details":{"max_error":err,"grid_points":len(wald)}})
    # Independent error cancellation at every stratum with arbitrary fixed shifts.
    differences = []
    for d0,d1 in ((0,0),(0,1),(1,1)):
        for k11,k00,eps in ((0,0,-2.),(7,3,.4),(1,11,2.)):
            base=eps+k11*d0+k00*(1-d1)
            differences.append((base+1)-base)
    checks.append({"name":"potential contrast for all three strata",
                   "passed":max(abs(v-1) for v in differences)<1e-14})
    spec=importlib.util.spec_from_file_location("qiu2021_verify_generator",Path(__file__).with_name("generator.py"))
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Chunking bounds memory for 200 observed columns.
    residuals, xs, mean_residuals = [], [], []
    for k in range(8):
        sample=module.generate(config,8192,20261029+k)
        x=np.column_stack([sample[f"X{j+1}"] for j in range(p)])
        z,d,y=(np.asarray(sample[v]) for v in ("Z","D","Y"))
        g=1/np.arange(1,p+1,dtype=float)**2
        t=x@g
        instrument=z-1/(1+np.exp(-t))
        r=instrument*(y-d-2*t)
        residuals.extend(r)
        xs.append(x[:,:5])
        pa=np.fromiter((phi(v-1) for v in t),float,count=len(t))
        ps=np.fromiter((phi(v+1) for v in t),float,count=len(t))
        pd=pa+z*(1-pa)*ps
        py=pd+2*t+config["lambda11"]*pa+config["lambda00"]*(1-pa)*(1-ps)
        mean_residuals.append(np.column_stack([(d-pd),(d-pd)*z,
                                               (y-py),(y-py)*z]))
    r=np.asarray(residuals)
    zstat=float(abs(r.mean())/(r.std(ddof=1)/np.sqrt(len(r))))
    checks.append({"name":"public generator conditional IV residual",
                   "passed":zstat<7,"details":{"n":len(r),"seed_start":20261029,"z":zstat,"threshold":7}})
    mr=np.concatenate(mean_residuals)
    conditional_z=float(np.max(abs(mr.mean(axis=0))/(mr.std(axis=0,ddof=1)/np.sqrt(len(mr)))))
    checks.append({"name":"threshold max repair and Poisson conditional means",
                   "passed":conditional_z<7,"details":{"maximum_z":conditional_z,"threshold":7}})
    xx=np.concatenate(xs)
    means=np.max(abs(xx.mean(axis=0)))*np.sqrt(len(xx))
    cov=xx.T@xx/len(xx)
    expected=.5**abs(np.arange(5)[:,None]-np.arange(5)[None,:])
    se=np.sqrt((1+expected**2)/len(xx))
    mz=float(np.max(abs(cov-expected)/se))
    checks.append({"name":"independent Gaussian covariance moments",
                   "passed":bool(means<7 and mz<7),
                   "details":{"max_mean_z":float(means),"max_second_moment_z":mz}})
    checks.append({"name":"observed-only fields",
                   "passed":set(sample)=={f"X{j+1}" for j in range(p)}|{"Z","D","Y"}})
    return {"passed":all(c["passed"] for c in checks),"checks":checks}
