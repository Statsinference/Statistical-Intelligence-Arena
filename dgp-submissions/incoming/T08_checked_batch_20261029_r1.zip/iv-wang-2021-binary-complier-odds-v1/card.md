# Binary IV complier risk difference and odds product

**Review priority R1:** truth=-1 is alpha1, a slope parameter of the conditional complier-effect curve, not marginal LATE or ATE. Whether this target category qualifies for T08 remains pending maintainer confirmation; machine PASS is not target approval. See the R1 scalar-target eligibility section below.

Wang, L., Zhang, Y., Richardson, T. S., and Robins, J. M. (2021), *Estimation of local treatment effects under the binary instrumental variable model*, Biometrika 108(4), 881–894, DOI https://doi.org/10.1093/biomet/asab003.
Read https://arxiv.org/html/2007.14458v2, dated 22 March 2022: Section 3 Theorem 1 (principal-stratum parameterization), Section 5 (all fixed parameters), Table 2 (target coefficients), Supplement S1 equations S4–S5 (inverse map).
Publisher confirms title, authors, DOI, year, volume and pages. This is a paper-version reconstruction, not a claim of exact byte/sample reproduction of the published supplement. No author software used; code commit is not applicable.

## Generation, in order
Individuals are iid; no clustering or interference. Let x~Uniform(-1,1), with implicit intercept 1. Define q=expit(-0.4+0.8*x), pz=expit(0.1-x), delta=tanh(-x), OP=exp(-0.4+x).
Draw binary Z with probability pz independently of the principal stratum given x. Principal stratum probabilities are CO:q, AT:(1-q)*q and NT:(1-q)^2. No defiers.
D=Z for compliers, D=1 for always takers and D=0 for never takers.
Complier outcome risks f0,f1 solve f1-f0=delta and f0*f1/((1-f0)*(1-f1))=OP. The unique feasible f0 lies in [max(0,-delta),min(1,1-delta)]. S4 gives an explicit quadratic solution; the generator uses 60 bisection iterations on the product equation so OP=1 is well defined. f0/f1 are probabilities without clipping.
Draw observed Y as Bernoulli(fD) in CO, Bernoulli(q) in AT and Bernoulli(q) in NT. This realizes exactly the S5 observed multinomial law without making a scientific claim about the unspecified joint coupling of Y(0),Y(1). Only X,Z,D,Y are returned; stratum and probabilities are internal.

All parameters: alpha=(0,-1), beta_i=(-0.4,0.8) for i=1,...,4, eta=(-0.4,1), gamma=(0.1,-1). Original simulation n=1000; n is a hook argument. One source_additive scenario. The multiplicative branch and fitting misspecification experiments are not separate contributions.

## Estimand and IV conditions
The scalar is alpha1=-1, the source-reported slope of conditional LATE(x)=tanh(alpha0+alpha1*x). Table 2 explicitly studies this scalar, so it is not a new arbitrary fixed-x query. It is not the marginal LATE or whole-population ATE. Conditional on x, the complier potential outcome risk difference is f1-f0. Exclusion and conditional independence, relevance q>0, overlap pz in (0,1), monotonicity and consistency identify the curve. Uniform bounded X gives uniform positive overlap and first stage. Always/never takers create confounding; their unobservable counterfactual risks need not be supplied for the observed-law target.

## Independent verification
truth returns the exact represented coefficient and error zero (numerical arithmetic only; not source uncertainty). verify implements independent, stable closed-form S4 inversion, constructs all eight S5 observed probability cells, checks normalization and signs over 2001 x values including OP=1 at x=0.4, obtains conditional Wald LATE, then fits arctanh(Wald) on (1,x) to recover (0,-1).
A separate public-generator sample of 131072 (seed 20261029) tests conditional Z,D,Y residual moments against the independent closed form, weighted by 1,x,Z. Threshold 7 estimated standard errors is a diagnostic, not a finite-sample simultaneous bound or estimator coverage claim. Source-constant checks and observed-column checks are included.

## Adaptations, family comparison, rights
Independent NumPy PCG64 probability-law implementation; no source R seed equivalence, fitting, bootstrap or CI reproduction. Source version is a later arXiv version; publication exact-match is not asserted.
This is structurally distinct from registry Athey2019 latent continuous compliance design and Ding2017 binary no-covariate bias amplification: continuous covariate, explicit variation-independent odds product and heterogeneous tanh complier curve. It is also distinct from Wang2018 marginal Wald nuisance parameterization (which is cited and contrasted in source Section 2/Remark 2). Maintainer family acceptance remains pending.
Publisher copyright belongs to Biometrika Trust. arXiv access is not permission to redistribute paper or author software. ZIP contains independent Python, metadata and attribution only; no paper/source text/code/data. Rights and named scientific acceptance remain review items. Codex assisted audit, implementation and tests; machine PASS is not scientific acceptance.

## Scientific review revision R1: scalar-target eligibility

**Target category: scalar parameter of an identified conditional causal-effect curve.** Let C={D(1)>D(0)} and delta_C(x)=E[Y(1)-Y(0)|C,X=x]=tanh(alpha0+alpha1*x). The returned -1 is alpha1 on the arctanh risk-difference scale, not E[Y(1)-Y(0)|C], a risk difference at a chosen x, or whole-population ATE. It need not lie in [-1,1] in general, although the curve itself must.

The source Table 2 evaluates this coefficient. Under the binary-IV assumptions and the correctly specified tanh model, the conditional Wald curve is identified; arctanh(delta_C(x))=alpha0+alpha1*x on nondegenerate X support identifies the coefficients. This is model-specific causal-effect parameter identification, not an assertion that every scalar coefficient meets this project's intake policy.

**Project eligibility remains pending maintainer confirmation.** The retrieved ZIP format requires an estimand definition and accepts numeric scenario truth, but does not provide an affirmative ruling on conditional-effect curve coefficients. Parser/runtime PASS therefore cannot settle eligibility. The existing Athey draft's point-query target is also unverified and is not an approval precedent. Keep the original target and one family; do not silently replace it with marginal LATE, a selected x query, or a second contribution. If the project allows only marginal ATE/LATE or another prescribed target, this contribution is on hold until a documented target decision and fresh truth verification.

## Scientific review revision R1: comparison with registered IV drafts

Compared the five actual registry draft generators/records on 2026-10-29, registry blob `3fa452e91c0c61403fc8921190555d4f97053f5e`. All are draft/unverified; this is a proposed structural comparison, not proof of eight accepted families. Source equations and observation rules, not different paper titles, seeds or coefficient values, drive the judgement.

| Existing draft | Provisional comparison | Scientific reason |
|---|---|---|
| Athey2019 | related_structurally_different_candidate | Both involve compliance. Wang explicitly samples CO/AT/NT with two-sided noncompliance and binary outcome risks linked by odds product; Athey has A=ZQ (no always takers), shared error-dependent compliance and continuous outcome. Different generation rules, not merely a change of target/query. |
| Ding2017 | related_structurally_different_candidate | Both are binary IV outcome designs. Wang has continuous X, covariate-dependent principal strata and an identified tanh complier risk-difference curve; Ding has no observed X and fixed binary probability matrices. Curve-coefficient eligibility is a separate unresolved issue, not a reason to count another family. |
| Kang2016 | distinct_family_candidate | Monotone binary compliance, binary risks and a conditional complier curve differ from linear continuous treatment and direct invalid-IV effects. |
| Dikkala2020 | distinct_family_candidate | Principal-stratum binary law differs from continuous treatment with sine response and Gaussian confounding. |
| Hartford2017 | distinct_family_candidate | Principal-stratum binary law differs from nonlinear continuous-price demand; both the sampling law and target population differ. |

The full 8-by-5 matrix and evidence receipts are retained in `literature/batch_20261029/revision_01/`; only this contribution's comparison is included here. Final scientific acceptance, family count and target eligibility are maintainer decisions.
