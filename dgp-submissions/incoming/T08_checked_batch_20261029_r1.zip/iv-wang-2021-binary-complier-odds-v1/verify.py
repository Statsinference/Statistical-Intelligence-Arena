"""Population cell-law inversion and public-sampler moment tests."""
import importlib.util
from pathlib import Path
import numpy as np


def verify(config):
    # Independent S4 inversion via the explicit quadratic, not generator bisection.
    x = np.linspace(-1, 1, 2001)
    a, b, e = (np.asarray(config[k]) for k in ("alpha", "beta", "eta"))
    delta = np.tanh(a[0]+a[1]*x)
    q = 1/(1+np.exp(-(b[0]+b[1]*x)))
    op = np.exp(e[0]+e[1]*x)
    # Stable conjugate form of S4; OP=1 has the continuous limit.
    aa = 1-op
    bb = delta+op*(2-delta)
    cc = -op*(1-delta)
    f0 = -2*cc/(bb+np.sqrt(bb*bb-4*aa*cc))
    f1 = f0+delta
    cells = np.zeros((len(x), 2, 2, 2))  # x,z,d,y
    # Exact S5, independently enumerate principal-stratum mixture cells.
    for z in (0, 1):
        cells[:, z, 0, 1] = (1-q)**2*q+(1-z)*q*f0
        cells[:, z, 0, 0] = (1-q)**3+(1-z)*q*(1-f0)
        cells[:, z, 1, 1] = (1-q)*q*q+z*q*f1
        cells[:, z, 1, 0] = (1-q)*q*(1-q)+z*q*(1-f1)
    ey = cells[:, :, :, 1].sum(axis=2)
    ed = cells[:, :, 1, :].sum(axis=2)
    wald = (ey[:, 1]-ey[:, 0])/(ed[:, 1]-ed[:, 0])
    fit = np.linalg.lstsq(np.column_stack([np.ones(len(x)), x]),
                          np.arctanh(wald), rcond=None)[0]
    checks = [
        {"name": "source fixed coefficients", "passed": config == {
            "alpha":[0,-1],"beta":[-0.4,0.8],"eta":[-0.4,1],"gamma":[0.1,-1]}},
        {"name":"all conditional probability cells valid",
         "passed": bool(cells.min() >= -1e-14 and np.max(abs(cells.sum(axis=(2,3))-1)) < 1e-12)},
        {"name":"Wald inversion recovers source alpha", "passed": bool(np.max(abs(fit-a)) < 1e-10),
         "details": {"recovered_alpha":fit.tolist(),"max_wald_error":float(np.max(abs(wald-delta)))}},
        {"name":"odds product and OP=1 feasible", "passed":bool(np.max(abs(f0*f1-op*(1-f0)*(1-f1)))<1e-12)},
    ]
    # Large sample checks public generator using conditional expectations built here.
    spec = importlib.util.spec_from_file_location("wang2021_verify_generator", Path(__file__).with_name("generator.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    sample = mod.generate(config, 131072, 20261029)
    xx, z, d, y = (np.asarray(sample[k]) for k in ("X","Z","D","Y"))
    qq = 1/(1+np.exp(-(-.4+.8*xx)))
    pp = 1/(1+np.exp(-(.1-xx)))
    dd = np.tanh(-xx)
    oo = np.exp(-.4+xx)
    B = dd+oo*(2-dd)
    ff = 2*oo*(1-dd)/(B+np.sqrt(B*B+4*(1-oo)*oo*(1-dd)))
    py = qq*(ff+z*dd)+(1-qq)*qq
    pd = qq*z+(1-qq)*qq
    maxz = 0.
    for response, expectation in ((z,pp),(d,pd),(y,py)):
        weights = (np.ones(len(xx)),xx) if response is z else (np.ones(len(xx)),xx,z)
        for weight in weights:
            r = weight*(response-expectation)
            stat = float(abs(r.mean())/(r.std(ddof=1)/np.sqrt(len(r))))
            maxz = max(maxz, stat)
    checks.append({"name":"public generator conditional moment diagnostics",
                   "passed":maxz<7., "details":{"n":len(xx),"seed":20261029,"maximum_z":maxz,"threshold":7}})
    checks.append({"name":"latent and oracle fields absent",
                   "passed":set(sample)=={"X","Z","D","Y"}})
    return {"passed":all(c["passed"] for c in checks), "checks":checks}
