"""Target is the source's conditional-LATE curve coefficient, not marginal ATE."""
def truth(config):
    return {"value": float(config["alpha"][1]), "estimated_error": 0.0,
            "method": "Exact coefficient alpha1 of tanh(alpha0+alpha1*x), source Table 2"}
