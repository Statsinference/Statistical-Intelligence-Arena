"""Homogeneous structural intervention contrast, not a sample estimate."""
import math


def truth(config):
    beta = config['beta']
    if isinstance(beta, bool) or not math.isfinite(beta):
        raise ValueError('beta must be finite numeric')
    return {'value': float(beta), 'estimated_error': 0.0,
            'method': 'Y(d+1)-Y(d)=beta holding Z and epsilon fixed',
            'error_interpretation': 'Exact algebraic contrast for represented beta; zero is not sampling uncertainty.'}
