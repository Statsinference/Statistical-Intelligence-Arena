"""Source fixtures + population moments + independent AR(1) simulation.

No generator covariance/validation helper is reused. Diagnostics are finite
statistical checks of the selected law, not source acceptance or CI coverage.
"""
import importlib.util
from pathlib import Path
import numpy as np

N_MC = 65536
MC_SEED = 20261027
Z_LIMIT = 7.0


def _load_generator():
    spec = importlib.util.spec_from_file_location(
        'lin_generator_verify', Path(__file__).with_name('generator.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.generate


def _moment_check(table, expected, name):
    n = len(table)
    # Means known zero: use raw second moments, with exact Gaussian product SE.
    second = table.T @ table / n
    variance = np.diag(expected)
    second_se = np.sqrt((variance[:, None] * variance[None, :] + expected**2) / n)
    maximum = float(np.max(np.abs(second - expected) / second_se))
    mean_max = float(np.max(np.abs(table.mean(axis=0)) / np.sqrt(variance / n)))
    return {'name': name, 'passed': bool(max(maximum, mean_max) <= Z_LIMIT),
            'details': {'n': n, 'max_second_moment_z': maximum,
                        'max_mean_z': mean_max, 'threshold': Z_LIMIT,
                        'se_basis': 'Exact zero-mean Gaussian product variances; 7-SE diagnostic, not a rigorous finite-sample simultaneous probability bound'}}


def verify(config):
    checks = []
    def record(name, passed, details):
        checks.append({'name': name, 'passed': bool(passed), 'details': details})

    alpha = np.asarray(config['alpha'], dtype=float)
    gamma = np.asarray(config['gamma'], dtype=float)
    expected_alpha = np.array([0.0]*9 + [0.4]*6 + [0.2]*6)
    source_ok = (config['p'] == 21 and alpha.shape == (21,) and gamma.shape == (21,)
                 and np.array_equal(alpha, expected_alpha)
                 and (np.array_equal(gamma, np.full(21, 0.15))
                      or np.array_equal(gamma, np.full(21, 0.4)))
                 and all(config[k] == v for k, v in {
                     'beta': 1, 'instrument_variance': 0.8, 'instrument_rho': 0.3,
                     'epsilon_variance': 1, 'eta_variance': 1,
                     'error_correlation': 0.6}.items()))
    record('pinned_code_parameter_fixture', source_ok,
           'One of two fixed source scenarios; 9 zero and 12 nonzero alpha; no permissive unknown scenarios.')
    if not source_ok:
        return {'passed': False, 'checks': checks}

    # Separate explicit scalar construction, no generator covariance helpers.
    s = np.array([[0.8 * 0.3**abs(j-k) for k in range(21)] for j in range(21)])
    errors = np.array([[1.0, 0.6], [0.6, 1.0]])
    record('positive_definite_covariances',
           np.linalg.eigvalsh(s).min() > 0 and np.linalg.eigvalsh(errors).min() > 0,
           {'min_eigenvalue_z': float(np.linalg.eigvalsh(s).min()),
            'min_eigenvalue_errors': float(np.linalg.eigvalsh(errors).min())})
    # Underlying vector order: Z1..Z21, epsilon, eta.
    covariance = np.zeros((23, 23))
    covariance[:21, :21] = s
    covariance[21:, 21:] = errors
    mapping = np.zeros((23, 23))
    mapping[:21, :21] = np.eye(21)
    mapping[21, :21], mapping[21, 22] = gamma, 1.0
    mapping[22, :21] = gamma + alpha
    mapping[22, 21:] = [1.0, 1.0]
    expected = mapping @ covariance @ mapping.T
    first_stage = np.linalg.solve(s, expected[:21, 21])
    reduced_form = np.linalg.solve(s, expected[:21, 22])
    ratios = reduced_form[:9] / first_stage[:9]
    record('population_partial_reduced_form_ratios',
           np.allclose(ratios, 1.0, atol=1e-12, rtol=0),
           {'ratios_valid_1_to_9': ratios.tolist(),
            'scope': 'Joint regression coefficients S^-1 Cov(Z,Y), not marginal Wald ratios with correlated invalid instruments.'})

    columns = [f'Z{j+1}' for j in range(21)] + ['D', 'Y']
    generated = _load_generator()(config, N_MC, MC_SEED)
    record('observed_columns', set(generated) == set(columns),
           '23 observed columns, no errors or validity labels')
    actual = np.column_stack([generated[c] for c in columns])
    checks.append(_moment_check(actual, expected, 'generator_gaussian_population_moments'))
    # Recover internal residuals solely inside verification; never model inputs.
    eta = actual[:, 21] - actual[:, :21] @ gamma
    epsilon = actual[:, 22] - actual[:, 21] - actual[:, :21] @ alpha
    residual_table = np.column_stack([actual[:, :21], epsilon, eta])
    checks.append(_moment_check(residual_table, covariance, 'generator_residual_moments'))

    # Independent AR(1) recurrence and scalar correlated-error construction.
    rng = np.random.Generator(np.random.PCG64(MC_SEED + 104729))
    independent = np.empty((N_MC, 23))
    independent[:, 0] = np.sqrt(0.8) * rng.standard_normal(N_MC)
    for j in range(1, 21):
        independent[:, j] = (0.3 * independent[:, j-1]
                              + np.sqrt(0.8 * (1-0.3**2)) * rng.standard_normal(N_MC))
    u, v = rng.standard_normal((2, N_MC))
    independent[:, 21] = independent[:, :21] @ gamma + 0.6*u + 0.8*v
    independent[:, 22] = independent[:, 21] + independent[:, :21] @ alpha + u
    checks.append(_moment_check(independent, expected, 'independent_ar1_population_moments'))
    # Population-residualized valid instrument: E[hY]/E[hD]=beta.
    # Adjusts for correlated invalid Z; denominator is a finite-sample estimate.
    weights = np.linalg.solve(s, np.eye(21)[:, 0])
    h = independent[:, :21] @ weights
    denominator = float(np.mean(h * independent[:, 21]))
    numerator = float(np.mean(h * independent[:, 22]))
    contrast = float(np.mean(h * (independent[:, 22] - independent[:, 21])))
    se_contrast = float(np.sqrt(weights @ s @ weights * (alpha @ s @ alpha + 1) / N_MC))
    record('independent_residualized_iv_truth',
           abs(contrast) <= Z_LIMIT * se_contrast and abs(denominator) > 0.01,
           {'beta_mc': numerator / denominator, 'population_beta': 1.0,
            'moment_error': contrast, 'moment_se': se_contrast,
            'threshold_se': Z_LIMIT, 'seed': MC_SEED + 104729,
            'interpretation': 'MC diagnostic, not the oracle truth or an estimated_error for truth.py'})
    return {'passed': all(c['passed'] for c in checks), 'checks': checks,
            'shared_components': 'Both routes share the selected scientific law and configuration; independent recurrence vs Cholesky. Population algebra is a model consistency check, not independent-person scientific acceptance.',
            'mc_design': {'n': N_MC, 'seed_generator': MC_SEED,
                          'seed_reference': MC_SEED + 104729, 'z_limit': Z_LIMIT}}
