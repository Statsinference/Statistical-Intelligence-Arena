"""Analytic causal ATE of the algebraic completion; no sample is used."""
import math


def truth(config):
    expected = {"alpha": [0.1, 0.5], "beta": [0.0, -0.5], "gamma": [0.1, -0.5],
                "eta": [-0.5, 1.0], "zeta": [0.0, -1.0], "kappa": 0.1}
    if config != expected:
        raise ValueError("Only the audited Section 5 parameter setting is supported")
    a, b = config["alpha"]
    def primitive(x):
        return math.log(math.cosh(a+b*x))/b
    value = primitive(-0.5)-primitive(-1)+primitive(1)-primitive(0.5)
    return {"value": value, "estimated_error": 2e-15,
            "method": "Analytic log-cosh antiderivative; floating-point roundoff diagnostic",
            "target": "E[Y(1)-Y(0)] = E_X delta(X) = average conditional Wald ratio under the explicit algebraic causal completion"}
