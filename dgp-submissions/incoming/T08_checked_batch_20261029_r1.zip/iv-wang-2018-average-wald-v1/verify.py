"""Independent odds-product inversion by root solving plus adaptive quadrature."""
import math
from scipy.integrate import quad
from scipy.optimize import brentq, minimize_scalar


def _root(d, q):
    lo, hi = max(0.0, -d), min(1.0, 1.0-d)
    def polynomial(p):
        return p*(p+d)-q*(1-p)*(1-p-d)
    return brentq(polynomial, lo, hi, xtol=5e-15)


def verify(config):
    # Deliberately no imports from generator.py or truth.py.
    expected = {"alpha": [0.1, 0.5], "beta": [0.0, -0.5], "gamma": [0.1, -0.5],
                "eta": [-0.5, 1.0], "zeta": [0.0, -1.0], "kappa": 0.1}
    if config != expected:
        raise ValueError("Unsupported parameters")
    def ratio(x):
        dd, delta = math.tanh(-0.5*x), math.tanh(0.1+0.5*x)
        p0d = _root(dd, math.exp(-0.5+x))
        p0y = _root(dd*delta, math.exp(-x))
        return ((p0y+dd*delta)-p0y)/((p0d+dd)-p0d)
    parts = [quad(ratio, lo, hi, epsabs=1e-12, epsrel=1e-12) for lo,hi in [(-1,-0.5),(0.5,1)]]
    independent = sum(p[0] for p in parts)
    # Interval enclosure uses F decreasing in d, increasing in q. This follows
    # from monotonicity of the odds product in p and in d on admissible support.
    # Conservatively bound each factor over subintervals, not just grid points.
    potential_bounds = []
    identity_errors = []
    for support_lo, support_hi in [(-1,-0.5),(0.5,1)]:
        for j in range(200):
            lo = support_lo+(support_hi-support_lo)*j/200
            hi = support_lo+(support_hi-support_lo)*(j+1)/200
            ds = sorted([math.tanh(-0.5*lo),math.tanh(-0.5*hi)])
            ts = [math.tanh(0.1+0.5*lo),math.tanh(0.1+0.5*hi)]
            products = [d*t for d in ds for t in ts]
            qd = [math.exp(-0.5+lo),math.exp(-0.5+hi)]
            qy = [math.exp(-hi),math.exp(-lo)]
            pd_range = [_root(ds[1],qd[0]),_root(ds[0],qd[1])]
            py_range = [_root(max(products),qy[0]),_root(min(products),qy[1])]
            for u in (0,1):
                k = 0.1*(2*u-1)
                rd = [p+k for p in pd_range]
                ry = [p+k for p in py_range]
                for a in (0,1):
                    terms = [t*(a-p) for t in ts for p in rd]
                    potential_bounds += [ry[0]+min(terms),ry[1]+max(terms)]
                x = (lo+hi)/2
                dd,t = math.tanh(-0.5*x),math.tanh(0.1+0.5*x)
                rdx = _root(dd,math.exp(-0.5+x))+k
                ryx = _root(dd*t,math.exp(-x))+k
                g0,g1 = ryx-t*rdx,ryx-t*rdx+t
                for z in (0,1):
                    pd = rdx+z*dd
                    identity_errors.append(abs((1-pd)*g0+pd*g1-(ryx+z*dd*t)))
    def causal_contrast(x):
        dd,t = math.tanh(-0.5*x),math.tanh(0.1+0.5*x)
        total = 0.0
        for u in (0,1):
            k=0.1*(2*u-1)
            rd=_root(dd,math.exp(-0.5+x))+k
            ry=_root(dd*t,math.exp(-x))+k
            g0=ry-t*rd
            g1=g0+t
            total += 0.5*(g1-g0)
        return total
    causal_ate = sum(quad(causal_contrast,lo,hi,epsabs=1e-12)[0] for lo,hi in [(-1,-0.5),(0.5,1)])
    def lc(x):
        return math.log(math.cosh(0.1+0.5*x))/0.5
    analytic = lc(-0.5)-lc(-1)+lc(1)-lc(0.5)
    # Numeric extrema checks include both endpoints and bounded optimizers.
    extrema = []
    for lo, hi in [(-1,-0.5),(0.5,1)]:
        for kind in ("D", "Y"):
            for z in (0,1):
                for u in (0,1):
                    def probability(x):
                        dd = math.tanh(-0.5*x)
                        diff = dd if kind == "D" else dd*math.tanh(0.1+0.5*x)
                        q = math.exp(-0.5+x) if kind == "D" else math.exp(-x)
                        return _root(diff,q)+z*diff+0.1*(2*u-1)
                    vals = [probability(lo), probability(hi)]
                    vals += [sgn*minimize_scalar(lambda x: sgn*probability(x),bounds=(lo,hi),method="bounded").fun for sgn in (1,-1)]
                    extrema.extend(vals)
    checks = [
        {"name":"potential_outcome_probability_interval_enclosures","passed":min(potential_bounds)>0 and max(potential_bounds)<1,
         "details":{"lower":min(potential_bounds),"upper":max(potential_bounds),"method":"monotone odds-map plus conservative interval products on 400 subintervals; root numerical tolerance 5e-15"}},
        {"name":"source_marginal_recovery_identity","passed":max(identity_errors)<1e-13,"details":{"max_error":max(identity_errors),"identity":"(1-pD)g0+pD*g1 = rY+z*deltaD*delta"}},
        {"name":"independent_causal_ate","passed":abs(causal_ate-independent)<1e-12,"details":{"value":causal_ate,"method":"integrate potential-outcome probability contrast, average U"}},
        {"name": "independent_population_quadrature", "passed": abs(independent-analytic)<1e-12,
         "details": {"root_inversion_quad": independent,"analytic":analytic,"quad_error":sum(p[1] for p in parts)}},
        {"name": "source_rounded_truth", "passed": round(independent,3)==0.087,"details": "Section 5/Table 2 report 0.087"},
        {"name": "conditional_probability_extrema", "passed": min(extrema)>0 and max(extrema)<1,
         "details": {"min":min(extrema),"max":max(extrema),"scope":"endpoints plus bounded optimization on each interval; numerical diagnostic"}},
        {"name": "relevance_away_from_zero", "passed": abs(math.tanh(-0.25))>0.24,"details": "min |deltaD| = tanh(0.25); sign changes across support intervals"},
        {"name": "unit_odds_product_limit", "passed": abs(_root(0.3,1)-0.35)<1e-13,"details":"q=1 implies p0=(1-d)/2"}]
    return {"passed":all(c["passed"] for c in checks),"checks":checks}
