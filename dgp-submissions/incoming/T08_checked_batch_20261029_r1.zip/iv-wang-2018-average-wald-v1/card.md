# Binary odds-product mechanism with algebraic causal completion

**Review priority R1:** the ATE is defined for our added causal completion under explicit mean no-interaction restrictions. Standard IV conditions and the source conditional marginals alone do not guarantee this ATE identification. The original full D/Y joint law is not recovered; see the R1 identification-boundary section below.

Wang, L. and Tchetgen Tchetgen, E. J. (2018), *Bounded, efficient and multiply robust estimation of average treatment effects using instrumental variables*, JRSS-B 80(3), 531–550, DOI [10.1111/rssb.12262](https://doi.org/10.1111/rssb.12262). Actual read version: [PMC6051728 author manuscript](https://pmc.ncbi.nlm.nih.gov/articles/PMC6051728/), NIHMS927773. Exact locators: Section 4.1 Proposition 2 equations (6),(7), Section 5 first parameter paragraph and seven simulation displays, Table 2 caption, and Section 3 Theorem 1. PDF pagination was not verified; no PDF page is invented.

## Source distributions and constants

The baseline is X=(1,X2), with X2 uniform on (-1,-0.5) union (0.5,1), density one on this total-length-one support. The source gives U~Bernoulli(0.5) and these conditional Bernoulli models:

    P(Z=1|X,U)=expit(0.1-0.5 X2),
    delta=tanh(0.1+0.5 X2), deltaD=tanh(-0.5 X2),
    OPD=exp(-0.5+X2), OPY=exp(-X2), kappa=0.1,
    P(D=1|Z,X,U)=p0D+Z*deltaD+0.1*(2U-1),
    P(Y=1|Z,X,U)=p0Y+Z*deltaD*delta+0.1*(2U-1).

Source constants: alpha=(0.1,0.5), beta=(0,-0.5), gamma=(0.1,-0.5), eta=(-0.5,1), zeta=(0,-1), kappa=0.1. Eta belongs to treatment odds product; zeta belongs to outcome odds product. No coefficients are invented or fitted.

For risk difference d and odds product q, put B=q(2-d)+d. Equations (6),(7) specify

    F(d,q)=(B-sqrt(B²+4q(1-d)(1-q)))/(2(q-1)).
    p0D=F(deltaD,OPD), p0Y=F(deltaD*delta,OPY).

Code evaluates the equivalent stable rationalization F(d,q)=2q(1-d)/(B+sqrt(B²+4q(1-d)(1-q))), which also gives F(d,1)=(1-d)/2. The defining equation is p0(p0+d)=q(1-p0)(1-p0-d). The q=1 endpoint limit is tested.

## Our explicit causal coupling adaptation

**The source's conditional Bernoulli marginals alone do not specify the joint counterfactual law.** We complete them algebraically, with no additional numerical coefficients. This is `adapted_from_source`, not a recovered author structural model. Set U independent of X2. Independently generate V_Z,V_D,V_Y~Uniform(0,1), also independent of X2,U, iid across individuals. Write

    t=delta(X), rD=p0D(X)+0.1*(2U-1), rY=p0Y(X)+0.1*(2U-1),
    Z=1{V_Z<expit(0.1-0.5X2)},
    D(z)=1{V_D<rD+z*deltaD(X)},
    g_a(X,U)=rY-t*rD+a*t,  a in {0,1},
    Y(a)=1{V_Y<g_a(X,U)}, D=D(Z), Y=Y(D).

One common V_Y couples Y(0),Y(1), and V_D is independent of V_Y. The implementation draws an equivalent conditional Bernoulli D and uses one uniform for observed Y. It emits no potential outcomes, U, uniforms, nuisance probabilities or individual treatment effects.

All thresholds must lie in [0,1]; none is clipped. The verifier encloses g_a throughout each support interval using monotonicity of F in d (decreasing) and q (increasing), plus interval product bounds on 400 subintervals. Numerical root tolerance is 5e-15, far below the positive margins. This verifies the potential-response probability domain across intervals rather than only at grid points. Direct extrema and grid diagnostics additionally check source conditional probabilities.

The source outcome marginal is recovered exactly:

    E[Y|Z=z,X,U]=(1-P(D=1|z,X,U))*g0+P(D=1|z,X,U)*g1
                 =g0+(rD+z*deltaD)*t
                 =rY+z*deltaD*t.

Since Y is binary, this conditional mean also determines its conditional Bernoulli distribution. Thus source Z,D,Y conditional marginal laws, constants and population covariate law are retained while a specific causal joint law is supplied. This changes the unspecified source D/Y coupling; no claim of source R-stream equivalence is made.

## Target and assumptions

The target is the full-population **causal ATE of this adapted completion**, E[Y(1)-Y(0)], for binary intervention 1 versus 0. Conditional mean contrast g1-g0=t, independent of U, gives ATE=E_X delta(X). The source Section 5 targets this same observed-data average Wald functional and reports rounded value 0.087. Marginalizing U gives treatment contrast deltaD and outcome contrast deltaD*delta, so the conditional Wald ratio equals delta. Average conditional ratios are used, not a ratio of marginal averages.

The causal assumptions follow from the constructed law: consistency Y=Y(D), iid units/no interference, exclusion because Y(a) contains no Z, Z independent of U conditional on X, and Y(a) independent of (D,Z) conditional on (X,U) by independent uniforms. A5.a follows from the U-independent treatment contrast deltaD; A5.b follows from g1-g0=delta. These correspond to the paper's A1-prime through A5 but are our completion's properties, not source-provided structural equations. Potential-outcome probabilities depend on U, and U affects D, giving unobserved confounding.

Instrument propensity is bounded away from 0/1. The absolute first-stage contrast is at least tanh(0.25), approximately 0.2449. Its sign changes across the intervals, so no globally increasing treatment monotonicity or causal LATE claim is made.

## Population truth and independent verification

Integrate tanh(0.1+0.5x) over both intervals with density one. Its primitive is 2 log cosh(0.1+0.5x). `truth.py` evaluates four endpoints analytically. Its 2e-15 error is a conservative floating-point diagnostic, not a formal interval-arithmetic error bound.

`verify.py` imports neither generator nor truth. It solves the original odds-product polynomial with Brent roots and adaptively integrates the reconstructed conditional Wald ratio. Independently, it builds g0,g1 from source means, integrates the potential-outcome contrast and checks source-marginal recovery at both U,Z values. It encloses potential-response probabilities with interval bounds, checks source conditional probability extrema, source 0.087 rounded anchor, first-stage separation and q=1 limit. It shares only source equations/configuration, with a different probability inversion and integration algorithm. Regression tests check a dense support grid, observed conditional moments, seed reproducibility, hidden-variable exclusion and intake compatibility.

Only the source parameter setting is accepted. Analyst misspecification settings in Section 5 alter estimators and are not separate DGP families/scenarios. Source n=500 and 1000 repetitions are experiment sizes; interface n/seed replace those fixed run settings. The intercept remains implicit, X2,Z,D,Y are observed, and algebraic causal completion plus X-U independence are explicit adaptations.

## Rights, assistance and remaining review

Paper files and author source code are excluded from the ZIP. Public source access does not grant a redistribution license; rights review remains pending. Python is independently written from cited mathematical models with AI assistance for extraction, algebraic completion, implementation and checking. Current registry had no Wang odds-product entry when checked. Machine PASS and the causal derivation do not confer named scientific acceptance; student/maintainer review remains pending. No external writes or `review/` changes were performed.

## Scientific review revision R1: identification boundary

**Standard IV assumptions alone do not generally point-identify the ATE.** The paper's Section 3 Theorem 1 adds A5.a or A5.b to its core conditions; see also Remark 1. Our returned value is the ATE of one explicitly constructed causal completion, not proof that the supplied conditional Bernoulli marginals uniquely determine an ATE or the original full joint law.

| Layer | What is specified / what is added |
|---|---|
| Source specification | X support, source numerical coefficients, odds-product inverse maps, conditional Z/D/Y Bernoulli marginals and average conditional Wald functional |
| Our added joint/causal model | U independent of X; independent V_Z,V_D,V_Y; D(z)=I[V_D<rD+z*deltaD]; Y(a)=I[V_Y<rY-t*rD+a*t], with shared V_Y across a |
| Extra mean restriction used for ATE | E[Y(1)-Y(0)|X,U]=t(X): additive-scale effect is not modified by U (A5.b). The construction also gives a U-independent additive first-stage contrast (A5.a) |
| Consequence under this model | Marginal recovery is g0+(rD+z*deltaD)*(g1-g0)=rY+z*deltaD*t. Hence conditional Wald=t, conditional mean causal contrast=t, and ATE=E_X[t] |
| What has not been established | Original author D/Y counterfactual coupling, uniqueness of the completion, identification from ordinary IV assumptions alone, or maintainer acceptance of this adaptation |

These restrictions concern conditional means; they do not claim every individual's Y(1)-Y(0) equals t. Tests of thresholds, marginal recovery and integrals establish internal consistency of the chosen completion, not an empirical test of otherwise untestable causal assumptions. The simulation's conditional marginals do not fix P(D,Y|Z,X,U); our joint coupling is additional scientific content. Retain `adapted_from_source` and submit this construction explicitly for scientific review. If the project requires the author's original joint law, the current contribution must remain pending rather than being relabelled exact reproduction.

## Scientific review revision R1: comparison with registered IV drafts

Compared the five actual registry draft generators/records on 2026-10-29, registry blob `3fa452e91c0c61403fc8921190555d4f97053f5e`. All are draft/unverified; this is a proposed structural comparison, not proof of eight accepted families. Source equations and observation rules, not different paper titles, seeds or coefficient values, drive the judgement.

| Existing draft | Provisional comparison | Scientific reason |
|---|---|---|
| Athey2019 | distinct_family_candidate | Continuous X with binary outcome, nonlinear odds-product marginal parameterization and sign-changing first stage; Athey has one-sided uptake and a continuous heterogeneous outcome. |
| Ding2017 | related_structurally_different_candidate | Both construct binary latent-confounded IV systems. Wang adds a nondegenerate continuous X, source risk-difference/odds-product functions, sign-changing deltaD and explicit A5 causal completion; Ding is a no-X finite-table monotone design. Under a very broad binary-SCM taxonomy these could be related; difference is more than coefficients in one table, but final family decision is pending. |
| Kang2016 | distinct_family_candidate | Nonlinear binary D/Y and odds-product marginal maps differ from continuous linear invalid-IV SEM; exclusion holds in the explicitly completed Wang law. |
| Dikkala2020 | distinct_family_candidate | Binary response probabilities and constructed potential outcomes differ from a continuous sine-response IV law. |
| Hartford2017 | distinct_family_candidate | Binary treatment/outcome, latent binary U and conditional mean homogeneity differ from continuous price/demand response with observed time/emotion. |

The full 8-by-5 matrix and evidence receipts are retained in `literature/batch_20261029/revision_01/`; only this contribution's comparison is included here. Final scientific acceptance, family count and target eligibility are maintainer decisions.
