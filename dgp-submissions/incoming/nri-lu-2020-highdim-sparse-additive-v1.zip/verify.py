"""Independent source-constant, support, and special-angle checks."""
import math


def _direct_special_angle(config):
    # Independent route: use exact sin(pi)=0 and cos(pi)=-1 rather than calling
    # the generic component implementation in truth.py.
    c = [float(v) for v in config["f1_coefficients"]]
    f1 = float(config["f1_scale"]) * (-c[1] - c[3])
    f2 = float(config["f2_scale"]) * 0.0
    f3 = float(config["f3_scale"]) / 2.0
    f4 = 0.0
    return f1 + f2 + f3 + f4, (f1, f2, f3, f4)


def verify(config):
    d = int(config.get("dimension", -1))
    t = float(config.get("dependence_parameter_t", float("nan")))
    source_ok = (
        d == 600 and config.get("active_indices") == [1, 2, 3, 4]
        and t == 0.3 and float(config.get("noise_sd", float("nan"))) == 1.5
        and config.get("source_sample_sizes") == [400, 500, 600]
    )
    q = float(config.get("query_point", float("nan")))
    special, components = _direct_special_angle(config) if q == 0.5 else (float("nan"), ())
    expected_corr = t * t / (1.0 + t * t) if math.isfinite(t) else float("nan")
    checks = [
        {"name": "source_constants_and_active_support", "passed": source_ok,
         "details": "Checks d=600, active coordinates 1–4, t=0.3, noise SD=1.5, and source n values {400,500,600}."},
        {"name": "independent_special_angle_truth", "passed": math.isfinite(special) and abs(special + 1.1) < 1e-12,
         "details": f"Using sin(pi)=0 and cos(pi)=-1 gives components {components} and m(x*)={special:.16g}; expected -1.1."},
        {"name": "shared_uniform_correlation_formula", "passed": math.isfinite(expected_corr) and abs(expected_corr - (0.09 / 1.09)) < 1e-15,
         "details": f"The shared U construction implies Corr(X_j,X_j')=t^2/(1+t^2)={expected_corr:.16g} for j != j'."},
        {"name": "no_interaction_and_inactive_coordinates", "passed": bool(config.get("active_dimension") == 4 and d == 600),
         "details": "The response uses only additive f1(X1)+...+f4(X4); X5,...,X600 are inactive and no cross-coordinate interaction is added."},
        {"name": "query_support", "passed": q == 0.5 and 0.0 <= q <= 1.0,
         "details": "The fixed query is x*=(0.5,...,0.5) inside the displayed [0,1]^600 support."}
    ]
    return {
        "passed": all(c["passed"] for c in checks),
        "checks": checks,
        "shared_components": "The independent route shares the declared source equations and fixed configuration, but does not import truth.py or generated rows; named human scientific review and independent-person reproduction remain separate.",
        "scope_note": "This verifies a scalar pointwise conditional-mean oracle. It does not verify simultaneous confidence-band coverage, the paper's bootstrap, or any estimator performance."
    }
