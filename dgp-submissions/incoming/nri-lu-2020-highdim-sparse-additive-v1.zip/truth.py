"""Analytic scalar oracle for the adapted pointwise conditional mean."""
import math


def _validate(config):
    if config.get("dimension") != 600 or config.get("active_indices") != [1, 2, 3, 4]:
        raise ValueError("truth requires the declared Example 5.1 active structure")
    if float(config["query_point"]) != 0.5:
        raise ValueError("this contribution fixes query_point=0.5")


def _component_values(config):
    x = float(config["query_point"])
    angle = 2.0 * math.pi * x
    s, co = math.sin(angle), math.cos(angle)
    c = [float(v) for v in config["f1_coefficients"]]
    f1 = float(config["f1_scale"]) * (c[0] * s + c[1] * co + c[2] * s**2 + c[3] * co**3 + c[4] * s**3)
    f2 = float(config["f2_scale"]) * (2.0 * x - 1.0) ** 2
    f3 = float(config["f3_scale"]) * x
    f4 = float(config["f4_scale"]) * s / (float(config["f4_denominator_constant"]) - s)
    return f1, f2, f3, f4


def truth(config):
    """Return m(x*) and a floating-point convergence/roundoff diagnostic."""
    _validate(config)
    values = _component_values(config)
    value = float(sum(values))
    # At x*=1/2, sin(pi)=0 and cos(pi)=-1.  This direct special-angle route
    # is used as a numerical audit, not as an estimate from generated data.
    c = [float(v) for v in config["f1_coefficients"]]
    exact_angle = float(config["f1_scale"]) * (c[1] * (-1.0) + c[3] * (-1.0) ** 3)
    exact_value = exact_angle + float(config["f3_scale"]) * 0.5
    estimated_error = abs(value - exact_value) + 4.0 * math.ulp(max(1.0, abs(value)))
    return {
        "value": value,
        "estimated_error": estimated_error,
        "method": "Direct evaluation of f1,f2,f3,f4 at fixed x*=0.5; roundoff audited against sin(pi)=0 and cos(pi)=-1 special-angle evaluation.",
        "error_interpretation": "Floating-point audit only; not a statistical estimation error or a rigorous uniform bound.",
        "target": "m(x*)=E[Y|X=x*]=sum_{j=1}^4 f_j(0.5), x*=(0.5,...,0.5)",
        "components": {"f1": values[0], "f2": values[1], "f3": values[2], "f4": values[3]}
    }
