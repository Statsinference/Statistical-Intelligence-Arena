# NRI collection card: Lu–Kolar–Liu Example 5.1 sparse additive DGP

**Status: candidate; automatic checks do not constitute named scientific acceptance.**

## A. Source and reconstruction

Primary target: Junwei Lu, Mladen Kolar and Han Liu, “Kernel Meets Sieve: Post-Regularization Confidence Bands for Sparse Additive Model,” *Journal of the American Statistical Association* 115(532):2084–2099 (2020), DOI [10.1080/01621459.2019.1689984](https://doi.org/10.1080/01621459.2019.1689984). I read the supplied preprint [arXiv:1503.02978v2](https://arxiv.org/abs/1503.02978), submitted 2018-02-12. The generation source is PDF p.21, §5.1 “Synthetic Data,” Example 5.1; p.22 gives the original inferential target. The supplied materials contain no author code commit or source-code archive, so code provenance is **missing**. Formal-version DGP differences were not checked and remain **unresolved**.

The original source mechanism is

1. (W_{ij}) and (U_i) are iid Uniform[0,1] (mutually independent before the transformation), and
   [
   X_{ij}=(W_{ij}+0.3U_i)/1.3,quad j=1,ldots,600.
   ]
   Rows are iid copies of (X_i). The source states (mathrm{Corr}(X_{ij},X_{ij'})=t^2/(1+t^2)) for (j\ne j'), with (t=0.3), hence (0.09/1.09\approx0.0825688).
2. [
   Y_i=\sum_{j=1}^4 f_j(X_{ij})+\epsilon_i,quad \epsilon_i\stackrel{iid}{\sim}N(0,1.5^2).
   ]
3. [
   \begin{aligned}
   f_1(t)&=6[0.1\sin(2\pi t)+0.2\cos(2\pi t)+0.3\sin^2(2\pi t)+0.4\cos^3(2\pi t)+0.5\sin^3(2\pi t)],\\
   f_2(t)&=3(2t-1)^2,\quad f_3(t)=5t,\\
   f_4(t)&=4\sin(2\pi t)/(2-\sin(2\pi t)).
   \end{aligned}
   ]
   Coordinates 5–600 are inactive in the response. The source also gives (d=600) and (n\in\{400,500,600\}). Its kernel, spline, tuning, bootstrap and 500-repetition details are method-evaluation settings, not needed by this generator.

The implementation returns only the observed numeric columns `X1`–`X600` and `Y`. The latent shared (U_i), the (W_{ij}), component values, counterfactuals, and truth are not output.

### Source reconciliation table

| Item | Primary evidence | Status |
|---|---|---|
| Citation/venue/year | supplied preprint title page; DOI supplied by requester | formal article metadata recorded; version used is v2 |
| Version | arXiv:1503.02978v2, 2018-02-12 | read directly |
| Location | PDF p.21 §5.1 Example 5.1; p.22 target clarification | read directly |
| Equations and fixed parameters | p.21 functions, shared-U construction, (t=.3), noise, (d=600), (n=400,500,600) | read directly |
| Code commit | none in supplied source section/materials | **missing**; maintainer would need the authors’ simulation repository/commit if exact code provenance is required |
| Formal-version DGP comparison | not present in supplied materials | **missing/unresolved**; maintainer would need the final-version supplement or author code |
| Estimand | library adaptation below; paper target is centered (f_1^*(t)) band | explicitly marked adaptation |
| Sampling unit | iid row ( (X_i,Y_i) ) | source states iid copies of (X_j) and iid noise; row-level implementation follows that statement |
| Truth | direct evaluation at fixed query | analytically derived here, not a paper-reported number |

## B. Library target and assumptions

This is **NRI / nonparametric regression**, not a causal task. The scalar estimand is

[
 m(x^*)=E[Y\mid X=x^*]=\sum_{j=1}^4f_j(0.5),
 qquad x^*=(0.5,\ldots,0.5)\in[0,1]^{600}.
]

Because (E[\epsilon\mid X]=0), the conditional mean is the displayed additive sum and inactive coordinates contribute zero. At (t=0.5), (sin(\pi)=0), (cos(\pi)=-1):

[
 f_1(0.5)=6[0.2(-1)+0.4(-1)]=-3.6,quad f_2(0.5)=0,quad f_3(0.5)=2.5,quad f_4(0.5)=0,
]
so the truth is **(m(x^*)=-1.1)**.

The paper instead constructs a confidence band for (f_1^*(t)=f_1(t)-E[f_1(X_1)]) and tests an inactive (f_5(t)=0). Those are not silently substituted for this card’s full conditional-mean query. The current scalar interface does not evaluate a simultaneous band or coverage probability.

Applicable conditions are iid rows, fully observed numeric (X,Y), independent mean-zero Gaussian noise, and the fixed query inside the support. The shared (U_i) creates within-row covariate dependence; it is not an interaction in the response. No treatment, intervention, unconfoundedness, mediation, IV, or other causal assumption is relevant or asserted. Smoothness/finite-support conditions are properties of the displayed functions and support, not claims of a theorem for all estimators.

## C. Adaptation boundary and scenarios

`config.json` contains one named `original` scenario with the source values. The response is deliberately **not** centered, and no intercept or altered noise is introduced. The only target-level adaptation is the fixed full-mean query (m(x^*)). Repeated seeds are smoke-test replicates, not new mechanism families. The source’s estimator choices (quadratic kernel, cubic B-splines, nine knots, (m=5), BIC tuning, multiplier/bootstrap repetitions and first-100-point band evaluation) are not implemented; no claim of reproducing the paper’s coverage study is made.

## D. Truth and independent verification

`truth.py` computes the four component functions at (x^*=0.5) and reports an observed floating-point roundoff diagnostic against the special-angle identities. `verify.py` independently computes the same scalar with (sin(\pi)=0,cos(\pi)=-1), checks the source constants, checks the shared-(U) correlation formula, and checks support/inactive-coordinate structure without importing `truth.py` or generated observations. These routes share the scientific equations and fixed configuration; they are not a substitute for an independent person reproducing the source. `estimated_error` is a roundoff/convergence diagnostic, not a statistical standard error or coverage guarantee.

## E. Diversity, scope and rights

Total dimension is 600; effective dimension is 4. The high-dimensional label refers to the 600 input coordinates relative to (n\in\{400,500,600\}), while 596 inactive coordinates are not called confounders. There are no cross-coordinate interactions. Nonlinearity is tied to the displayed trigonometric polynomial, quadratic and rational-sine functions. This card does not add causal paths, interference, missingness, semisupervision, altered parameters, or extra scenarios.

The paper is copyrighted; no PDF, original code, data, credentials or model weights are packaged. The implementation and documentation were written for this collection task with AI assistance. Automatic checks establish only local format, execution, reproducibility and hash properties; status remains `awaiting_scientific_review` until the maintainer confirms the source, exact target, rights, and independent reproduction.
