# Lin et al. (2024): pinned author-code IV mechanism

Source audit: code-source verified; publication exact-match unresolved.
Scientific acceptance: pending named review and independent-person reproduction.
One mechanism family, two fixed scenarios. Source relation: adapted_from_source.

## Source and version

Lin, Y., Windmeijer, F., Song, X., and Fan, Q. (2024). On the instrumental variable estimation with many weak and invalid instruments. JRSS-B 86(4), 1068-1088. DOI: https://doi.org/10.1093/jrsssb/qkae025.

Selected executable source: https://github.com/QoifoQ/WIT/blob/b0d078533650f0d0766b8c73aaaa99ddc97fe8a2/Numerical%20Demonstrations/Simulation.R

- Commit: b0d078533650f0d0766b8c73aaaa99ddc97fe8a2.
- File blob SHA: 179178ad1f19ac946bc470e61b6e17e7bec63b59.
- One-based source lines 40-49: commented Case 1 and active Case 2.
- Lines 101-114: instrument covariance and sampling.
- Lines 121-128: overwritten intermediate variance and final error covariance.
- Lines 134-136: D and Y structural equations.
- Paper: Section 2.1 Eq.(1), Section 4. Handoff locates PDF page 17 (zero-based 16), journal page 1084; publication covariance typesetting has not been visually resolved here.

The fixed R source was read directly during implementation; it was not executed, copied into this package, or used to download its estimator dependencies.

## Generation law and fixed parameters

Draw individuals independently. Within each individual, Z is a correlated continuous vector; draw Z independently of the two correlated structural errors.

1. Z ~ Normal_21(0, S), where S[j,k]=0.8 * 0.3^abs(j-k), including diagonal 0.8.
2. (epsilon, eta) ~ Normal_2(0, [[1,0.6],[0.6,1]]). Both variances are 1; correlation and covariance are 0.6.
3. D = Z dot gamma + eta.
4. Y = beta * D + Z dot alpha + epsilon.

beta=1. alpha has 9 initial zeros, then 6 entries 0.4, then 6 entries 0.2.

| Scenario | gamma | Source setting |
|---|---|---|
| code_case_2 (default) | 21 entries 0.15 | Active pinned script, original script n=1000 |
| code_case_1 | 21 entries 0.4 | Commented source alternative, original script n=1000 |

The publication discusses n=500/1000. n is supplied to generate, not an extra family or a truth parameter. The harness uses n=128 for smoke checks. All variables have real support, with no truncation or clipping. No baseline adjustment covariates are present: dimension/effective_dimension=0. The separate instrument_dimension=21 records the instruments, all active in D. No nonlinear link, interaction, clustering or interference is introduced. This is a fixed-p law; it does not implement Supplement A5 high-dimensional designs.

Output: exactly Z1,...,Z21,D,Y, each a numeric list of length n. epsilon, eta, validity indicators, parameters and truth remain outside observed inputs.

## Target and identification

The estimand is the homogeneous structural coefficient beta. Holding Z and epsilon fixed, Y(d+1)-Y(d)=beta, so the population unit-treatment contrast also equals beta. This is a continuous-treatment structural target, not a complier/LATE target. No monotonicity assumption is imported from binary-IV theory.

Endogeneity arises from Cov(epsilon,eta)=0.6. Z is independent of both errors. Conditional on the other instruments, Z1-Z9 satisfy exclusion; Z10-Z21 have direct effects. With correlated Z, a zero alpha_j does NOT imply the unadjusted marginal Wald ratio Cov(Z_j,Y)/Cov(Z_j,D) equals beta: other correlated invalid instruments contribute to that moment.

If the valid set is known, use partial regression or residualize a valid instrument on the remaining Z. If validity is unknown, additional identifying restrictions are required. In these fixed scenarios, the joint reduced-form coefficient ratios form groups of sizes 9 (valid), 6 and 6 (invalid), supporting a plurality interpretation; a majority-valid claim would be false. Machine checks do not establish an estimator's identification theorem.

## Truth and independent checks

truth(config) returns beta and estimated_error=0 from the algebraic intervention contrast. Zero refers to the exact represented structural parameter, not sampling uncertainty, coverage, or source uncertainty.

Population identities: Cov(Z,D)=S gamma and Cov(Z,Y)=S(beta gamma+alpha). Solving these joint coefficient systems gives beta on the first 9 valid components. verify constructs S independently by scalar entries and checks positive definiteness, source constants and valid coefficient ratios.

Two Monte Carlo checks are fixed in verify.py before execution: n=65536, seeds 20261027 and 20365756, threshold 7 standard errors. One checks the public generator and reconstructs errors inside the verifier; the other generates Z using a stationary scalar AR(1) recurrence and errors from independent scalar normals. Both check all means and second moments against the full analytical joint Gaussian covariance. For known zero means, SE(mean X_a X_b)=sqrt((V_a V_b+C_ab^2)/n); mean SE=sqrt(V_a/n). The maximum standardized discrepancy must be at most 7. These are diagnostics with exact moment variances, not rigorous simultaneous finite-sample probability bounds.

An additional independent Monte Carlo IV check uses h=Z dot S^-1 e_1. Then E[h(Y-beta D)]=0 and E[hD]=gamma_1. Its standard error follows Var(h)*Var(Z alpha+epsilon)/n, since the two Gaussian factors have zero covariance. A sample ratio is reported diagnostically; it never replaces the analytic truth. Checks share the scientific equations and configuration, and hence do not constitute independent-person source verification.

## Explicit adaptations and unresolved source questions

- Select the fixed author-code covariance law. Exact publication typography remains unresolved.
- Code error variances are 1/1. Publication text describes epsilon SD=0.5 and eta SD=1; the publication-derived error covariance would be [[0.25,0.3],[0.3,1]]. Do not silently combine the two laws.
- README labels Case 1 while the active script is Case 2; this contribution makes the active code case the default.
- Ignore overwritten Sigma_U=txx/Const and mu=30 as generator controls; the final source variance is 1. No fixed concentration=30 claim.
- Use independent Python/NumPy local PCG64 and Cholesky draws. R/MASS uses different random streams and factorization conventions; no sample-by-sample R reproduction is claimed. The Python law directly represents iid Gaussian sampling.
- Omit estimator fitting, repeated simulation experiments, model training and CI evaluations.
- The 2022 preprint Appendix A5 is an algorithm section. Previously imported low/high-dimensional A5 parameter claims must not be treated as verified 2024 Supplement evidence. The final source handoff supersedes those preliminary claims.

## Rights and assistance

No explicit license for redistributing author R code has been confirmed. This package contains independently written Python and attribution, with no R source, paper PDF, data or model weights. Any permissions required for redistribution remain a maintainer review item; public repository access is not an open-source license grant. No unconfirmed license is assigned to the authors' artifacts.

Chat assisted scientific-source auditing; Codex read the pinned script, wrote this Python reconstruction and diagnostics, and ran the local checks recorded under checks/. AI work does not sign named scientific acceptance. Remaining review items: exact publication covariance image, 2024 Supplement version and parameters, permissions, maintainer duplicate check and named independent reproduction.
