# Folded-AR Gaussian Quadratic Interaction and Cubic Projection

## 来源

Deng, S., Ning, Y., Zhao, J. and Zhang, H. (2024). Optimal and Safe Estimation for High-Dimensional Semi-Supervised Learning. Journal of the American Statistical Association 119(548), 2748-2759. DOI: 10.1080/01621459.2023.2277409.

DOI: https://doi.org/10.1080/01621459.2023.2277409

实际阅读: https://arxiv.org/pdf/2011.14185v2；Pinned arXiv:2011.14185v2, 2023-03-18, 57 pages. The journal publication identity is verified against the publisher and PMC metadata; contribution IDs use the verified journal year only, without inferring a publication month. Final typeset simulation equations were not independently compared; fidelity is to the pinned preprint with the explicit adaptations below.

定位: Pinned arXiv v2 Section 6.1, Model 2, printed/PDF p.16; p=500,nL=200 in Section 6.2 pp.17-19 and Figures 1-3 pp.18-20, select N/n=5. Page numbers refer to arXiv v2, not the journal.

PDF SHA-256: c2855accabcbfe5cb1b67161df81e10e28b3d18b9ab9bef21aa89127a9721b86。原文 PDF 不打入贡献包。

## 完整生成机制

1. 独立个体；生成 Z1~N(0,1)，Z_j=0.3 Z_(j-1)+sqrt(0.91) e_j，所有 e_j 独立标准正态；共500维。
2. X1=abs(Z1)，其余 Xj=Zj，输出的是未中心化协变量。
3. Y = 0.6 (X1+X2)^2 + 0.4 X4^3 - X5 + 2 X6 + epsilon；epsilon~N(0,1)，独立于协变量和其他个体。
4. 参考 nL=200,nU=1000；API n 为总行数，按 floor(n/6) 分配有标签数并截到[1,n-1]。只为前 nL 行生成响应；R=1,Y_obs=Y。其他行 R=0,Y_obs=0 是占位符，必须按R屏蔽。

固定参数与完整支持集见 config.json。无外部预测器；不输出噪声、条件均值、未标记真实响应、真值或原文拟合结果。后续预测器须仅用训练折标签拟合。

## 标量目标与真值

Coordinate 4 of beta in argmin_(alpha,beta) E[(Y-alpha-X^T beta)^2]. All 500 observed covariates are included, with an intercept.

beta4=0.4*3=1.2. The folded X1-X2 interaction contributes only to coordinates 1 and 2 under the specified AR law; it does not change slope 4.

默认真值 1.2，estimated_error=2e-14 为浮点诊断，非严格区间界。原文中心化处理与本包“原始观测+带截距投影”的斜率相同；下游不能省略截距。

## 独立数值核验

verify.py 用另一条路线 beta_j=E[W_j Y]，其中内部目标坐标的 Gaussian precision score 为 W_j=((1+rho^2)X_j-rho(X_(j-1)+X_(j+1)))/(1-rho^2)。W_j 与所有其他 Gaussian 坐标独立，且与 Z1 独立。因此只剩包含 X_j 的三次项。用8阶和12阶二维 Gauss-Hermite 积分核验 E[W_j*c*S^3]，不复用 truth.py 的计算结果作为数值积分输入。

另用16个不同种子、每批1200行（200可见标签）、合计3200标签，检验投影score矩、展开后的来源方程残差、噪声二阶矩、折叠正态矩、AR协方差、schema和标签屏蔽。随机诊断采用6或7标准误，不能证明全部分布或CI覆盖正确。仍共享作者、来源解读和NumPy，不是另一人的科学复现。

## 与来源的改动

- Map independent labeled/unlabeled samples to one table with n=total rows. nL=max(1,min(n-1,floor(n*200/1200))); nU=n-nL. At n=1200 the source sample counts (200,1000) are exact. R=0 implies Y_obs=0 placeholder, not observed zero.
- Export raw X1=abs(Z1) and raw Y from the printed response formula. Define the target as one slope in the population linear projection WITH intercept. These slopes equal those from population-centering X and Y as in the paper; do not fit a no-intercept regression to the exported raw table.
- Select one scalar coordinate of the original vector regression target, not a different DGP. No fitted prediction, oracle response or hidden noise is exported.
- Independent PCG64 implementation. All coefficients are fixed across rows and replications; p=500,nL=200,N/n=5 selected from source experiments. No original estimation algorithm or benchmark is reproduced.

## 区别、复现和审核

Source Model 2: additive polynomial, pairwise quadratic/cubic, and multi-coordinate cubic-index interaction are different response structures. Parameter/support/target changes are not separately counted.

已对照 Mark8924 PR #1 固定版本及 2026-10-28 主分支目录，未发现相同完整生成结构。共享“多项式”“交互”标签不自动构成同一机制；本机制的折叠AR协变量、完整响应结构和噪声共同定义其身份。

Python>=3.10；requirements.txt 仅 NumPy。选择 config.json/scenarios/source_formula_fixed 后传入 generate(c,n,seed)、truth(c)、verify(c)。参数修改须重新推导真值及更新元数据，生成器会拒绝未声明场景。

Final-journal versus pinned-preprint simulation equivalence has not been verified.

Paper remains under its publisher/authors rights. Equations independently implemented with citation; no paper PDF, original author code, real data or third-party model weights redistributed. Contributor code licensing and scientific acceptance require maintainer review.

AI协助；具名科学审核待完成。本阶段仅本地构建，未上传、未创建PR，未做经典方法/PFN性能或置信区间覆盖比较。
