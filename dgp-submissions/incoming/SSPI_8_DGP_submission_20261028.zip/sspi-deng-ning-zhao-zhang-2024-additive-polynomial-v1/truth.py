"""Selected slope of the population linear projection WITH intercept."""
from generator import validate

def truth(config):
    validate(config)
    m=config['model']
    if m==1:value=3*0.8
    elif m==2:value=3*0.4
    else:
        s=config['support_cubic'];rho=config['rho']
        variance=sum(rho**abs(j-k) for j in s for k in s)
        value=3*0.05*variance
    return {'value':float(value),'estimated_error':2e-14,
            'method':'Gaussian integration by parts for the selected projection slope; cubic-index variance includes all AR covariances',
            'error_interpretation':'Floating-point diagnostic, not certified interval arithmetic'}
