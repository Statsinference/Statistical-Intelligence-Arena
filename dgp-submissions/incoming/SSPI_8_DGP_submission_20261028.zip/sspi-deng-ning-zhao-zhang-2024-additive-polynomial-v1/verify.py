"""Independent quadrature/score identities and observable distribution diagnostics."""
import math
import numpy as np
from generator import generate
from truth import truth

def numerical_slope(c,order):
    # A different route: b_j=E[W_j f(X)], W_j is the Gaussian precision score.
    # W_j is independent of every Gaussian coordinate except X_j, including Z1.
    # Only the cubic term containing X_j survives. Correlation within its index
    # is kept through a covariance matrix constructed independently of truth.py.
    m=c['model'];idx=([3] if m==1 else [4]) if m!=3 else c['support_cubic']
    coeff={1:0.8,2:0.4,3:0.05}[m]
    ids=np.asarray(idx);C=np.power(c['rho'],np.abs(ids[:,None]-ids[None,:]))
    one=np.ones(len(idx));v=float(one @ C @ one)
    q=(1+c['rho']**2)/(1-c['rho']**2)
    points,weights=np.polynomial.hermite.hermgauss(order)
    s=np.sqrt(2*v)*points[:,None]
    score=s/v+math.sqrt(q-1/v)*math.sqrt(2)*points[None,:]
    return float(np.sum(weights[:,None]*weights[None,:]*score*coeff*s**3)/math.pi)

def independent_response(x,c):
    # Expanded source polynomial, not a call to the generating formula.
    if c['model']==2:
        f=.6*x[:,0]**2+1.2*x[:,0]*x[:,1]+.6*x[:,1]**2+.4*x[:,3]**3-x[:,4]+2*x[:,5]
    else:
        f=.5*x[:,0]**2+.8*x[:,2]**3-x[:,3]**2+4*x[:,3]+2*x[:,4]**2+4*x[:,4]+2*x[:,5]-2
        if c['model']==3:
            f=f+sum(2*x[:,j-1] for j in c['support_linear'])+.05*sum(x[:,j-1] for j in c['support_cubic'])**3
    return f

def verify(c):
    exact=truth(c)['value'];a=numerical_slope(c,8);b=numerical_slope(c,12)
    checks=[{'name':'independent_precision_score_quadrature','passed':abs(b-exact)<1e-9 and abs(a-b)<1e-9,'order8':a,'order12':b,'analytic':exact,'absolute_error':abs(b-exact)}]
    # Reference counts: 200 labeled, 1000 unlabeled per batch; 3200 labels total.
    score_y=[];residual=[];x1=[];x2=[];x3=[];schema_ok=True;mask_ok=True
    for seed in range(202610280,202610296):
        dat=generate(c,1200,seed)
        x=np.column_stack([dat[f'X{j+1}'] for j in range(c['dimension'])]);y=np.asarray(dat['Y_obs']);r=np.asarray(dat['R'],dtype=bool)
        schema_ok &= set(dat)=={f'X{j+1}' for j in range(c['dimension'])}|{'R','Y_obs'} and np.isfinite(x).all() and np.isfinite(y).all()
        mask_ok &= r.sum()==200 and np.all(y[~r]==0) and np.all(x[:,0]>=0)
        target=c['target_coordinate']-1;rho=c['rho']
        w=((1+rho*rho)*x[r,target]-rho*(x[r,target-1]+x[r,target+1]))/(1-rho*rho)
        score_y.extend(w*y[r]);residual.extend(y[r]-independent_response(x[r],c))
        x1.extend(x[:,0]);x2.extend(x[:,1]);x3.extend(x[:,2])
    sy=np.asarray(score_y);res=np.asarray(residual);f=np.asarray(x1);g=np.asarray(x2);h=np.asarray(x3)
    se=sy.std(ddof=1)/math.sqrt(len(sy))
    checks.append({'name':'generated_projection_score_moment','passed':bool(abs(sy.mean()-exact)<6*se),'estimate':float(sy.mean()),'target':exact,'mc_se':float(se),'n_labeled':len(sy),'rule':'6 MC standard errors; diagnostic only'})
    checks.append({'name':'expanded_source_equation_noise','passed':bool(abs(res.mean())<6/math.sqrt(len(res)) and abs(np.mean(res**2)-1)<6*math.sqrt(2/len(res))),'mean':float(res.mean()),'second_moment':float(np.mean(res**2))})
    foldmean=math.sqrt(2/math.pi);ns=len(f)
    checks.append({'name':'folded_first_coordinate_moments','passed':bool(abs(f.mean()-foldmean)<7/math.sqrt(ns) and abs(np.mean(f*f)-1)<7*math.sqrt(2/ns)),'mean':float(f.mean()),'second_moment':float(np.mean(f*f))})
    checks.append({'name':'AR_covariance_and_folded_cross_moment','passed':bool(abs(np.mean(g*h)-c['rho'])<7*math.sqrt(2/ns) and abs(np.mean(f*g))<7*math.sqrt(3/ns)),'cov_X2_X3':float(np.mean(g*h)),'E_X1_X2':float(np.mean(f*g))})
    checks.append({'name':'observable_schema_mask_and_group_counts','passed':bool(schema_ok and mask_ok)})
    return {'passed':all(t['passed'] for t in checks),'checks':checks,'independence_limits':'Separate mathematical route and expanded polynomial; same author/runtime/source interpretation, not independent-person scientific review.'}
