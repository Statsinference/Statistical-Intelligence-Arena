# Three-Component Quadratic Semi-Supervised Projection Intercept

## 来源与定位

Chakrabortty, A. and Cai, T. (2018). Efficient and adaptive linear regression in semi-supervised settings. The Annals of Statistics 46(4), 1541-1572. DOI: 10.1214/17-AOS1594.

稳定 DOI: https://doi.org/10.1214/17-AOS1594

实际阅读版本: Published journal PDF hosted by the University of Pennsylvania, 32 pages; issue August 2018.

阅读链接: https://faculty.wharton.upenn.edu/wp-content/uploads/2018/10/Chakrabortty-AOS1594.pdf

精确定位: Section 6.1, model (iv), journal p. 1559 = PDF p. 19; n=500 and N=10000 on journal p. 1558 = PDF p. 18; regression target in Section 2.

PDF SHA-256: `27b7937eb9f22c9722807029fd67579a2ed21a6d66d83f6fb6c3ce1ed0b940b4`。论文仅保留在本地研究目录，不进入提交包。

## 目标与样本

任务 `semi_supervised`；Intercept alpha of argmin_(alpha,beta) E[(Y-alpha-X^T beta)^2]; since E[X]=0 and Cov(X) is positive definite, alpha=E[Y].

独立个体；有标签与无标签来自同一总体，标注不依赖协变量或响应。原文参考样本量 nL=500, nU=10000；API 的 n 是总行数。非整比例小样本时 nL=max(1,min(n-1,floor(n*500/10500)))，剩余为无标签。前 nL 行 R=1，其余 R=0；固定组别设计不是独立 Bernoulli 抽签。抽样顺序与 X、Y 无关。

## 按顺序生成的完整机制

1. Coordinates independent N(0,1) conditional on -5 <= X_j <= 5; implemented by rejection, not clipping. This makes the source restriction explicit.
2. Y = (X^T b)(1 + X^T delta) + (X^T omega)^2 + epsilon; epsilon ~ N(0,1)。噪声独立于协变量和其他个体；Normal 的第二参数在公式中为方差，代码使用标准差。
3. b、delta、omega 的完整数值见 config.json；b1/b2 为原文两个场景。
4. 仅为 R=1 的行生成响应；输出 X1 到 X10、R、Y_obs。R=0 时 Y_obs=0 只是有限占位符，模型必须先按 R 屏蔽。没有输出完整不可观测 Y、条件均值、噪声或真值。Poisson 的零率自然返回零（适用时）。

下游预测器：本阶段不拟合预测器，也不提供外部预测或 oracle 预测。后续方法仅可用有标签训练折训练 nuisance model，预测与真实标签需分列；原文的拟合、交叉验证和 CI 比较没有在此复现。

## 真值及独立核验

Let v=1-2a phi(a)/(2 Phi(a)-1), a=5. alpha=E[Y]=v(b^T delta+omega^T omega).

场景真值：`{"source_b1_conditional_truncation": 4.999925663981647, "source_b2_conditional_truncation": 9.999851327963293}`。

truth.py 使用解析期望；verify.py 以另一条数值路线复核：高斯一维 Simpson 积分、截断正态矩积分与二阶精确轴向求积，或 Poisson 概率递推。4096/8192 子区间结果比较；误差门槛固定 1e-9。解析式的 estimated_error 是浮点诊断，不冒充严格区间界。

另以 8 个独立批次、合计 800 个可见标签，检查均值、来源方程残差、噪声二阶矩、协变量矩与标签屏蔽。蒙特卡洛以 6 或 7 个标准误作诊断，不能证明分布完全正确或 CI 覆盖达标。数值核验不调用生成器的 conditional_mean；仍共享同一作者与 NumPy，不是另一人的独立复现。

## 机制区别与属性

Total input dimension 10; source Section 6.1(iv) NL3C. All ten coordinates enter the index products; polynomial terms are explicit. Fixed p=10 is not called high-dimensional relative to 500 labels.

Separate source response structure Section 6.1(iv) NL3C; coefficient choices remain scenarios. NL1C/NL2C/NL3C are separate source-listed index structures (one squared index, two-index product, three-index product-plus-square), not additional coefficient/seed copies.

## 相对来源的改动

- Map the two-sample SS design to one numeric table. API n is total rows, not the paper labeled n; R=1 for labeled rows; Y_obs=0 for R=0 is a sentinel, never a label. Source reference sample sizes are stored separately.
- For arbitrary CPU test n, labeled_count=max(1,min(n-1,floor(n*nL_ref/(nL_ref+nU_ref)))); first labeled_count rows form the independent labeled sample. At n=nL_ref+nU_ref the source counts are exact.
- Independent NumPy PCG64 implementation; no author code copied; original estimator tuning, fitted predictions, repeated CI experiments and PFN training are outside this DGP collection.
- Fix p=10; retain both source coefficient vectors as scenarios, not separate mechanisms.
- The paper states restriction to [-5,5]^p without specifying clipping versus rejection. We explicitly define independent conditional truncated normals via rejection; this is a declared adaptation requiring reviewer confirmation, not exact author-code reproduction.
- Select the intercept component of the population least-squares projection with an intercept. Since E[X]=0, this scalar equals E[Y]; the full regression vector is outside the scalar truth interface.

## 使用与复现

Python >=3.10，依赖见 requirements.txt。先从 config.json 的 scenarios 选择一个参数对象 c，再调用 generate(c,n,seed)、truth(c)、verify(c)。不能把整个 config.json 作为 c。建议核验命令：`python collect.py check PATH --run --n 128 --seed 1729`；实际执行结果以 checks/report.json 为准。

## 权利、未决问题与审核状态

Paper remains under its publisher/authors rights. Equations independently implemented with citation; no paper PDF, original author code, real data or third-party model weights redistributed. Contributor code licensing and scientific acceptance require maintainer review.

Confirm with reviewer whether the declared conditional-truncation convention matches the source implementation. Complete distribution and exact truth for this explicit convention are provided.

OpenAI Codex assisted source extraction, formula implementation, numerical verification and report preparation; human review pending.

当前仅为本地候选贡献，未上传、未创建 PR、未取得维护人认领或科学接收。2026-10-28 当前 main 目录已含 8 个 SSPI 机制；本包已逐项对照 Mark8924 PR #1 的固定版本及当前目录，未发现该保留机制的相同完整生成结构。查重不能排除未公开工作。没有 PFN 训练、经典方法 benchmark 或置信区间覆盖评测。


## 本次查重

详见交付目录 duplicate_review.json。比较的是协变量分布、响应函数、噪声及观测机制；换目标、样本量或维数本身不算新增机制。与 Mark 的八项没有发现相同完整生成结构；共享论文不等于共享模型。
