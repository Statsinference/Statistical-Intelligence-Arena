"""Scalar target; analytic moments, independently checked in verify.py."""
import math

def truth(config):
    k = config["mechanism"]
    if k in ("linear", "sine"):
        value, error = 0.0, 0.0
        method = "Zero marginal first moment / odd sine under centered Gaussian symmetry"
    elif k == "cosine":
        value, error = 3.0 * math.exp(-1.5), 2e-15
        method = "Gaussian characteristic function at frequency one; Var(X1+X2+X3)=3"
    elif k == "interaction":
        value, error = 0.5*(1.0+0.5**2), 0.0
        method = "Independent standard Gaussian moments; E[X1 X2]=0"
    elif k.startswith("nl"):
        a = config["truncation_bound"]
        z = math.erf(a/math.sqrt(2.0))
        v = 1.0 - 2*a*math.exp(-a*a/2)/math.sqrt(2*math.pi)/z
        b, delta, omega = config["b"], config["delta"], config["omega"]
        factor = sum(t*t for t in b) if k == "nl1c" else sum(t*u for t,u in zip(b,delta))
        if k == "nl3c": factor += sum(t*t for t in omega)
        value, error = v*factor, 2e-14*max(1.0,abs(factor))
        method = "Projection intercept equals E[Y] because E[X]=0; truncated Gaussian second moment"
    elif k == "poisson":
        value = config["covariate_rate"] * config["response_multiplier"]
        error, method = 0.0, "Iterated expectation of nested Poisson laws"
    else:
        raise ValueError("Unknown mechanism")
    return {"value":float(value), "estimated_error":float(error), "method":method,
            "error_interpretation":"Floating-point diagnostic, not a formal interval-arithmetic bound"}
