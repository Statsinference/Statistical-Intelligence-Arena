"""Quadrature/finite sums and distribution checks; no estimator or CI benchmark."""
import math
import numpy as np
from generator import generate
from truth import truth

def simpson(y, h):
    return float(h/3*(y[0]+y[-1]+4*y[1:-1:2].sum()+2*y[2:-1:2].sum()))

def expected_surface(x, c):
    # Independently written source formula; does not import generator.conditional_mean.
    k = c["mechanism"]
    if k == "linear": return np.add.reduce(x[:, :c["s"]], axis=1)/np.sqrt(c["s"])
    if k == "cosine": return 3*np.cos(x[:,0]+x[:,1]+x[:,2])
    if k == "sine": return np.sum(np.sin(x)*np.array([0.7**j for j in range(x.shape[1])]),axis=1)
    if k == "interaction": return x[:,0]*x[:,1]+0.5*x[:,2]**2+0.5*x[:,2]+0.125
    if k == "poisson": return c["response_multiplier"]*x[:,0]
    b, d, w = np.array(c["b"]), np.array(c["delta"]), np.array(c["omega"])
    if k == "nl1c":
        q = np.outer(b,b)
    else:
        q = (np.outer(b,d)+np.outer(d,b))/2
        if k == "nl3c": q += np.outer(w,w)
    return x@b + np.einsum('ni,ij,nj->n',x,q,x)

def independent_value(c, intervals):
    k = c["mechanism"]
    if k == "poisson":
        # Recursion for Poisson(10) probabilities, distinct from lambda*multiplier.
        lam, prob = c["covariate_rate"], math.exp(-c["covariate_rate"])
        ans = 0.0
        for j in range(1,161):
            prob *= lam/j
            ans += c["response_multiplier"]*j*prob
        return ans
    if k.startswith("nl"):
        a=c["truncation_bound"]
        z=np.linspace(-a,a,intervals+1); dens=np.exp(-z*z/2)
        variance=simpson(z*z*dens,2*a/intervals)/simpson(dens,2*a/intervals)
        # Degree-two-exact axial cubature evaluates the actual quadratic surface.
        d=c["dimension"]; pts=np.zeros((2*d,d)); t=math.sqrt(d*variance)
        for j in range(d): pts[2*j,j]=t; pts[2*j+1,j]=-t
        return float(expected_surface(pts,c).mean())
    z=np.linspace(-12,12,intervals+1); dens=np.exp(-z*z/2)/math.sqrt(2*math.pi)
    if k == "linear": y=z
    elif k == "cosine": y=3*np.cos(math.sqrt(3)*z)
    elif k == "sine":
        p=c["dimension"]+1
        y=np.sin(math.sqrt(1-1/(2*p))*z)*sum(0.7**j for j in range(c["dimension"]))
    elif k == "interaction": y=0.5*z*z+0.5*z+0.125
    return simpson(y*dens,24/intervals)

def verify(config):
    c=config; k=c["mechanism"]; checks=[]
    exact=truth(c)["value"]; a=independent_value(c,4096); b=independent_value(c,8192)
    checks.append({"name":"independent_quadrature_or_probability_sum", "passed":bool(abs(b-exact)<1e-9 and abs(a-b)<1e-9),
                   "computed":b,"analytic":exact,"difference":abs(b-exact),"grid_difference":abs(a-b),"tolerance":1e-9})
    if k.startswith("nl"):
        zero=dict(c,b=[0]*c["dimension"],delta=[0]*c["dimension"],omega=[0]*c["dimension"])
        checks.append({"name":"zero_signal_special_case", "passed":bool(abs(independent_value(zero,4096))<1e-12 and truth(zero)["value"]==0)})
    elif k == "poisson":
        zero=dict(c,covariate_rate=0.0)
        checks.append({"name":"zero_rate_special_case", "passed":bool(truth(zero)["value"]==0 and independent_value(zero,4096)==0)})
    else:
        checks.append({"name":"symmetry_and_origin_special_case", "passed":bool(abs(expected_surface(np.zeros((1,c["dimension"])),c)[0]-({'cosine':3.,'interaction':.125}.get(k,0.)))<1e-12)})
    # Eight independent batches, 100 labeled units each. CPU/memory bounded even at d=1000.
    ratio=(c["labeled_reference"]+c["unlabeled_reference"])/c["labeled_reference"]
    rows=int(round(100*ratio)); ys=[]; residual=[]; xfirst=[]; xsecond=[]; hidden_ok=True
    for seed in range(93001,93009):
        dat=generate(c,rows,seed); rr=np.asarray(dat['R'],dtype=bool); yy=np.asarray(dat['Y_obs'])
        hidden_ok &= bool(np.all(yy[~rr]==0) and rr.sum()==100)
        xx=np.column_stack([dat[f'X{j+1}'] for j in range(c['dimension'])])
        ys.extend(yy[rr]); residual.extend(yy[rr]-expected_surface(xx[rr],c))
        xfirst.extend(xx[:,0]); xsecond.extend(xx[:,1])
    ys=np.asarray(ys); residual=np.asarray(residual); xfirst=np.asarray(xfirst); xsecond=np.asarray(xsecond)
    mean_se=float(ys.std(ddof=1)/math.sqrt(len(ys)))
    checks.append({"name":"generated_labeled_mean_sanity", "passed":bool(abs(ys.mean()-exact)<=6*mean_se+1e-10),
                   "sample_mean":float(ys.mean()),"target":exact,"mc_standard_error":mean_se,"n_labeled":len(ys),"rule":"6 MC standard errors; diagnostic only"})
    noise_var=100.0 if k=='poisson' else c['noise_sd']**2
    res_se=math.sqrt(noise_var/len(residual))
    checks.append({"name":"source_equation_residual_mean", "passed":bool(abs(residual.mean())<=6*res_se),"mean":float(residual.mean()),"bound":6*res_se})
    # Poisson has varying conditional variance; use a conservative analytical fourth-moment bound.
    fourth=33100.0 if k=='poisson' else 3*noise_var**2
    variance_bound=6*math.sqrt((fourth-noise_var**2)/len(residual))
    checks.append({"name":"source_noise_second_moment", "passed":bool(abs(np.mean(residual**2)-noise_var)<=variance_bound),"second_moment":float(np.mean(residual**2)),"target":noise_var,"bound":variance_bound})
    target_mean=10.0 if k=='poisson' else 0.0
    target_var=10.0 if k=='poisson' else (1-1/(2*(c['dimension']+1)) if k=='sine' else 1.0)
    if k.startswith('nl'):
        aa=c['truncation_bound']; zz=np.linspace(-aa,aa,8193); dd=np.exp(-zz**2/2)
        target_var=simpson(zz**2*dd,2*aa/8192)/simpson(dd,2*aa/8192)
    target_cov=1/(2*(c['dimension']+1)) if k=='sine' else 0.0
    se_mean=math.sqrt(target_var/len(xfirst)); bound_var=7*target_var*math.sqrt(2/len(xfirst))
    checks.append({"name":"covariate_marginal_moments", "passed":bool(abs(xfirst.mean()-target_mean)<7*se_mean and abs(xfirst.var()-target_var)<bound_var),"mean":float(xfirst.mean()),"variance":float(xfirst.var()),"target_variance":target_var})
    cov=float(np.mean((xfirst-target_mean)*(xsecond-target_mean)))
    checks.append({"name":"covariate_cross_moment", "passed":bool(abs(cov-target_cov)<7*target_var/math.sqrt(len(xfirst))),"cross_moment":cov,"target":target_cov})
    checks.append({"name":"unlabeled_placeholder_and_fixed_sample_counts", "passed":hidden_ok})
    return {"passed":all(t['passed'] for t in checks),"checks":checks,
            "independence_limits":"Independent mathematical routes and independently written formula evaluation, but same AI author, NumPy runtime and source interpretation. Not independent-person scientific review."}
