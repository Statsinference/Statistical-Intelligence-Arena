# Poisson Covariates and Poisson Response Semi-Supervised Mean

## 来源与定位

Zhang, A., Brown, L. D. and Cai, T. T. (2019). Semi-supervised inference: General theory and estimation of means. The Annals of Statistics 47(5), 2538-2566. DOI: 10.1214/18-AOS1756.

稳定 DOI: https://doi.org/10.1214/18-AOS1756

实际阅读版本: Actually read arXiv:1606.07268v2 (2018-08-14), 62 pages, linked to the 2019 journal publication. Journal final simulation equations were not independently compared; this contribution claims fidelity to the pinned preprint setting only.

阅读链接: https://arxiv.org/abs/1606.07268v2

精确定位: Pinned arXiv v2 Section 4, setting 3, PDF p. 19 (unnumbered display); Table 1 on PDF p. 20 supplies (p,n,m)=(10,100,1000); sampling equations (1.1)-(1.2), PDF p. 2. These are preprint PDF page numbers, not journal pages.

PDF SHA-256: `d39050be41f6551de1e08a3058421e5220251ed7fb8ad920a771e1d1c0506634`。论文仅保留在本地研究目录，不进入提交包。

## 目标与样本

任务 `semi_supervised`；Superpopulation mean theta=E[Y] under the declared fixed mechanism, shared by labeled and unlabeled samples.

独立个体；有标签与无标签来自同一总体，标注不依赖协变量或响应。原文参考样本量 nL=100, nU=1000；API 的 n 是总行数。非整比例小样本时 nL=max(1,min(n-1,floor(n*100/1100)))，剩余为无标签。前 nL 行 R=1，其余 R=0；固定组别设计不是独立 Bernoulli 抽签。抽样顺序与 X、Y 无关。

## 按顺序生成的完整机制

1. X_1,...,X_10 independent Poisson(10)
2. X_j iid ~ Poisson(10); Y | X ~ Poisson(10 X_1)。噪声独立于协变量和其他个体；Normal 的第二参数在公式中为方差，代码使用标准差。
3. 固定参数见 config.json；未额外生成实验级随机参数。
4. 仅为 R=1 的行生成响应；输出 X1 到 X10、R、Y_obs。R=0 时 Y_obs=0 只是有限占位符，模型必须先按 R 屏蔽。没有输出完整不可观测 Y、条件均值、噪声或真值。Poisson 的零率自然返回零（适用时）。

下游预测器：本阶段不拟合预测器，也不提供外部预测或 oracle 预测。后续方法仅可用有标签训练折训练 nuisance model，预测与真实标签需分列；原文的拟合、交叉验证和 CI 比较没有在此复现。

## 真值及独立核验

E[Y|X]=10 X1 and E[X1]=10, hence theta=100. Var(Y)=E[10X1]+Var(10X1)=1100.

场景真值：`{"source_fixed": 100.0}`。

truth.py 使用解析期望；verify.py 以另一条数值路线复核：高斯一维 Simpson 积分、截断正态矩积分与二阶精确轴向求积，或 Poisson 概率递推。4096/8192 子区间结果比较；误差门槛固定 1e-9。解析式的 estimated_error 是浮点诊断，不冒充严格区间界。

另以 8 个独立批次、合计 800 个可见标签，检查均值、来源方程残差、噪声二阶矩、协变量矩与标签屏蔽。蒙特卡洛以 6 或 7 个标准误作诊断，不能证明分布完全正确或 CI 覆盖达标。数值核验不调用生成器的 conditional_mean；仍共享同一作者与 NumPy，不是另一人的独立复现。

## 机制区别与属性

Total input dimension 10; source Section 4 setting 3. Only X1 affects response; other nine coordinates do not. Conditional mean is linear; conditional Poisson variance is 10 X1 (heteroskedastic).

Separate source response structure Section 4 setting 3; coefficient choices remain scenarios. NL1C/NL2C/NL3C are separate source-listed index structures (one squared index, two-index product, three-index product-plus-square), not additional coefficient/seed copies.

## 相对来源的改动

- Map the two-sample SS design to one numeric table. API n is total rows, not the paper labeled n; R=1 for labeled rows; Y_obs=0 for R=0 is a sentinel, never a label. Source reference sample sizes are stored separately.
- For arbitrary CPU test n, labeled_count=max(1,min(n-1,floor(n*nL_ref/(nL_ref+nU_ref)))); first labeled_count rows form the independent labeled sample. At n=nL_ref+nU_ref the source counts are exact.
- Independent NumPy PCG64 implementation; no author code copied; original estimator tuning, fitted predictions, repeated CI experiments and PFN training are outside this DGP collection.

## 使用与复现

Python >=3.10，依赖见 requirements.txt。先从 config.json 的 scenarios 选择一个参数对象 c，再调用 generate(c,n,seed)、truth(c)、verify(c)。不能把整个 config.json 作为 c。建议核验命令：`python collect.py check PATH --run --n 128 --seed 1729`；实际执行结果以 checks/report.json 为准。

## 权利、未决问题与审核状态

Paper remains under its publisher/authors rights. Equations independently implemented with citation; no paper PDF, original author code, real data or third-party model weights redistributed. Contributor code licensing and scientific acceptance require maintainer review.

Final-journal versus pinned-preprint simulation equivalence has not been verified; source claim is limited to arXiv v2 setting 3.

OpenAI Codex assisted source extraction, formula implementation, numerical verification and report preparation; human review pending.

当前仅为本地候选贡献，未上传、未创建 PR、未取得维护人认领或科学接收。2026-10-28 当前 main 目录已含 8 个 SSPI 机制；本包已逐项对照 Mark8924 PR #1 的固定版本及当前目录，未发现该保留机制的相同完整生成结构。查重不能排除未公开工作。没有 PFN 训练、经典方法 benchmark 或置信区间覆盖评测。


## 本次查重

详见交付目录 duplicate_review.json。比较的是协变量分布、响应函数、噪声及观测机制；换目标、样本量或维数本身不算新增机制。与 Mark 的八项没有发现相同完整生成结构；共享论文不等于共享模型。
