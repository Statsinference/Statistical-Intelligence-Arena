"""Independent Simpson-integral and source-equation checks."""
import math


def _theta_scalar(x, config):
    z = float(config["theta_intercept"]) + float(config["theta_x1_coefficient"]) * x
    # Scalar softplus form, independently coded from generator.py's np.logaddexp.
    softplus = max(z, 0.0) + math.log1p(math.exp(-abs(z)))
    return softplus / float(config["theta_scale_denominator"])


def _simpson_ate(config, steps):
    if steps % 2:
        raise ValueError("Simpson integration needs an even number of steps")
    left, right = -10.0, 10.0
    h = (right - left) / steps
    total = 0.0
    for k in range(steps + 1):
        x = left + k * h
        theta = _theta_scalar(x, config)
        density = math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)
        y = 2.0 * float(config["outcome_effect_half_scale"]) * theta * density
        weight = 1 if k in (0, steps) else (4 if k % 2 else 2)
        total += weight * y
    return h * total / 3.0


def _simpson_treatment_moments(config, steps):
    left, right = -10.0, 10.0
    h = (right - left) / steps
    prob_sum = 0.0
    weighted_sum = 0.0
    for k in range(steps + 1):
        x = left + k * h
        theta = _theta_scalar(x, config)
        prob = -math.expm1(-theta)
        density = math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)
        weight = 1 if k in (0, steps) else (4 if k % 2 else 2)
        prob_sum += weight * prob * density
        weighted_sum += weight * theta * prob * density
    return h * prob_sum / 3.0, h * weighted_sum / 3.0


def verify(config):
    ate_coarse = _simpson_ate(config, 4096)
    ate_fine = _simpson_ate(config, 8192)
    source_ok = (
        int(config["source_n"]) == 400 and int(config["p"]) == 1600
        and int(config["source_replications"]) == 400
        and float(config["theta_intercept"]) == -2.0
        and float(config["theta_x1_coefficient"]) == -2.0
        and float(config["theta_scale_denominator"]) == 0.915
        and int(config["outcome_first_p"]) == 10
        and float(config["outcome_effect_half_scale"]) == 0.5
        and float(config["outcome_noise_sd"]) == 1.0
        and config["source_table5_n_grid"] == [400, 1000]
        and config["source_table5_p_grid"] == [100, 200, 400, 800, 1600]
    )

    theta_values = [_theta_scalar(x, config) for x in (-3.0, -1.0, 0.0, 1.0, 3.0)]
    probs = [-math.expm1(-v) for v in theta_values]
    probability_ok = all(t > 0.0 for t in theta_values) and all(0.0 < p < 1.0 for p in probs) and all(
        probs[i] > probs[i + 1] for i in range(len(probs) - 1)
    )

    half = float(config["outcome_effect_half_scale"])
    contrast_values = [theta * ((2.0 * 1.0 - 1.0) - (2.0 * 0.0 - 1.0)) * half for theta in theta_values]
    contrast_ok = all(abs(v - 2.0 * half * t) < 1e-14 for v, t in zip(contrast_values, theta_values))

    # Source notes ATT is much larger than the overall ATE in this synthetic setting.
    p_w, theta_w = _simpson_treatment_moments(config, 8192)
    att = theta_w / p_w if p_w > 0 else float("nan")
    att_check = math.isfinite(att) and att > ate_fine

    zero_half = 0.0
    zero_effect = max(abs(theta * ((2.0 * 1.0 - 1.0) - (2.0 * 0.0 - 1.0)) * zero_half) for theta in theta_values)

    checks = [
        {"name": "source_table5_parameters", "passed": source_ok,
         "details": "Selected original Table 5 point n=400,p=1600; source ranges n={400,1000}, p={100,200,400,800,1600}; source scale and outcome coefficients recorded."},
        {"name": "independent_simpson_truth", "passed": abs(ate_fine - 0.389416787118157) < 1e-9,
         "details": f"Composite Simpson estimate={ate_fine:.15g}; registered ATE≈0.389416787118157; does not call truth.py."},
        {"name": "simpson_refinement", "passed": abs(ate_fine - ate_coarse) < 1e-9,
         "details": f"Simpson 4096={ate_coarse:.15g}, 8192={ate_fine:.15g}, difference={abs(ate_fine - ate_coarse):.3g}; integral truncation is to [-10,10]."},
        {"name": "treatment_probability_equation", "passed": probability_ok,
         "details": f"theta values={['%.5g' % t for t in theta_values]}, probabilities={['%.5g' % p for p in probs]}; prob=1-exp(-theta) is valid and decreases as X1 increases at tested points."},
        {"name": "potential_outcome_contrast", "passed": contrast_ok,
         "details": "For fixed X and epsilon, Y(1)-Y(0)=2*effect_half_scale*theta(X1); at source scale 0.5 this equals theta(X1)."},
        {"name": "ATT_exceeds_overall_ATE", "passed": att_check,
         "details": f"Independent Simpson diagnostic: P(W=1)≈{p_w:.12g}, ATT≈{att:.12g}, ATE≈{ate_fine:.12g}; ATT is only a qualitative source-consistency check, not the collected target."},
        {"name": "zero_effect_special_case", "passed": zero_effect == 0.0,
         "details": "With the treatment-effect multiplier set to zero, the structural contrast is identically zero."}
    ]
    return {"passed": all(x["passed"] for x in checks), "checks": checks,
            "shared_components": "verify.py independently implements scalar softplus and composite Simpson quadrature; it shares the source-declared DGP and parameters with generator.py/truth.py. This is not an independent-person scientific reproduction.",
            "notes": "The Simpson integral truncates to [-10,10]; the standard-normal tail contribution is negligible at this scale. No large simulation, bootstrap, coverage study or PFN training was run."}
