"""Population ATE for the LaLonde-inspired misspecified source mechanism."""
import math
import numpy as np
from numpy.polynomial.hermite import hermgauss


def _mean_theta(config, order):
    nodes, weights = hermgauss(order)
    x = math.sqrt(2.0) * nodes  # transform Hermite nodes to N(0,1)
    z = float(config["theta_intercept"]) + float(config["theta_x1_coefficient"]) * x
    theta = np.logaddexp(0.0, z) / float(config["theta_scale_denominator"])
    return float(np.dot(weights, theta) / math.sqrt(math.pi))


def truth(config):
    """Return population ATE and quadrature convergence diagnostic."""
    scale = float(config["outcome_effect_half_scale"])
    low = 2.0 * scale * _mean_theta(config, 64)
    high = 2.0 * scale * _mean_theta(config, 128)
    return {
        "value": high,
        "estimated_error": abs(high - low) + 1e-14,
        "method": "64/128-node Gauss-Hermite quadrature for E[theta(X1)], X1~N(0,1)",
        "derivation": "Under Y(w)=sum_{j=1}^{10}X_j + theta(X1)*(2w-1)*effect_half_scale + epsilon, the contrast is 2*effect_half_scale*theta(X1). At the source value effect_half_scale=0.5, ATE=E[theta(X1)].",
        "target": "Population ATE E[Y(1)-Y(0)], not ATT",
        "error_interpretation": "Difference between quadrature orders plus round-off allowance; convergence diagnostic, not a rigorous uniform error bound."
    }
