# ATE collection: LaLonde-inspired misspecified simulation

**Status:** candidate; machine checks do not constitute scientific acceptance. No PFN is trained or evaluated.

## Source and precise locator

Athey, S., Imbens, G. W. and Wager, S. (2018), “Approximate residual balancing: Debiased inference of average treatment effects in high dimensions,” *Journal of the Royal Statistical Society: Series B (Statistical Methodology)*, 80(4), 597–623. DOI: [10.1111/rssb.12268](https://doi.org/10.1111/rssb.12268). The read version was the 27-page electronic reprint PDF linked from the published article. The DGP is in Section 5.2, the unnumbered paragraph beginning “To test the robustness of all the methods considered, we also ran a misspecified simulation,” printed p. 618 / PDF page 22 of 27. Table 5 and its footnote are on printed p. 619 / PDF page 23 of 27. Figure 2(b), printed p. 616, sketches this setting. The paragraph has no numbered equation; these paragraph/page locators are used instead. A web PDF screenshot attempt returned a source cache-miss error, so the page reference was checked against the readable PDF text and the page footer rather than a screenshot.

The paragraph states that this setting is “loosely inspired” by LaLonde (1986); it is a **synthetic simulation**, not the LaLonde data and not a `real_data_claim`. The source says the average treatment effect on the treated (ATT) is much greater than the overall ATE. The constant 0.915 appears in the original theta formula; the paragraph does not explain how it was calibrated, so its rationale remains unverified.

## Original DGP in generation order

The source gives the following equations (none has a separate printed equation number in this paragraph):

1. Draw the covariate vector `X_i ~ Normal_p(0, I_p)`. Thus all coordinates have mean 0, variance 1 and are independent under the specified multivariate normal law.
2. Define the latent scalar

   `theta_i = log(1 + exp(-2 - 2 * X_i1)) / 0.915`.

   `theta_i` is a deterministic, positive, nonlinear function of `X_i1`; it is not released as a feature.
3. Draw treatment

   `W_i | X_i ~ Bernoulli(1 - exp(-theta_i))`.

   Code uses `-expm1(-theta_i)` for stable evaluation. In finite floating-point arithmetic probabilities may round to 0 or 1 in extreme tails; the implementation clips only floating-point round-off to the Bernoulli interval `[0,1]`.
4. Draw `epsilon_i ~ Normal(0, 1)` and form

   `Y_i = X_i1 + ... + X_i10 + theta_i * (2 * W_i - 1) / 2 + epsilon_i`.

   The source specifies the marginal normal law of epsilon, but its misspecified-setting paragraph does not fully enumerate cross-independence relationships. The implementation draws epsilon independently of X and W and iid across people; this added convention is an adaptation pending scientific review.

The paper says it varied `n` and `p`; Table 5 shows `n` in `{400,1000}` and `p` in `{100,200,400,800,1600}`, with results averaged over 400 simulation replications. This contribution implements the source-listed high-dimensional point `n=400, p=1600`. The collector requires a fixed observed-column schema shared by all configurations; varying `p` inside a single package cannot be represented without adding padding columns to lower-dimensional settings, which would misrepresent the original DGP. Other Table 5 grid points are therefore documented, not falsely represented as implemented scenarios. Smoke tests use `n=128` as required by the project check command and do not reproduce 400 Monte Carlo replications.

## Target and identification

The treatment-effect component in the observed-outcome equation suggests the structural potential outcomes

`Y_i(w) = sum_{j=1}^{10} X_ij + theta_i * (2*w - 1)/2 + epsilon_i`, `w in {0,1}`.

Holding the same `X` and `epsilon` fixed, `Y_i(1)-Y_i(0)=theta_i`. The target collected here is the **population ATE** `E[theta(X_1)]`, not the ATT `E[theta(X_1)|W=1]` highlighted in the paper's discussion. The implementation assumes consistency and independent outcome error under the source DGP; the exact cross-independence convention for epsilon is not fully spelled out in the paragraph and remains pending confirmation. Individuals are iid; within each row, the Gaussian coordinates are independent. There is no clustering, repeated measurement or interference.

## Truth and independent verification

Since `X_1 ~ Normal(0,1)`,

`ATE = integral log(1 + exp(-2 - 2x)) / 0.915 * phi(x) dx`.

Gauss-Hermite quadrature of orders 64 and 128 gives `ATE = 0.389416787118157` (approximate numerical value). The reported `estimated_error` is the difference between these two quadrature orders plus a small floating-point allowance; it is a convergence diagnostic, not a rigorous uniform error bound. `verify.py` uses a separately coded composite Simpson integral of the standard-normal density over `[-10,10]`, compares refinements, checks `ATT > ATE` as a qualitative source-consistency check, and checks that setting the treatment-effect scale to zero yields zero ATE. These implementations share the stated DGP, not the quadrature method. An independent-person scientific reproduction has not been performed.

## Properties and scope

- Total dimension: `p=1600`; selected source setting has `n=400`, so `p>n`.
- Effective dimension: 10 coordinates occur in the outcome baseline (`X_1` through `X_10`); treatment assignment's nonlinear intensity uses only `X_1`.
- Nonlinearity: `theta(X_1)=softplus(-2-2X_1)/0.915` and `P(W=1|X)=1-exp(-theta(X_1))`.
- Effect modification / interaction: `theta(X_1)*(2W-1)/2` makes the treatment effect depend on `X_1`.
- The mechanism is synthetic and LaLonde-inspired; no real LaLonde observations are included.

## Rights, adaptations and open questions

This is an independently written implementation, not a redistribution of the article PDF, authors' code or original sensitive data. Source parameter `0.915` is copied from the source equation, but the paragraph does not explain its calibration. The source-listed supplemental PDF describes proofs and was not accessible to read in this run. The source paragraph specifies `epsilon ~ Normal(0,1)` but not every cross-independence relation; this implementation uses independent draws and leaves the convention for review. The author code repository's current commit was not pinned or executed. AI assisted source extraction and implementation; no named reviewer or acceptance is claimed.

No PFN training, hyperdistribution generation, large bootstrap/coverage experiment, checkpoint modification, GitHub upload, PR, or external message was performed.
