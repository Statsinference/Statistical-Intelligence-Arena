"""Deterministic cross-checks; independent numerical route, not an independent human reproduction."""
import math
from statistics import NormalDist
from truth import truth

def simpson(f,a,b,n):
    h=(b-a)/n
    return h/3*(f(a)+f(b)+4*sum(f(a+h*i) for i in range(1,n,2))+2*sum(f(a+h*i) for i in range(2,n,2)))

def normal_integral(z,n):
    return .5+simpson(lambda t:math.exp(-t*t/2)/math.sqrt(2*math.pi),0,z,n)

def check(name,error,tolerance):
    return dict(name=name,passed=bool(error<=tolerance),absolute_error=float(error),tolerance=tolerance)

def normal_checks(z,tau):
    p1=normal_integral(z,1024);p2=normal_integral(z,2048)
    return [check('Integrate normal density at the proposed quantile',abs(p2-tau),1e-9),check('Quadrature refinement',abs(p2-p1),1e-9),check('Normal symmetry at zero',abs(normal_integral(0,128)-.5),1e-12)]

def verify(config):
    value=truth(config)['value']
    checks=[]
    x,y=config['x_query']; a=config['surface_rate']
    # Cancel the common quadratic exponential in equation (40).
    b1=a*(.6*x-.4*y+.03)
    b2=a*(-.4*x+.6*y+.03)
    m=config['surface_multiplier']/(math.exp(b1)+math.exp(b2))
    z=value-m
    if config['error']=='normal':density=lambda t:math.exp(-t*t/2)/math.sqrt(2*math.pi)
    elif config['error']=='t3':density=lambda t:2/(math.pi*math.sqrt(3))*(1+t*t/3)**(-2)
    elif config['error']=='normal_mixture':density=lambda t:.1*math.exp(-t*t/50)/(5*math.sqrt(2*math.pi))+.9*math.exp(-t*t/2)/math.sqrt(2*math.pi)
    else:raise ValueError('Unsupported error scenario')
    p1=.5+simpson(density,0,z,1024)
    p2=.5+simpson(density,0,z,2048)
    checks.append(check('Independent error-density integration',abs(p2-config['tau']),1e-9))
    checks.append(check('Error-density quadrature refinement',abs(p2-p1),1e-9))
    checks.append({'name':'Positive error density at target','passed':density(z)>0,'density':density(z)})
    return {"passed":all(c["passed"] for c in checks),"checks":checks}
