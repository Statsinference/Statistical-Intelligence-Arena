import math
from statistics import NormalDist

def truth(config):
    x1,x2=config['x_query']; a=config['surface_rate']
    m=config['surface_multiplier']*math.exp(a*((x1-.5)**2+(x2-.5)**2))/(math.exp(a*((x1-.2)**2+(x2-.7)**2))+math.exp(a*((x1-.7)**2+(x2-.2)**2)))
    if config['error']=='normal':z=NormalDist().inv_cdf(config['tau'])
    else:
        def cdf(z):
            if config['error']=='normal_mixture':return .1*NormalDist().cdf(z/5)+.9*NormalDist().cdf(z)
            if config['error']=='t3':
                v=z/math.sqrt(3)
                return .5+(math.atan(v)+v/(1+v*v))/math.pi
            raise ValueError('Unsupported error scenario')
        lo,hi=-100.,100.
        for _ in range(60):
            mid=(lo+hi)/2
            if cdf(mid)<config['tau']:lo=mid
            else:hi=mid
        z=(lo+hi)/2
    value=m+z
    return {"value":float(value),"estimated_error":1e-12,"error_interpretation":"Floating-point and bisection diagnostic; not a rigorous uniform error bound"}
