"""Scalar conditional CDF, with finite PMF sum and Decimal precision audit.

The default query is P(Y <= 3 | X=5) = (118/3) exp(-5).
No estimate from the generated rows is used as population truth.
"""
from decimal import Decimal, localcontext
import math


def _parameters(config):
    # Deliberately no dependency on generator.py or its rate implementation.
    for key, expected in (("x_low", 0), ("x_high", 10),
                          ("rate_floor", 1), ("rate_cap", 6)):
        value = config[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or value != expected:
            raise ValueError(f"Unsupported source parameter: {key}")
    x, y = config["query_x"], config["cdf_threshold"]
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
           for v in (x, y)):
        raise ValueError("The query must be finite numeric")
    if not 0 < x < 10 or not -100 <= y <= 100:
        raise ValueError("Query outside the supported source/threshold domain")
    rate = 1.0 if x <= 1 else (6.0 if x >= 6 else float(x))
    return rate, math.floor(y)


def _decimal_cdf(rate, k, precision):
    with localcontext() as ctx:
        ctx.prec = precision
        lam = Decimal.from_float(rate)
        term = Decimal(1)
        total = term
        for j in range(1, k + 1):
            term = term * lam / j
            total += term
        return (-lam).exp() * total


def truth(config):
    """A noncausal scalar CDF; the threshold is inclusive and floored for counts."""
    rate, k = _parameters(config)
    if k < 0:
        return {"value": 0.0, "estimated_error": 0.0,
                "target": "P(Y <= cdf_threshold | X=query_x)",
                "method": "Exact support identity: Y is nonnegative",
                "error_interpretation": "Exact zero below support; no simulation error."}
    polynomial = math.fsum(rate ** j / math.factorial(j) for j in range(k + 1))
    value = math.exp(-rate) * polynomial
    dec60 = _decimal_cdf(rate, k, 60)
    dec90 = _decimal_cdf(rate, k, 90)
    with localcontext() as ctx:
        ctx.prec = 100
        discrepancy = abs(Decimal.from_float(value) - dec90)
        refinement = abs(dec60 - dec90)
        diagnostic = float(discrepancy + refinement) + 8 * math.ulp(value)
    return {
        "value": value,
        "estimated_error": diagnostic,
        "target": "P(Y <= cdf_threshold | X=query_x)",
        "query": {"x": config["query_x"], "y": config["cdf_threshold"],
                  "integer_threshold": k, "conditional_rate": rate},
        "method": "Finite Poisson PMF sum with math.fsum; Decimal precisions 60/90 audit",
        "decimal_reference": str(dec90),
        "decimal_precision_difference": float(refinement),
        "error_interpretation": "Numerical diagnostic: double-vs-Decimal discrepancy + precision refinement + 8 ULP. No Monte Carlo error; not a certified uniform bound. The Decimal audit shares the finite-sum identity; independent Gamma-integral verification is in verify.py."
    }
