"""Separate Gamma-survival integral, analytic fixtures and generator checks.

No scipy/numpy/R dependency. Fixed tolerances are defined before any execution.
Only the submitted local generator/truth modules are imported, without networking.
"""
from copy import deepcopy
import importlib.util
import math
from pathlib import Path
import random


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("qdi_check_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _gamma_integral(rate, steps):
    # For threshold 3, Poisson CDF = P(Gamma(shape=4, rate=1) > rate).
    # Integrate t^3 exp(-t)/6 directly; no Poisson-CDF routine or PMF sum.
    upper = 60.0
    h = (upper - rate) / steps
    def integrand(t):
        return t * t * t * math.exp(-t) / 6.0
    weighted = [integrand(rate), integrand(upper)]
    weighted.extend((4 if j % 2 else 2) * integrand(rate + j * h)
                    for j in range(1, steps))
    value = h * math.fsum(weighted) / 3.0
    # Integral beyond 60: log derivative 3/t - 1 <= -(1-3/60).
    tail_bound = integrand(upper) / (1 - 3 / upper)
    return value, tail_bound


def verify(config):
    oracle = _module("truth.py")
    gen = _module("generator.py")
    checks = []
    def record(name, passed, details):
        checks.append({"name": name, "passed": bool(passed), "details": details})

    fixture = {"x_low": 0.0, "x_high": 10.0, "rate_floor": 1.0,
               "rate_cap": 6.0, "query_x": 5.0, "cdf_threshold": 3}
    record("source_constants_and_declared_query", config == fixture,
           "Equation (26) law is fixed; x=5,y=3 is the user-declared adaptation.")
    reference = oracle.truth(config)
    # Independent literal lambda=5 makes a changed/misread config fail the fixture.
    coarse, tail = _gamma_integral(5.0, 4096)
    fine, _ = _gamma_integral(5.0, 8192)
    refinement = abs(fine - coarse)
    error = abs(reference["value"] - fine)
    record("independent_gamma_survival_integral", error <= 1e-10,
           {"oracle": reference["value"], "simpson_8192": fine,
            "absolute_difference": error, "tolerance": 1e-10})
    record("integral_refinement_and_tail", refinement <= 1e-10 and tail < 1e-20,
           {"simpson_4096": coarse, "simpson_8192": fine,
            "refinement_difference": refinement, "tail_upper_bound": tail,
            "note": "Refinement is a diagnostic, not a certified Simpson bound."})
    record("truth_precision_diagnostic", reference["estimated_error"] <= 1e-13,
           {"estimated_error": reference["estimated_error"], "tolerance": 1e-13})
    record("algebraic_query_anchor", abs(reference["value"] - (118.0 / 3.0) * math.exp(-5)) <= 1e-14,
           "Finite-sum simplification (118/3) exp(-5); shares exp and algebra, not independent evidence.")

    special_results = []
    for x, rate in ((0.25, 1.0), (0.75, 1.0), (1.0, 1.0),
                    (5.0, 5.0), (6.0, 6.0), (8.0, 6.0), (9.75, 6.0)):
        c = {**config, "query_x": x, "cdf_threshold": 0}
        observed = oracle.truth(c)["value"]
        expected = math.exp(-rate)
        ok = abs(observed - expected) <= 1e-14 and gen._rate(x, config) == rate
        special_results.append({"x": x, "rate": rate, "cdf_at_zero": observed, "passed": ok})
    record("analytic_zero_count_and_clipping_plateaus", all(r["passed"] for r in special_results), special_results)
    record("cdf_below_support_exact_zero", oracle.truth({**config, "cdf_threshold": -0.1})["value"] == 0.0,
           "Nonnegative counts imply F(-0.1 | x)=0 exactly.")
    at_between = oracle.truth({**config, "cdf_threshold": 3.75})["value"]
    at_two = oracle.truth({**config, "cdf_threshold": 2})["value"]
    record("discrete_threshold_and_inclusive_jump",
           at_between == reference["value"] and
           abs((reference["value"] - at_two) - math.exp(-5) * 125 / 6) <= 1e-14,
           "F(3.75|5)=F(3|5), and F(3|5)-F(2|5)=P(Y=3|5).")
    grid = [0.25, 0.75, 1.0, 2.0, 5.0, 6.0, 8.0, 9.75]
    cdfs = [oracle.truth({**config, "query_x": x})["value"] for x in grid]
    record("stochastic_order_and_plateaus", all(a >= b for a, b in zip(cdfs, cdfs[1:]))
           and cdfs[0] == cdfs[1] == cdfs[2] and cdfs[-3] == cdfs[-2] == cdfs[-1],
           {"x": grid, "cdf_at_3": cdfs, "scope": "Algebraic point checks only, no simultaneous confidence band."})

    # Hand-controlled uniforms test event count and loop stopping, not RNG quality.
    class ConstantUniform:
        def __init__(self, value):
            self.value = value
        def random(self):
            return self.value
    sampler_results = []
    for rate in (1.0, 5.0, 6.0):
        for count in (0, 1, 3, 8):
            draw = gen._poisson(rate, ConstantUniform(math.exp(-rate / (count + 0.5))))
            sampler_results.append(draw == count)
    record("poisson_sampler_event_count", all(sampler_results),
           "Controlled uniforms put the crossing between arrival count k and k+1 for k=0,1,3,8 and rates 1,5,6.")

    before_rng, before_config = random.getstate(), deepcopy(config)
    data = gen.generate(config, 128, 1729)
    repeat = gen.generate(config, 128, 1729)
    changed = gen.generate(config, 128, 1730)
    other_query = gen.generate({**config, "query_x": 8.0, "cdf_threshold": 0}, 128, 1729)
    record("local_rng_and_config_preserved", random.getstate() == before_rng and config == before_config,
           "Local random.Random(seed); neither global RNG nor input config is mutated.")
    record("observed_only_replay_and_query_independence",
           set(data) == {"X", "Y"} and all(len(v) == 128 for v in data.values())
           and all(0 < x < 10 and math.isfinite(x) for x in data["X"])
           and all(type(y) is int and y >= 0 for y in data["Y"])
           and data == repeat and data != changed and data == other_query,
           "Only observed X,Y; integer Y with no jitter; query does not condition the generated sample.")
    return {
        "passed": all(c["passed"] for c in checks), "checks": checks,
        "shared_components": "All routes share the documented Poisson law and source interpretation. Gamma integration uses independently written integrand/nodes, without the truth PMF implementation. Analytic fixtures share math.exp; Decimal refinement shares the PMF identity. No independent-person reproduction or scientific acceptance is asserted."
    }
