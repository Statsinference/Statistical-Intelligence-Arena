# QDI：Henzi–Ziegel–Gneiting 的截断强度 Poisson 机制

贡献 ID：`qdi-henzi-2021-poisson-clipped-rate-v1`；类型 `synthetic_dgp`；family `quantile_distribution`。
机制标识 `henzi-ziegel-gneiting-2021-poisson-clipped-rate`；唯一场景 `original_poisson_qdi`。
本轮修订：`published-source-revision-20261101`。
状态 **awaiting_scientific_review**，`scientific_acceptance=false`。
这是独立目录中的本地修订；未向外部服务提交、创建 PR 或联系维护人。
旧 ZIP 保留，SHA-256 为 `66ec5bf2063a06211f49c9a750d0bc425ce726e961cb188758523bbf30370d00`。

## 当前主来源与阅读记录

Henzi, Alexander; Ziegel, Johanna F.; Gneiting, Tilmann (2021).
*Isotonic distributional regression*. Journal of the Royal Statistical Society:
Series B (Statistical Methodology), **83(5):963–993**。
[DOI 10.1111/rssb.12450](https://doi.org/10.1111/rssb.12450)。JRSS-B 属于本轮四刊范围。

**当前主来源为实际取得并于 2026-11-01 亲自核读的正式发表 PDF（Version of Record，31 页）**，
同时读了官方补充 PDF（11 页，首页日期 March 19, 2021）。正式 PDF 首页、相关正文与公式已提取，
PDF 第 12、13、17、19 页和补充第 3、7、8 页的图像已检查。
历史 arXiv v3（2021-09-28）仅保留为差异记录，不再充当当前主来源。

| 来源项目 | 具体版本和定位 | 本轮核对结果 |
|---|---|---|
| 作者、题目、期刊、年份、DOI | 正式 PDF 第 1 页／期刊第 963 页；DOI 稳定链接 | 已核实作者三人、2021 年、83(5):963–993；不是预印本发表信息 |
| X 的设计 | 正式版 §4，PDF 第 17 页／期刊第 979 页，式 (23) 前的未编号段落 | X~Uniform(0,10)，端点 0、10 有原文依据 |
| Poisson 机制 | 正式版 §4，式 (26)，PDF 第 19 页／期刊第 981 页 | Y4 条件强度 min(max(X,1),6)，下/上限 1、6 有原文依据；本包 Y4 改名 Y |
| 论文实验规模 | 正式 PDF 第 19 页／期刊第 981 页，以 “Under each scenario” 开头的首段；Table 1 在 PDF 第 18 页／期刊第 980 页 | 每场景 500 个训练集，n=500/1000/2000/4000；测试 m=5000。本轮不复跑这些估计器实验 |
| iid 与正则性 | 正式 §2.4 Theorem 3，PDF 第 12–13 页／期刊第 974–975 页；官方补充 S4，第 7 页 | theorem 明确行内数组 iid；S4 说明 iid 观察对和独立测试样本。条件与本机制的对应推导见下文 |
| 官方补充 | [出版社入口](https://academic.oup.com/jrsssb/article/83/5/963/7056107?login=false#supplementary-data)，rssb12450-sup-0001-supinfo.pdf | 已实际阅读；S2 第 2–5 页、证明从第 3 页开始；S4 第 7 页；S5 引言第 7 页，Table S1 第 8 页；补充页码独立于期刊页码 |
| 代码仓库及固定版本 | [isodistrreg](https://github.com/AlexanderHenzi/isodistrreg)，commit `c339ffa652ca24111f183ed833aa7bd5fa43acfd`，2021-03-22T12:19:56Z | 已复读此前取得的官方固定提交文件，并核对保存的 Git tree / commit 元数据；不是当前 master |
| 代码位置 | [simulation_example.R](https://github.com/AlexanderHenzi/isodistrreg/blob/c339ffa652ca24111f183ed833aa7bd5fa43acfd/simulation_example.R#L42)，顶层脚本而非命名函数 | 训练 X 第 57 行、Poisson 第 61 行；验证 X 第 72 行、Poisson 第 79 行 |
| 作者历史种子配方 | 同脚本第 42、52、54、55、70 行 | n 默认 2000、id 默认 250，注释 id=1..500；训练 set.seed(n+id)，验证 set.seed(id)，故默认种子 2250／250。并非“作者种子未找到” |
| 脚本分支与微扰 | 第 38 行 `type="S"`；P 分支第 36、61、79 行；第 67–68 行训练微扰 | 默认脚本是 S 分支，选择 P 才是本 Poisson 机制；训练 X/Y 另加 ±10⁻⁶ 均匀微扰。本包遵循正式式 (26) 的未微扰整数 Y |
| 本次目标 | 本次用户请求，不是论文表格结果 | θ=P(Y≤3\|X=5)；固定标量 CDF，属于显式 adaptation |

来源文件 SHA-256（PDF、作者 R 文件均不放入贡献 ZIP）：

- 正式 PDF：`9b06bc5fe39f69fefa3b0a69913a61575ab32ca9adbb00327a5fd031a806203a`
- 官方补充 PDF：`e4cc5b6ce76ada9f5bd7c2a4e69100e31dc9f490b127cab4d32a21bde762fda0`
- 历史 arXiv v3 PDF：`17cb3876c95eb7886a537730d9a36c5fdee6d792bfd42f8086108727c0f6fd26`
- 固定 simulation_example.R：`afb45e41b810c021f58a83db8289c31952a23b45d63e1a3ab4dbc579c885c0b8`
- 固定 simulation_example_functions.R：`117334f35d634b84edf96f4ffe1f3af82f076a0e4efc8431676f00043837db93`
- 固定 DESCRIPTION：`1a1c102db3ac27caeba8bfa5234a374e6cb65a0aea2f83bd5cebee48cbf95756`

## 版本对照与来源缺口处理

| 原记录 / 对照项 | 当前结论 | 是否影响本包数学机制完整 |
|---|---|---|
| 正式 PDF 页码曾为 missing | **已解决**：X 在 PDF 17／979，式 (26) 在 PDF 19／981。两者分开记录；PDF 18／980 是整页 Table 1 | 否，现有明确正式定位 |
| 官方补充曾返回 HTTP 403 | **已解决**：本地正式补充已取得、核读并记录哈希。2026-10-31 的 403 只作历史抓取记录，不再视为当前缺失 | 否 |
| 正式版与预印本公式 | **已核对目标范围**：正式式 (26) 与 [arXiv v3](https://arxiv.org/pdf/1909.03725v3) PDF 第 19 页的 Uniform–Poisson 机制一致 | 否；不宣称全文/所有证明逐字相同 |
| 定理编号 | 正式 §2.4 **Theorem 3**，条件 (a)–(d)，对应 arXiv **Theorem 2.3** 条件 (i)–(iv)；官方补充 S2 第 3 页仍写 **Proof of Theorem 2.3**。按 (a)↔(i)、(b)↔(ii)、(c)↔(iii)、(d)↔(iv) 记录 | 否；是编号/表述映射 |
| 附录与补充定位 | arXiv Appendix D 第 41–42 页对应官方 S4 第 7 页；arXiv Appendix E/Table 3 第 43 页对应官方 S5/Table S1 第 8 页 | 否 |
| 作者历史种子配方 | **已解决**：训练 n+id，验证 id，及脚本默认值、id=1..500 注释均有固定行号 | 否；本包小样本 seed=1729 是检查参数，不冒充作者 seed |
| 最终论文 Table 1 的锁定 commit／完整运行清单 | **仍未找到于已调查范围**：正式全文 31 页、补充 11 页对 seed/commit/reproducibility/code/GitHub 的检索与 §4、S4、S5 核读；固定提交的两份 simulation 脚本、DESCRIPTION、已保存 Git tree/commit；2026-11-01 查看的 GitHub history/releases 页面，均未发现把最终 Table 1 明确绑定到完整 SHA 和全部运行配置的声明。固定 README、tags 页面本次返回 cache miss，未将它们当作已读证据 | **否**：核心分布、参数和标量真值完整；仅限制论文全表逐位复跑。若未来需要，须由作者提供表格与 commit/run manifest 的对应关系，本轮未联系作者 |

上述检索范围不等于穷尽所有未公开或无法访问材料，不能据此断言作者从未记录最终运行版本。
源文件许可声明已核对（正式首页及固定 DESCRIPTION）；本贡献的发布许可/署名安排仍属维护人决定，
未替贡献者授予许可。具名科学审核、他人独立复现、维护人查重与采纳均未执行，不能用检索代替。

## 原始机制、观察表与改编

生成律为

\[
X_i\overset{iid}{\sim}\mathrm{Uniform}(0,10),\quad
\lambda(x)=\begin{cases}
1,&0<x\le1,\\
x,&1<x<6,\\
6,&6\le x<10,
\end{cases}\quad
Y_i\mid X_i=x\sim\mathrm{Poisson}(\lambda(x)).
\]

按生成顺序的完整机制清单：

| 顺序 | 变量 / 对象 | 分布、参数与尺度 | 依赖、边界与观察 |
|---|---|---|---|
| 1 | X | Uniform(0,10)；密度 0.1；推导均值 5、方差 100/12 | 各行 iid；开区间端点是零概率事件；实际实现排除机器 RNG 的零端点。观察列 |
| 2 | λ(X) | 确定性 clamp(X,1,6)，下限 1、上限 6 | X≤1 为 1、1<X<6 为 X、X≥6 为 6；两折点连续；仅内部使用，不输出 |
| 3 | Y（原文 Y4） | 条件 Poisson(λ)；条件均值=方差=λ，条件标准差 √λ | 支持 {0,1,2,…}，**无有限上界**；截断的是强度，不是计数 Y。没有额外 additive noise、自由离散度/尺度参数。观察列 |
| 4 | 观测映射 | 完整观察 (X,Y) | 一个单位是一对数据，行内 Y 经 λ(X) 依赖 X；单位间独立。处理分配、中介、缺失、半监督标注、删失、interference 均不适用 |

不存在人为裁剪、上端封顶或 Gaussian 噪声替代 Poisson；给模型的 Y 保持非负整数。

不同 i 的对相互独立。给定 X 后没有额外的独立加性误差项；Poisson 条件分布本身提供随机性。
`generate(config,n,seed)` 中 n 是完整观察对的行数，返回 `{"X": [...], "Y": [...]}`。
X 为浮点协变量，Y 为非负整数响应、无有限上界；schema 的 X 边界 0、10 为外包范围，
实现排除端点 0，实际输出满足 0<X<10。两列均完整可见，无缺失、删失、标注指示、占位值、
真实数据或潜变量输出。内部强度 λ 不返回给模型；真值与查询元数据仅在 oracle/检查材料中。

仅声明一个场景 `original_poisson_qdi`。它保留原文固定分布与参数，并明确采用本次请求的新目标。
特殊查询仅用于验证数学身份，不作为新增已声明 DGP 场景或新的 family。
改变种子或参数不构成独立机制 family。

改动完整列举：

1. 原文 Y4 改列名为 Y，不改变其分布。
2. 将原论文整条条件分布的预测比较改为 θ=P(Y≤3|X=5) 的固定标量 QDI 目标。
3. 采用方程 (26) 的离散响应，不添加作者训练脚本第 67–68 行的微扰。
4. 用本地 Python RNG 和均匀乘积法实现 Poisson 抽样；不要求与 R 的随机流逐位相同。
5. 只运行 n=128 的接口检查及真值计算；未运行论文的多次拟合/验证实验。

## 目标、抽样与识别条件

目标是 **条件 CDF**，采用包含端点的事件 Y≤3；不是边际 CDF、条件均值、分位数或因果效应。
没有分位水平参数。如果未来另做分位数场景，应采用离散分位数
`inf{y : F_x(y) >= alpha}` 并单独声明 alpha；本包不评估该场景。

由于 X 连续，P(X=5)=0。这里 θ 是由已知机制指定的条件概率核在 x=5 的值。
从一般联合分布识别该点值时，需要选取在 x=5 连续的条件版本，并有该点邻域的设计支持；
不能以恰好 X=5 的观察行计数代替识别。此模型 f_X(x)=0.1，5 在支持内部，λ 在 5 附近等于 x，
故目标是良好定义的点态量。

适用条件及本包推导（不是未核验的原文参数）：

- iid 抽样、X/Y 完整观测、生成律按 (26) 正确指定；无时间/空间/网络依赖。
- 通常数值顺序下，λ 非减。若 λ₂≥λ₁，可耦合 Y₂=Y₁+Z，Z~Pois(λ₂-λ₁) 独立；
  因此条件分布按随机序递增，固定 y 的 CDF 随 x 非增。
- 同一耦合给出 `sup_y |F_x(y)-F_x'(y)| <= 1-exp(-|lambda(x)-lambda(x')|) <= |x-x'|`。
  λ 在 1、6 有折点，但连续且 1-Lipschitz。X/10 的重标度使设计支持符合正式 §2.4 Theorem 3（PDF 12–13／期刊 974–975）
  的 [0,1] 表述；官方补充 S2 的 Theorem 2.3 是相应证明的旧编号；一维全序不存在复杂反链问题。这里只说明此机制的结构，不声称验证了任何估计器的收敛率。
- Y 为离散分布，零点和每个非负整数上均有正质量，条件均值和方差都为 λ(x)，所有矩有限。
  不存在关于 Lebesgue 测度的响应密度，连续分位数推断中的正密度条件不适用。
- 不施加干预、无混杂、NIE/NDE、cross-world 等因果假设；本次没有因果目标。

## 真值推导与计算精度

令 k=⌊y⌋。k<0 时 F_x(y)=0；否则

\[
F_x(y)=e^{-\lambda(x)}\sum_{j=0}^{k}\frac{\lambda(x)^j}{j!}.
\]

在固定查询 x=5、y=3，λ=5，因此

\[
\theta=e^{-5}(1+5+25/2+125/6)
=\frac{118}{3}e^{-5}
=0.26502591529736170580101790464383802045475034440930002692535\ldots
\]

这是真值推导所得，未将任何论文估计值当作真值。
`truth.py` 使用 `math.fsum` 对有限项求和，没有尾部截断误差；再以 Decimal 60 与 90 位精度
复算诊断。返回 `estimated_error` 为双精度与 90 位结果的差、60/90 位差及 8 ULP 裕量之和。
这不是置信区间，也不是对任意平台/配置的严格统一误差界。参考值与 truth 容限预先设为
`0.2650259152973617` 和 `1e-13`；无 Monte Carlo 真值误差。

对当前只包含固定机制的包，生成器拒绝改动 0、10、1、6。truth 支持机制内其他查询用于特殊情况检查：
0<x<10，-100≤y≤100；这些不是自动登记的参数扩展。

## 独立核验与边界

`verify.py` 使用另一条计算路线：单位率 Poisson 过程的第 4 次到达时间 T4~Gamma(4,rate=1)，
于是 `P(N(5)<=3)=P(T4>5)=Integral_5^infinity t^3 exp(-t)/6 dt`。
也可连续分部积分得到相同恒等式。
积分实现直接求 Gamma 密度的面积，不调用 `truth.py` 的求和函数、Decimal 函数或 Poisson CDF。
使用 [5,60] 上 4096/8192 个子区间的复合 Simpson 积分。

尾部界由 `d log(f(t))/dt = 3/t-1 <= -(1-3/60)`（t≥60）给出：
`Integral_60^infinity f(t)dt <= f(60)/(1-3/60)`。
Gamma 积分与 oracle 的允许差为 `1e-10`；网格细化差也要求 ≤`1e-10`，尾部界 <`1e-20`。
**1e-13 是 truth 自身误差诊断的容限，1e-10 是不同路线的积分交叉比较容限，两者衡量不同误差；约 2e-13 的积分差不构成 truth 失败。**
这些阈值在原包首次运行前确定，本轮原样保留。网格细化仅是数值收敛诊断，不冒充严格 Simpson 余项界。

其他逐项检查：原文常数和固定查询；oracle 精度；代数简化；y<0 的精确零；
y=0 的 `exp(-lambda)`；下/上截断平台及折点；`F(3.75|5)=F(3|5)`；
`F(3|5)-F(2|5)=P(Y=3|5)`；CDF 的随机序方向；受控均匀数下 Poisson 抽样器的到达计数；
局部 RNG 不改变全局状态；输入配置不变；观察列与整数响应；同种子复现、异种子变化；
改变查询不会改变生成样本。

独立性限制：所有路线共享同一论文方程及其人工/AI 解读；Decimal 精度复算共享有限和公式，
代数特例共享 `math.exp`，这些不是独立证据。Gamma 积分使用独立的被积函数及网格实现，
仍不是另一人的独立复现。自动逐点 PASS 不是同时置信带验证或置信区间 coverage 验证。
检查实际结果及机器环境以 `checks/report.json` 为准。

## 标签、权利、协助与未决项

协变量总维数=1，有效维数=1，均指 X；Y 不算输入维数。
`high_dimensional=false`，`interactions=false`，没有乘积交互项或无关变量填充。
`nonlinear=true` 对应全域非仿射函数 `min(max(x,1),6)` 以及在 (1,6) 上非线性的条件 CDF，
不能把分段线性误写成处处光滑。没有高维混杂、预测辅助器或样本划分需求。

出版社页面注明 ©2021 The Authors / CC BY-NC-ND 4.0；核对的作者 DESCRIPTION 为 GPL (>=2)。
本包不再分发论文/补充 PDF、作者 R 源码或任何真实观测，Python 是从数学机制独立实现。
引用来源许可不自动决定本贡献的发布许可，维护人仍需核对署名和分发安排。

AI 完成来源读取、代码编写和本地数值审核；没有代签具名科学审核。
本轮已关闭正式页码与官方补充缺口。仍待事项仅为上表限定检索范围内未找到的最终表格 commit/run manifest、
本贡献发布许可/署名安排，以及维护人查重、他人独立复现和具名科学接收。核心生成参数没有缺项或补造。

本轮未执行 PFN 训练/微调、大规模超分布、bootstrap/coverage、原实验改动、检查点改动、
真实数据获取、远端 submit、PR 或消息发送。ZIP 的自动运行/哈希 PASS 仅是格式与运行证据，
状态保持 **awaiting_scientific_review**。
