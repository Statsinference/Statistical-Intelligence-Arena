# Nie–Wager (2021) Setup C: constant effect under a logistic propensity

**Contribution `cate-nie-2021-setup-c-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `nie-wager-2021-setup-c`

## Source and reconstruction

- Citation: Nie, X. and Wager, S. (2021). Quasi-oracle estimation of heterogeneous treatment effects. Biometrika 108(2), 299-319. DOI: 10.1093/biomet/asaa076.
- Venue / year: Biometrika, 2021
- Link: https://arxiv.org/abs/1712.04912
- **Exact locator**: Section 6.1, arXiv:1712.04912v3 PDF p.16, unnumbered Setup C paragraph (no equation number in the source): 'e*(Xi) = 1/(1 + e^{Xi2+Xi3}), b*(Xi) = 2 log(1 + e^{Xi1+Xi2+Xi3}), and the treatment effect is constant, tau*(Xi) = 1'.
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **X1-X3**: `Xj ~ Normal(0,1) independently, j = 1..3`
2. **Treatment**: `e(X) = 1 / (1 + exp(X2 + X3))`
3. **Baseline**: `b(X) = 2 log(1 + exp(X1 + X2 + X3))`
4. **Heterogeneity**: `tau(X) = 1`
5. **Outcome**: `Y = b(X) + A tau(X) + sigma eps, eps ~ Normal(0,1), sigma = 1`

Sampling unit: individual · dependence: independent and identically distributed

Fixed parameters: no free coefficients beyond the structure; baseline multiplier 2, constant effect 1, noise sigma = 1.

### Adaptations relative to the source

- Dimension fixed at d = 3, the smallest dimension for which Setup C is defined; the source varies d in {6, 12}.
- The source writes Y = b(X) + (W - 0.5) tau(X) + sigma eps; this package uses A in {0,1}. The CATE is unchanged.
- sigma fixed at 1 (source grid {0.5, 1, 2, 3}).

## Target and identification

- Symbol: `tau(x0) = E[Y(1) - Y(0) | X = x0]`
- Definition: Conditional average treatment effect at the declared query points; constant equal to 1 for every x, so the whole difficulty is the strongly confounded nuisance structure.
- Query points (part of the estimand): `primary`: (X1 = 0.0, X2 = 0.0, X3 = 0.0); `secondary`: (X1 = 0.5, X2 = -0.5, X3 = 0.0)

Identification assumptions:

- SUTVA: one version of treatment, no interference
- Unconfoundedness: treatment depends on X2 + X3, which also enters the baseline; the design is observational
- Overlap: e(x) = 1/(1+e^{x2+x3}) is strictly inside (0,1) for every finite x, but the tails are thin; no uniform bound is claimed
- Homoscedastic Gaussian noise with sigma = 1

Setup C is the mirror image of Setup A: the effect is trivial but the propensity is simple while the baseline is complex and strongly confounded. It is the natural complement for testing whether a method can remove bias without a flexible propensity model.

## Truth and independent verification

Additive outcome: E[Y|A=1,X=x] - E[Y|A=0,X=x] = tau(x) = 1 for every x. Exact.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and confirms end-to-end that the realised
outcome column of `generator.py` carries the declared surface (arm-contrast shift
equals the mean of tau over treated rows, at identical seed). Both routes share the
declared mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 3 (effective 3) · high dimensional: False · interactions: False · nonlinear: True
- Constant-effect design; it cannot discriminate between methods on heterogeneity, only on bias and interval calibration. Gaussian covariates mean the propensity approaches 0 and 1 in the tails, so finite-sample overlap can be poor even though positivity holds pointwise.

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| X1 | covariate | float | · | · | true |
| X2 | covariate | float | · | · | true |
| X3 | covariate | float | · | · | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by Oxford University Press for Biometrika. No PDF or author code is redistributed.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: d fixed at 3, sigma fixed at 1.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
