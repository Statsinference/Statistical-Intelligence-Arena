import itertools
import numpy as np
from numpy.polynomial.hermite import hermgauss
from numpy.polynomial.legendre import leggauss
from generator import generate, _draw
from truth import truth


def verify(config):
    checks=[]
    def equal(name,observed,expected,tol=1e-10):
        error=float(np.max(np.abs(np.asarray(observed)-np.asarray(expected))))
        checks.append({"name":name,"passed":bool(np.isfinite(error) and error<=tol),"details":{"max_absolute_error":error,"tolerance":float(tol)}})
    def mc(name,values,expected):
        v=np.asarray(values);se=float(v.std(ddof=1)/np.sqrt(v.size))
        equal(name,v.mean(),expected,max(1e-12,6*se))
    c=config
    expected=dict(SOURCE_ANCHOR)
    if 'beta' in expected:expected['beta']=c['beta']
    checks.append({"name":"fixed_source_parameter_anchor","passed":c==expected,"details":"Config matches the fixed parameter transcription. This catches later edits but cannot detect an error in the original transcription."})
    # Two-dimensional Gauss-Legendre integration: direct risk standardization.
    def integrate(order,beta):
        v,w=leggauss(order);u,x=np.meshgrid((v+1)/2,(v+1)/2,indexing='ij');weights=np.outer(w/2,w/2)
        risks=[np.sum(weights*np.exp(c['eta0']+beta*a-2*u-.25*x-.75*u*x)) for a in [0,1]]
        return risks,u,x,weights
    risks,u,x,weights=integrate(64,c['beta']);coarse,_,_,_=integrate(32,c['beta'])
    equal('quadrature_population_log_RR',np.log(risks[1]/risks[0]),truth(c)['value'])
    equal('quadrature_order_diagnostic',risks,coarse)
    null,_,_,_=integrate(64,0)
    equal('null_effect_special_case',np.log(null[1]/null[0]),0)
    error=[]
    for a,uu,xx in itertools.product([0,1],[0.,.4,1.],[0.,.6,1.]):
        mz=.25*a+.25*xx+5*uu
        eq=1+np.exp((1-2*a)*(-1.00125-.0475*a+.2*mz+.2*xx)+.5*.2**2*.25**2)
        pa=1/(1+np.exp(1-uu-.25*xx))
        error.append(eq*(pa if a else 1-pa)-1)
    equal('normal_treatment_bridge_identity',error,0)
    pa=1/(1+np.exp(1-u-.25*x));pd=np.exp(-4.605+.25*x-.2*u)
    ps=1/(1+np.exp(1.4-.5*x-2*u-u*x))
    total=0.;moments={k:0. for k in ['X','A','Z','W','Y']}
    for a in [0,1]:
        py=np.exp(c['eta0']+c['beta']*a-2*u-.25*x-.75*u*x)
        wa=weights*(pa if a else 1-pa);ws=wa*(py+pd-py*pd)*ps;total+=ws.sum()
        for k,v in [('X',x),('A',a),('Z',.25*a+.25*x+5*u),('W',.25*x+2*u)]:moments[k]+=np.sum(ws*v)
        moments['Y']+=np.sum(wa*py*ps)
    sample=generate(c,4096,314164)
    for name,val in moments.items():mc('selected_mean_'+name,sample[name],val/total)
    checks.append({'name':'integrated_selection_probability','passed':bool(0<total<1),'details':{'probability':float(total)}})
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'shared_components':'Every check uses the same transcribed source model. The structural, enumeration and quadrature calculations run separately from the generator; sample-moment tests call it. Independent review of the source transcription is still required.',
            'limits':'Finite grids and simulation checks cannot establish identification, behavior in the tails, or estimator coverage. Tolerances were set in advance. Null-path tests are diagnostic cases, not new scenarios.'}

SOURCE_ANCHOR = {'uniform_min': 0, 'uniform_max': 1, 'a_logit': [-1, 1, 0.25], 'z': [0, 0.25, 0.25, 5], 'w': [0, 0.25, 2], 'proxy_sd': 0.25, 'eta0': -4.605170185988091, 'beta': -0.6931471805599453, 'y': [-2, -0.25, -0.75], 'd_logrisk': [-4.605, 0.25, -0.2], 's_logit': [-1.4, 0.5, 2, 1], 'selected_sample': True, 'max_candidates': 100000000}
