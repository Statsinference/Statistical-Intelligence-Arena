# Continuous negative-control proxies in test-negative design

Status: candidate; not scientifically accepted.

## 文献来源与任务

Li K Q, Shi X, Miao W, Tchetgen Tchetgen E. *Double Negative Control Inference in Test-Negative Design Studies of Vaccine Effectiveness*. Journal of the American Statistical Association, 2024, 119(547):1859–1870. DOI: [10.1080/01621459.2023.2220935](https://doi.org/10.1080/01621459.2023.2220935)。

读取材料为作者仓库 `KenLi93/TND_methods` 的 `TND-manuscript-supplement.pdf`，固定 commit [`ba9dc3c581390fcefce0ca4cdabf65688a91a455`](https://github.com/KenLi93/TND_methods/tree/ba9dc3c581390fcefce0ca4cdabf65688a91a455)，PDF 第25页，Section I，Table S.1 的连续代理块。任务类别为 `proximal`；`collection.json` 的 `source_relation` 为 `adapted_from_source`。

ID 日期说明：`proximal-li-2023-07-10-continuous-tnd-v1` 中的 `2023-07-10` 沿用论文 online-first（在线优先发表）日期；`source.year=2024` 按正式卷期的发表年份登记。ID 日期、正式卷期年份和所读版本日期分别记录，含义不同。


## 连续代理数据生成方程

取 `σ(t)=1/(1+exp(-t))`。对来源总体独立个体依次生成：

1. `U ~ Uniform(0,1)`，`X ~ Uniform(0,1)`；两者独立。
2. `A | U,X ~ Bernoulli(σ(-1 + U + 0.25X))`。
3. `Z = 0.25A + 0.25X + 5U + εZ`。
4. `W = 0.25X + 2U + εW`。
5. `Y | A,U,X ~ Bernoulli(exp(η0 + βA - 2U - 0.25X - 0.75UX))`，`η0=ln(0.01)`。
6. `D | U,X ~ Bernoulli(exp(-4.605 + 0.25X - 0.2U))`。
7. `S | Y,D,U,X ~ Bernoulli(max(Y,D) × σ(-1.4 + 0.5X + 2U + UX))`。

`εZ` 与 `εW` 为独立 `Normal(0,0.25²)`，并独立于 `U,X` 及二元节点的随机数。最终只返回 `S=1` 个体的观测列 `X,A,Z,W,Y`；内部变量为 `U,D,S`。连续协变量 `X` 的边界是 `[0,1]`；连续代理与正态噪声无固定数值截断。

## 登记场景

四个场景均固定 `η0=log(0.01)`，只改变处理效应 `β∈{log(0.2), log(0.5), log(0.7), 0}`。
默认场景为 `table-eta001-rr050`；下表与 config.json 一一对应。

| 场景 ID | RR=exp(β) | β 的设定与数值 |
|---|---:|---|
| `table-eta001-rr020` | 0.2 | `log(0.2)` = -1.6094379124341 |
| `table-eta001-rr050` | 0.5 | `log(0.5)` = -0.6931471805599453 |
| `table-eta001-rr070` | 0.7 | `log(0.7)` = -0.3566749439387324 |
| `table-eta001-rr100` | 1.0 | `0` = 0 |

每套 TND 的四个参数场景仍属于同一个 mechanism family，不按场景增加 DGP 数量。

## 因果目标与识别条件

目标为选择前来源总体的因果对数风险比 `βlogRR=log(E[Y(1)]/E[Y(0)])`。令 `q(U,X)=-2U-0.25X-0.75UX`，则

`E[Y(a)] = exp(η0+βa) × E[exp(q(U,X))]`；因此 `βlogRR=β`。辅助真值为 `RR=exp(β)`、`VE=1-exp(β)`。机制使用一致性、无干扰、给定 `U,X` 的处理交换性及正性、代理变量排除限制、连续代理桥函数及完备性条件。

## 真值与核验

`truth.py:truth` 返回解析值 `β`，`estimated_error=0`。`verify.py:verify` 对 `U,X∈[0,1]` 实施 32 阶与 64 阶二维 Gauss–Legendre 积分，核对处理组边际风险比及求积阶数；另计算 `β=0` 特例、连续代理处理桥恒等式，以及选择概率和入选样本 `X,A,Z,W,Y` 的均值诊断。入选样本矩采用固定种子、样本量4096的数值模拟进行核验。

## 维度与范围

观测基线协变量为 `X`，总维数和有效维数均为1；潜在混杂变量为 `U`。`Y` 与选择机制中出现 `UX` 交互项；`A` 与 `S` 使用 logistic 链接，`Y,D` 使用指数风险链接。只有选择后的5列观测数据提供给下游程序。
## 接口、观测数据与数值处理

`generator.py:generate(config, n, seed)` 接收 `config.json` 中指定场景的参数字典、正整数 `n` 和非负整数 `seed`。随机数由 NumPy 的 `Generator(PCG64(seed))` 产生。同一随机种子复现同一观测数组。`schema.csv` 给出所有变量的类型与可观测性。概率由相应分布表达式计算；当概率非有限或不在 `[0,1]` 范围内时，生成函数抛出异常，不执行概率裁剪。所有配置保存在 `config.json`，主要函数位于 `generator.py`、`truth.py` 和 `verify.py`，依赖范围位于 `requirements.txt`。

## 权利与 AI 协助 / Rights and assistance

Status: candidate；尚未获得具名科学接收，本卡片不构成科学审核结论。

### 来源与权利

本机制（proximal-li-2023-07-10-continuous-tnd-v1）的论文、补充材料及作者原始代码的相关权利归各自权利人所有；
具体来源、读取版本与公式定位见本卡片「文献来源」及 source_evidence.json。

本贡献包仅包含依据所列生成机制独立重写的实现、参数配置与核验记录，未附带论文或补充材料全文、
作者原始代码、真实个体数据或模型权重。引用文献不表示取得相关材料的额外再分发授权。
本贡献代码的公开分发许可与适用范围由贡献者与项目维护人确认，目前尚未确认。

### AI 协助与核验

本贡献在整理过程中使用 OpenAI Codex 辅助：从所读版本中提取公式与参数、核对公式与实现的一致性、
整理贡献包结构与逐文件哈希、运行学生参考包检查器（n=128，seed=1729）并重新打包。
AI 未逐页对照正式刊印版与所读版本的差异；参数转录、识别假设与真值推导由贡献者负责核对。
可复查的执行记录见 checks/report.json 与 checks/sample.json；问题及处理记录见 AI_ISSUE_LOG.md。

本地检查通过仅表示所执行的格式、运行与数值核验通过，不等同于具名科学审核、
另一人的独立复现或项目正式接收。

### 未决事项

- 贡献认领与重复机制核查（维护人）
- 所读预印本／补充材料与正式刊印版尚未逐页对照
- 具名科学审核与另一人的独立复现
- 代码与文档的公开分发许可
