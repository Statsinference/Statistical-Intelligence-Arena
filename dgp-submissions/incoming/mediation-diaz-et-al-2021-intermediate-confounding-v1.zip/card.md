# M11 — treatment-induced confounding (Díaz et al., 2021)

**Status:** local candidate; named human scientific review pending.

## 1. Source and source version

Source: https://doi.org/10.1093/biomet/asaa085 ; read arXiv:1912.09936v2 §5 PDF p.12 and Eq. (2) PDF p.5.

## 2. Generating mechanism

DGP: W1~Bern(.6), W2~Bern(.3), W3|W1,W2~Bern(.2+(W1+W2)/3); A|W~Bern(expit(.25ΣW+3W1W2−2)); Z|A,W~Bern(expit(ΣW/3−A−AW3−.25)); M|Z,A,W~Bern(expit(W1+W2+A−Z+AZ−.3AW2)); Y|M,Z,A,W~Bern(expit((A−Z+M−AZ)/(ΣW+1))).

## 3. Causal target and population truth

Target: IIE = E[Y(1,G1)−Y(1,G0)] = 0.030268754049997. The numeric truth was derived by exact enumeration, not quoted from the paper. G_a is drawn from M(a)|W and is independent of Z under outcome treatment 1. This avoids applying an invalid natural-effect interpretation under treatment-induced confounding.

## 4. Changes, checks and limits

Changes: independent Python implementation; uses standard expit despite the preprint's sign inconsistency; includes only one family despite the paper's nuisance-model fitting variations. A [2024 Biometrika correction](https://doi.org/10.1093/biomet/asae009) revises supplementary Theorem 5 and downstream estimator robustness/asymptotic results; it does not state a change to the §5 simulation equations used here. This contribution does not reproduce those corrected estimator claims. See `source_audit.json`.

## 5. Rights and AI assistance

This ZIP contains an independent Python implementation and source references. The paper PDF and author code are not redistributed. Codex assisted with source transcription, derivation, implementation and this card. `collect.py check --run` verifies the local interface and contributor-supplied mathematical checks; it does not confer scientific acceptance. A named human reviewer must compare all equations, parameters, estimand interpretation, and stated changes against the cited original before submission.
