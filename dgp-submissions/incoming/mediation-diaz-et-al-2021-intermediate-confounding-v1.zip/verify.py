"""Alternative summation ordering and mediation-path null checks."""
from copy import deepcopy
import importlib.util
import itertools
import math
from pathlib import Path

def _oracle(c):
    spec=importlib.util.spec_from_file_location("diaz2021_truth",Path(__file__).with_name("truth.py"))
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod.truth(c)["value"]

def _p(v): return 1/(1+math.exp(-v))

def _other(c):
    acc=0.
    for x,y,z in itertools.product((0,1),repeat=3):
        w=(x,y,z); p3=.2+(x+y)/3
        pw=(.6 if x else .4)*(.3 if y else .7)*(p3 if z else 1-p3)
        def mz(a):
            q=_p((x+y+z)/3-a-a*z-.25)
            return sum((q if k else 1-q)*_p(x+y+a-k+a*k-.3*a*y) for k in (0,1))
        dg=mz(1)-mz(0)
        for zz in (0,1):
            qz=_p((x+y+z)/3-1-z-.25)
            yp1=_p((1-zz+1-zz)/(x+y+z+1))
            yp0=_p((1-zz-zz)/(x+y+z+1))
            acc+=pw*(qz if zz else 1-qz)*(yp1-yp0)*dg
    return acc

def verify(config):
    a=_oracle(config); b=_other(config)
    no_am=deepcopy(config); no_am["m_a"]=no_am["m_az"]=no_am["m_aw2"]=0.; no_am["z_a"]=no_am["z_aw3"]=0.
    no_my=deepcopy(config); no_my["y_m"]=0.
    checks=[
       {"name":"independent_state_summation","passed":abs(a-b)<1e-12,"details":f"Main={a:.15g}, separate ordering={b:.15g}, gap={abs(a-b):.3g}"},
       {"name":"zero_exposure_to_mediator_path","passed":abs(_oracle(no_am))<1e-14,"details":"Removing A->Z and A->M paths zeros IIE."},
       {"name":"zero_mediator_to_outcome_path","passed":abs(_oracle(no_my))<1e-14,"details":"Removing M->Y path zeros IIE."},
       {"name":"section_5_coefficients","passed":config["p_w1"]==.6 and config["p_w2"]==.3 and config["treatment_w1w2"]==3 and config["m_aw2"]==-.3,"details":"Key constants checked against Section 5 displayed DGP."}
    ]
    return {"passed":all(q["passed"] for q in checks),"checks":checks,"shared_components":"Both enumerations use Section 5 DGP, but have separate probability calculations and different summation order; scientific review remains pending."}
