Status: candidate for human scientific review. The local checker verifies format and code behavior only.
