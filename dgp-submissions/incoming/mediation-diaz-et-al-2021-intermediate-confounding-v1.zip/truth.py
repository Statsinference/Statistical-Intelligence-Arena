"""Exact interventional indirect effect by discrete state summation."""
import itertools
import math

def sigmoid(v): return .5*(1+math.tanh(v/2))

def baseline(config,w):
    w1,w2,w3=w
    p3=config["p_w3_intercept"]+config["p_w3_slope"]*(w1+w2)
    return (config["p_w1"] if w1 else 1-config["p_w1"])*(config["p_w2"] if w2 else 1-config["p_w2"])*(p3 if w3 else 1-p3)

def pz(c,a,w):
    return sigmoid(c["z_intercept"]+c["z_w_sum"]*sum(w)+c["z_a"]*a+c["z_aw3"]*a*w[2])

def pm(c,a,z,w):
    return sigmoid(c["m_w1"]*w[0]+c["m_w2"]*w[1]+c["m_a"]*a+c["m_z"]*z+c["m_az"]*a*z+c["m_aw2"]*a*w[1])

def py(c,a,z,m,w):
    return sigmoid((c["y_a"]*a+c["y_z"]*z+c["y_m"]*m+c["y_az"]*a*z)/(sum(w)+c["y_denominator_intercept"]))

def theta(c, outcome_a, mediator_a):
    total=0.
    for w in itertools.product((0,1),repeat=3):
        qg=pz(c,mediator_a,w)
        gm=(1-qg)*pm(c,mediator_a,0,w)+qg*pm(c,mediator_a,1,w)
        qy=pz(c,outcome_a,w)
        ey=0.
        for z in (0,1):
            yz=(1-gm)*py(c,outcome_a,z,0,w)+gm*py(c,outcome_a,z,1,w)
            ey+=(qy if z else 1-qy)*yz
        total+=baseline(c,w)*ey
    return total

def truth(config):
    value=theta(config,1,1)-theta(config,1,0)
    return {"value":value,"estimated_error":1e-14,"method":"Exact enumeration of 8 W, 2 Z and 2 M states for each cross-intervention; rounding bound only.","target":"IIE = E[Y(1,G1)-Y(1,G0)]"}
