"""Scalar conditional CDF; no sample or fitted estimator is used."""
import math
import mpmath as mp


def _evaluate(config, dps):
    ctx = mp.mp.clone()
    ctx.dps = dps
    number = lambda key: ctx.mpf(str(config[key]))
    x, y = number('query_x'), number('cdf_threshold')
    if not (ctx.isfinite(x) and ctx.isfinite(y) and number('x_min') < x < number('x_max')):
        raise ValueError('Finite query strictly inside covariate support required')
    a = x ** number('shape_power')
    b = min(max(x, number('scale_min')), number('scale_max'))
    if not (a > 0 and b > 0):
        raise ValueError('Positive shape and scale required')
    shift = ctx.mpf(0)
    if config['shift_threshold'] is not None and x >= number('shift_threshold'):
        shift = number('shift_size')
    z = (y - shift) / b
    return ctx.mpf(0) if z <= 0 else ctx.gammainc(a, 0, z, regularized=True)


def truth(config):
    low, high = _evaluate(config, 40), _evaluate(config, 70)
    value = float(high)
    ctx = mp.mp.clone()
    ctx.dps = 80
    error = 0.0 if high == 0 else float(abs(ctx.mpf(high) - ctx.mpf(low))
            + abs(ctx.mpf(high) - ctx.mpf(value))) + 4 * math.ulp(value)
    return {'value': value, 'estimated_error': error,
            'target': f"P(Y <= {config['cdf_threshold']} | X = {config['query_x']})",
            'method': 'Regularized lower incomplete Gamma at 40/70 decimal digits; exact support branch',
            'high_precision_value': str(high),
            'error_interpretation': 'Precision refinement plus binary64 conversion error and 4 ulps; numerical diagnostic, not a certified uniform bound. Both precision runs share mpmath.'}
