"""Independent density quadrature, analytic special cases and generator audit."""
from copy import deepcopy
import importlib.util
import math
from pathlib import Path
import random
import warnings
from unittest.mock import patch
import numpy as np
from scipy.integrate import quad, IntegrationWarning


def _module(name):
    spec = importlib.util.spec_from_file_location('qdi_audit_' + name,
                                                Path(__file__).with_name(name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _integral(config, x, y):
    # Reconstruct source constants independently; import no oracle formula helper.
    shift = {'smooth_gamma': 0.0,
             'discontinuous_gamma': 10.0 if x >= 5 else 0.0,
             'non_isotonic_gamma': -2.0 if x >= 7 else 0.0}[config['scenario']]
    z = (y - shift) / (1.0 if x < 1 else (6.0 if x > 6 else x))
    if z <= 0:
        return 0.0, 0.0
    a = math.sqrt(x)
    # t=z*u^(1/a) removes a possible density singularity at t=0.
    factor = math.exp(a * math.log(z) - math.lgamma(a + 1))
    with warnings.catch_warnings():
        warnings.simplefilter('error', IntegrationWarning)
        return quad(lambda u: factor * math.exp(-z * u ** (1 / a)),
                    0, 1, epsabs=2e-13, epsrel=2e-13, limit=250)


def verify(config):
    oracle, gen = _module('truth'), _module('generator')
    checks = []
    def add(name, passed, details):
        checks.append({'name': name, 'passed': bool(passed), 'details': details})
    threshold, shift, eq = {'smooth_gamma': (None, 0.0, '23'),
        'discontinuous_gamma': (5.0, 10.0, '24'),
        'non_isotonic_gamma': (7.0, -2.0, '25')}[config['scenario']]
    fixture = {'scenario': config['scenario'], 'source_equation': eq,
        'x_min': 0.0, 'x_max': 10.0, 'shape_power': 0.5, 'scale_min': 1.0,
        'scale_max': 6.0, 'shift_threshold': threshold, 'shift_size': shift,
        'query_x': 5.5, 'cdf_threshold': 10.0}
    add('source_parameters_and_query', config == fixture,
        'Source equations (23)-(25); fixed query is declared adaptation.')
    ref = oracle.truth(config)
    independent, err = _integral(config, 5.5, 10.0)
    difference = abs(ref['value'] - independent)
    add('independent_density_integral', difference <= 1e-11 and err <= 1e-11,
        {'oracle': ref['value'], 'quad': independent, 'difference': difference,
         'quad_error_estimate': err, 'absolute_tolerance': 1e-11})
    add('oracle_precision_refinement', ref['estimated_error'] <= 1e-12,
        {'estimated_error': ref['estimated_error'], 'absolute_tolerance': 1e-12})
    xs = [0.25, 1., 4., 4.999999, 5., 5.000001, 5.5, 6., 6.999999, 7., 7.000001, 9.]
    max_difference = max_error = 0.0
    for x in xs:
        for y in (-2., 0., 10., 25.):
            c = {**config, 'query_x': x, 'cdf_threshold': y}
            v, e = _integral(c, x, y)
            max_difference = max(max_difference, abs(oracle.truth(c)['value'] - v))
            max_error = max(max_error, e)
    add('boundary_grid_integrals', max_difference <= 1e-11 and max_error <= 1e-11,
        {'queries': 48, 'max_difference': max_difference, 'max_quad_error': max_error,
         'scope': 'Pointwise numerical fixtures; not new estimands or confidence bands'})
    special_errors = []
    for x, k, b in ((1., 1, 1.), (4., 2, 4.), (9., 3, 6.)):
        d = (10. if x >= 5 else 0.) if eq == '24' else (
            (-2. if x >= 7 else 0.) if eq == '25' else 0.)
        z = 1.25
        analytic = 1 - math.exp(-z) * sum(z ** j / math.factorial(j) for j in range(k))
        c = {**config, 'query_x': x, 'cdf_threshold': d + b * z}
        special_errors.append(abs(oracle.truth(c)['value'] - analytic))
        for y in (d, d - 1):
            special_errors.append(abs(oracle.truth({**c, 'cdf_threshold': y})['value']))
    add('exponential_erlang_support', max(special_errors) <= 1e-12,
        {'max_difference': max(special_errors), 'shapes': [1, 2, 3],
         'formula': '1-exp(-z)*sum(z^j/j!, j=0..k-1); zero at/below shift'})

    class ReplayRNG:
        def __init__(self):
            self.calls = []
        def uniform(self, lo, hi, size):
            self.calls.append((lo, hi, size))
            return np.array(xs)
        def gamma(self, shape, scale):
            self.shape, self.scale = shape.copy(), scale.copy()
            return np.full(len(xs), 3.)
    fake = ReplayRNG()
    with patch.object(gen.np.random, 'default_rng', return_value=fake):
        observed = gen.generate(config, len(xs), 1729)
    ey = [3 + (shift if threshold is not None and x >= threshold else 0) for x in xs]
    eb = [1. if x < 1 else (6. if x > 6 else x) for x in xs]
    add('generator_equations_inclusive_boundaries',
        observed == {'X': xs, 'Y': ey} and fake.calls == [(0., 10., len(xs))]
        and np.allclose(fake.shape, [math.sqrt(x) for x in xs], rtol=0, atol=1e-14)
        and np.array_equal(fake.scale, eb),
        'Controlled RNG audits uniform bounds, shape/scale arguments, clipping at 1/6, and >= shifts at 5/7. Does not test NumPy Gamma sampler accuracy.')

    class EndpointRNG:
        """Force the exact-zero endpoint, a tiny positive X, and zero Gamma outputs."""
        def __init__(self):
            self.calls = []
        def uniform(self, lo, hi, size):
            self.calls.append((lo, hi, size))
            if len(self.calls) == 1:
                return np.array([0., np.nextafter(0., 1.), 5., 7.])
            if len(self.calls) == 2 and size == 1:
                return np.array([0.25])
            raise AssertionError('Unexpected extra endpoint redraw')
        def gamma(self, shape, scale):
            self.shape, self.scale = shape.copy(), scale.copy()
            return np.zeros(4)
    edge = EndpointRNG()
    with patch.object(gen.np.random, 'default_rng', return_value=edge):
        edge_data = gen.generate(config, 4, 1729)
    edge_x = [0.25, float(np.nextafter(0., 1.)), 5., 7.]
    edge_y = [shift if threshold is not None and x >= threshold else 0. for x in edge_x]
    add('zero_endpoint_and_gamma_underflow_policy',
        edge.calls == [(0., 10., 4), (0., 10., 1)]
        and edge_data == {'X': edge_x, 'Y': edge_y}
        and np.all(edge.shape > 0) and edge.shape[1] < 1e-100,
        'Only exact X=0 is redrawn; smallest positive binary64 X is not clipped; a zero Gamma return is retained then shifted. This tests the policy, not the frequency of real underflow.')
    before, py_before, saved = np.random.get_state(), random.getstate(), deepcopy(config)
    gen.generate(config, 128, 1729)
    after = np.random.get_state()
    add('local_rng_immutable_config', before[0] == after[0]
        and np.array_equal(before[1], after[1]) and before[2:] == after[2:]
        and py_before == random.getstate() and config == saved,
        'Global NumPy/Python RNG states and config unchanged.')
    return {'passed': all(c['passed'] for c in checks), 'checks': checks,
        'shared_components': 'Shared source equations/target, independently restated constants. scipy.integrate.quad plus math.lgamma versus mpmath.gammainc; no shared integration helper. Same AI authored both implementations; no independent-person scientific reproduction. NumPy sampler itself is not independently verified.'}
