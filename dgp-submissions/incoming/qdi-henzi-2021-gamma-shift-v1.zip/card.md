# QDI：Henzi–Ziegel–Gneiting Gamma 与阈值平移机制

贡献 ID：`qdi-henzi-2021-gamma-shift-v1`。任务 family：`quantile_distribution`。
Kind：`synthetic_dgp`，不是 real_data_claim。一个 mechanism family，三个原文 scenario。
状态：**awaiting_scientific_review**，`scientific_acceptance=false`。自动检查不表示科学接收，也不表示已向维护人认领或查重。

## 来源核对与认领范围

Henzi, Alexander; Ziegel, Johanna F.; Gneiting, Tilmann (2021). *Isotonic distributional regression*. Journal of the Royal Statistical Society: Series B (Statistical Methodology), 83(5), 963–993. [DOI](https://doi.org/10.1111/rssb.12450)。JRSS-B 属于本轮四刊范围。

**本轮当前主来源为正式发表版（Version of Record）**，已直接核读用户提供的 31 页 PDF，SHA-256 为 `9b06bc5fe39f69fefa3b0a69913a61575ab32ca9adbb00327a5fd031a806203a`。正式 PDF 第 17、19 页已渲染目视核对；不再把 arXiv 第 19 页用作正式版统一定位。

| 项目 | 正式版精确定位与机制 |
|---|---|
| X 分布 | Section 4，PDF 第 17 页／期刊 979 页，(23) 紧前未编号段落：X~Uniform(0,10) |
| Smooth Gamma | (23)，PDF 第 17 页／979：shape=sqrt(X)，scale=min(max(X,1),6)；不是 rate |
| Discontinuous Gamma | (24)，同页：+10·1{X>=5}，包含等号 |
| Non-isotonic Gamma | (25)，PDF 第 19 页／981：−2·1{X>=7}，包含等号 |
| 夹页说明 | PDF 第 18 页／980 为 Table 1，不能将所有三个公式笼统记为第 19 页 |
| 原实验规模 | PDF 第 19 页／981，以 Under each scenario 开头的页首段落：500 次重复，训练 n=500/1000/2000/4000，测试 m=5000；本轮不复跑 |
| 理论假设 | Section 2.4，Theorem 3，PDF 第 12–13 页／974–975；条件为充分设计密度、反链大小控制、随机单调、一致连续 |
| 补充材料 | `rssb12450-sup-0001-supinfo.pdf`，2021-03-19，11 页；S4 PDF 第 7 页 iid 验证样本、独立测试集及 CRPS/L2 联系；S5/Table S1 PDF 第 8 页方法设置与作者仓库 |
| 历史版本对照 | arXiv:1909.03725v3（2021-09-28），Section 4 PDF 第 19 页 (23)–(25)。所选生成公式、参数、样本规模一致；仅用于差异记录 |
| 编号差异 | 正式 Theorem 3 对应 arXiv／该补充材料的 Theorem 2.3；正式版引用 S4、S5/Table S1，arXiv 使用 Appendix D、E/Table 3。没有声称全文逐字等同 |
| 目标 adaptation | 用户固定 theta_s=P(Y_s<=10\|X=5.5)；原文比较 CRPS/L2，未报告该特定标量查询真值 |

不收集 (26) Poisson，不认领天气真实数据；没有 real_data_claim。同一机制族下保留三个 scenario。

### 作者代码已补齐与实际调查范围

核读官方仓库 [AlexanderHenzi/isodistrreg](https://github.com/AlexanderHenzi/isodistrreg) 的固定 commit `c339ffa652ca24111f183ed833aa7bd5fa43acfd`（2021-03-22）。已读 commit 元数据、完整递归树、两份 R 文件与 DESCRIPTION；每份源码 SHA-256 在 collection.json，且按 Git blob 编码重新算 SHA-1 与 tree 相符。两处只读保存的 R 文件 SHA-256 也一致。作者代码只作来源证据，不装入本贡献 ZIP，也不执行。

- [simulation_example.R](https://github.com/AlexanderHenzi/isodistrreg/blob/c339ffa652ca24111f183ed833aa7bd5fa43acfd/simulation_example.R)：顶层脚本，无具名生成函数。第 57 行训练 X；59–64 行 Gamma 分支；67–68 行训练 jitter；70 行验证 seed；72 行验证 X，74–82 行验证 Gamma 分支；190–204 行 ideal CRPS。
- [simulation_example_functions.R](https://github.com/AlexanderHenzi/isodistrreg/blob/c339ffa652ca24111f183ed833aa7bd5fa43acfd/simulation_example_functions.R)：`probFit` 16–70 行、`probPredict` 74–76 行、IDR predict 79–91 行、subagging 94–125 行及后续拟合预测辅助函数。它不定义另一套 DGP。
- [DESCRIPTION](https://github.com/AlexanderHenzi/isodistrreg/blob/c339ffa652ca24111f183ed833aa7bd5fa43acfd/DESCRIPTION)：包 version 0.1.0，Date 2021-03-16，License GPL (>=2)。

| 发现 | 作者代码 | 本贡献的明确选择 |
|---|---|---|
| NI 边界 | 训练 62–63 行、验证 80–81 行用 X>7；ideal CRPS 200–204 行也用 >7 | 正式 (25) 用 X>=7，故保留 >=。连续设计下二者联合分布几乎处处相同，但精确 X=7 条件版本不同，不能说逐点相同；当前 x=5.5 不受影响 |
| jitter | 67–68 行，在训练响应生成后，分别给训练 X/Y 加独立顺序抽取的 U(−10⁻⁶,10⁻⁶)；验证段未加同样 jitter | 正式方程未包含此额外噪声，本包不加。jitter 后的观察 X 不再严格等于原始生成条件 X，不能称为同一观察律的精确代码复现 |
| 种子 | 55 行 set.seed(n+id)，70 行 set.seed(id) | 种子规则已找到；不再 missing。本包局部 NumPy seed=1729 仅用于小样本检查，不复现 R 随机流 |
| 单次默认设置 | 38 行 type=S；42 行 n=2000；45 行 nValid=5000；52 行 id=250，54 行说明 id=1..500 | 这些是脚本默认值，不能替代正式论文的全 n 网格；本包允许请求 n，本轮 n=128 |
| 拟合行范围 | 167 行拟合参数包含 `[1:2000,]` | 不执行或修改作者估计器，也不声称此快照直接复现全部四个 n 的表格 |

**仍未确认的是“最终发表表格的实验锁定 commit”，不是代码文件或种子缺失。** 已查范围：正式版 Section 4 与 code-availability 段、补充 S4/S5、上述 commit/tree/脚本头、文件历史（2020-11-13 创建、2021-03-22 修改、2026 删除）及当前可读取 release 列表。所查材料未明确将正式发表的最终数值结果唯一绑定到该 commit；未联系作者，也不作全仓库全历史均无此证据的断言。需要最终实验归档或作者／维护人确认才能提升这一表述。这个限制不影响正式方程 DGP 的数学完整性。

## 原始方程与观察表

对每一行 i 独立抽样：

```text
X_i ~ Uniform(0,10)
a(x) = sqrt(x)
b(x) = min(max(x,1),6)
G_i | X_i=x ~ Gamma(shape=a(x), scale=b(x))
d_s(x) = 0                         [smooth_gamma, (23)]
       = 10 * 1{x>=5}               [discontinuous_gamma, (24)]
       = -2 * 1{x>=7}               [non_isotonic_gamma, (25)]
Y_i = G_i + d_s(X_i)
```

Gamma 密度为 g^(a−1) exp(−g/b)/(Gamma(a)b^a)，g>0。
因此 E[Y|x]=a(x)b(x)+d_s(x)，Var(Y|x)=a(x)b(x)^2，不能把 scale 取倒数。

generate(config,n,seed) 接收一个场景参数对象，返回 `{'X': [数值,...], 'Y': [数值,...]}`。没有输出 G、shape、scale、真实 CDF、scenario 标签或其他 oracle 列。schema 中 X 的 0/10 是支持闭包；Y 的 −2 是跨场景共同下界，上界无穷；实际条件下界为 d_s(x)。数值表不含 NaN/null。config 中 smooth 的 null threshold 仅表示没有平移阈值，不是观察数据缺失值。

局部 NumPy default_rng；同 seed 在同一依赖环境可重现。均匀 RNG 恰好生成 0 时只重抽这个端点，因为 Gamma(shape=0) 未定义且理想连续 X 给该点零概率。没有把小正 X 截成 epsilon。极小 shape 的浮点 Gamma 抽样可能下溢为 0，这是数值表示限制，未人为改变响应律或拒绝抽样来修饰它。跨场景同 seed 可产生相同 X 和基础 Gamma 流，属于核验便利；每个 scenario 单独输出自己的 Y，不能把它当作一个有三种响应的观测设计。

## 目标、正则性与适用范围

唯一登记目标为 theta_s=F_s(10|5.5)。不是边际 P(Y<=10)，不是条件均值或分位数，不是未来单个响应的预测区间，也没有干预方向、NIE/NDE 或中介 functional。

X 是连续变量，P(X=5.5)=0；一般条件分布仅几乎处处确定。本 DGP 明确给出条件核，三个场景在 x=5.5 的邻域均连续，因此可用局部连续版本解释从观察分布的点态识别。查询设计密度为 0.1>0，不靠“在样本中恰好找到 X=5.5”求真值。

Smooth 和正向平移的条件分布随机递增；CDF 随 x 非增。负向平移在 x=7 使 CDF 向上跳，违反全局随机单调性，这是原文保留的压力情形。Discontinuous 的“discontinuous”是 x 方向的条件分布跳跃，不是 Y 含原子。所有固定 x>0 的响应连续，阈值点没有点质量。

正式版 Section 2.4/Theorem 3，PDF 第 12–13 页／期刊 974–975 页另要求充分设计密度、反链大小控制、随机单调和 CDF 对 x 的一致连续性。这是 IDR 一致性理论的条件，不是本次 oracle 计算的必要条件。平移场景在阈值处不连续，Non-isotonic 另违反随机单调性；也不主张 sqrt(x) 在 x=0 的退化极限符合整个闭区间的一致连续条件。未经另行论证不把该定理用于本包所有场景。不存在因果混杂假设的需要。

输入总维数=有效维数=1；非高维，无多协变量交互。非线性来自 sqrt(x)、截断 scale 和指标函数。Smooth 是原文命名，b(x) 在 1 和 6 有折点，并非处处可微。响应方差随 x 变化。

在 x=5.5，a=sqrt(5.5)，b=5.5：Smooth 和 Non-isotonic 的 d=0，故相同目标真值。Discontinuous 的 d=10，y=10 恰为支持下端，CDF=0，且此处密度为 0；不满足常见的内点 CDF/正密度近似条件。本次目标对区分三个机制的能力有限，但按用户要求保留。检验用的额外查询点不是新增估计目标或场景。

## 真值推导与精度

令 z=(y−d_s(x))/b(x)，则

```text
F_s(y|x) = 0,                                      z <= 0
         = 1/Gamma(a) * integral_0^z t^(a-1)e^-t dt, z > 0
         = P(a,z).
theta_s  = F_s(10|5.5).
```

truth.py 以 mpmath 独立精度上下文在 40 与 70 位计算 P(a,z)，最终返回 binary64 标量；estimated_error 是两精度差、转为 binary64 的误差加四个 ulp。支持边界分支严格为 0、误差 0。该估计是诊断，不是经过区间算术证明的统一误差界。40/70 位计算共享同一 mpmath 算法，不能仅凭它们一致声称独立验证。collection.json 的绝对真值容差预定为 1e−12；reference_value 留 null，不把本包推导数值充作原文报告的标量真值，真值与核验结果由 checks/report.json 逐场景记录。

verify.py 另行按原文硬编码参数计算：代换 t=z*u^(1/a)，得到

```text
P(a,z) = z^a/Gamma(a+1) * integral_0^1 exp(-z*u^(1/a)) du.
```

采用 scipy.integrate.quad 与 math.lgamma，积分 epsabs=epsrel=2e−13；与 oracle 差及积分误差估计均须 <=1e−11。该实现不调用 truth.py 的 CDF/参数转换代码来获得参考积分；两者共同依据原文方程。每场景还检查 48 个含阈值上下侧、scale 折点、支持边界的数值查询，不是同时置信带验证。

解析特例保持源分布函数、仅改变核验查询：x=1 时 a=1（指数），x=4 时 a=2，x=9 时 a=3（Erlang）。整数形状的 CDF 为 1−exp(−z)sum_{j=0}^{k−1}z^j/j!；核验容差 1e−12，另检查 y=d 与 y<d 时严格为 0。

生成器审计以控制 RNG 检查 generate 实际传入 Uniform/Gamma 的参数、shape/scale、在 x=1/6 截断以及 x=5/7 包含等号的平移和观察列。它不独立检验 NumPy Gamma 随机采样算法。另检查不改变全局 Python/NumPy RNG 或输入 config。collect.py 对全部场景检查 n、有限值、schema、同 seed 重放、异 seed 变化、truth 与 verify 接口。

新增强制端点检查：控制 RNG 先给出精确 X=0、最小正 binary64、5 和 7，只重抽零端点，确认小正 X 未截断；再强制 Gamma 返回 0，确认不拒绝该值而按场景平移。这是对实现策略的确定性检查，不表示测得真实下溢频率。

核验路线由同一个 AI 编写，属于实现自检，不是另一人独立复现或具名科学审阅。没有通过放宽容差、删除场景或手写 PASS 报告处理失败。

## 适配、权利、缺口与移交

三个正式版生成方程、参数、查询 F(10|5.5) 全部保留；适配为用户指定标量查询、统一观察列名 Y、Python RNG 实现、小样本核验。没有为使真值不同而改查询。生成顺序是 X、内部 Gamma 随机响应、确定性场景平移；不存在另加正态误差、处理分配、标签指示或缺失机制。所有行独立，行内 X 与 Y 依赖；各场景是替代观察律，未输出三响应联合数据。无因果假设、interference、网络或面板结构。

正式 PDF 第 1 页明示 ©2021 The Authors、Creative Commons Attribution-NonCommercial-NoDerivs（不从名称猜许可证版本）；作者快照 DESCRIPTION 第 12 行为 GPL (>=2)。此前“来源许可未找到”现已补齐为实际通知；它们不自动等于本贡献新代码的许可证。本贡献没有再分发论文、作者代码或真实数据；贡献许可选择仍由维护人处理。AI 根据方程独立编写 Python，自查不等于具名审核。

干净环境验证：已核对并保存成功安装日志、venv 配置、实际导入路径、pip check 输出及原全场景运行报告。本地 macOS 26.5.1 arm64 / Python 3.13.13 的独立 venv 未启用 system-site-packages 或用户 site；numpy 2.4.4、scipy 1.17.1、mpmath 1.3.0 均从该 venv 内导入，pip check 返回 No broken requirements found。成功安装日志明确记录这三个版本安装完成；原干净检查的八个源文件与 r3 ZIP 逐字节一致，报告与源文件／样本哈希绑定，三个场景各 8 项核验通过。完整证据及哈希已复制到包外 audit/cleancheck-r4，原 cleancheck 目录仅以只读方式使用；本版检查结果由同一干净环境运行 collect.py 产生并随 ZIP 保存。先前访问 pypi.org / files.pythonhosted.org 的 DNS 失败日志与 r3 状态保留为历史，不再作为当前未完成事项，也不曾证明固定版本不存在。本结论仅覆盖上述本地系统、架构、Python 与依赖版本；其他平台未执行验证，不表示跨平台通过、独立人员复现或科学接收。requirements 与数值容差均未改。

| 原缺口／限制 | 当前状态 | 是否影响本次数学机制完整 |
|---|---|---|
| 正式版及页码、公式定位 | 已解决，正式版设主来源；17/979 与 19/981 分开记录 | 不影响；定位已完整 |
| 原文参数、Gamma 尺度、依赖与边界 | 已解决，按生成顺序记录；正式版无缺参 | 不影响；公式完整 |
| 作者代码 commit／文件／行号 | 已解决，固定快照和 blob/hash 已核验 | 不影响 |
| 作者种子与默认样本设置 | 已解决，逐行登记；与本包小样本设定分开 | 不影响 |
| 作者代码与正式公式差异 | 已解决，>7／>=7 和训练 jitter 均披露，选择正式律 | 不影响正式律；不宣称作者脚本精确复现 |
| 正式最终实验锁定 commit | 在上述检索范围仍未找到明确绑定；需最终实验归档或确认 | 不影响选定方程；影响全论文结果复现声明 |
| 精确 X=0 与浮点 Gamma 下溢策略 | 已披露，并新增确定性入口测试 | 数值实现限制；不填造源参数 |
| 干净环境依赖安装 | 已解决：本地 macOS 26.5.1 arm64／Python 3.13.13 成功安装、隔离性、pip check 与运行证据已核实；旧 DNS 失败仅作历史 | 不影响公式；结论仅限已测平台，其他平台未验证 |
| 查询导致零值／相同真值 | 已分析，按用户要求保留 | 不影响定义；限制区分场景能力 |
| 具名科学审核、独立人员复现、科学接收与贡献许可选择 | 待办理，不伪造认领或具名审核 | 不属于生成参数缺口 |

本轮保留旧 ZIP，不对外 submit／上传／创建 PR／发消息。包内仍为八个固定源文件、工具产生的 checks 与 MANIFEST；包外执行报告记录 CRC、逐文件 SHA-256、源文件和 ZIP 一致、报告／样本绑定、依赖与失败记录。状态始终 awaiting_scientific_review / scientific_acceptance=false。
