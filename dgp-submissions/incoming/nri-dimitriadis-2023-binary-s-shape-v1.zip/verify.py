"""Independent analytic and shape checks for the S-shaped NRI target."""
import math


def _ratio(x, s):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    exponent = 1.0 + s
    a = x ** exponent
    b = (1.0 - x) ** exponent
    return a / (a + b)


def _log_odds(x, s):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    z = (1.0 + s) * (math.log(x) - math.log1p(-x))
    if z >= 0.0:
        return 1.0 / (1.0 + math.exp(-z))
    ez = math.exp(z)
    return ez / (1.0 + ez)


def verify(config):
    s = float(config["s"])
    x_star = float(config["x_star"])
    direct = _ratio(x_star, s)
    alternate = _log_odds(x_star, s)
    grid = [i / 100.0 for i in range(101)]
    values = [_ratio(x, s) for x in grid]
    checks = [
        {
            "name": "independent_power_ratio_vs_log_odds",
            "passed": abs(direct - alternate) <= 2e-15,
            "details": f"power-ratio={direct:.17g}; log-odds={alternate:.17g}; difference={abs(direct-alternate):.3g}."
        },
        {
            "name": "conditional_probability_support",
            "passed": all(0.0 <= value <= 1.0 for value in values),
            "details": "The S-shaped probabilities on the checked [0,1] grid stay in [0,1]."
        },
        {
            "name": "source_monotonicity_on_grid",
            "passed": all(values[i] <= values[i + 1] + 1e-15 for i in range(len(values) - 1)),
            "details": "p_s is nondecreasing for every declared s>=0, matching the source band assumption."
        },
        {
            "name": "endpoint_limits",
            "passed": _ratio(0.0, s) == 0.0 and _ratio(1.0, s) == 1.0,
            "details": "The implementation uses the source continuous endpoint limits p_s(0)=0 and p_s(1)=1."
        },
        {
            "name": "midpoint_symmetry_anchor",
            "passed": abs(direct - 0.5) <= 2e-15 and all(abs(_ratio(x, s) + _ratio(1.0 - x, s) - 1.0) <= 2e-14 for x in (0.1, 0.25, 0.4)),
            "details": "At x*=0.5, equal powers give p_s(0.5)=0.5; p_s(x)+p_s(1-x)=1 is the independent symmetry identity."
        }
    ]
    if abs(s) < 1e-15:
        checks.append({
            "name": "s0_diagonal_anchor",
            "passed": max(abs(_ratio(x, s) - x) for x in grid) <= 2e-15,
            "details": "s=0 reduces to p_0(x)=x; this endpoint is retained for source fidelity and deduplicated across other shape families."
        })
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": "The independent route shares the declared S-shaped equation and query, but does not call truth.py; no source replication code or confidence-band computation is included.",
        "scope": "These checks cover the scalar analytic truth and source shape conditions only; they do not establish simultaneous confidence-band coverage."
    }
