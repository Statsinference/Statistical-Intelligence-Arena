"""Analytic scalar NRI truth for the selected S-shaped scenario."""
import math
import sys


def _validate(config):
    if not isinstance(config, dict):
        raise ValueError("config must be a scenario dictionary")
    s = config.get("s")
    x_star = config.get("x_star")
    if isinstance(s, bool) or not isinstance(s, (int, float)) or not math.isfinite(float(s)):
        raise ValueError("s must be finite numeric")
    if not 0.0 <= float(s) <= 1.0:
        raise ValueError("s must lie in the source grid [0,1]")
    if isinstance(x_star, bool) or not isinstance(x_star, (int, float)) or not math.isfinite(float(x_star)):
        raise ValueError("x_star must be finite numeric")
    if abs(float(x_star) - 0.5) > 1e-15:
        raise ValueError("this contribution fixes the NRI query at x_star=0.5")


def _odds_form(x, s):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    exponent = 1.0 + s
    log_odds = exponent * (math.log(x) - math.log1p(-x))
    if log_odds >= 0.0:
        return 1.0 / (1.0 + math.exp(-log_odds))
    odds = math.exp(log_odds)
    return odds / (1.0 + odds)


def truth(config):
    """Return m_s(0.5)=E[Y|X=0.5]=p_s(0.5)=1/2."""
    _validate(config)
    s = float(config["s"])
    x_star = float(config["x_star"])
    exponent = 1.0 + s
    left = x_star ** exponent
    right = (1.0 - x_star) ** exponent
    stable_value = left / (left + right)
    alternate = _odds_form(x_star, s)
    estimated_error = abs(stable_value - alternate) + 2.0 * sys.float_info.epsilon
    return {
        "value": float(stable_value),
        "estimated_error": float(estimated_error),
        "method": "Endpoint-safe power-ratio evaluation x_star**(1+s)/(x_star**(1+s)+(1-x_star)**(1+s)); independently audited by a log-odds form.",
        "error_interpretation": "Floating-point agreement between equivalent analytic evaluations; not a confidence-band or coverage error bound.",
        "target": "m_s(x_star)=E[Y|X=x_star]=p_s(x_star)",
        "query": {"x_star": x_star, "s": s}
    }
