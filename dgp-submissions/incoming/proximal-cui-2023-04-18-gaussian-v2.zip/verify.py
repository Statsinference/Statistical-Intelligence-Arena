import itertools
import numpy as np
from numpy.polynomial.hermite import hermgauss
from numpy.polynomial.legendre import leggauss
from generator import generate, _draw
from truth import truth


def verify(config):
    checks=[]
    def equal(name,observed,expected,tol=1e-10):
        error=float(np.max(np.abs(np.asarray(observed)-np.asarray(expected))))
        checks.append({"name":name,"passed":bool(np.isfinite(error) and error<=tol),"details":{"max_absolute_error":error,"tolerance":float(tol)}})
    def mc(name,values,expected):
        v=np.asarray(values);se=float(v.std(ddof=1)/np.sqrt(v.size))
        equal(name,v.mean(),expected,max(1e-12,6*se))
    c=config
    expected=dict(SOURCE_ANCHOR)
    if 'beta' in expected:expected['beta']=c['beta']
    checks.append({"name":"fixed_source_parameter_anchor","passed":c==expected,"details":"Config matches the fixed parameter transcription. This catches later edits but cannot detect an error in the original transcription."})
    # Independent standardized means: marginal U|X is the natural-A mixture.
    def standardized(order,ba):
        q,wt=hermgauss(order);wt=wt/np.sqrt(np.pi)
        x=.25+np.sqrt(2)*.25*q
        means=np.zeros(2)
        for i,x1 in enumerate(x):
            for j,x2 in enumerate(x):
                xs=x1+x2;s=.25+.25*xs;p=1/(1+np.exp(.125*xs))
                for natural_a,prob in [(0,1-p),(1,p)]:
                    u=s+.25*natural_a+np.sqrt(2)*q
                    ew=.5*s+.5*u
                    for a in [0,1]:
                        ey=2.25+ba*a+.5*xs+u+2*ew
                        means[a]+=wt[i]*wt[j]*prob*np.dot(wt,ey)
        return means
    m8=standardized(8,c['y_a']);m16=standardized(16,c['y_a'])
    equal('standardized_ATE_vs_truth',m16[1]-m16[0],truth(c)['value'])
    equal('quadrature_order_diagnostic',m8,m16)
    zero=standardized(16,0)
    equal('zero_direct_effect_special_case',zero[1]-zero[0],0)
    equal('proxy_conditional_covariance_constraint',.25-.5*.5,0)
    equal('proxy_treatment_invariance_constraint',.125-.5*.25,0)
    errors=[]
    for u,xs,a in itertools.product([-2.,.2,2.],[-1.,.5,2.],[0,1]):
        s=.25+.25*xs;mz=.5*s+.125*a+.5*u
        eq=1+np.exp((2*a-1)*(.25-.5*mz-.125*a+.25*xs)+.5*.5**2*.75)
        propensity=1/(1+np.exp(-(.25*u-.1875*xs-.09375)))
        errors.append(eq*(propensity if a else 1-propensity)-1)
    equal('treatment_bridge_against_Bayes',errors,0)
    d=_draw(c,65536,np.random.default_rng(314159));xs=d['X1']+d['X2'];s=.25+.25*xs
    residual=np.stack([d['Z']-s-.25*d['A'],d['W']-s-.125*d['A'],d['U']-s-.25*d['A']])
    cov=np.asarray([[1,.25,.5],[.25,1,.5],[.5,.5,1]])
    se=np.sqrt((cov**2+np.outer(np.diag(cov),np.diag(cov)))/(65536-1))
    equal('generated_conditional_covariance_zscores',(np.cov(residual)-cov)/se,0,6)
    mc('outcome_bridge_residual_mean',d['Y']-(2+2*d['A']+4*d['W']+.25*xs),0)
    mc('outcome_noise_mean',d['Y']-(2.25+2*d['A']+.5*xs+d['U']+2*d['W']),0)
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'shared_components':'Every check uses the same transcribed source model. The structural, enumeration and quadrature calculations run separately from the generator; sample-moment tests call it. Independent review of the source transcription is still required.',
            'limits':'Finite grids and simulation checks cannot establish identification, behavior in the tails, or estimator coverage. Tolerances were set in advance. Null-path tests are diagnostic cases, not new scenarios.'}

SOURCE_ANCHOR = {'x_mean': [0.25, 0.25], 'x_cov': [[0.0625, 0], [0, 0.0625]], 'a_logit': [0, -0.125, -0.125], 'zwu_intercepts': [0.25, 0.25, 0.25], 'zwu_a': [0.25, 0.125, 0.25], 'zwu_x': [[0.25, 0.25], [0.25, 0.25], [0.25, 0.25]], 'zwu_cov': [[1, 0.25, 0.5], [0.25, 1, 0.5], [0.5, 0.5, 1]], 'y_intercept': 2, 'y_a': 2, 'y_x': [0.25, 0.25], 'bridge_w': 4, 'omega': 2, 'y_sd': 0.25}
