def truth(config):
    return {"value":float(config['y_a']),"estimated_error":0.,"method":"Analytic bridge contrast E[h(W,1,X)-h(W,0,X)]=b_a","target":"population ATE","error_interpretation":"Zero integration/MC approximation error for the primary analytic target; not a scientific or roundoff guarantee."}
