"""Independent midpoint integration of all four branches."""
import math
def verify(config):
    def m(x):
        if x < -0.5: return (x+2)**2/2
        if x < 0: return x/2+0.875
        if x < 0.5: return -5*(x-0.2)**2+1.075
        return x+0.125
    k=100000
    integral=sum(m(-1+(i+0.5)*2/k)/k for i in range(k))
    checks=[
      {'name':'source_scenario','passed':config['mode']=='piecewise_mar','details':'JRSS-B 2025, Section 6.2.'},
      {'name':'independent_quadrature','passed':abs(integral-27/32)<1e-8,'details':f'Numerical mean={integral:.12g}.'},
      {'name':'observation_probability','passed':0.5*(0.1+0.9)==0.5,'details':'P(R=1) is 0.5 under symmetric Uniform X.'},
      {'name':'noise_scale','passed':all(0.1-1e-12<=0.2-0.1*math.cos(2*math.pi*x)<=0.3+1e-12 for x in [-1,-0.5,0,0.5,1]),'details':'Paper specifies squared conditional standard deviation as variance.'},
      {'name':'finite_mask_value','passed':math.isfinite(float(config['missing_outcome_placeholder'])),'details':'Missing outcome is masked.'}
    ]
    return {'passed':all(c['passed'] for c in checks),'checks':checks}
