"""Exact piecewise-polynomial expectation."""
def truth(config):
    if config['mode']!='piecewise_mar':
        raise ValueError('invalid scenario')
    return {'value':27/32,'estimated_error':0.0,'method':'Integrate the four polynomial branches of m(x) against Uniform[-1,1]','target':'Full-data E(Y)'}
