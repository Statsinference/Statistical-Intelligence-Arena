# Piecewise response mean with discontinuous MAR propensity

Yiu, S., Fong, E., Holmes, C. and Rousseau, J. (2025). Semiparametric posterior corrections. Journal of the Royal Statistical Society: Series B 87(4), 1025-1054. DOI: 10.1093/jrsssb/qkaf005.

Yiu et al. (2025), JRSS-B §6.2, journal p. 1045 / main PDF p. 21; Table 2 on p. 1046 / PDF p. 22 names outcome-mean estimation. The section explicitly says the DGP comes from Kennedy (2023), whose piecewise m(x) originated in Györfi et al. (2002). Preserve this provenance in duplicate review. E(Y)=27/32 follows by integration of the source’s four branches; it is derived here, not numerically printed in the source. Conditional variance is [0.2-0.1cos(2πx)]². X is always visible; R=1 indicates observed Y; P(R=1|X<0)=0.1 and P(R=1|X>0)=0.9. One call returns one iid sample. R=0 uses a zero placeholder, not an observed value. Original article PDF is kept outside this ZIP. Machine checks do not constitute scientific review.
