# Standard NIE1 adaptation: cheng

This record is version 1.0.0 of a new standardized **complete-data NIE1** adaptation.
Its target is `E[Y(1,M(1))-Y(1,M(0))]` over the fixed-SEM superpopulation,
jointly moving all mediator coordinates. It is not a claim that the source paper
used this adapted law or target. The original contribution remains unchanged.

Source: Cheng, C. and Li, F. (2025). Identification and multiply robust estimation in causal mediation analysis across principal strata. Journal of the Royal Statistical Society Series B: Statistical Methodology 88(1), 1-22. DOI: 10.1093/jrsssb/qkaf037.

Original registry record(s): mediation-cheng-li-2025-principal-strata-kang-schafer-v1.
Frozen original commit: `8182caf7185845a31a2122e032811bb2254d6342`.

## Changes and truth

Set mediator_event_coefficient and outcome_event_coefficient to zero and remove D structurally; map source Z to A. The former principal-stratum/direct-effect target is not reused.

Original registered target: ITT-NDE = E[Y_{1 M_0}] - E[Y_{0 M_0}].
Its full definition is preserved verbatim in source_audit.json and the vendor record.
New truth computation: **gauss_hermite_80** — One-dimensional Gaussian quadrature of the logistic-normal mediator probability contrast, multiplied by the outcome mediator coefficient.
Native numerical reference: `0.30114731040193965`.

Use the complete ZIP. `generator.py` is a thin entry point importing the one
canonical `nie_standard_v1` package, not a self-contained replacement for it.
Call `generate(config,n,seed)` for observed-only column arrays, or `sample_task`
for separate observed/schema/evaluator fields. Truth computation is off by default.
Parameters in config.json are fixed for independent row replicates. The optional
randomized mechanism prior is separate and must be frozen before benchmark use.

See the top-level README.md and SCIENTIFIC_SPEC.md for the exact executable
equations, error independence, role/type schema, numerical-truth scope and
task-template bridge. No accepted leaderboard result is asserted by this record.
