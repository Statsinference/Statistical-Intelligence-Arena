# Standard NIE1 adaptation: jones correlated

This record is version 1.0.0 of a new standardized **complete-data NIE1** adaptation.
Its target is `E[Y(1,M(1))-Y(1,M(0))]` over the fixed-SEM superpopulation,
jointly moving all mediator coordinates. It is not a claim that the source paper
used this adapted law or target. The original contribution remains unchanged.

Source: Jones, J., Ertefaie, A. and Strawderman, R. L. (2025). Causal mediation analysis: selection with asymptotically valid inference. Journal of the Royal Statistical Society: Series B 87(3), 678–700. DOI: 10.1093/jrsssb/qkae109.

Original registry record(s): mediation-jones-et-al-2025-correlated-sparse-v1.
Frozen original commit: `8182caf7185845a31a2122e032811bb2254d6342`.

## Changes and truth

Retain randomized A, vector mediator and unit-diagonal two-block Gaussian error covariance. Factor sampling is distributionally equivalent for 0<=rho_bridge<=rho_within<1. The source code does not use mediator_error_sd, and neither does this adaptation.

Original registered target: NIE_1.
Its full definition is preserved verbatim in source_audit.json and the vendor record.
New truth computation: **analytic** — Number of shared active A-M and M-Y indices times a_to_m_coefficient * m_to_y_coefficient.
Native numerical reference: `2`.

Use the complete ZIP. `generator.py` is a thin entry point importing the one
canonical `nie_standard_v1` package, not a self-contained replacement for it.
Call `generate(config,n,seed)` for observed-only column arrays, or `sample_task`
for separate observed/schema/evaluator fields. Truth computation is off by default.
Parameters in config.json are fixed for independent row replicates. The optional
randomized mechanism prior is separate and must be frozen before benchmark use.

See the top-level README.md and SCIENTIFIC_SPEC.md for the exact executable
equations, error independence, role/type schema, numerical-truth scope and
task-template bridge. No accepted leaderboard result is asserted by this record.
