# Standard NIE1 adaptation: shan

This record is version 1.0.0 of a new standardized **complete-data NIE1** adaptation.
Its target is `E[Y(1,M(1))-Y(1,M(0))]` over the fixed-SEM superpopulation,
jointly moving all mediator coordinates. It is not a claim that the source paper
used this adapted law or target. The original contribution remains unchanged.

Source: Shan, J., Li, W. and Ai, C. (2026). Efficient Nonparametric Inference for Mediation Analysis with Nonignorable Missing Confounders. Journal of the American Statistical Association, published online 25 June 2026, pages 1-12. DOI: 10.1080/01621459.2026.2654218.

Original registry record(s): mediation-shan-li-ai-2026-missing-confounders-aux-shadow-v1, mediation-shan-li-ai-2026-missing-confounders-internal-shadow-v1.
Frozen original commit: `8182caf7185845a31a2122e032811bb2254d6342`.

## Changes and truth

Export complete X1/X2/X3, M and Y before observation masks. Omit shadows/masks. Merge the auxiliary/internal-shadow records only in this new full-data namespace; both original records remain untouched.

Original registered target: MF theta = E[Y(1, M(0))].
Its full definition is preserved verbatim in source_audit.json and the vendor record.
New truth computation: **analytic** — (outcome_mediator + outcome_treatment_mediator) * (mediator_treatment + mediator_treatment_x1_squared / 3)
Native numerical reference: `1`.

Use the complete ZIP. `generator.py` is a thin entry point importing the one
canonical `nie_standard_v1` package, not a self-contained replacement for it.
Call `generate(config,n,seed)` for observed-only column arrays, or `sample_task`
for separate observed/schema/evaluator fields. Truth computation is off by default.
Parameters in config.json are fixed for independent row replicates. The optional
randomized mechanism prior is separate and must be frozen before benchmark use.

See the top-level README.md and SCIENTIFIC_SPEC.md for the exact executable
equations, error independence, role/type schema, numerical-truth scope and
task-template bridge. No accepted leaderboard result is asserted by this record.
