# Standard NIE1 adaptation: xia binary

This record is version 1.0.0 of a new standardized **complete-data NIE1** adaptation.
Its target is `E[Y(1,M(1))-Y(1,M(0))]` over the fixed-SEM superpopulation,
jointly moving all mediator coordinates. It is not a claim that the source paper
used this adapted law or target. The original contribution remains unchanged.

Source: Xia, F. and Chan, K. C. G. (2023). Identification, Semiparametric Efficiency, and Quadruply Robust Estimation in Mediation Analysis with Treatment-Induced Confounding. Journal of the American Statistical Association 118(542), 1272–1281. DOI: 10.1080/01621459.2021.1990765.

Original registry record(s): mediation-xia-chan-2023-binary-plackett-v1.
Frozen original commit: `8182caf7185845a31a2122e032811bb2254d6342`.

## Changes and truth

Remove C and its effects in Y structurally: y_c=y_ac=0. Preserve the original marginal M law and A-M interaction. Recompute NIE1 rather than reuse source NDE truth.

Original registered target: NDE.
Its full definition is preserved verbatim in source_audit.json and the vendor record.
New truth computation: **gauss_hermite_80** — 80-node Gaussian quadrature of the mediator probability contrast times (y_m+y_am).
Native numerical reference: `-0.36488213957756865`.

Use the complete ZIP. `generator.py` is a thin entry point importing the one
canonical `nie_standard_v1` package, not a self-contained replacement for it.
Call `generate(config,n,seed)` for observed-only column arrays, or `sample_task`
for separate observed/schema/evaluator fields. Truth computation is off by default.
Parameters in config.json are fixed for independent row replicates. The optional
randomized mechanism prior is separate and must be frozen before benchmark use.

See the top-level README.md and SCIENTIFIC_SPEC.md for the exact executable
equations, error independence, role/type schema, numerical-truth scope and
task-template bridge. No accepted leaderboard result is asserted by this record.
