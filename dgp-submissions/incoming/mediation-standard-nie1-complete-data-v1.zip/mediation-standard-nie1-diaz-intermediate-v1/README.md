# Standard NIE1 adaptation: diaz intermediate

This record is version 1.0.0 of a new standardized **complete-data NIE1** adaptation.
Its target is `E[Y(1,M(1))-Y(1,M(0))]` over the fixed-SEM superpopulation,
jointly moving all mediator coordinates. It is not a claim that the source paper
used this adapted law or target. The original contribution remains unchanged.

Source: Díaz, I., Hejazi, N. S., Rudolph, K. E. and van der Laan, M. J. (2021). Non-parametric efficient causal mediation with intermediate confounders. Biometrika 108(3), 627–641. DOI: 10.1093/biomet/asaa085.

Original registry record(s): mediation-diaz-et-al-2021-intermediate-confounding-v1.
Frozen original commit: `8182caf7185845a31a2122e032811bb2254d6342`.

## Changes and truth

Remove Z structurally: set m_z, m_az, y_z and y_az to zero. Recompute natural NIE1, replacing the source interventional indirect-effect target.

Original registered target: IIE_1.
Its full definition is preserved verbatim in source_audit.json and the vendor record.
New truth computation: **exact_finite_enumeration** — Enumerate all eight baseline states; multiply the mediator probability contrast by the treatment-1 outcome-mean contrast between mediator values.
Native numerical reference: `0.016868281659205248`.

Use the complete ZIP. `generator.py` is a thin entry point importing the one
canonical `nie_standard_v1` package, not a self-contained replacement for it.
Call `generate(config,n,seed)` for observed-only column arrays, or `sample_task`
for separate observed/schema/evaluator fields. Truth computation is off by default.
Parameters in config.json are fixed for independent row replicates. The optional
randomized mechanism prior is separate and must be frozen before benchmark use.

See the top-level README.md and SCIENTIFIC_SPEC.md for the exact executable
equations, error independence, role/type schema, numerical-truth scope and
task-template bridge. No accepted leaderboard result is asserted by this record.
