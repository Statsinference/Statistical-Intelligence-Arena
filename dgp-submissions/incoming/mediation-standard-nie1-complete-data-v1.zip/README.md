# Standard NIE1 mediation generator collection — version 1.0.0

This additive collection makes fourteen complete-data presets share one target:
**the superpopulation natural indirect effect at treatment 1**,
`E[Y(1,M(1))-Y(1,M(0))]`. Scalar and vector mediators may be continuous or discrete;
the outcome can be continuous or discrete. Treatment A has levels 0/1 for this
contrast. The entire mediator vector moves jointly.

Fifteen frozen registry records produce fourteen unique complete-data presets:
the two Shan observation schemes merge after removing observation masks/shadows.
Zhou's ordered and Luo's dynamic designs are excluded. All original contribution
ZIPs, Python generators, Markdown and original estimands remain separate.
These are disclosed adaptations, not claims to reproduce each source paper.

## Quick start

Extract the **whole ZIP**, open that directory, and install NumPy:

```sh
python -m pip install -r requirements.txt
python -c "from nie_standard_v1 import verify_source; print(verify_source())"
python -m nie_standard_v1.test_api
python -m nie_standard_v1.test_generators
```

```python
from nie_standard_v1 import available_sources, sample_mechanism, sample_task, truth

config = sample_mechanism('jones_lnl', mechanism_seed=51, randomize=False)
first = sample_task('jones_lnl', n=200, observation_seed=1001, config=config)
second = sample_task('jones_lnl', n=200, observation_seed=1002, config=config)
observed = first['observed']  # only x, a, m, y arrays
schema = first['schema']     # roles/types and the public target convention
reference = truth('jones_lnl', config)  # evaluator only; never a model feature
```

`x` has shape [n,p] (p=0 is valid), `a` and `y` shape [n], `m` shape [n,q].
All arrays are float32. `schema` names roles/types; Y is always the outcome,
not a treatment-classification label. The causal treatment label is A.
`metadata` contains source/configuration/seeds/provenance and is evaluator-only.
`truth` is None unless `compute_truth=True`; no truth is computed on the default
factual-data path. Pass observed arrays and permitted schema to a method, not
the entire task dictionary. Native configurations are the default.

The mechanism seed draws parameters only when `randomize=True`; the observation
seed draws independent rows at fixed parameters. Arbitrarily large nonnegative
integer seeds are accepted. A different observation seed is **not** a different
structural mechanism. The original optional randomized prior and its named
source split are retained in generators.py as historical implementation; this
standard does not prescribe that split or establish OOD exposure for any model.

Each record's thin `generator.py` exposes the existing Arena convention
`generate(config,n,seed)` and returns observed column arrays `X1,...,A,M1,...,Y`.
It imports the shared package, so a separately downloaded wrapper needs the
complete ZIP. `sample_task` keeps metadata/truth apart for evaluator use.

## Scientific scope and provenance

`registry.json` maps each new record to its original target and adaptation.
Treatment-induced confounder effects are removed in the structural law, not
merely hidden. Missing-data designs export complete variables before masking.
Source truth labels for NDE, mediation functionals, interventional or path-specific
effects are not relabeled as NIE. Truth is recomputed for the adapted SEM.

Truth uses algebra, finite enumeration or 80-node Gauss-Hermite quadrature.
The numerical quadrature values are deterministic references, not exact analytic
truths or certified error bounds for every arbitrary parameter override.
The tests include independent Monte Carlo integration, 80/160-node resolution
checks, null/cancelling paths, source-distribution agreement and covariance tests.
Freeze parameter domains and certify numerical tolerances for each benchmark.

Read SCIENTIFIC_SPEC.md for the exact executable structural equations and
identification/noise conditions. Upstream source commit:
`8182caf7185845a31a2122e032811bb2254d6342`.
The canonical generator source is byte-identical to the implemented version,
SHA256 `443e04663970594a8ec2932dc0ee9718c10cc501314d133686dfd0e9acf1baa8`.
Original source generator bytes are retained under nie_standard_v1/vendor and
checked by their Git blob identities. The Apache-2.0 license and notice remain.
No trained weights, private test tables, oracle bank labels or authentication
material are included.

## Arena integration status

These ZIP records follow the native catalog schema and generate normal Markdown
and generator links after intake. The current Arena task/leaderboard runner is
a scaffold; catalog inclusion is not task acceptance, scientific signoff or a
ranking. `task_bridge.json` maps observed roles and NIE1 to protocol 0.3 /
output schema 0.2.0 without overwriting starter/task.yaml or claiming a run.
An actual benchmark still needs frozen fixed-DGP populations, n/replicates,
seed ledgers, paired methods, budgets, failure/coverage gates and independent review.
