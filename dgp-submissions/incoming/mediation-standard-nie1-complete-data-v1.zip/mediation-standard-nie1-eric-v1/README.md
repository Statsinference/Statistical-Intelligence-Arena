# Standard NIE1 adaptation: eric

This record is version 1.0.0 of a new standardized **complete-data NIE1** adaptation.
Its target is `E[Y(1,M(1))-Y(1,M(0))]` over the fixed-SEM superpopulation,
jointly moving all mediator coordinates. It is not a claim that the source paper
used this adapted law or target. The original contribution remains unchanged.

Source: Tchetgen Tchetgen, E. J. and Shpitser, I. (2012). Semiparametric theory for causal mediation analysis: efficiency bounds, multiple robustness and sensitivity analysis. The Annals of Statistics 40(3), 1816–1845. DOI: 10.1214/12-AOS990.

Original registry record(s): nie-eric-original-v1.
Frozen original commit: `8182caf7185845a31a2122e032811bb2254d6342`.

## Changes and truth

Retain the scalar discrete-mediator SEM and superpopulation target; do not replace population X integration by the realized empirical-X average.

Original registered target: theta_NIE = theta_11 - theta_10.
Its full definition is preserved verbatim in source_audit.json and the vendor record.
New truth computation: **finite_enumeration_and_gauss_hermite_80** — Enumerate the four discrete baseline states and integrate the conditional Gaussian baseline by 80-node Gauss-Hermite quadrature.
Native numerical reference: `0.23661990123343668`.

Use the complete ZIP. `generator.py` is a thin entry point importing the one
canonical `nie_standard_v1` package, not a self-contained replacement for it.
Call `generate(config,n,seed)` for observed-only column arrays, or `sample_task`
for separate observed/schema/evaluator fields. Truth computation is off by default.
Parameters in config.json are fixed for independent row replicates. The optional
randomized mechanism prior is separate and must be frozen before benchmark use.

See the top-level README.md and SCIENTIFIC_SPEC.md for the exact executable
equations, error independence, role/type schema, numerical-truth scope and
task-template bridge. No accepted leaderboard result is asserted by this record.
