# Scientific contract: standardized full-data NIE1

The target is a fixed-configuration superpopulation parameter, not an average
over the sampled table's baseline covariates and not a distribution over
randomly drawn configurations. Treatment is set to 1 in both outcome terms:
psi=E[Y(1,M(1))-Y(1,M(0))]. Multiple mediators are intervened on jointly.

Rows are iid conditional on the structural configuration. Random draws for
baseline generation, treatment assignment, mediator noise and outcome noise
are independent unless an explicitly retained mediator covariance or baseline
dependence is stated in the source branch below. Exogenous noise is not an
extra shared mediator-outcome confounder. The marginal mediator law is retained
when a removed variable no longer affects Y. Complete observations are exported
before any missingness mechanism. The returned float32 arrays represent the
specified underlying SEM subject to numeric rounding.

For identification from observed data, a sufficient assumption set includes
consistency, treatment exchangeability, mediator-outcome exchangeability,
appropriate cross-world conditions and treatment/mediator support. The simple
mediation formula excludes treatment-induced mediator-outcome confounders;
randomized treatment alone is insufficient. A numerical sample does not test
these assumptions. Causal misspecification is a different benchmark contract.

## Exact executable equations

The blocks below are copied verbatim from the unchanged canonical `_draw`
branches. `c` is the fully declared fixed configuration, `r` is NumPy's
observation-seeded generator, `n` the row count, `expit` the logistic function.
The helper `_dh_probs`, shared source aliases and truth implementations are
defined once in nie_standard_v1/generators.py; no private package is imported.
Each config.json records native coefficient values. The structural-removal
routine also enforces removed paths under explicit configuration overrides.

## cheng

Set mediator_event_coefficient and outcome_event_coefficient to zero and remove D structurally; map source Z to A. The former principal-stratum/direct-effect target is not reused.

```python
x = c["covariate_sd"]*r.standard_normal((n, 4))
a = r.binomial(1, expit(x@c["treatment_coefficients"]))
m = r.binomial(1, expit(c["mediator_intercept"]+c["mediator_treatment_coefficient"]*a+x@c["mediator_coefficients"]))[:, None]
y = c["outcome_intercept"]+c["outcome_treatment_coefficient"]*a+c["outcome_mediator_coefficient"]*m[:, 0]+x@c["outcome_coefficients"]+c["outcome_noise_sd"]*r.standard_normal(n)
return x,a,m,y,["binary"],["continuous"]*4,"continuous"
```

Truth class: gauss_hermite_80. One-dimensional Gaussian quadrature of the logistic-normal mediator probability contrast, multiplied by the outcome mediator coefficient.

Original registered target (retained separately): ITT-NDE = E[Y_{1 M_0}] - E[Y_{0 M_0}].

## diaz_hejazi

Retain the three-dimensional joint mediator and baseline law. All mediator coordinates are intervened on jointly; no scalar-mediator substitution.

```python
if s == "diaz_hejazi":
            x = r.binomial(1, c["baseline_probabilities"], (n,3))
            a = r.binomial(1, x.sum(1)/c["treatment_denominator"]+c["treatment_intercept"])
            m = r.binomial(1, _dh_probs(c["mediation_path_scale"]*a, x))
            y = m@c["outcome_mediator_coefficients"]+c["outcome_treatment_coefficient"]*a+c["outcome_baseline_quadratic_coefficient"]*x.sum(1)**2+c["outcome_noise_sd"]*r.standard_normal(n)
            return x,a,m,y,["binary"]*3,["binary"]*3,"continuous"
x = np.empty((n,3))
x[:,0]=r.binomial(1,c["p_w1"],n)
x[:,1]=r.binomial(1,c["p_w2"],n)
x[:,2]=r.binomial(1,c["p_w3_intercept"]+c["p_w3_slope"]*(x[:,0]+x[:,1]))
a=r.binomial(1,expit(c["treatment_intercept"]+c["treatment_w_sum"]*x.sum(1)+c["treatment_w1w2"]*x[:,0]*x[:,1]))
m=r.binomial(1,expit(c["m_w1"]*x[:,0]+c["m_w2"]*x[:,1]+c["m_a"]*a+c["m_aw2"]*a*x[:,1]))[:,None]
y=r.binomial(1,expit((c["y_a"]*a+c["y_m"]*m[:,0])/(x.sum(1)+c["y_denominator_intercept"])))
return x,a,m,y,["binary"],["binary"]*3,"binary"
```

Truth class: exact_finite_enumeration. Sum the three mediator probability contrasts weighted by outcome coefficients over all eight baseline states and their population probabilities.

Original registered target (retained separately): NIE_1.

## diaz_intermediate

Remove Z structurally: set m_z, m_az, y_z and y_az to zero. Recompute natural NIE1, replacing the source interventional indirect-effect target.

```python
if s == "diaz_hejazi":
            x = r.binomial(1, c["baseline_probabilities"], (n,3))
            a = r.binomial(1, x.sum(1)/c["treatment_denominator"]+c["treatment_intercept"])
            m = r.binomial(1, _dh_probs(c["mediation_path_scale"]*a, x))
            y = m@c["outcome_mediator_coefficients"]+c["outcome_treatment_coefficient"]*a+c["outcome_baseline_quadratic_coefficient"]*x.sum(1)**2+c["outcome_noise_sd"]*r.standard_normal(n)
            return x,a,m,y,["binary"]*3,["binary"]*3,"continuous"
x = np.empty((n,3))
x[:,0]=r.binomial(1,c["p_w1"],n)
x[:,1]=r.binomial(1,c["p_w2"],n)
x[:,2]=r.binomial(1,c["p_w3_intercept"]+c["p_w3_slope"]*(x[:,0]+x[:,1]))
a=r.binomial(1,expit(c["treatment_intercept"]+c["treatment_w_sum"]*x.sum(1)+c["treatment_w1w2"]*x[:,0]*x[:,1]))
m=r.binomial(1,expit(c["m_w1"]*x[:,0]+c["m_w2"]*x[:,1]+c["m_a"]*a+c["m_aw2"]*a*x[:,1]))[:,None]
y=r.binomial(1,expit((c["y_a"]*a+c["y_m"]*m[:,0])/(x.sum(1)+c["y_denominator_intercept"])))
return x,a,m,y,["binary"],["binary"]*3,"binary"
```

Truth class: exact_finite_enumeration. Enumerate all eight baseline states; multiply the mediator probability contrast by the treatment-1 outcome-mean contrast between mediator values.

Original registered target (retained separately): IIE_1.

## he_song_xu

Retain the scalar linear complete-data SEM; expose the source alternatives/nulls through explicit configs or the optional parameter prior.

```python
x=np.column_stack([c["x1_sd"]*r.standard_normal(n),r.binomial(1,c["x2_probability"],n)])
a=r.binomial(1,c["treatment_probability"],n)
m=(c["mediator_intercept"]+c["alpha_s"]*a+c["mediator_x1"]*x[:,0]+c["mediator_x2"]*x[:,1]+c["mediator_noise_sd"]*r.standard_normal(n))[:,None]
y=c["outcome_intercept"]+c["beta_m"]*m[:,0]+c["outcome_direct"]*a+c["outcome_x1"]*x[:,0]+c["outcome_x2"]*x[:,1]+c["outcome_noise_sd"]*r.standard_normal(n)
return x,a,m,y,["continuous"],["continuous","binary"],"continuous"
```

Truth class: analytic. alpha_s * beta_m

Original registered target (retained separately): NIE_1.

## jones_lnl

Retain LNL propensity/mediator-confounding/outcome-confounding forms, vector mediators and active paths.

```python
x=np.sqrt(c["covariate_variance"])*r.standard_normal((n,3))
q=c["mediator_count"]
pa=expit(c["propensity_scale"]*((x[:,0]+x[:,1]) if c["propensity_form"]=="linear" else (x[:,0]*x[:,1]+x[:,1])))
a=r.binomial(1,pa)
xm=(x[:,0] if c["mediator_confounding_form"]=="linear" else x[:,0]**2)+x[:,1]-x[:,2]
xy=2*((x[:,0]-.5) if c["outcome_confounding_form"]=="linear" else (x[:,0]-.5)**2)+x[:,1]+2*x[:,2]
m=a[:,None]*np.asarray(c["alpha0"])+xm[:,None]+c["mediator_noise_sd"]*r.standard_normal((n,q))
y=c["gamma0"]*a+m@c["beta0"]+xy+c["outcome_noise_sd"]*r.standard_normal(n)
return x,a,m,y,["continuous"]*q,["continuous"]*3,"continuous"
```

Truth class: analytic. inner product alpha0 dot beta0

Original registered target (retained separately): NIE = alpha_0 . beta_0.

## jones_lnn

Retain LNN propensity/mediator-confounding/outcome-confounding forms, vector mediators and active paths.

```python
x=np.sqrt(c["covariate_variance"])*r.standard_normal((n,3))
q=c["mediator_count"]
pa=expit(c["propensity_scale"]*((x[:,0]+x[:,1]) if c["propensity_form"]=="linear" else (x[:,0]*x[:,1]+x[:,1])))
a=r.binomial(1,pa)
xm=(x[:,0] if c["mediator_confounding_form"]=="linear" else x[:,0]**2)+x[:,1]-x[:,2]
xy=2*((x[:,0]-.5) if c["outcome_confounding_form"]=="linear" else (x[:,0]-.5)**2)+x[:,1]+2*x[:,2]
m=a[:,None]*np.asarray(c["alpha0"])+xm[:,None]+c["mediator_noise_sd"]*r.standard_normal((n,q))
y=c["gamma0"]*a+m@c["beta0"]+xy+c["outcome_noise_sd"]*r.standard_normal(n)
return x,a,m,y,["continuous"]*q,["continuous"]*3,"continuous"
```

Truth class: analytic. inner product alpha0 dot beta0

Original registered target (retained separately): NIE = alpha_0 . beta_0.

## jones_nnn

Retain NNN propensity/mediator-confounding/outcome-confounding forms, vector mediators and active paths.

```python
x=np.sqrt(c["covariate_variance"])*r.standard_normal((n,3))
q=c["mediator_count"]
pa=expit(c["propensity_scale"]*((x[:,0]+x[:,1]) if c["propensity_form"]=="linear" else (x[:,0]*x[:,1]+x[:,1])))
a=r.binomial(1,pa)
xm=(x[:,0] if c["mediator_confounding_form"]=="linear" else x[:,0]**2)+x[:,1]-x[:,2]
xy=2*((x[:,0]-.5) if c["outcome_confounding_form"]=="linear" else (x[:,0]-.5)**2)+x[:,1]+2*x[:,2]
m=a[:,None]*np.asarray(c["alpha0"])+xm[:,None]+c["mediator_noise_sd"]*r.standard_normal((n,q))
y=c["gamma0"]*a+m@c["beta0"]+xy+c["outcome_noise_sd"]*r.standard_normal(n)
return x,a,m,y,["continuous"]*q,["continuous"]*3,"continuous"
```

Truth class: analytic. inner product alpha0 dot beta0

Original registered target (retained separately): NIE = alpha_0 . beta_0.

## jones_correlated

Retain randomized A, vector mediator and unit-diagonal two-block Gaussian error covariance. Factor sampling is distributionally equivalent for 0<=rho_bridge<=rho_within<1. The source code does not use mediator_error_sd, and neither does this adaptation.

```python
q=int(c["p"])
within=float(c["rho_within"])
bridge=float(c["rho_bridge"])
if not 0<=bridge<=within<1: raise ValueError("Need 0 <= bridge <= within < 1")
a=r.binomial(1,c["p_treatment"],n)
m=np.sqrt(1-within)*r.standard_normal((n,q))+np.sqrt(bridge)*r.standard_normal((n,1))
group=r.standard_normal((n,2))
m[:,:2]+=np.sqrt(within-bridge)*group[:,0,None]
m[:,2:]+=np.sqrt(within-bridge)*group[:,1,None]
ai=np.asarray(c["a_to_m_indices"])-1
bi=np.asarray(c["m_to_y_indices"])-1
if np.any(ai<0) or np.any(ai>=q) or np.any(bi<0) or np.any(bi>=q): raise ValueError("Index outside mediator vector")
m[:,ai]+=c["a_to_m_coefficient"]*a[:,None]
y=c["direct_effect"]*a+c["m_to_y_coefficient"]*m[:,bi].sum(1)+c["outcome_error_sd"]*r.standard_normal(n)
return np.empty((n,0)),a,m,y,["continuous"]*q,[],"continuous"
```

Truth class: analytic. Number of shared active A-M and M-Y indices times a_to_m_coefficient * m_to_y_coefficient.

Original registered target (retained separately): NIE_1.

## miles

Remove all three induced C1 variables and their M/Y interactions structurally by zeroing mediator_confounder, mediator_exposure_confounder and outcome_confounder. Retain A-M interaction and use treatment-1 natural NIE, not the source reference-level path-specific effect.

```python
x=r.uniform(*c["baseline_support"],size=(n,1))
a=r.binomial(1,expit(c["exposure_coefficients"][0]+c["exposure_coefficients"][1]*x[:,0]))
m=(c["mediator_intercept"]+c["mediator_baseline"]*x[:,0]+c["mediator_exposure"]*a+c["mediator_sd"]*r.standard_normal(n))[:,None]
y=c["outcome_intercept"]+c["outcome_baseline"]*x[:,0]+c["outcome_exposure"]*a+(c["outcome_mediator"]+c["outcome_exposure_mediator"]*a)*m[:,0]+c["outcome_sd"]*r.standard_normal(n)
return x,a,m,y,["continuous"],["continuous"],"continuous"
```

Truth class: analytic. mediator_exposure * (outcome_mediator + outcome_exposure_mediator)

Original registered target (retained separately): P_AMY = E(Y[M{a, C1(a')}, C1(a'), a']) - E[Y(a')].

## shan

Export complete X1/X2/X3, M and Y before observation masks. Omit shadows/masks. Merge the auxiliary/internal-shadow records only in this new full-data namespace; both original records remain untouched.

```python
x=np.column_stack([r.random((n,2)),r.binomial(1,c["x3_probability"],n)])
a=r.binomial(1,expit(c["propensity_intercept"]+c["propensity_x1_squared"]*x[:,0]**2+c["propensity_x2"]*x[:,1]+c["propensity_x3"]*x[:,2]))
m=(c["mediator_intercept"]+c["mediator_treatment"]*a+c["mediator_treatment_x1_squared"]*a*x[:,0]**2+c["mediator_x1_squared"]*x[:,0]**2+c["mediator_sin_x2"]*np.sin(x[:,1])+c["mediator_x3"]*x[:,2]+c["mediator_noise_sd"]*r.standard_normal(n))[:,None]
y=c["outcome_intercept"]+c["outcome_treatment"]*a+(c["outcome_mediator"]+c["outcome_treatment_mediator"]*a)*m[:,0]+c["outcome_treatment_x1"]*a*x[:,0]+c["outcome_sin_x1"]*np.sin(x[:,0])+c["outcome_x2_squared"]*x[:,1]**2+c["outcome_x3"]*x[:,2]+c["outcome_noise_sd"]*r.standard_normal(n)
return x,a,m,y,["continuous"],["continuous","continuous","binary"],"continuous"
```

Truth class: analytic. (outcome_mediator + outcome_treatment_mediator) * (mediator_treatment + mediator_treatment_x1_squared / 3)

Original registered target (retained separately): MF theta = E[Y(1, M(0))].

## eric

Retain the scalar discrete-mediator SEM and superpopulation target; do not replace population X integration by the realized empirical-X average.

```python
x=np.empty((n,3))
x[:,0]=r.binomial(1,c["x1_probability"],n)
x[:,1]=r.binomial(1,c["x2_coefficients"][0]+c["x2_coefficients"][1]*x[:,0])
xc=c["x3_coefficients"]
x[:,2]=xc[0]+xc[1]*x[:,0]+xc[2]*x[:,1]+c["x3_sd"]*r.standard_normal(n)
f=np.column_stack([np.ones(n),x,x[:,0]*x[:,2]])
a=r.binomial(1,expit(f@c["treatment_coefficients"]))
m=r.binomial(1,expit(f@c["mediator_coefficients"]+c["mediator_treatment_coefficient"]*a))[:,None]
y=np.column_stack([np.ones(n),x,a,m[:,0],a*m[:,0]])@c["outcome_coefficients"]+c["outcome_noise_sd"]*r.standard_normal(n)
return x,a,m,y,["binary"],["binary","binary","continuous"],"continuous"
```

Truth class: finite_enumeration_and_gauss_hermite_80. Enumerate the four discrete baseline states and integrate the conditional Gaussian baseline by 80-node Gauss-Hermite quadrature.

Original registered target (retained separately): theta_NIE = theta_11 - theta_10.

## xia_binary

Remove C and its effects in Y structurally: y_c=y_ac=0. Preserve the original marginal M law and A-M interaction. Recompute NIE1 rather than reuse source NDE truth.

```python
x=c["x_sd"]*r.standard_normal((n,1))
a=r.binomial(1,expit(c["a_logit_intercept"]+c["a_logit_x"]*x[:,0]))
if s=="xia_binary": m=r.binomial(1,expit(c["m_logit_intercept"]+c["m_logit_a"]*a+c["m_logit_x"]*x[:,0]))[:,None]
        else: m=(c["m_intercept"]+c["m_a"]*a+c["m_x"]*x[:,0]+c["m_sd"]*r.standard_normal(n))[:,None]
y=c["y_intercept"]+c["y_a"]*a+(c["y_m"]+c["y_am"]*a)*m[:,0]+c["y_x"]*x[:,0]+c["y_sd"]*r.standard_normal(n)
return x,a,m,y,["binary" if s=="xia_binary" else "continuous"],["continuous"],"continuous"
```

Truth class: gauss_hermite_80. 80-node Gaussian quadrature of the mediator probability contrast times (y_m+y_am).

Original registered target (retained separately): NDE.

## xia_continuous

Remove C and its effects in Y structurally: y_c=y_ac=0. Preserve the original marginal M law and A-M interaction. Recompute NIE1 rather than reuse source NDE truth.

```python
x=c["x_sd"]*r.standard_normal((n,1))
a=r.binomial(1,expit(c["a_logit_intercept"]+c["a_logit_x"]*x[:,0]))
if s=="xia_binary": m=r.binomial(1,expit(c["m_logit_intercept"]+c["m_logit_a"]*a+c["m_logit_x"]*x[:,0]))[:,None]
        else: m=(c["m_intercept"]+c["m_a"]*a+c["m_x"]*x[:,0]+c["m_sd"]*r.standard_normal(n))[:,None]
y=c["y_intercept"]+c["y_a"]*a+(c["y_m"]+c["y_am"]*a)*m[:,0]+c["y_x"]*x[:,0]+c["y_sd"]*r.standard_normal(n)
return x,a,m,y,["binary" if s=="xia_binary" else "continuous"],["continuous"],"continuous"
```

Truth class: analytic. m_a * (y_m + y_am)

Original registered target (retained separately): NDE.

## zuo

Export complete M and Y before MNAR masks; omit missingness indicators. Preserve the full-data A-M interaction and natural NIE1.

```python
x=c["x_mean"]+c["x_sd"]*r.standard_normal((n,1))
a=r.binomial(1,c["p_t"],n)
m=(c["alpha_0"]+c["alpha_t"]*a+c["alpha_x"]*x[:,0]+c["m_sd"]*r.standard_normal(n))[:,None]
y=c["beta_0"]+c["beta_t"]*a+(c["beta_m"]+c["beta_mt"]*a)*m[:,0]+c["beta_x"]*x[:,0]+c["y_sd"]*r.standard_normal(n)
return x,a,m,y,["continuous"],["continuous"],"continuous"
```

Truth class: analytic. alpha_t * (beta_m + beta_mt)

Original registered target (retained separately): NIE_1.

## Additional prior and evaluation design

`randomize=False` uses the first native registered configuration after the
declared structural adaptation. Explicit config.json values select any
registered alternative/null without changing targets. `randomize=True` uses
the frozen optional coefficient prior; the package's canonical source records
its exact ranges and path-null mixture. It is not a source-paper claim.

Keep independently drawn mechanisms distinct from repeated observations at
one mechanism. Family-balanced prior performance and fixed-DGP coverage answer
different questions. Hold out complete provenance families or compositions
only under a separately frozen protocol, and document inherited pretrained
backbone exposure. Do not tune models or calibration using exposed tests.
