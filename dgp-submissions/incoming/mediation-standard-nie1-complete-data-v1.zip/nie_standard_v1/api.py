"""Observed/evaluator separation for the versioned NIE1 generator standard."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

import numpy as np

from . import generators as _core

VERSION = "1.0.0"
TARGET = "superpopulation_NIE_1"
CORE_SHA256 = "443e04663970594a8ec2932dc0ee9718c10cc501314d133686dfd0e9acf1baa8"
SOURCE_COMMIT = _core.SOURCE_COMMIT


def available_sources():
    """The fourteen unique complete-data presets, without a benchmark split."""
    return _core.available_sources("all")


def sample_mechanism(source_id, mechanism_seed=0, *, randomize=False):
    """Native parameter preset by default; optional disclosed parameter prior."""
    _seed(mechanism_seed, "mechanism_seed")
    return _core.sample_mechanism(source_id, seed=int(mechanism_seed), randomize=randomize)


def _seed(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or value < 0:
        raise ValueError(name + " must be a nonnegative integer")


def truth(source_id, config=None):
    """Superpopulation NIE1 for the adapted SEM, never table-conditional truth."""
    return _core.truth(source_id, config=deepcopy(config))


def sample_task(source_id, n, observation_seed, *, mechanism_seed=0,
                config=None, randomize=False, compute_truth=False):
    """Return separate observed arrays, role/type schema and evaluator metadata.

    Pass only ``task['observed']`` and the permitted role/type schema to a
    method. Parameters, provenance, mechanism identity and truth are evaluator
    fields. Changing observation_seed redraws rows at the same mechanism.
    """
    _seed(observation_seed, "observation_seed")
    _seed(mechanism_seed, "mechanism_seed")
    task = _core.sample_task(source_id, n=n, seed=int(observation_seed),
                            mechanism_seed=int(mechanism_seed), config=deepcopy(config),
                            randomize=randomize, compute_truth=compute_truth)
    observed = {key: task[key] for key in ("x", "a", "m", "y")}
    schema = {"roles": {"x": "baseline_covariates", "a": "treatment",
                         "m": "joint_mediator_vector", "y": "outcome"},
              "x_types": list(task["x_types"]),
              "mediator_types": list(task["mediator_types"]),
              "treatment_type": "binary", "treatment_values": [0, 1],
              "outcome_type": task["outcome_type"],
              "target": TARGET, "treatment_contrast": [0, 1]}
    metadata = deepcopy(task["metadata"])
    metadata.update(standard_version=VERSION, canonical_core_sha256=CORE_SHA256,
                    observation_seed=int(observation_seed))
    return {"observed": observed, "schema": schema, "metadata": metadata,
            "truth": task["truth"] if compute_truth else None}


def as_columns(task):
    """Observed-only scalar columns for the Arena's generate(config,n,seed) API."""
    d = task["observed"]
    out = {"X" + str(i + 1): d["x"][:, i] for i in range(d["x"].shape[1])}
    out["A"] = d["a"]
    out.update({"M" + str(i + 1): d["m"][:, i] for i in range(d["m"].shape[1])})
    out["Y"] = d["y"]
    return out


def verify_source():
    """Verify the unchanged canonical core and frozen original generator blobs."""
    base = Path(__file__).resolve().parent
    if hashlib.sha256((base / "generators.py").read_bytes()).hexdigest() != CORE_SHA256:
        raise ValueError("Canonical generator bytes changed")
    manifest = json.loads((base / "source_manifest.json").read_text(encoding="utf-8"))
    if manifest["commit"] != SOURCE_COMMIT or len(manifest["sources"]) != 15:
        raise ValueError("Unexpected original-source manifest")
    for record in manifest["sources"]:
        raw = (base / "vendor" / (record["name"] + ".py")).read_bytes()
        blob = hashlib.sha1(("blob %d\0" % len(raw)).encode() + raw).hexdigest()
        if blob != record["sha"]:
            raise ValueError("Original generator bytes changed: " + record["name"])
    return {"status": "PASS", "standard_version": VERSION,
            "canonical_core_sha256": CORE_SHA256, "original_generators_verified": 15}
