"""Portable standalone contract and scientific regression checks."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np

from . import api
from . import generators as core


class StandardAPI(unittest.TestCase):
    def test_pinned_source(self):
        self.assertEqual(api.verify_source()["original_generators_verified"], 15)
        self.assertEqual(len(api.available_sources()), 14)

    def test_same_core_rows_types_and_truth_for_all_presets(self):
        for source in api.available_sources():
            a = api.sample_task(source, 60, 17, mechanism_seed=4, compute_truth=True)
            b = core.sample_task(source, 60, 17, mechanism_seed=4, randomize=False)
            for key in ("x", "a", "m", "y"):
                np.testing.assert_array_equal(a["observed"][key], b[key])
            self.assertEqual(a["truth"], b["truth"])
            self.assertEqual(a["schema"]["mediator_types"], b["mediator_types"])
            self.assertEqual(a["schema"]["outcome_type"], b["outcome_type"])
            columns = api.as_columns(a)
            self.assertEqual(len(columns), b["x"].shape[1] + b["m"].shape[1] + 2)
            self.assertFalse(set(columns) & {"truth", "config", "mechanism_id", "source_id"})

    def test_truth_not_called_or_exposed_by_default(self):
        with patch.object(core, "truth", side_effect=RuntimeError("must not compute truth")):
            a = api.sample_task("jones_lnl", 40, 5)
        self.assertIsNone(a["truth"])
        self.assertEqual(set(a["observed"]), {"x", "a", "m", "y"})
        self.assertFalse(set(a["schema"]) & {"config", "source_id", "mechanism_seed", "truth"})

    def test_mechanism_and_observation_seeds_are_separate(self):
        for source in api.available_sources():
            a = api.sample_task(source, 40, 10, mechanism_seed=10**100 + 17, randomize=True, compute_truth=True)
            b = api.sample_task(source, 40, 11, mechanism_seed=10**100 + 17, randomize=True, compute_truth=True)
            c = api.sample_task(source, 40, 10, mechanism_seed=10**100 + 17, randomize=True, compute_truth=True)
            self.assertEqual(a["metadata"]["mechanism_id"], b["metadata"]["mechanism_id"])
            self.assertEqual(a["truth"], b["truth"])
            self.assertFalse(np.array_equal(a["observed"]["y"], b["observed"]["y"]))
            np.testing.assert_array_equal(a["observed"]["y"], c["observed"]["y"])

    def test_structural_removal_and_input_config_not_mutated(self):
        for source, keys in [("cheng", ["mediator_event_coefficient", "outcome_event_coefficient"]),
                             ("diaz_intermediate", ["m_z", "m_az", "y_z", "y_az"]),
                             ("miles", ["mediator_confounder", "mediator_exposure_confounder", "outcome_confounder"]),
                             ("xia_binary", ["y_c", "y_ac"]), ("xia_continuous", ["y_c", "y_ac"])]:
            config = api.sample_mechanism(source)
            for key in keys:
                config[key] = [.5, .6, .7] if isinstance(config[key], list) else .9
            before = deepcopy(config)
            a = api.sample_task(source, 40, 6, config=config, compute_truth=True)
            self.assertEqual(config, before)
            for key in keys:
                self.assertTrue(np.all(np.asarray(a["metadata"]["config"][key]) == 0))
            self.assertEqual(a["truth"], api.truth(source, config))

    def test_full_data_alias_and_discrete_outcome(self):
        a = api.sample_task("shan", 40, 8, compute_truth=True)
        b = api.sample_task("shan_internal", 40, 8, compute_truth=True)
        for key in a["observed"]:
            np.testing.assert_array_equal(a["observed"][key], b["observed"][key])
        y = api.sample_task("diaz_intermediate", 40, 9)
        self.assertEqual(y["schema"]["outcome_type"], "binary")
        self.assertTrue(set(np.unique(y["observed"]["y"])) <= {0, 1})
        self.assertEqual(api.sample_task("jones_correlated", 40, 10)["observed"]["x"].shape[1], 0)

    def test_quadrature_resolution_is_reported_not_exact_claim(self):
        old_x, old_w = core._GH_X.copy(), core._GH_W.copy()
        for source in ("cheng", "eric", "xia_binary"):
            base = api.truth(source)
            x, w = np.polynomial.hermite.hermgauss(160)
            try:
                core._GH_X, core._GH_W = np.sqrt(2)*x, w/np.sqrt(np.pi)
                core._truth_cached.cache_clear()
                refined = api.truth(source)
            finally:
                core._GH_X, core._GH_W = old_x, old_w
                core._truth_cached.cache_clear()
            self.assertLess(abs(base-refined), 1e-7, (source, base, refined))

    def test_invalid_seeds_are_rejected(self):
        for value in (-1, 1.5, True, "10"):
            with self.assertRaises(ValueError):
                api.sample_task("he_song_xu", 20, value)
            with self.assertRaises(ValueError):
                api.sample_mechanism("he_song_xu", value)


if __name__ == "__main__":
    unittest.main(verbosity=2)
