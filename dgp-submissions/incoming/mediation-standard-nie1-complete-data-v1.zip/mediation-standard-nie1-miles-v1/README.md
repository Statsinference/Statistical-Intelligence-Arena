# Standard NIE1 adaptation: miles

This record is version 1.0.0 of a new standardized **complete-data NIE1** adaptation.
Its target is `E[Y(1,M(1))-Y(1,M(0))]` over the fixed-SEM superpopulation,
jointly moving all mediator coordinates. It is not a claim that the source paper
used this adapted law or target. The original contribution remains unchanged.

Source: Miles, C. H., Shpitser, I., Kanki, P., Meloni, S. and Tchetgen Tchetgen, E. J. (2019). On semiparametric estimation of a path-specific effect in the presence of mediator-outcome confounding. Biometrika 107(1), 159-172. DOI: 10.1093/biomet/asz063.

Original registry record(s): mediation-miles-2019-toxicity-path-specific-v1.
Frozen original commit: `8182caf7185845a31a2122e032811bb2254d6342`.

## Changes and truth

Remove all three induced C1 variables and their M/Y interactions structurally by zeroing mediator_confounder, mediator_exposure_confounder and outcome_confounder. Retain A-M interaction and use treatment-1 natural NIE, not the source reference-level path-specific effect.

Original registered target: P_AMY = E(Y[M{a, C1(a')}, C1(a'), a']) - E[Y(a')].
Its full definition is preserved verbatim in source_audit.json and the vendor record.
New truth computation: **analytic** — mediator_exposure * (outcome_mediator + outcome_exposure_mediator)
Native numerical reference: `-0.51000000000000001`.

Use the complete ZIP. `generator.py` is a thin entry point importing the one
canonical `nie_standard_v1` package, not a self-contained replacement for it.
Call `generate(config,n,seed)` for observed-only column arrays, or `sample_task`
for separate observed/schema/evaluator fields. Truth computation is off by default.
Parameters in config.json are fixed for independent row replicates. The optional
randomized mechanism prior is separate and must be frozen before benchmark use.

See the top-level README.md and SCIENTIFIC_SPEC.md for the exact executable
equations, error independence, role/type schema, numerical-truth scope and
task-template bridge. No accepted leaderboard result is asserted by this record.
