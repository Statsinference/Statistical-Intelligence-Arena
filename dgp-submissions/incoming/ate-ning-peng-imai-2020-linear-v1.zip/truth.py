def truth(config):
    """Analytical population ATE for the linear potential-outcome DGP."""
    # E[X_j]=0 for every coordinate and E[epsilon_a]=0.
    # Thus all covariate and error terms vanish in E[Y(1)-Y(0)].
    value = float(config["y1_intercept"]) - float(config["y0_intercept"])
    return {
        "value": value,
        "estimated_error": 0.0,
        "method": "analytic expectation under mean-zero Gaussian covariates and mean-zero errors",
        "target": "E[Y(1)-Y(0)] for intervention A=1 versus A=0",
        "derivation": "intercept difference + coefficient-weighted covariate means + error-mean difference = 2 - 1 + 0 = 1"
    }
