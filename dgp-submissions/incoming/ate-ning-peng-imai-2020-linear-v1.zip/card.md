# High-dimensional Gaussian covariates with linear potential outcomes (ATE)

**Status: candidate; awaiting scientific review.** No PFN is trained or evaluated.

## Source and reconstruction

Ning, Yang and Imai (2020), “Robust estimation of causal effects via a high-dimensional covariate balancing propensity score,” *Biometrika* 107(3), 533–554, DOI [10.1093/biomet/asaa020](https://doi.org/10.1093/biomet/asaa020). Equation-level source used: arXiv:1812.08683v1, submitted 20 Dec 2018, [PDF](https://arxiv.org/pdf/1812.08683), Section 5 “Simulation Studies,” PDF viewer page 21/29 (unnumbered DGP equations in the opening paragraphs and the following linear-outcome paragraph). The published article’s Section 5 is the corresponding journal source.

### Original DGP, in generation order

1. For independent individuals i=1,...,n, generate a d-dimensional Gaussian covariate vector `X_i ~ N_d(0, Sigma)`, with `Sigma_jk = rho^|j-k|` and `rho=1/2`. This gives marginal variance 1 for each coordinate and covariance `0.5^|j-k|`.
2. Generate binary treatment `A_i | X_i ~ Bernoulli(e_i)`, where `e_i = 1 - 1/{1 + exp(-X_i1 + X_i2/2 - X_i3/4 - X_i4/10 - X_i5/10 + X_i6/10)}`. Equivalently, `e_i=expit(eta_i)` with `eta_i=-X_i1+X_i2/2-X_i3/4-X_i4/10-X_i5/10+X_i6/10`. The logistic link maps any finite eta to a probability strictly between 0 and 1; no clipping is applied.
3. Generate `Y_i(1)=2+0.137(X_i5+X_i6+X_i7+X_i8)+epsilon_i1`.
4. Generate `Y_i(0)=1+0.291(X_i5+X_i6+X_i7+X_i8+X_i9+X_i10)+epsilon_i0`. The source states `epsilon_i1` and `epsilon_i0` are independent standard normal random variables. It does not explicitly state in that sentence whether they are independent of X; the executable implementation draws them independently of X and treatment. **This independence-from-X detail is an adaptation/interpretation requiring scientific confirmation**, not asserted as an explicit source statement.
5. Observe `Y_i=A_iY_i(1)+(1-A_i)Y_i(0)`. The returned table includes only `X1,...,Xd,A,Y`; neither potential outcomes nor the true ATE is an observed column.

The source studies d=1000 and 2000 with sample sizes n=500 and 1000 (Section 5, around PDF pp.21–22; the exact paper experiments are not reproduced here). This contribution implements the original linear-potential-outcome setting with `d=1000`. The local `n=128` is only a smoke test. The Gaussian vector is generated via an AR(1) recursion, distributionally equivalent to the stated covariance model but not guaranteed to reproduce the authors’ random-number stream.

## Target and identification

The estimand is the population average treatment effect for intervention A=1 versus A=0: `ATE=E[Y(1)-Y(0)]`. Under the declared DGP, individuals are independent; within each individual the Gaussian covariates are correlated. Treatment is drawn conditionally on X. The intended causal interpretation relies on consistency, conditional exchangeability of potential outcomes given X and positivity. Pointwise positivity follows from the logistic assignment for finite X, but no uniform lower/upper propensity bound is claimed.

## Truth and independent verification

Since every `X_j` has mean zero and both errors have mean zero,

`E[Y(1)-Y(0)] = (2-1) + 0.137 E[X5+X6+X7+X8] - 0.291 E[X5+...+X10] + E[epsilon1-epsilon0] = 1.`

The analytic reference value is 1.0 with numerical error 0. The verifier independently computes the means of the two potential-outcome equations and includes a zero-effect special case with identical potential-outcome mean equations. This is a second algebraic implementation, not independent-person replication; both code paths share the source equations. The checker’s smoke tests do not prove identification or source fidelity.

## Diversity and scope

`dimension=1000` is the total baseline covariate count; `effective_dimension=10` means X1–X10 are the only coordinates with direct nonzero coefficients in the treatment or outcome equations. All coordinates are correlated under Sigma, so the remaining coordinates are correlated proxies, not direct equation terms. `high_dimensional=true` refers to the paper’s d=1000/2000 settings relative to n=500/1000. `interactions=false`: no product terms appear in the original linear DGP. `nonlinear=true` only because treatment uses a logistic link; both potential-outcome conditional means are linear. This is one mechanism family; changing d or seed does not create a new family.

## Rights and assistance

This is an independently written reconstruction; no paper PDF, author source code, sensitive data, credentials, model weights or data bank are included. Article rights remain with the publisher/authors; redistribution permission is not claimed. AI assistance was used to extract and structure equations and draft implementation, followed by local code review and machine checks. `scientific_review` remains pending; no named reviewer or independent-person reproduction is claimed.

## Unresolved items

1. Confirm from the published PDF/supplement whether the errors are explicitly independent of X, or retain the documented implementation adaptation.
2. Ask maintainers to check duplicate-family status before final acceptance.
3. Verify source locator and exact PDF-page mapping against their preferred archival copy.
