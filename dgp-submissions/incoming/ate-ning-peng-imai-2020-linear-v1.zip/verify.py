import math

def verify(config):
    """Independent algebraic checks; does not call truth.py."""
    checks = []
    # Independent route: directly compute expectation of each potential-outcome equation.
    mu_x = 0.0
    y1_mean = float(config["y1_intercept"]) + float(config["y1_coefficient"]) * len(config["y1_indices_1based"]) * mu_x
    y0_mean = float(config["y0_intercept"]) + float(config["y0_coefficient"]) * len(config["y0_indices_1based"]) * mu_x
    ate = y1_mean - y0_mean
    checks.append({"name":"independent_population_mean_derivation", "passed":math.isclose(ate, 1.0, rel_tol=0.0, abs_tol=1e-12), "details":f"E[Y1]={y1_mean:.16g}; E[Y0]={y0_mean:.16g}; difference={ate:.16g}"})
    # Analytic zero-path special case: equal potential-outcome equations imply zero ATE.
    zero_path_y1_intercept = 1.25
    zero_path_y0_intercept = 1.25
    zero_path_y1_slope = 0.0
    zero_path_y0_slope = 0.0
    zero_path = (zero_path_y1_intercept-zero_path_y0_intercept) + zero_path_y1_slope*0.0 - zero_path_y0_slope*0.0
    checks.append({"name":"zero_effect_special_case", "passed":math.isclose(zero_path, 0.0, rel_tol=0.0, abs_tol=1e-14), "details":"When both potential-outcome means are the same constant and both error means are zero, ATE=0."})
    # Confirm the selected covariate dimension supports all source outcome indices.
    d_ok = int(config["d"]) >= max(max(config["y1_indices_1based"]), max(config["y0_indices_1based"]))
    checks.append({"name":"source_index_bounds", "passed":d_ok, "details":f"d={config['d']}; highest direct outcome index={max(max(config['y1_indices_1based']), max(config['y0_indices_1based']))}"})
    return {"passed":all(c["passed"] for c in checks), "checks":checks, "independence_note":"This is an independent algebraic implementation of the stated linear equations, not an independent-person reproduction of the paper. Error independence from X remains a source-interpretation question."}
