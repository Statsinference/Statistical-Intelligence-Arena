"""Wald truth verified by integrating observed conditional laws over epsilon and Q."""
import copy
import math
import numpy as np
from generator import generate
from truth import truth
from common import result


def scalar(x,c):
    k=c['signal_dimension']
    # |t| representation independent of the generator's maximum operations.
    pos=lambda t:(t+abs(t))/2
    if c['additive']:
        effect=sum(pos(t) for t in x[:k]); baseline=c['nuisance_scale']*(pos(x[4])+pos(x[5]))
    else:
        effect=pos(sum(x[:k])); baseline=c['nuisance_scale']*pos(x[4]+x[5])
    return baseline,c['effect_scale']*effect


def integrated(c,order):
    ns,ws=np.polynomial.hermite.hermgauss(order)
    mu,tau=scalar(c['query_point'],c)
    dy=[]; da=[]
    eqeps=0.0
    for z in [0,1]:
        ey=ea=0.0
        for node,weight in zip(ns,ws):
            eps=math.sqrt(2)*float(node); w=float(weight)/math.sqrt(math.pi)
            pq=1/(1+math.exp(-c['omega']*eps))
            for q,p in [(0,1-pq),(1,pq)]:
                a=z*q
                ey+=w*p*(mu+(a-0.5)*tau+eps); ea+=w*p*a
            if z==1: eqeps+=w*pq*eps
        dy.append(ey); da.append(ea)
    return (dy[1]-dy[0])/(da[1]-da[0]), da[1]-da[0], eqeps/3


def verify(config):
    before=copy.deepcopy(config); checks=[]
    def record(name,ok,**details): checks.append({'name':name,'passed':bool(ok),**details})
    value,first,cov=integrated(config,48)
    value2,first2,cov2=integrated(config,80)
    target=truth(config)['value']
    error=max(abs(value-target),abs(value2-target))
    record('independent_observed_law_Wald_integration',error<1e-10,absolute_error=error,
           value=value2,first_stage=first2,order_difference=abs(value-value2))
    record('first_stage_symmetry',abs(first-.5)<1e-12 and abs(first2-.5)<1e-12)
    record('endogeneity_matches_source',abs(cov2)<1e-12 if config['omega']==0 else cov2>0,
           covariance_A_epsilon=cov2,quadrature_diagnostic=abs(cov-cov2))
    errors=[]
    for scale in [0.0,-1.0,2.0]:
        c=copy.deepcopy(config); c['effect_scale']=scale
        errors.append(abs(integrated(c,32)[0]-truth(c)['value']))
    record('zero_reverse_double_effect_controls',max(errors)<1e-10,max_absolute_error=max(errors))
    n,seed=73,81025; data=generate(config,n,seed)
    rng=np.random.Generator(np.random.PCG64(seed))
    x=rng.normal(size=(n,10)); eps=rng.normal(size=n); uz=rng.random(n); uq=rng.random(n)
    error=0.0; binary=True
    for i in range(n):
        z=int(uz[i]<1/3); a=z*int(uq[i]<1/(1+math.exp(-config['omega']*float(eps[i]))))
        mu,tau=scalar(x[i].tolist(),config)
        error=max(error,abs(data['Y'][i]-(mu+(a-.5)*tau+eps[i])))
        binary=binary and data['A'][i]==a and data['Z'][i]==z
    record('scalar_source_equation_replay',binary and error<1e-10,max_outcome_error=error,rows=n)
    record('one_sided_noncompliance',all(a<=z for a,z in zip(data['A'],data['Z'])))
    record('observed_only',set(data)=={*(f'X{j}' for j in range(1,11)),'Z','A','Y'})
    record('configuration_unchanged',config==before)
    return result(checks)
