"""Local IV Wald effect; equals conditional LATE and CATE in this particular DGP."""
from generator import validate_config


def truth(config):
    validate_config(config)
    x=config['query_point'][:config['signal_dimension']]
    signal=sum(max(0,t) for t in x) if config['additive'] else max(0,sum(x))
    return {'value':float(config['effect_scale']*signal),'estimated_error':0.0,
            'method':'Analytic local structural effect. First-stage contrast = E[expit(omega*epsilon)] = 1/2 by symmetry.',
            'error_interpretation':'No quadrature in truth; ordinary floating-point rounding remains.'}
