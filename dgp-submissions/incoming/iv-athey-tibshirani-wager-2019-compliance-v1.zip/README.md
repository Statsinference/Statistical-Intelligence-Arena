# iv-athey-tibshirani-wager-2019-compliance-v1

本贡献按独立学生包接口组织；完整机制、来源和适配见 card.md。三个 hook 在收集器中运行，Python 3.10+ 与 NumPy 即可。报告 PDF 随 ZIP 单独提交。
