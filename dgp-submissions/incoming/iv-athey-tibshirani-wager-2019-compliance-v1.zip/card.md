# IV：内生不依从与局部处理效应

## 来源与定位
Athey, S., Tibshirani, J. and Wager, S. (2019). Generalized random forests. The Annals of Statistics 47(2), 1148–1178. DOI: 10.1214/18-AOS1709.

https://arxiv.org/abs/1610.01271v4

arXiv v4 (2018-04-05), Appendix C.2, PDF pp.45–47, equation (49) and Table 2. Main paper §7 supplies local IV interpretation.

源公式足以实现已登记场景；未声称运行作者代码。

## 原始机制与参数
- X ~ N(0,I₁₀); ε ~ N(0,1); Z ~ Bernoulli(1/3), mutually independent.
- Q|ε ~ Bernoulli(expit(ωε)); A=ZQ; Y=μ(X)+(A−1/2)τ(X)+ε.
- Additive: τ(x)=Σⱼ₌₁ᵏ max(0,xⱼ); μ(x)=c[max(0,x₅)+max(0,x₆)].
- Nonadditive: τ(x)=max(0,Σⱼ₌₁ᵏ xⱼ); μ(x)=c max(0,x₅+x₆).
- k ∈ {2,4}; ω ∈ {0,1}; c ∈ {0,3}; p=10.

逐个固定参数见 config.json。本包含 16 个具名场景；默认场景为 `source_additive_k2_omega1_mu3`。各场景的 effect_scale（如存在）均为1。源码检查使用小样本，不改变单个个体的总体机制。

## 目标与真值
Conditional Wald ratio at fixed x*: {E[Y|Z=1,x*]-E[Y|Z=0,x*]}/{E[A|Z=1,x*]-E[A|Z=0,x*]}.

由正态对称性 E[expit(omega·ε)]=1/2。给定 x，Z 的结果均值差为 τ(x)/2，一阶段差为 1/2，Wald 比值为 τ(x)。效应不依赖 ε 或 Q，因此本模型的条件 LATE 等于 CATE。

默认场景真值：1。truth 返回解析值，estimated_error=0 指无积分/Monte Carlo 近似，不是浮点误差的严格零界。固定查询点在 config.json 中记录，不通过生成样本选择。

## 识别条件
- Consistency and well-defined treatment interventions.
- Independent identically distributed units; no interference.
- Z is randomized Bernoulli(1/3), independent of X, epsilon and compliance randomization.
- Exclusion: Z affects Y only through A. A(z)=z*Q; monotonicity A(1)>=A(0).
- Relevance: E[A|Z=1,X]-E[A|Z=0,X]=1/2.
- Treatment effect tau(X) is independent of latent epsilon/Q conditional on X; hence conditional LATE equals CATE here, not in every IV model.

## 维数、交互和样本结构
最多 X1–X4 定义 tau，X5/X6 定义 nuisance；X7–X10 不起作用。有效维数随场景为2/4/6，6为包内最大值。非加性正部函数、A×tau(X)、logistic compliance 体现交互/非线性；p=10不标高维。

导出列：X1, X2, X3, X4, X5, X6, X7, X8, X9, X10, Z, A, Y。仅输出观察变量；内部噪声、Q、潜在结果及逐行真值均不输出。真值与参数供维护端核验，不应作为估计器输入特征。

## 明确适配与范围
- 使用新写的 Python/NumPy PCG64 实现；保持所选场景的分布，不保证与 R 同种子逐行相同。
- n=128、seed=1729 仅用于接口运行检查；不复跑论文估计器、不报告覆盖率。
- 固定原文 p=10，收集 k=2/4、omega=0/1、mu 系数=0/3、加性/非加性共16场景；不混用 C.3 的 mu 系数1。
- 原文 W 重命名 A。标量目标选固定 x* 的局部 Wald 效应；该特定模型下等于 conditional LATE 和 CATE。
- 同一不依从机制的函数形式和参数设置集中在一个 family；未按场景重复计数。

与本地既有 AoS observational CATE 包不同：本包有 Z、潜在 Q 及 epsilon 诱导的不依从内生性。16个场景只计一套机制。

本包固定 p=10；未把原文 p=20、C.1示意例或 C.3区间实验并入。一般 IV 不能仅靠有效工具识别 ATE；此处的 CATE 等价来自源模型额外结构。

## 独立核验与可复现性
verify 不调用生成器的结构函数求真值。它用独立标量公式、潜在结果/观察律积分或总体矩恒等式核对 truth，并检查零效应、反向效应、源方程逐行重建和输入不变。自动运行检查还覆盖 schema、有限值、同 seed 重现、不同 seed 变化及观察列限制。积分阶数对照属于数值诊断，不等于严格误差界。

在学生包根目录执行：
```powershell
& .\.venv\Scripts\python.exe collect.py check contributions/iv-athey-tibshirani-wager-2019-compliance-v1 --run --n 128 --seed 1729
& .\.venv\Scripts\python.exe collect.py pack contributions/iv-athey-tibshirani-wager-2019-compliance-v1 --out submissions/iv-athey-tibshirani-wager-2019-compliance-v1.zip
```
改源文件后须重跑全部场景检查，并使用新 ZIP 文件名。

## 权利与审核状态
仅提供独立实现与来源链接，不包含论文 PDF 或原作者程序。论文版权归原权利人；正式发布权利审核待维护人完成。

AI 协助：OpenAI Codex，2026-10-25；包括文献核对、代码实现、报告与本地检查。没有代签人类原文阅读或独立人员复现。认领、跨库去重、具名科学审核与正式接收待维护人处理；本地运行通过不等于正式接收。未训练 PFN、未拟合估计器、未测 CI coverage。
