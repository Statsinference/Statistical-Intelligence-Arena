"""Local scientific checks; no claim of human review or benchmark acceptance."""
from copy import deepcopy
from itertools import product
import math
import numpy as np
from generator import generate
from truth import truth

def check(name,passed,**details):
    return dict(name=name,passed=bool(passed),**details)

def row_check(c, expected, n, seed):
    actual=generate(c,n,seed)
    errors={k:float(np.max(np.abs(np.asarray(actual[k])-v))) for k,v in expected.items()}
    return check('source_equation_row_reconstruction',set(actual)==set(expected) and max(errors.values())<1e-11,max_errors=errors,n=n,seed=seed)

def common(c,source_configs):
    original=deepcopy(c);a=generate(c,128,1729);b=generate(c,128,1729);d=generate(c,128,1730)
    return [check('source_parameter_fixture',c in source_configs),
      check('seed_replay_and_input_immutability',a==b and a!=d and c==original),
      check('observed_finite_columns',all(len(v)==128 and np.isfinite(v).all() for v in a.values()),columns=list(a))]

SOURCE_CONFIGS = [{'cov_xu': [[0.25, 0, 0.05], [0, 0.25, 0.05], [0.05, 0.05, 1]], 'a_to_m': -0.3, 'm_to_y': 1.0, 'direct_effect': 2.0}]

def nested(c,a):
    g,w=np.polynomial.hermite.hermgauss(4);g=g*math.sqrt(2);w=w/math.sqrt(math.pi);root=np.linalg.cholesky(c['cov_xu']);value=0.
    for idx in product(range(4),repeat=3):
        x,y,u=root@np.array([g[i] for i in idx])+np.array([.25,.25,0]);weight=math.prod(w[i] for i in idx)
        m0=-.5*(x+y)+.4*u;ew=.3+.2*(x+y)-.6*u
        value+=weight*(2+c['direct_effect']*a+c['m_to_y']*m0+2*ew-x-y-u)
    return value
def reconstruct(c):
    n=37;seed=314159;r=np.random.Generator(np.random.PCG64(seed));e=r.standard_normal((n,3));root=np.linalg.cholesky(c['cov_xu']);ra=r.random(n);ez=r.normal(size=n);ew=r.normal(size=n);em=r.normal(size=n);ey=r.normal(size=n)
    out={k:[] for k in ['X1','X2','A','Z','W','M','Y']}
    for i in range(n):
        x=.25+sum(root[0,j]*e[i,j] for j in range(3));xx=.25+sum(root[1,j]*e[i,j] for j in range(3));u=sum(root[2,j]*e[i,j] for j in range(3))
        a=int(ra[i]<1/(1+math.exp(.5*(x+xx)+.4*u)));z=.2-.52*a+.2*(x+xx)-u+ez[i];w=.3+.2*(x+xx)-.6*u+ew[i]
        m=c['a_to_m']*a-.5*(x+xx)+.4*u+em[i];y=2+c['direct_effect']*a+c['m_to_y']*m+2*w-x-xx-u+2*ey[i]
        for k,v in zip(out,[x,xx,a,z,w,m,y]):out[k].append(v)
    return row_check(c,out,n,seed)
def verify(config):
    c=config;checks=common(c,SOURCE_CONFIGS);v=truth(c)['value'];q=nested(c,1)-nested(c,0)
    checks.append(check('independent_nested_intervention_integration',abs(v-q)<1e-12,truth=v,independent=q));checks.append(reconstruct(c))
    null={**c,'direct_effect':0};reverse={**c,'direct_effect':-c['direct_effect']}
    checks.append(check('null_direct_path_and_sign_reversal',truth(null)['value']==0 and abs(nested(null,1)-nested(null,0))<1e-12 and truth(reverse)['value']==-v))
    changed={**c,'a_to_m':-1.2,'m_to_y':2.5}
    checks.append(check('nde_invariant_to_mediated_path',abs(nested(changed,1)-nested(changed,0)-v)<1e-12 and truth(changed)['value']==v))
    checks.append(check('total_effect_differs_from_nde',abs((c['direct_effect']+c['a_to_m']*c['m_to_y'])-v)>.1,total_effect=c['direct_effect']+c['a_to_m']*c['m_to_y']))
    return {'passed':all(x['passed'] for x in checks),'checks':checks}
