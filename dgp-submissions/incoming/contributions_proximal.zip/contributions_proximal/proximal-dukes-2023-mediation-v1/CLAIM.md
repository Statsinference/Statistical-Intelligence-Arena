# 来源认领记录

proximal-dukes-2023-mediation-v1

Dukes, O., Shpitser, I., & Tchetgen Tchetgen, E. J. (2023). Proximal mediation analysis. Biometrika, 110(4), 973–987. DOI: 10.1093/biomet/asad015.

定位：§4 Simulation studies，advance-access PDF 第10–11页；原文实验1的生成模型。

机制区别：含中介且目标为嵌套潜在结局的自然直接效应。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
