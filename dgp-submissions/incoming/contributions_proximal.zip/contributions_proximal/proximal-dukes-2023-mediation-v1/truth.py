"""Natural direct effect under the source linear structural equations."""
def truth(config):
    return {'value':float(config['direct_effect']),'estimated_error':0.,'method':'analytic nested intervention contrast',
            'explanation':'E[Y(1,M(0))-Y(0,M(0))]; the shared M(0), X, U, W and centered outcome errors cancel. This is NDE, not total effect or NIE.'}
