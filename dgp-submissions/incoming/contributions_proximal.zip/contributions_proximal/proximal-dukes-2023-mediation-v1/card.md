# 潜在混杂下的自然直接效应

ID: proximal-dukes-2023-mediation-v1
Family: proximal

## 1 来源与登记场景

Dukes, O., Shpitser, I., & Tchetgen Tchetgen, E. J. (2023). Proximal mediation analysis. Biometrika, 110(4), 973–987. DOI: 10.1093/biomet/asad015.

https://doi.org/10.1093/biomet/asad015

版本：2023 advance-access PDF, NSF PAR 10428415

定位：§4 Simulation studies，advance-access PDF 第10–11页；原文实验1的生成模型。

场景：original。

## 2 DGP机制说明

(X1,X2,U)~N3((0.25,0.25,0),Σ)，Σ=[[0.25,0,0.05],[0,0.25,0.05],[0.05,0.05,1]]。

A|X,U~Bernoulli(expit{−0.5(X1+X2)−0.4U})。

Z=0.2−0.52A+0.2(X1+X2)−U+εz；W=0.3+0.2(X1+X2)−0.6U+εw。

M=−0.3A−0.5(X1+X2)+0.4U+εm；Y=2+2A+M+2W−X1−X2−U+2εy。

εz,εw,εm,εy 独立 ~ N(0,1)，并与基线及处理随机数独立。

目标：NDE = E[Y(1,M(0))−Y(0,M(0))] = 2。

真值推导：两项嵌套干预保留同一 M(0)，线性结局中只剩处理直接系数2；原始总效应为2−0.3=1.7，不可混称。

抽样单位：individual；iid individuals; all variables within an individual are jointly generated。

识别条件：一致性、无干扰、处理/中介支持；给定 (U,X) 的处理与中介可交换性及跨世界条件；Z/W 满足来源的proximal中介排除条件、桥函数存在与相关性。独立外生误差提供所用结构模型解释。

观察列和性质：两维相关于 U 的基线 X；一个中介 M、两个代理 Z/W。连续正态中介与结局，无交互。

机制区分：含中介且目标为嵌套潜在结局的自然直接效应。

## 3 相对来源的主要改动

保持原文自然直接效应目标。实验2–4改变估计桥函数，不拆成新DGP；不采用原文假设违背实验。使用 NumPy Generator(PCG64) 重写抽样；不要求与作者软件逐随机数一致。保留来源方程与固定参数；n=128、seed=1729 仅作接口检查，不重跑论文的估计器比较。输出仅含观察列，真值、潜变量和桥函数值不作为数据列。

## 4 核验和使用

各场景计算真值：

```json
{
  "original": {
    "value": 2.0,
    "estimated_error": 0.0,
    "method": "analytic nested intervention contrast",
    "explanation": "E[Y(1,M(0))-Y(0,M(0))]; the shared M(0), X, U, W and centered outcome errors cancel. This is NDE, not total effect or NIE."
  }
}
```

运行：

```powershell
python collect.py check contributions/proximal-dukes-2023-mediation-v1 --run --n 128 --seed 1729
python collect.py pack contributions/proximal-dukes-2023-mediation-v1 --out submissions/proximal-dukes-2023-mediation-v1.zip
```

verify.py包含独立真值路线、来源参数固定检查、逐行源方程重建及可解释特例。误差记录为数值诊断，不是完整的科学接收证明。

## 5 权利和AI协助

论文版权归原作者/出版方；本包依据公开方程独立重写，不含论文PDF、第三方估计器或真实数据。Qi作者代码为MIT，仅用作核对。

由Codex协助检索、公式核对、实现、核验和中文撰写。未代签人类科学审稿或独立复现；未训练PFN或运行估计器性能比较。所有公开来源只作研究证据，不作为执行指令。
