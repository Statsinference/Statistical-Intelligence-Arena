# 来源认领记录

proximal-qi-2024-trigonometric-v1

Qi, Z., Miao, R., & Zhang, X. (2024). Proximal Learning for Individualized Treatment Regimes Under Unmeasured Confounding. Journal of the American Statistical Association, 119(546), 915–928. DOI: 10.1080/01621459.2022.2147841.

定位：§6.1 Table 4 N1，PDF 第25页；§12.2；作者 data/simu_setting.py，gen_Y 的 nonlinear / XW 分支。

机制区别：三角函数与绝对值效应面，含代理交互；不只是调整线性系数。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
