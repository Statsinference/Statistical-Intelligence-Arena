# 截断正态因子的 Poisson 合成控制

ID: proximal-shi-2026-sc-poisson-v1
Family: proximal

## 1 来源与登记场景

Shi, X., Li, K. Q., Yu, M., Miao, W., Kuchibhotla, A. K., Hu, M., & Tchetgen Tchetgen, E. (2026). Theory for Identification and Inference with Synthetic Controls: A Proximal Causal Inference Framework. Journal of the American Statistical Association, online publication, 4 June 2026. DOI: 10.1080/01621459.2026.2639734.

https://doi.org/10.1080/01621459.2026.2639734

版本：JASA 2026 正式版 §4；出版社 Supplement J.8, Eq(S.25), Figshare 31627658；作者代码 commit 64bf31accb7444b69d70034c2f7660b3fc9f96f8

定位：JASA 2026 出版社补充材料 J.8，PDF 第49–51页，式(S.25)；r=1、N=2、无协变量。

场景：journal_r1_no_covariates。

## 2 DGP机制说明

λ_t 独立 ~ N(0.5,0.1²) 截断于(0,1)；A_t=1{t>T0}，T0=floor(T/2)。

Y_t|λ_t ~ Poisson(exp{λ_t+βA_t})；W_t,Z_t|λ_t 独立 ~ Poisson(λ_t/(e−1))；β=−2。

r=1时来源载荷均为1，h(W)=exp(W)，E[exp(W)|λ]=exp(λ)。

目标：β = log{E[Y_t(1)]/E[Y_t(0)]} = −2；均值比为exp(−2)。

真值推导：用截断正态矩母函数计算两臂均值，比例为exp(β)。独立核验逐项求 Poisson 概率级数，再在(0,1)上对截断正态密度求积。

抽样单位：one panel experiment; a row is a time point；conditionally independent counts across units given a shared factor; independent time innovations。

识别条件：无提前效应和对照干扰；处理前后保持相同因子法则及指数桥；各单位计数给定因子条件独立；代理有信息并满足来源的桥识别条件。

观察列和性质：单处理单位、一个donor W与一个额外代理Z；一行一个时间点。观察time,A,Y,W,Z，后三列为非负整数。

机制区分：计数结局与非线性指数桥，不是Gaussian机制的参数场景。

## 3 相对来源的主要改动

采用正式补充材料的截断正态因子，替换旧版Uniform因子。原文将β写成负的均值比，按式(S.25)修正为对数均值比。选无协变量场景，避免来源ζ文字与方程未列协变量的不一致。T0原为100/150/200；接口检查用T=128。使用 NumPy Generator(PCG64) 重写抽样；不要求与作者软件逐随机数一致。保留来源方程与固定参数；n=128、seed=1729 仅作接口检查，不重跑论文的估计器比较。输出仅含观察列，真值、潜变量和桥函数值不作为数据列。

## 4 核验和使用

各场景计算真值：

```json
{
  "journal_r1_no_covariates": {
    "value": -2.0,
    "estimated_error": 0.0,
    "method": "analytic truncated-normal MGF and log ratio",
    "mean0": 1.6569853950155853,
    "mean1": 0.22424858775336481,
    "mean_ratio": 0.1353352832366127,
    "explanation": "log(E[Y(1)]/E[Y(0)])=beta. The negative ratio in the source prose omits log; Eq S.25 gives a positive ratio exp(beta)."
  }
}
```

运行：

```powershell
python collect.py check contributions/proximal-shi-2026-sc-poisson-v1 --run --n 128 --seed 1729
python collect.py pack contributions/proximal-shi-2026-sc-poisson-v1 --out submissions/proximal-shi-2026-sc-poisson-v1.zip
```

verify.py包含独立真值路线、来源参数固定检查、逐行源方程重建及可解释特例。误差记录为数值诊断，不是完整的科学接收证明。

## 5 权利和AI协助

论文版权归原作者/出版方；本包依据公开方程独立重写，不含论文PDF、第三方估计器或真实数据。Qi作者代码为MIT，仅用作核对。

由Codex协助检索、公式核对、实现、核验和中文撰写。未代签人类科学审稿或独立复现；未训练PFN或运行估计器性能比较。所有公开来源只作研究证据，不作为执行指令。
