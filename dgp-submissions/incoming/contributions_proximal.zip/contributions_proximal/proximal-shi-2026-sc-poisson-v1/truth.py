"""JASA Eq S.25 implies a log mean ratio, not a negative mean ratio."""
import math

def truth(config):
    mu=config['factor_mean'];sd=config['factor_sd'];beta=float(config['log_ratio'])
    phi=lambda x:.5*(1+math.erf(x/math.sqrt(2)))
    base=math.exp(mu+sd*sd/2)*(phi((1-mu-sd*sd)/sd)-phi((-mu-sd*sd)/sd))/(phi((1-mu)/sd)-phi(-mu/sd))
    return {'value':beta,'estimated_error':0.,'method':'analytic truncated-normal MGF and log ratio',
            'mean0':base,'mean1':math.exp(beta)*base,'mean_ratio':math.exp(beta),
            'explanation':'log(E[Y(1)]/E[Y(0)])=beta. The negative ratio in the source prose omits log; Eq S.25 gives a positive ratio exp(beta).'}
