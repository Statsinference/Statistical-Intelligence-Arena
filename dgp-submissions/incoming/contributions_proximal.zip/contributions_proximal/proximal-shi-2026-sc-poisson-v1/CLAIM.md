# 来源认领记录

proximal-shi-2026-sc-poisson-v1

Shi, X., Li, K. Q., Yu, M., Miao, W., Kuchibhotla, A. K., Hu, M., & Tchetgen Tchetgen, E. (2026). Theory for Identification and Inference with Synthetic Controls: A Proximal Causal Inference Framework. Journal of the American Statistical Association, online publication, 4 June 2026. DOI: 10.1080/01621459.2026.2639734.

定位：JASA 2026 出版社补充材料 J.8，PDF 第49–51页，式(S.25)；r=1、N=2、无协变量。

机制区别：计数结局与非线性指数桥，不是Gaussian机制的参数场景。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
