"""Local scientific checks; no claim of human review or benchmark acceptance."""
from copy import deepcopy
from itertools import product
import math
import numpy as np
from generator import generate
from truth import truth

def check(name,passed,**details):
    return dict(name=name,passed=bool(passed),**details)

def row_check(c, expected, n, seed):
    actual=generate(c,n,seed)
    errors={k:float(np.max(np.abs(np.asarray(actual[k])-v))) for k,v in expected.items()}
    return check('source_equation_row_reconstruction',set(actual)==set(expected) and max(errors.values())<1e-11,max_errors=errors,n=n,seed=seed)

def common(c,source_configs):
    original=deepcopy(c);a=generate(c,128,1729);b=generate(c,128,1729);d=generate(c,128,1730)
    return [check('source_parameter_fixture',c in source_configs),
      check('seed_replay_and_input_immutability',a==b and a!=d and c==original),
      check('observed_finite_columns',all(len(v)==128 and np.isfinite(v).all() for v in a.values()),columns=list(a))]

SOURCE_CONFIGS = [{'factor_mean': 0.5, 'factor_sd': 0.1, 'log_ratio': -2.0}]

def series(rate,transform):
    mass=math.exp(-rate);value=mass*transform(0)
    for k in range(1,100):
        mass*=rate/k;value+=mass*transform(k)
    return value

def verify(config):
    c=config;checks=common(c,SOURCE_CONFIGS);g,w=np.polynomial.legendre.leggauss(100);m0=m1=mass=bridge_error=0.
    for point,wt in zip((g+1)/2,w/2):
        weight=wt*math.exp(-.5*((point-c['factor_mean'])/c['factor_sd'])**2)/(c['factor_sd']*math.sqrt(2*math.pi))
        mass+=weight;m0+=weight*series(math.exp(point),lambda k:k);m1+=weight*series(math.exp(point+c['log_ratio']),lambda k:k)
        bridge_error=max(bridge_error,abs(series(point/math.expm1(1),math.exp)-math.exp(point)))
    m0/=mass;m1/=mass;q=math.log(m1/m0);v=truth(c)['value']
    checks.append(check('independent_poisson_series_and_truncated_normal_integration',abs(q-v)<1e-12 and abs(m0-truth(c)['mean0'])<1e-12,truth=v,independent=q,mean0=m0,mean1=m1,truncation_mass=mass))
    checks.append(check('nonlinear_bridge_poisson_mgf',bridge_error<1e-12,max_error=bridge_error))
    checks.append(check('positive_ratio_and_log_interpretation',m1/m0>0 and abs(m1/m0-math.exp(v))<1e-12,ratio=m1/m0))
    n=37;seed=314159;r=np.random.Generator(np.random.PCG64(seed));t=np.arange(1,n+1);a=(t>n//2).astype(int);u=r.normal(c['factor_mean'],c['factor_sd'],n)
    invalid=np.array([not 0<x<1 for x in u])
    while invalid.any():
        u[invalid]=r.normal(c['factor_mean'],c['factor_sd'],int(invalid.sum()));invalid=np.array([not 0<x<1 for x in u])
    y=r.poisson(np.array([math.exp(ui+c['log_ratio']*ai) for ui,ai in zip(u,a)]));ww=r.poisson(u/math.expm1(1));zz=r.poisson(u/math.expm1(1))
    checks.append(row_check(c,dict(time=t,A=a,Y=y,W=ww,Z=zz),n,seed))
    checks.append(check('null_and_reverse_log_ratio',truth({**c,'log_ratio':0})['value']==0 and truth({**c,'log_ratio':-c['log_ratio']})['value']==-v))
    return {'passed':all(x['passed'] for x in checks),'checks':checks}
