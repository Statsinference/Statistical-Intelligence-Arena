"""Local scientific checks; no claim of human review or benchmark acceptance."""
from copy import deepcopy
from itertools import product
import math
import numpy as np
from generator import generate
from truth import truth

def check(name,passed,**details):
    return dict(name=name,passed=bool(passed),**details)

def row_check(c, expected, n, seed):
    actual=generate(c,n,seed)
    errors={k:float(np.max(np.abs(np.asarray(actual[k])-v))) for k,v in expected.items()}
    return check('source_equation_row_reconstruction',set(actual)==set(expected) and max(errors.values())<1e-11,max_errors=errors,n=n,seed=seed)

def common(c,source_configs):
    original=deepcopy(c);a=generate(c,128,1729);b=generate(c,128,1729);d=generate(c,128,1730)
    return [check('source_parameter_fixture',c in source_configs),
      check('seed_replay_and_input_immutability',a==b and a!=d and c==original),
      check('observed_finite_columns',all(len(v)==128 and np.isfinite(v).all() for v in a.values()),columns=list(a))]

SOURCE_CONFIGS = [{'copula_cov': [[1, 0.25, 0.25], [0.25, 1, 0.25], [0.25, 0.25, 1]], 'selection_intercept': -0.625, 'effect_scale': 1.0}]

def independent(c,order=46):
    # Direct normal-density Legendre cubature, independent of the Hermite truth rule.
    l,w=np.polynomial.legendre.leggauss(order);z=8*l;w=8*w*np.exp(-z*z/2)/math.sqrt(2*math.pi)
    grid=np.stack([g.ravel() for g in np.meshgrid(z,z,z,indexing='ij')],axis=1)
    weights=np.einsum('i,j,k->ijk',w,w,w).ravel();raw=grid@np.linalg.cholesky(c['copula_cov']).T
    sx=np.array([.5*(1+math.erf(x/math.sqrt(2))) for x in raw.flat]).reshape(-1,3).sum(axis=1)
    nodes,wu=np.polynomial.legendre.leggauss(20);numerator=denominator=0.
    for interval in range(3):
        for p,v in zip(nodes,wu):
            t=interval+(1+p)/2;u=-t
            density=t*t/2 if t<1 else ((-2*t*t+6*t-3)/2 if t<2 else (3-t)**2/2)
            target=1/(1+np.exp(c['selection_intercept']+.5*sx+.5*u))
            # Integrating the explicit outcome bridge h=-1+2*sum(W)-sum(X).
            eh=-1+2*(u+sx)-sx
            denominator+=v*density/2*np.dot(weights,target)
            numerator+=v*density/2*np.dot(weights,target*eh)
    return c['effect_scale']*numerator/denominator
def reconstruct(c):
    n=37;seed=314159;r=np.random.Generator(np.random.PCG64(seed));raw=r.standard_normal((n,3))@np.linalg.cholesky(c['copula_cov']).T
    x=np.array([[.5*(1+math.erf(t/math.sqrt(2))) for t in row] for row in raw]);u=r.uniform(-1,0,(n,3));rs=r.random(n);ra=r.random(n);ez=r.normal(0,.5,(n,3));ew=r.normal(0,.5,(n,3));ey=r.normal(0,.5,n)
    out={k:[] for k in [*[f'X{i+1}' for i in range(3)],*[f'W{i+1}' for i in range(3)],*[f'SZ{i+1}' for i in range(3)],'S','SA','SY']}
    for i in range(n):
        sx=sum(x[i]);su=sum(u[i]);s=int(rs[i]<1/(1+math.exp(-c['selection_intercept']-.5*sx-.5*su)));a=int(ra[i]<.5)
        z=[u[i,j]+x[i,j]+ez[i,j] for j in range(3)];w=[u[i,j]+x[i,j]+ew[i,j] for j in range(3)]
        y=.5+su+sx+sum(w)+c['effect_scale']*a*(-1+su+sum(w))+ey[i]
        for j in range(3):out[f'X{j+1}'].append(x[i,j]);out[f'W{j+1}'].append(w[j]);out[f'SZ{j+1}'].append(s*z[j])
        out['S'].append(s);out['SA'].append(s*a);out['SY'].append(s*y)
    return row_check(c,out,n,seed)
def verify(config):
    c=config;checks=common(c,SOURCE_CONFIGS);v=truth(c)['value'];q=independent(c)
    checks.append(check('independent_target_bridge_legendre_cubature',abs(v-q)<1e-6,truth=v,independent=q,difference=abs(v-q)));checks.append(reconstruct(c))
    data=generate(c,200,71);mask=np.array(data['S'])==0
    checks.append(check('source_only_columns_masked_in_target',all(np.all(np.array(data[k])[mask]==0) for k in ['SA','SY','SZ1','SZ2','SZ3']) and mask.any() and (~mask).any()))
    # Normal MGF for q(Z,X)=exp(.53125-.5 sum(Z)) yields the participation odds.
    x=np.array([.2,.5,.8]);u=np.array([-.2,-.5,-.8]);qmean=math.exp(.53125-.5*sum(u+x)+.5*.25*.25*3)
    odds=math.exp(.625-.5*sum(x)-.5*sum(u))
    checks.append(check('participation_and_outcome_bridge_moments',abs(qmean-odds)<1e-12 and abs((-1+2*sum(u+x)-sum(x))-(-1+2*sum(u)+sum(x)))<1e-12))
    checks.append(check('selection_changes_target_population',abs(v-(-2.5*c['effect_scale']))>1e-3,unselected_effect=-2.5*c['effect_scale']))
    checks.append(check('null_effect_control',truth({**c,'effect_scale':0})['value']==0))
    return {'passed':all(x['passed'] for x in checks),'checks':checks}
