"""Integrate target-population selection, Gaussian copula X and Irwin-Hall sum(U)."""
import math
import numpy as np
def _integrate(c,order):
    z,w=np.polynomial.hermite.hermgauss(order);z=z*math.sqrt(2);w=w/math.sqrt(math.pi)
    mesh=np.meshgrid(z,z,z,indexing='ij');g=np.stack([v.ravel() for v in mesh],axis=1)
    wg=np.einsum('i,j,k->ijk',w,w,w).ravel()
    gx=g@np.linalg.cholesky(c['copula_cov']).T
    sx=np.array([.5*(1+math.erf(v/math.sqrt(2))) for v in gx.flat]).reshape(-1,3).sum(axis=1)
    l,v=np.polynomial.legendre.leggauss(24);num=den=0.
    for interval in range(3):
        t=interval+(l+1)/2
        density=.5*(t*t-3*np.maximum(t-1,0)**2+3*np.maximum(t-2,0)**2)
        for uj,wu in zip(-t,v*density/2):
            target=1/(1+np.exp(c['selection_intercept']+.5*sx+.5*uj))
            den+=wu*np.dot(wg,target)
            num+=wu*np.dot(wg,target*(-1+2*uj+sx))
    return num/den,den
def truth(config):
    low,_=_integrate(config,24);value,pr_target=_integrate(config,40)
    return {'value':float(config['effect_scale']*value),'estimated_error':float(abs(config['effect_scale'])*abs(value-low)),
            'method':'3D Gauss-Hermite plus piecewise Gauss-Legendre on sum of three uniforms',
            'target_probability':float(pr_target),
            'explanation':'E[(1-pS)(-1+2 sum(U)+sum(X))]/E[1-pS], multiplied by effect_scale. Quadrature difference is a numerical convergence diagnostic, not a rigorous error bound.'}
