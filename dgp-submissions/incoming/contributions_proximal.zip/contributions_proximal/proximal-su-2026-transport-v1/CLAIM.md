# 来源认领记录

proximal-su-2026-transport-v1

Su, Z., Rytgaard, H. C., Ravn, H., & Eriksson, F. (2026). Proximal indirect comparison. Biometrika, 113(1), asaf044. DOI: 10.1093/biomet/asaf044.

定位：§5.1，arXiv v2 PDF 第10–11页；Supplement S4.1 第30–31页。

机制区别：两来源观察模式和对S=0目标人群的效果迁移。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
