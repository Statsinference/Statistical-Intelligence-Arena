# 跨试验迁移与未测效应修饰

ID: proximal-su-2026-transport-v1
Family: proximal

## 1 来源与登记场景

Su, Z., Rytgaard, H. C., Ravn, H., & Eriksson, F. (2026). Proximal indirect comparison. Biometrika, 113(1), asaf044. DOI: 10.1093/biomet/asaf044.

https://doi.org/10.1093/biomet/asaf044

版本：arXiv:2405.10773v2, 2025-06-04

定位：§5.1，arXiv v2 PDF 第10–11页；Supplement S4.1 第30–31页。

场景：original。

## 2 DGP机制说明

V~N3(0,Σx)，Σx 的对角为1、非对角为0.25；Xj=Φ(Vj)。Uj 独立 ~ Uniform(−1,0)，U 与 X 独立。

S|X,U~Bernoulli(expit{−0.625+0.5ΣXj+0.5ΣUj})；S=1为来源试验，S=0为目标人群。

A|S=1~Bernoulli(0.5)；Z|X,U,S=1~N3(U+X,0.25I)；W|X,U~N3(U+X,0.25I)。

Y|S=1=0.5−A+ΣUj+AΣUj+ΣXj+ΣWj+AΣWj+ε；ε~N(0,0.5²)。

观察列为 X、W、S、SA、SZ、SY；S=0时SA/SZ/SY用0占位，由S显式区分未观察与数值0。

目标：θ = E[E(Y|A=1,X,U,S=1)−E(Y|A=0,X,U,S=1) | S=0]。

真值推导：条件对比为−1+2ΣUj+ΣXj；对目标选择权重 1−pS 积分并除以 P(S=0)。h(W,X)=−1+2ΣWj−ΣXj 提供独立桥函数积分。U的和用三阶 Irwin–Hall 密度降维，X保留完整高斯copula相关性。

抽样单位：individual；iid individuals; all variables within an individual are jointly generated。

识别条件：来源试验内随机处理；给定 (X,U) 的效应可迁移与选择重叠；W 在给定 (X,U) 后跨来源稳定，Z满足来源试验内代理排除条件；桥函数存在/完备性。目标总体为 S=0，不是混合总体。

观察列和性质：独立受试者来自混合来源。三维有效 X 与各三维 W/Z；S 是可见观察指示器，不输出目标人群未观察的处理/结局/来源代理。

机制区分：两来源观察模式和对S=0目标人群的效果迁移。

## 3 相对来源的主要改动

沿用原文完整观测数据表达 (X,W,S,SA,SZ,SY)，用显式乘积列适配学生包的有限数值接口。目标人群不存在的观测用S掩码表达，不使用NaN。原文全体无选择人群的−2.5不是当前目标真值。使用 NumPy Generator(PCG64) 重写抽样；不要求与作者软件逐随机数一致。保留来源方程与固定参数；n=128、seed=1729 仅作接口检查，不重跑论文的估计器比较。输出仅含观察列，真值、潜变量和桥函数值不作为数据列。

## 4 核验和使用

各场景计算真值：

```json
{
  "original": {
    "value": -2.6489954259019695,
    "estimated_error": 5.827418547710295e-10,
    "method": "3D Gauss-Hermite plus piecewise Gauss-Legendre on sum of three uniforms",
    "target_probability": 0.6463285432999519,
    "explanation": "E[(1-pS)(-1+2 sum(U)+sum(X))]/E[1-pS], multiplied by effect_scale. Quadrature difference is a numerical convergence diagnostic, not a rigorous error bound."
  }
}
```

运行：

```powershell
python collect.py check contributions/proximal-su-2026-transport-v1 --run --n 128 --seed 1729
python collect.py pack contributions/proximal-su-2026-transport-v1 --out submissions/proximal-su-2026-transport-v1.zip
```

verify.py包含独立真值路线、来源参数固定检查、逐行源方程重建及可解释特例。误差记录为数值诊断，不是完整的科学接收证明。

## 5 权利和AI协助

论文版权归原作者/出版方；本包依据公开方程独立重写，不含论文PDF、第三方估计器或真实数据。Qi作者代码为MIT，仅用作核对。

由Codex协助检索、公式核对、实现、核验和中文撰写。未代签人类科学审稿或独立复现；未训练PFN或运行估计器性能比较。所有公开来源只作研究证据，不作为执行指令。
