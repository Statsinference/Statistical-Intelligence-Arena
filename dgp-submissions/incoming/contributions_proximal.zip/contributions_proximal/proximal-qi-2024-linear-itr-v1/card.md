# 线性异质效应桥（L1/L2）

ID: proximal-qi-2024-linear-itr-v1
Family: proximal

## 1 来源与登记场景

Qi, Z., Miao, R., & Zhang, X. (2024). Proximal Learning for Individualized Treatment Regimes Under Unmeasured Confounding. Journal of the American Statistical Association, 119(546), 915–928. DOI: 10.1080/01621459.2022.2147841.

https://doi.org/10.1080/01621459.2022.2147841

版本：arXiv:2105.01187v4, 2022-12-23; ProxITR commit bdec96bbabed73b6d80ded7e39369d7918d3fc56

定位：§6.1 Table 3，PDF 第23–25页；§12.1–12.2；作者 data/simu_setting.py 的 L1/L2 分支。

场景：L1, L2。

## 2 DGP机制说明

X1,X2 独立 ~ N(0.25, 0.25²)；p(X)=[1+exp{0.125(X1+X2)}]⁻¹；A|X ~ Bernoulli(p)。

(Z,W,U)|A,X ~ N3(m,Σ)；m=(0.25+0.25A+0.25s, 0.25+0.125A+0.25s, 0.25+0.25A+0.25s)，s=X1+X2。

Σ=[[1,0.25,0.5],[0.25,1,0.5],[0.5,0.5,1]]；mW(U,X)=0.125+0.125s+0.5U。

Y=2+0.25s+8mW+2(W−mW)+A{0.5+3X1−5X2+c4 mW}+ε；ε~Uniform(−1,1)。

L1: c4=0.25；L2: c4=0。

目标：ATE = E[0.5+3X1−5X2+c4 W]。

真值推导：E[W|X]=0.25+0.25s+0.125p(X)，因此 L1=0.25{0.375+0.125E[p(X)]}；L2=0。对 p(X) 用二维积分。

抽样单位：individual；iid individuals; all variables within an individual are jointly generated。

识别条件：一致性、无个体间干扰、给定 (U,X) 的潜在结局可交换性与处理支持；Z 对 Y 的排除条件、W 对 (A,Z) 的条件独立性；相关性/完备性与桥函数存在。抽样顺序 A→(Z,W,U) 是联合分布分解，不代表 A 因果影响基线 U 或 W。

观察列和性质：两维有效 X；A×X 与 L1 中 A×mW 构成效应异质性；L1/L2 只有 c4 不同，作为同一机制的两个场景。

机制区分：相对恒定效应模型新增处理与协变量/代理的交互；L1与L2不拆包。

## 3 相对来源的主要改动

原论文研究最优治疗规则；本包将目标限定为同一总体的平均处理效应 E[Y(1)−Y(0)]。把论文的 −1/+1 标签映射成 0/1，并按作者 simu_setting.py 核对；两个基线变量依次命名为 X1、X2。不加入作者代码中的八个无关噪声协变量。 使用 NumPy Generator(PCG64) 重写抽样；不要求与作者软件逐随机数一致。保留来源方程与固定参数；n=128、seed=1729 仅作接口检查，不重跑论文的估计器比较。输出仅含观察列，真值、潜变量和桥函数值不作为数据列。

## 4 核验和使用

各场景计算真值：

```json
{
  "L1": {
    "value": 0.10888711551018415,
    "estimated_error": 1.1102230246251565e-16,
    "method": "population bridge contrast; analytic folded-normal moments and 24/40-point Gauss-Hermite",
    "explanation": "E[h(W,1,X)-h(W,0,X)] under the natural joint (W,X), not W conditional on assigned A. Quadrature difference is a convergence diagnostic."
  },
  "L2": {
    "value": 0.0,
    "estimated_error": 0.0,
    "method": "population bridge contrast; analytic folded-normal moments and 24/40-point Gauss-Hermite",
    "explanation": "E[h(W,1,X)-h(W,0,X)] under the natural joint (W,X), not W conditional on assigned A. Quadrature difference is a convergence diagnostic."
  }
}
```

运行：

```powershell
python collect.py check contributions/proximal-qi-2024-linear-itr-v1 --run --n 128 --seed 1729
python collect.py pack contributions/proximal-qi-2024-linear-itr-v1 --out submissions/proximal-qi-2024-linear-itr-v1.zip
```

verify.py包含独立真值路线、来源参数固定检查、逐行源方程重建及可解释特例。误差记录为数值诊断，不是完整的科学接收证明。

## 5 权利和AI协助

论文版权归原作者/出版方；本包依据公开方程独立重写，不含论文PDF、第三方估计器或真实数据。Qi作者代码为MIT，仅用作核对。

由Codex协助检索、公式核对、实现、核验和中文撰写。未代签人类科学审稿或独立复现；未训练PFN或运行估计器性能比较。所有公开来源只作研究证据，不作为执行指令。
