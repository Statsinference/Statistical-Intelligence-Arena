# 来源认领记录

proximal-qi-2024-linear-itr-v1

Qi, Z., Miao, R., & Zhang, X. (2024). Proximal Learning for Individualized Treatment Regimes Under Unmeasured Confounding. Journal of the American Statistical Association, 119(546), 915–928. DOI: 10.1080/01621459.2022.2147841.

定位：§6.1 Table 3，PDF 第23–25页；§12.1–12.2；作者 data/simu_setting.py 的 L1/L2 分支。

机制区别：相对恒定效应模型新增处理与协变量/代理的交互；L1与L2不拆包。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
