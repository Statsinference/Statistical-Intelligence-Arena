"""Local scientific checks; no claim of human review or benchmark acceptance."""
from copy import deepcopy
from itertools import product
import math
import numpy as np
from generator import generate
from truth import truth

def check(name,passed,**details):
    return dict(name=name,passed=bool(passed),**details)

def row_check(c, expected, n, seed):
    actual=generate(c,n,seed)
    errors={k:float(np.max(np.abs(np.asarray(actual[k])-v))) for k,v in expected.items()}
    return check('source_equation_row_reconstruction',set(actual)==set(expected) and max(errors.values())<1e-11,max_errors=errors,n=n,seed=seed)

def common(c,source_configs):
    original=deepcopy(c);a=generate(c,128,1729);b=generate(c,128,1729);d=generate(c,128,1730)
    return [check('source_parameter_fixture',c in source_configs),
      check('seed_replay_and_input_immutability',a==b and a!=d and c==original),
      check('observed_finite_columns',all(len(v)==128 and np.isfinite(v).all() for v in a.values()),columns=list(a))]

SOURCE_CONFIGS = [{'noise_sd': 0.5, 'direct_a0': 1.14, 'direct_a1': 1.0, 'regime_treated': [1, 1], 'regime_control': [0, 0]}]

def integrated(c,regime):
    z,w=np.polynomial.hermite.hermgauss(3);z=z*math.sqrt(2);w=w/math.sqrt(math.pi)
    result=0.;a0,a1=regime
    for idx in product(range(3),repeat=5):
        e=[z[i]*c['noise_sd'] for i in idx];weight=math.prod(w[i] for i in idx)
        x0=-.35+e[0];u0=.35+e[1];x1=.2+.7*a0+.7*x0+e[2];u1=.2+.7*a0+.7*u0+e[3]
        y=-1.3+c['direct_a1']*a1+c['direct_a0']*a0+.5*x1-.7*u1+.2*x0-.7*u0+e[4]
        result+=weight*y
    return result
def reconstruct(c):
    n=37;seed=314159;r=np.random.Generator(np.random.PCG64(seed));s=c['noise_sd']
    ex=r.normal(size=n);eu=r.normal(size=n);ra=r.random(n);ez=r.normal(size=n);ew=r.normal(size=n);ex1=r.normal(size=n);eu1=r.normal(size=n);ra1=r.random(n);ez1=r.normal(size=n);ew1=r.normal(size=n);ey=r.normal(size=n)
    out={k:[] for k in ['X0','A0','Z0','W0','X1','A1','Z1','W1','Y']}
    for i in range(n):
        x=-.35+s*ex[i];u=.35+s*eu[i];a=int(ra[i]<1/(1+math.exp(.5-.35*x+.35*u)))
        z=.2+.5*a+.5*x+.75*u+s*ez[i];w=.2+.5*x-.95*u+s*ew[i]
        xx=.2+.7*a+.7*x+s*ex1[i];uu=.2+.7*a+.7*u+s*eu1[i]
        aa=int(ra1[i]<1/(1+math.exp(.5-.5*a-.35*(x+xx)-.35*(u+uu))))
        zz=.2+.5*(a+aa)+.5*(x+xx)-.75*(u+uu)+s*ez1[i]
        ww=.35+.45*(x+xx)-.85*(u+uu)+s*ew1[i]
        y=-1.3+c['direct_a1']*aa+c['direct_a0']*a+.5*xx-.7*uu+.2*x-.7*u+s*ey[i]
        for key,value in zip(out,[x,a,z,w,xx,aa,zz,ww,y]):out[key].append(value)
    return row_check(c,out,n,seed)
def verify(config):
    c=config;checks=common(c,SOURCE_CONFIGS);q=integrated(c,c['regime_treated'])-integrated(c,c['regime_control']);v=truth(c)['value']
    checks.append(check('independent_five_dimensional_sequential_g_formula',abs(v-q)<1e-12,truth=v,independent=q))
    checks.append(reconstruct(c))
    null={**c,'regime_treated':c['regime_control']};reverse={**c,'regime_treated':c['regime_control'],'regime_control':c['regime_treated']}
    checks.append(check('null_and_reverse_regimes',truth(null)['value']==0 and abs(truth(reverse)['value']+v)<1e-12))
    checks.append(check('query_does_not_change_observed_data',generate(c,32,3)==generate(null,32,3)))
    checks.append(check('source_msmm_slope_one',abs(integrated(c,[1,0])-integrated(c,[0,0])-1)<1e-12 and abs(integrated(c,[0,1])-integrated(c,[0,0])-1)<1e-12))
    return {'passed':all(x['passed'] for x in checks),'checks':checks}
