# 来源认领记录

proximal-ying-2023-longitudinal-v1

Ying, A., Miao, W., Shi, X., & Tchetgen Tchetgen, E. J. (2023). Proximal causal inference for complex longitudinal studies. Journal of the Royal Statistical Society Series B, 85(3), 684–704. DOI: 10.1093/jrsssb/qkad020.

定位：Supplement F.1，合并 PDF 第47–48页，式(F.1)–(F.3)；F.2 兼容性证明。

机制区别：处理改变下一期混杂变量，采用序贯proximal识别。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
