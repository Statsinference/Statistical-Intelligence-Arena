"""Propagate regime means through time-varying covariates and confounders."""
def truth(config):
    c=config
    d0=c['regime_treated'][0]-c['regime_control'][0]
    d1=c['regime_treated'][1]-c['regime_control'][1]
    value=(c['direct_a0']+.5*.7-.7*.7)*d0+c['direct_a1']*d1
    return {'value':value,'estimated_error':0.,'method':'analytic sequential intervention means',
            'explanation':'The A0 paths through X1 and U1 contribute +0.35 and -0.49. For source coefficients E[Y(1,1)-Y(0,0)]=2, twice the source MSMM slope beta1=1.'}
