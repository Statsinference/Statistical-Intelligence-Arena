# 两期处理与时变混杂反馈

ID: proximal-ying-2023-longitudinal-v1
Family: proximal

## 1 来源与登记场景

Ying, A., Miao, W., Shi, X., & Tchetgen Tchetgen, E. J. (2023). Proximal causal inference for complex longitudinal studies. Journal of the Royal Statistical Society Series B, 85(3), 684–704. DOI: 10.1093/jrsssb/qkad020.

https://doi.org/10.1093/jrsssb/qkad020

版本：arXiv:2109.07030v5, 2022-08-03

定位：Supplement F.1，合并 PDF 第47–48页，式(F.1)–(F.3)；F.2 兼容性证明。

场景：original。

## 2 DGP机制说明

X0~N(−0.35,0.5²)，U0~N(0.35,0.5²)，相互独立；p0=[1+exp(0.5−0.35X0+0.35U0)]⁻¹。

A0~Bernoulli(p0)；Z0=0.2+0.5A0+0.5X0+0.75U0+εz0；W0=0.2+0.5X0−0.95U0+εw0。

X1=0.2+0.7A0+0.7X0+εx1；U1=0.2+0.7A0+0.7U0+εu1。

p1=[1+exp{0.5−0.5A0−0.35(X0+X1)−0.35(U0+U1)}]⁻¹；A1~Bernoulli(p1)。

Z1=0.2+0.5(A0+A1)+0.5(X0+X1)−0.75(U0+U1)+εz1。

W1=0.35+0.45(X0+X1)−0.85(U0+U1)+εw1。

Y=−1.3+A1+1.14A0+0.5X1−0.7U1+0.2X0−0.7U0+εy；各新增 ε 独立 ~ N(0,0.5²)。

目标：E[Y(1,1)−Y(0,0)] = 2。

真值推导：干预 A0 对末期均值的总系数为1.14+0.5×0.7−0.7×0.7=1；A1系数为1。与原文 MSMM 斜率 β1=1 一致，当前对比为2β1。

抽样单位：individual；iid individuals; longitudinal dependence within each row。

识别条件：序贯一致性、无干扰、给定潜在历史的序贯可交换性和处理支持；每期代理的序贯排除/独立条件、相关性及序贯桥函数存在（来源 F.2）。

观察列和性质：一人一行，保留 X0,A0,Z0,W0,X1,A1,Z1,W1,Y；基线 X0 一维，X1 为治疗后时变协变量，不把两期当独立个体。

机制区分：处理改变下一期混杂变量，采用序贯proximal识别。

## 3 相对来源的主要改动

将原文向量参数 (β0,β1) 转成明确的静态方案对比 (1,1) 与 (0,0)。数据保持宽表，不扁平化重复测量。使用 NumPy Generator(PCG64) 重写抽样；不要求与作者软件逐随机数一致。保留来源方程与固定参数；n=128、seed=1729 仅作接口检查，不重跑论文的估计器比较。输出仅含观察列，真值、潜变量和桥函数值不作为数据列。

## 4 核验和使用

各场景计算真值：

```json
{
  "original": {
    "value": 1.9999999999999998,
    "estimated_error": 0.0,
    "method": "analytic sequential intervention means",
    "explanation": "The A0 paths through X1 and U1 contribute +0.35 and -0.49. For source coefficients E[Y(1,1)-Y(0,0)]=2, twice the source MSMM slope beta1=1."
  }
}
```

运行：

```powershell
python collect.py check contributions/proximal-ying-2023-longitudinal-v1 --run --n 128 --seed 1729
python collect.py pack contributions/proximal-ying-2023-longitudinal-v1 --out submissions/proximal-ying-2023-longitudinal-v1.zip
```

verify.py包含独立真值路线、来源参数固定检查、逐行源方程重建及可解释特例。误差记录为数值诊断，不是完整的科学接收证明。

## 5 权利和AI协助

论文版权归原作者/出版方；本包依据公开方程独立重写，不含论文PDF、第三方估计器或真实数据。Qi作者代码为MIT，仅用作核对。

由Codex协助检索、公式核对、实现、核验和中文撰写。未代签人类科学审稿或独立复现；未训练PFN或运行估计器性能比较。所有公开来源只作研究证据，不作为执行指令。
