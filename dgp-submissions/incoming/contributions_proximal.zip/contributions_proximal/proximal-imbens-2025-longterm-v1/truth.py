"""Sum all directed treatment paths; fixed coefficients are in config.json."""
import numpy as np

def truth(config):
    b={key:np.asarray(value) for key,value in config['coefficients'].items()}
    d2=float(b['tau2'])+float(b['alpha2']@b['tau1'])
    d3=b['tau3']+b['alpha3']*d2
    value=config['effect_scale']*(float(b['tau_y'])+float(b['alpha_y']@d3))
    return {'value':float(value),'estimated_error':0.,'method':'analytic total effect via all directed treatment paths',
            'explanation':'Fixed-scenario E[Y(1)-Y(0)] in the experimental population. Invertible transformations apply only to X and short-term outcomes, not to Y. Treatment coefficients stay fixed across sampling seeds.'}
