# 来源认领记录

proximal-imbens-2025-longterm-v1

Imbens, G., Kallus, N., Mao, X., & Wang, Y. (2025). Long-term causal inference under persistent confounding via data combination. Journal of the Royal Statistical Society Series B: Statistical Methodology, 87(2), 362–388. DOI: 10.1093/jrsssb/qkae095.

定位：JRSS-B 正式版 §7.2，Table 2；作者稿 PDF 第23页；Example 2、Appendix B.2；作者 minimax/data.R 用于检查维度与运算顺序。

机制区别：三组处理后代理、实验组缺长期Y、观察组受持久潜在混杂的数据融合结构。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
