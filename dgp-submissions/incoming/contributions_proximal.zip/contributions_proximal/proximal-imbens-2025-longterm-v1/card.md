# 序贯代理与长期效应数据融合

ID: proximal-imbens-2025-longterm-v1
Family: proximal

## 1 来源与登记场景

Imbens, G., Kallus, N., Mao, X., & Wang, Y. (2025). Long-term causal inference under persistent confounding via data combination. Journal of the Royal Statistical Society Series B: Statistical Methodology, 87(2), 362–388. DOI: 10.1093/jrsssb/qkae095.

https://doi.org/10.1093/jrsssb/qkae095

版本：JRSS-B 正式版 §7.2；已接受作者稿 arXiv:2202.07234v5（2024-08-31）第23页；作者仓库 commit 20d046e9b959679c1ac65f25f5733119d460b44c，采用正文数值并记录代码差异

定位：JRSS-B 正式版 §7.2，Table 2；作者稿 PDF 第23页；Example 2、Appendix B.2；作者 minimax/data.R 用于检查维度与运算顺序。

场景：paper_q2_p5_fixed_design。

## 2 DGP机制说明

两组独立样本：G=1为观察组，G=0为实验组。X̃,U 独立 ~ N5(0,0.5I)。

P(A=1|X̃,U,G=1)=[1+exp(κxᵀX̃+κuᵀU)]⁻¹；实验组处理概率为1/2。

S̃1=τ1A+β1X̃+γ1U+ε1；S̃2=τ2A+α2S̃1+β2X̃+γ2U+ε2。

S̃3=τ3A+α3S̃2+β3X̃+γ3U+ε3；Y=τyA+αyᵀS̃3+βyᵀX̃+γyᵀU+εy。

S̃1,S̃3为5维，S̃2,Y为标量；各误差分量独立 ~ N(0,0.5)。X,S1,S2,S3逐项变换为g(v)=sign(v)|v|²。

系数先取Uniform(0,1)方向，再将向量及列范数归一至0.5；冻结设计seed=20261023的一个实现，完整数值见config.json；τ2=τy=0.5。

目标：τ = E[Y(1)−Y(0)|G=0]，给定登记的固定系数。

真值推导：τ=τy+αyᵀ{τ3+α3(τ2+α2τ1)}。独立核验对两臂结构方程做精确仿射球面求积；g可逆且不作用于Y，故不改变该目标。

抽样单位：independent individuals from two samples；independent rows conditional on fixed source membership; sequential dependence within each row。

识别条件：一致性、无干扰，实验组随机处理；两组共享潜在结构和基线分布；给定U及中间短期结局的序贯代理条件；代理载荷满秩、桥存在及支持条件。这里的代理允许受处理影响，属于来源明确发展的proximal扩展。

观察列和性质：五维有效X和三组短期结局；两组按约1:1固定样本量抽样。观察X1–X5,S1_1–S1_5,S2,S3_1–S3_5,G,A,GY；实验组Y不可见，以GY=0及G标识。

机制区分：三组处理后代理、实验组缺长期Y、观察组受持久潜在混杂的数据融合结构。

## 3 相对来源的主要改动

选择正文p=5,q=2，固定一次系数抽取以供truth(config)定义稳定真值；不声称复现原文每轮重抽参数的200次实验。正文协变量方差与系数范数均为0.5；作者代码分别用1和√0.5，本包按正文，并按列向量方程归一矩阵列。τy标量固定0.5。保留来源实验组Y缺失结构。使用 NumPy Generator(PCG64) 重写抽样；不要求与作者软件逐随机数一致。n=128、seed=1729 仅作接口检查，不重跑论文的估计器比较。输出仅含观察列，真值、潜变量和桥函数值不作为数据列。

## 4 核验和使用

各场景计算真值：

```json
{
  "paper_q2_p5_fixed_design": {
    "value": 0.8797723708687131,
    "estimated_error": 0.0,
    "method": "analytic total effect via all directed treatment paths",
    "explanation": "Fixed-scenario E[Y(1)-Y(0)] in the experimental population. Invertible transformations apply only to X and short-term outcomes, not to Y. Treatment coefficients stay fixed across sampling seeds."
  }
}
```

运行：

```powershell
python collect.py check contributions/proximal-imbens-2025-longterm-v1 --run --n 128 --seed 1729
python collect.py pack contributions/proximal-imbens-2025-longterm-v1 --out submissions/proximal-imbens-2025-longterm-v1.zip
```

verify.py包含独立真值路线、来源参数固定检查、逐行源方程重建及可解释特例。误差记录为数值诊断，不是完整的科学接收证明。

## 5 权利和AI协助

论文版权归原作者/出版方；本包依据公开方程独立重写，不含论文PDF、第三方估计器或真实数据。Qi作者代码为MIT，仅用作核对。

由Codex协助检索、公式核对、实现、核验和中文撰写。未代签人类科学审稿或独立复现；未训练PFN或运行估计器性能比较。所有公开来源只作研究证据，不作为执行指令。
