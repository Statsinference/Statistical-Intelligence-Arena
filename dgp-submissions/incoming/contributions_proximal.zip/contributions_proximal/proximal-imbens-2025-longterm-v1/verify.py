"""Local scientific checks; no claim of human review or benchmark acceptance."""
from copy import deepcopy
from itertools import product
import math
import numpy as np
from generator import generate
from truth import truth

def check(name,passed,**details):
    return dict(name=name,passed=bool(passed),**details)

def row_check(c, expected, n, seed):
    actual=generate(c,n,seed)
    errors={k:float(np.max(np.abs(np.asarray(actual[k])-v))) for k,v in expected.items()}
    return check('source_equation_row_reconstruction',set(actual)==set(expected) and max(errors.values())<1e-11,max_errors=errors,n=n,seed=seed)

def common(c,source_configs):
    original=deepcopy(c);a=generate(c,128,1729);b=generate(c,128,1729);d=generate(c,128,1730)
    return [check('source_parameter_fixture',c in source_configs),
      check('seed_replay_and_input_immutability',a==b and a!=d and c==original),
      check('observed_finite_columns',all(len(v)==128 and np.isfinite(v).all() for v in a.values()),columns=list(a))]

SOURCE_CONFIGS = [{'p': 5, 'latent_dim': 5, 'power': 2.0, 'baseline_variance': 0.5, 'noise_variance': 0.5, 'effect_scale': 1.0, 'design_seed': 20261023, 'coefficients': {'kappa_x': [0.10293310421191341, 0.19469450617267828, 0.31007286220688596, 0.10325500045307012, 0.30772073431561664], 'kappa_u': [0.09919714487276697, 0.06453700649757634, 0.32334920616951696, 0.35601879340793857, 0.06848949445952891], 'tau1': [0.23049302220376702, 0.08006294692308698, 0.28360956134573545, 0.29003988827486016, 0.160951455936723], 'beta1': [[0.2565759068242021, 0.32165460441311067, 0.12984896790106742, 0.18006814123355258, 0.3089354129553848], [0.0659992023465683, 0.2791981726875588, 0.32577396970894984, 0.3976105447498496, 0.37468868104389813], [0.2672029816325738, 0.16048056602360725, 0.34965720463434685, 0.03838879452702383, 0.06263978591428829], [0.21362134940072688, 0.12771643261969867, 0.012954882491292397, 0.20631719444505173, 0.08795253164827112], [0.2505621579844613, 0.16285329777260893, 0.06769472994281855, 0.1242611562295553, 0.05007906066353274]], 'gamma1': [[0.09994601161820321, 0.07947675129422592, 0.04942319332061586, 0.26341910649327194, 0.20038335516962263], [0.09631758132276609, 0.24224955482993152, 0.2829162156152717, 0.2450184589428931, 0.3842360257106106], [0.294765480134071, 0.06962529808063762, 0.18182876584799906, 0.2148426610635728, 0.04421936087467044], [0.15587130251138728, 0.14607756698841062, 0.13670362105561074, 0.014309188943355738, 0.19301870845747926], [0.34576172006814243, 0.39851256125540696, 0.34024429870962375, 0.27242284634450575, 0.1516496416953306]], 'tau2': 0.5, 'alpha2': [0.5, 0.5, 0.5, 0.5, 0.5], 'beta2': [0.5, 0.5, 0.5, 0.5, 0.5], 'gamma2': [0.5, 0.5, 0.5, 0.5, 0.5], 'tau3': [0.1904829053389909, 0.16090524567946038, 0.16783075403336312, 0.35721025566886355, 0.1790514896113054], 'alpha3': [0.17899040120753815, 0.2791181484697104, 0.35143721563135416, 0.11955616409877892, 0.047473177328594754], 'beta3': [[0.27125042777007435, 0.2584249430670121, 0.16332833425797064, 0.12193223870264232, 0.3643445964718717], [0.04389055378286149, 0.13118978649890242, 0.09993937044891249, 0.33148506716916726, 0.3138050756089748], [0.23277348268515433, 0.3287457579985182, 0.1918212567766318, 0.04263676364058202, 0.009248250051630439], [0.32776470762497406, 0.19445179291523854, 0.34385576591817596, 0.32480033314039547, 0.1044940226701467], [0.11350606555301286, 0.14184680309831751, 0.24146178819069852, 0.1339291954241485, 0.0881751588656805]], 'gamma3': [[0.287425774757792, 0.07907036944268181, 0.08098320656944324, 0.3277523642036832, 0.26544516959188513], [0.20540381268654415, 0.30597004037421666, 0.32860025584464764, 0.1721068834078018, 0.23877663383697462], [0.19658361747437178, 0.004894035058239602, 0.35470095153691483, 0.22877272065988746, 0.23814916354250767], [0.21724858820047696, 0.33590424274381325, 0.09758573219512541, 0.23683424044924098, 0.2099581165560225], [0.19837749369397623, 0.19306630777313835, 0.011307164247124572, 0.06730671047714172, 0.14740131027256934]], 'tau_y': 0.5, 'alpha_y': [0.14226292126486106, 0.42568130713269664, 0.047590936626025114, 0.20959831820436828, 0.04858326613088896], 'beta_y': [0.23612518005490915, 0.059736190680819284, 0.3327835628764011, 0.043373291891701624, 0.2793749178017726], 'gamma_y': [0.1827424015391337, 0.25401964982289466, 0.26828372184044447, 0.18083596144526698, 0.21771869884593953]}}]

def potential(c,a,noise):
    # Scalar loop structural equations, independent of the generator's matrix operations.
    b=c['coefficients'];p=c['p'];k=c['latent_dim'];s=c['effect_scale'];dot=lambda x,y:sum(t*v for t,v in zip(x,y))
    x=noise[:p];u=noise[p:p+k];e=noise[p+k:]
    s1=[s*a*b['tau1'][j]+dot(b['beta1'][j],x)+dot(b['gamma1'][j],u)+e[j] for j in range(k)]
    s2=s*a*b['tau2']+dot(b['alpha2'],s1)+dot(b['beta2'],x)+dot(b['gamma2'],u)+e[k]
    s3=[s*a*b['tau3'][j]+b['alpha3'][j]*s2+dot(b['beta3'][j],x)+dot(b['gamma3'][j],u)+e[k+1+j] for j in range(k)]
    return s*a*b['tau_y']+dot(b['alpha_y'],s3)+dot(b['beta_y'],x)+dot(b['gamma_y'],u)+e[2*k+1],s1,s2,s3

def reconstruct(c):
    n=37;seed=314159;r=np.random.Generator(np.random.PCG64(seed));p=c['p'];k=c['latent_dim'];b=c['coefficients']
    x=r.normal(0,math.sqrt(c['baseline_variance']),(n,p));u=r.normal(0,math.sqrt(c['baseline_variance']),(n,k));unif=r.random(n)
    sd=math.sqrt(c['noise_variance']);e1=r.normal(0,sd,(n,k));e2=r.normal(0,sd,n);e3=r.normal(0,sd,(n,k));ey=r.normal(0,sd,n)
    out={name:[] for name in [*[f'X{j+1}' for j in range(p)],*[f'S1_{j+1}' for j in range(k)],'S2',*[f'S3_{j+1}' for j in range(k)],'G','A','GY']}
    tr=lambda v:math.copysign(abs(v)**c['power'],v)
    for i in range(n):
        g=int(i<n//2);eta=sum(x[i,j]*b['kappa_x'][j] for j in range(p))+sum(u[i,j]*b['kappa_u'][j] for j in range(k));prob=1/(1+math.exp(eta)) if g else .5;a=int(unif[i]<prob)
        y,s1,s2,s3=potential(c,a,[*x[i],*u[i],*e1[i],e2[i],*e3[i],ey[i]])
        for j in range(p):out[f'X{j+1}'].append(tr(x[i,j]))
        for j in range(k):out[f'S1_{j+1}'].append(tr(s1[j]));out[f'S3_{j+1}'].append(tr(s3[j]))
        out['S2'].append(tr(s2));out['G'].append(g);out['A'].append(a);out['GY'].append(g*y)
    return row_check(c,out,n,seed)

def verify(config):
    c=config;checks=common(c,SOURCE_CONFIGS);b={key:np.asarray(value) for key,value in c['coefficients'].items()};k=c['latent_dim'];d=c['p']+k+2*k+2
    # Degree-two spherical cubature is exact for each affine potential mean.
    means=[]
    for a in (0,1):
        total=0.
        for j in range(d):
            for sign in (-1,1):
                z=[0.]*d;var=c['baseline_variance'] if j<c['p']+k else c['noise_variance'];z[j]=sign*math.sqrt(d*var);total+=potential(c,a,z)[0]/(2*d)
        means.append(total)
    q=means[1]-means[0];v=truth(c)['value']
    checks.append(check('independent_sequential_intervention_cubature',abs(q-v)<1e-12,truth=v,independent=q,mean0=means[0],mean1=means[1]))
    checks.append(reconstruct(c))
    # Outcome bridge coefficients in the untransformed coordinates.
    bridge=np.linalg.solve(b['gamma3'].T,b['gamma3'].T@b['alpha_y']+b['gamma_y'])
    residual=float(np.max(np.abs(b['gamma3'].T@bridge-b['gamma3'].T@b['alpha_y']-b['gamma_y'])))
    checks.append(check('full_rank_proxy_and_outcome_bridge',np.linalg.matrix_rank(b['gamma1'])==k and np.linalg.matrix_rank(b['gamma3'])==k and residual<1e-12,residual=residual))
    data=generate(c,128,71);mask=np.asarray(data['G'])==0
    checks.append(check('experimental_outcome_mask_and_two_sample_sizes',np.all(np.asarray(data['GY'])[mask]==0) and int(mask.sum())==64 and set(data)==set(generate(c,37,5))))
    vals=np.array([-3.,-.2,0.,.7,4.]);transformed=np.sign(vals)*np.abs(vals)**c['power'];restored=np.sign(transformed)*np.abs(transformed)**(1/c['power'])
    checks.append(check('invertible_proxy_transform_preserves_truth',np.allclose(vals,restored) and truth({**c,'power':1})['value']==v))
    checks.append(check('null_and_reverse_effect',truth({**c,'effect_scale':0})['value']==0 and abs(truth({**c,'effect_scale':-1})['value']+v)<1e-12))
    norms=[np.linalg.norm(b[name]) for name in ['kappa_x','kappa_u','tau1','tau3','alpha_y','beta_y','gamma_y']]
    norms += [np.linalg.norm(b[name],axis=0) for name in ['beta1','gamma1','beta3','gamma3']]
    norms += [np.abs(b['alpha2']),np.linalg.norm(b['alpha3']),np.abs(b['beta2']),np.abs(b['gamma2'])]
    checks.append(check('journal_variances_and_column_norms',c['baseline_variance']==.5 and c['noise_variance']==.5 and all(np.allclose(t,.5) for t in norms)))
    return {'passed':all(x['passed'] for x in checks),'checks':checks}
