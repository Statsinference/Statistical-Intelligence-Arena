# 来源认领记录

proximal-qi-2024-quadratic-v1

Qi, Z., Miao, R., & Zhang, X. (2024). Proximal Learning for Individualized Treatment Regimes Under Unmeasured Confounding. Journal of the American Statistical Association, 119(546), 915–928. DOI: 10.1080/01621459.2022.2147841.

定位：§6.1 Table 4 N2，PDF 第25页；作者 simu_setting.py，nonlinear / X 分支和 h0_nonlinear_X_fun。

机制区别：协变量乘积效应面和二次主效应；N1与N2的函数结构不同，分别登记。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
