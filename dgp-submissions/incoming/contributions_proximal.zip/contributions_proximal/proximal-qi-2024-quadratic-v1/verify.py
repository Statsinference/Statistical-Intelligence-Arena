"""Local scientific checks; no claim of human review or benchmark acceptance."""
from copy import deepcopy
from itertools import product
import math
import numpy as np
from generator import generate
from truth import truth

def check(name,passed,**details):
    return dict(name=name,passed=bool(passed),**details)

def row_check(c, expected, n, seed):
    actual=generate(c,n,seed)
    errors={k:float(np.max(np.abs(np.asarray(actual[k])-v))) for k,v in expected.items()}
    return check('source_equation_row_reconstruction',set(actual)==set(expected) and max(errors.values())<1e-11,max_errors=errors,n=n,seed=seed)

def common(c,source_configs):
    original=deepcopy(c);a=generate(c,128,1729);b=generate(c,128,1729);d=generate(c,128,1730)
    return [check('source_parameter_fixture',c in source_configs),
      check('seed_replay_and_input_immutability',a==b and a!=d and c==original),
      check('observed_finite_columns',all(len(v)==128 and np.isfinite(v).all() for v in a.values()),columns=list(a))]

SOURCE_CONFIGS = [{'x_mean': 0.25, 'x_sd': 0.25, 'propensity_coef': [0.125, 0.125], 'cov_zwu': [[1, 0.25, 0.5], [0.25, 1, 0.5], [0.5, 0.5, 1]], 'mean_zwu': [0.25, 0.25, 0.25], 'a_shift': [0.25, 0.125, 0.25], 'x_coef': [0.25, 0.25], 'form': 'quadratic', 'intercept': 2.0, 'main_x': [0.25, 0.25], 'w_coef': 5.0, 'omega': 2.0, 'effect_intercept': 0.25, 'effect_x': [0.0, 0.0], 'effect_w': 0.0, 'effect_scale': 1.0, 'noise': 'uniform', 'noise_scale': 1.0, 'effect_product': -6.0}]

def independent(c,order=52):
    # Integrate scalar expanded arm means on split bounded intervals under normal density.
    # Splits resolve the abs() kinks, unlike truth.py's folded-normal formula + Hermite rule.
    g,v=np.polynomial.legendre.leggauss(order);mu=c['x_mean'];sd=c['x_sd']
    lo,hi=mu-10*sd,mu+10*sd
    def nodes(cut):
        bounds=[lo]+([cut] if lo<cut<hi else [])+[hi];out=[]
        for left,right in zip(bounds,bounds[1:]):
            for node,weight in zip(g,v):
                x=(left+right)/2+(right-left)/2*node
                wt=weight*(right-left)/2*math.exp(-.5*((x-mu)/sd)**2)/(sd*math.sqrt(2*math.pi))
                out.append((x,wt))
        return out
    m0=m1=0.
    for (x,vx),(y,vy) in product(nodes(1),nodes(-1)):
        p=1/(1+math.exp(c['propensity_coef'][0]*x+c['propensity_coef'][1]*y))
        eu=c['mean_zwu'][2]+c['x_coef'][0]*x+c['x_coef'][1]*y+c['a_shift'][2]*p
        ew=c['mean_zwu'][1]+c['x_coef'][0]*x+c['x_coef'][1]*y+.5*(eu-c['mean_zwu'][2]-c['x_coef'][0]*x-c['x_coef'][1]*y)
        if c['form']=='linear':
            base=c['intercept']+c['main_x'][0]*x+c['main_x'][1]*y+c['w_coef']*ew
            treated=base+c['effect_scale']*(c['effect_intercept']+c['effect_x'][0]*x+c['effect_x'][1]*y+c['effect_w']*ew)
        elif c['form']=='quadratic':
            base=c['intercept']+x*x+y*y+c['w_coef']*ew
            treated=base+c['effect_scale']*(c['effect_intercept']+c['effect_product']*x*y)
        else:
            base=c['intercept']+x*x+y*y+c['w_coef']*ew
            treated=base+c['effect_scale']*(c['effect_intercept']+abs(x-1)-abs(y+1)+(c['effect_w']+math.sin(x)-2*math.cos(y))*ew)
        m0+=vx*vy*base;m1+=vx*vy*treated
    return m1-m0

def reconstruct(c):
    n=37;seed=314159;r=np.random.Generator(np.random.PCG64(seed))
    x=r.normal(c['x_mean'],c['x_sd'],(n,2));ra=r.random(n)
    a=np.array([int(t<1/(1+math.exp(sum(s*b for s,b in zip(row,c['propensity_coef']))))) for row,t in zip(x,ra)])
    innovations=r.standard_normal((n,3));root=np.linalg.cholesky(c['cov_zwu'])
    z=[];w=[];u=[]
    for row,ai,noise in zip(x,a,innovations):
        values=[c['mean_zwu'][j]+c['a_shift'][j]*ai+sum(b*s for b,s in zip(row,c['x_coef']))+sum(root[j,k]*noise[k] for k in range(3)) for j in range(3)]
        z.append(values[0]);w.append(values[1]);u.append(values[2])
    error=r.normal(0,c['noise_scale'],n) if c['noise']=='normal' else r.uniform(-c['noise_scale'],c['noise_scale'],n)
    outcomes=[]
    for (xx,yy),ai,wi,ui,ei in zip(x,a,w,u,error):
        mw=.125+.125*(xx+yy)+.5*ui
        if c['form']=='linear':
            b=c['intercept']+c['main_x'][0]*xx+c['main_x'][1]*yy+c['omega']*wi+(c['w_coef']-c['omega'])*mw
            d=c['effect_intercept']+c['effect_x'][0]*xx+c['effect_x'][1]*yy+c['effect_w']*mw
        elif c['form']=='quadratic':
            b=c['intercept']+xx**2+yy**2+c['omega']*wi+(c['w_coef']-c['omega'])*mw
            d=c['effect_intercept']+c['effect_product']*xx*yy
        else:
            b=c['intercept']+xx**2+yy**2+c['omega']*wi+(c['w_coef']-c['omega'])*mw
            d=c['effect_intercept']+abs(xx-1)-abs(yy+1)+(c['effect_w']+math.sin(xx)-2*math.cos(yy))*mw
        outcomes.append(b+c['effect_scale']*ai*d+ei)
    return row_check(c,dict(X1=x[:,0],X2=x[:,1],A=a,Z=z,W=w,Y=outcomes),n,seed)

def verify(config):
    c=config;checks=common(c,SOURCE_CONFIGS);v=truth(c)['value'];q=independent(c)
    checks.append(check('independent_split_legendre_potential_mean_integration',abs(v-q)<1e-9,truth=v,independent=q,absolute_difference=abs(v-q)))
    checks.append(reconstruct(c))
    cov=np.array(c['cov_zwu']);s=np.array(c['a_shift'])
    checks.append(check('proxy_conditional_independence_covariance_constraints',abs(cov[0,1]-cov[0,2]*cov[1,2]/cov[2,2])<1e-14 and abs(s[1]-cov[1,2]/cov[2,2]*s[2])<1e-14))
    null={**c,'effect_scale':0.};reverse={**c,'effect_scale':-c['effect_scale']}
    yp=np.array(generate(c,53,2026)['Y']);yz=np.array(generate(null,53,2026)['Y']);ym=np.array(generate(reverse,53,2026)['Y'])
    checks.append(check('null_and_sign_reversal',truth(null)['value']==0 and abs(truth(reverse)['value']+v)<1e-12 and np.max(np.abs(yp+ym-2*yz))<1e-11))
    checks.append(check('quadrature_refinement',abs(q-independent(c,40))<1e-9 and truth(c)['estimated_error']<1e-9))
    return {'passed':all(v['passed'] for v in checks),'checks':checks}
