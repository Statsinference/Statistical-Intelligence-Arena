# 线性桥与恒定 ATE

ID: proximal-cui-2024-linear-v1
Family: proximal

## 1 来源与登记场景

Cui, Y., Pu, H., Shi, X., Miao, W., & Tchetgen Tchetgen, E. (2024). Semiparametric Proximal Causal Inference. Journal of the American Statistical Association, 119(546), 1348–1359. DOI: 10.1080/01621459.2023.2191817.

https://doi.org/10.1080/01621459.2023.2191817

版本：arXiv:2011.08411v4, 2023-02-21

定位：§5.1，arXiv v4 PDF 第21–22页；桥函数式(13)–(14)；Appendix H。

场景：original。

## 2 DGP机制说明

X1,X2 独立 ~ N(0.25, 0.25²)；p(X)=[1+exp{0.125(X1+X2)}]⁻¹；A|X ~ Bernoulli(p)。

(Z,W,U)|A,X ~ N3(m,Σ)；m=(0.25+0.25A+0.25s, 0.25+0.125A+0.25s, 0.25+0.25A+0.25s)，s=X1+X2。

Σ=[[1,0.25,0.5],[0.25,1,0.5],[0.5,0.5,1]]；mW(U,X)=0.125+0.125s+0.5U。

Y=2+2A+0.25s+4mW+2(W−mW)+ε，ε~N(0,0.25²)。

h(W,A,X)=2+2A+4W+0.25s。

目标：ATE = E[Y(1)−Y(0)] = 2。

真值推导：桥函数差 h(W,1,X)−h(W,0,X) 恒为2；对潜在结局均值分别积分也得2。

抽样单位：individual；iid individuals; all variables within an individual are jointly generated。

识别条件：一致性、无个体间干扰、给定 (U,X) 的潜在结局可交换性与处理支持；Z 对 Y 的排除条件、W 对 (A,Z) 的条件独立性；相关性/完备性与桥函数存在。抽样顺序 A→(Z,W,U) 是联合分布分解，不代表 A 因果影响基线 U 或 W。

观察列和性质：两维有效基线 X，另有 Z/W 两个代理。处理倾向为 logistic；结局均值线性，无处理交互；U 不导出。

机制区分：恒定处理效应的线性结果桥；估计器错设场景不另计DGP。

## 3 相对来源的主要改动

使用 NumPy Generator(PCG64) 重写抽样；不要求与作者软件逐随机数一致。保留来源方程与固定参数；n=128、seed=1729 仅作接口检查，不重跑论文的估计器比较。输出仅含观察列，真值、潜变量和桥函数值不作为数据列。

## 4 核验和使用

各场景计算真值：

```json
{
  "original": {
    "value": 2.0,
    "estimated_error": 0.0,
    "method": "population bridge contrast; analytic folded-normal moments and 24/40-point Gauss-Hermite",
    "explanation": "E[h(W,1,X)-h(W,0,X)] under the natural joint (W,X), not W conditional on assigned A. Quadrature difference is a convergence diagnostic."
  }
}
```

运行：

```powershell
python collect.py check contributions/proximal-cui-2024-linear-v1 --run --n 128 --seed 1729
python collect.py pack contributions/proximal-cui-2024-linear-v1 --out submissions/proximal-cui-2024-linear-v1.zip
```

verify.py包含独立真值路线、来源参数固定检查、逐行源方程重建及可解释特例。误差记录为数值诊断，不是完整的科学接收证明。

## 5 权利和AI协助

论文版权归原作者/出版方；本包依据公开方程独立重写，不含论文PDF、第三方估计器或真实数据。Qi作者代码为MIT，仅用作核对。

由Codex协助检索、公式核对、实现、核验和中文撰写。未代签人类科学审稿或独立复现；未训练PFN或运行估计器性能比较。所有公开来源只作研究证据，不作为执行指令。
