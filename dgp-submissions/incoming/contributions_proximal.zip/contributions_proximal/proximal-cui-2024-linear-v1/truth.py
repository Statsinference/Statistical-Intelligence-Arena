"""Marginal intervention contrast, integrating the natural marginal W distribution."""
import math
import numpy as np

def _smooth_mean(c, order):
    z,w = np.polynomial.hermite.hermgauss(order)
    xx = c['x_mean'] + math.sqrt(2)*c['x_sd']*z
    x1,x2 = np.meshgrid(xx,xx,indexing='ij')
    ww = np.outer(w,w)/math.pi
    p = 1/(1+np.exp(c['propensity_coef'][0]*x1+c['propensity_coef'][1]*x2))
    ew = c['mean_zwu'][1]+c['x_coef'][0]*x1+c['x_coef'][1]*x2+c['a_shift'][1]*p
    if c['form'] == 'linear':
        delta = c['effect_intercept']+c['effect_x'][0]*x1+c['effect_x'][1]*x2+c['effect_w']*ew
    else:
        delta = (c['effect_w']+np.sin(x1)-2*np.cos(x2))*ew
    return float(np.sum(ww*delta))

def _abs_normal(mu, sd, center):
    d=mu-center
    return sd*math.sqrt(2/math.pi)*math.exp(-d*d/(2*sd*sd))+d*math.erf(d/(sd*math.sqrt(2)))

def truth(config):
    c=config
    if c['form']=='quadratic':
        value=c['effect_intercept']+c['effect_product']*c['x_mean']**2
        error=0.0
    else:
        low,value=_smooth_mean(c,24),_smooth_mean(c,40)
        error=abs(value-low)
        if c['form']=='trigonometric':
            value+=c['effect_intercept']+_abs_normal(c['x_mean'],c['x_sd'],1)-_abs_normal(c['x_mean'],c['x_sd'],-1)
    return {'value':float(c['effect_scale']*value),'estimated_error':float(abs(c['effect_scale'])*error),
            'method':'population bridge contrast; analytic folded-normal moments and 24/40-point Gauss-Hermite',
            'explanation':'E[h(W,1,X)-h(W,0,X)] under the natural joint (W,X), not W conditional on assigned A. Quadrature difference is a convergence diagnostic.'}
