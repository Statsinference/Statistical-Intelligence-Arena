# 来源认领记录

proximal-cui-2024-linear-v1

Cui, Y., Pu, H., Shi, X., Miao, W., & Tchetgen Tchetgen, E. (2024). Semiparametric Proximal Causal Inference. Journal of the American Statistical Association, 119(546), 1348–1359. DOI: 10.1080/01621459.2023.2191817.

定位：§5.1，arXiv v4 PDF 第21–22页；桥函数式(13)–(14)；Appendix H。

机制区别：恒定处理效应的线性结果桥；估计器错设场景不另计DGP。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
