# 来源认领记录

proximal-shi-2026-sc-gaussian-v1

Shi, X., Li, K. Q., Yu, M., Miao, W., Kuchibhotla, A. K., Hu, M., & Tchetgen Tchetgen, E. (2026). Theory for Identification and Inference with Synthetic Controls: A Proximal Causal Inference Framework. Journal of the American Statistical Association, online publication, 4 June 2026. DOI: 10.1080/01621459.2026.2639734.

定位：JASA 2026 正式版 §4 的线性因子模型与载荷；固定 r=5、无协变量、独立误差；作者 run_sim_linear_est.R 的 stationary/constrained/addcov=FALSE。

机制区别：平稳多因子、加性 Gaussian 面板与线性合成控制桥。

已在本地现有贡献中查重；未向维护人发送，待维护人认领/全库查重和具名科学审核。
