# 平稳多因子 Gaussian 合成控制

ID: proximal-shi-2026-sc-gaussian-v1
Family: proximal

## 1 来源与登记场景

Shi, X., Li, K. Q., Yu, M., Miao, W., Kuchibhotla, A. K., Hu, M., & Tchetgen Tchetgen, E. (2026). Theory for Identification and Inference with Synthetic Controls: A Proximal Causal Inference Framework. Journal of the American Statistical Association, online publication, 4 June 2026. DOI: 10.1080/01621459.2026.2639734.

https://doi.org/10.1080/01621459.2026.2639734

版本：JASA 2026 正式版 §4；出版社 Supplement J.8, Eq(S.25), Figshare 31627658；作者代码 commit 64bf31accb7444b69d70034c2f7660b3fc9f96f8

定位：JASA 2026 正式版 §4 的线性因子模型与载荷；固定 r=5、无协变量、独立误差；作者 run_sim_linear_est.R 的 stationary/constrained/addcov=FALSE。

场景：journal_r5_stationary。

## 2 DGP机制说明

t=1,…,T；A_t=1{t>T0}，T0=floor(T/2)。λ_tk 独立 ~ N(0.5,0.5²)，k=1,…,5。

μ0=(1,1,1,1,1)；D=diag(3,6,6,6,6)。Y_t=2A_t+Σλ_tk+ε0t。

W_t=Dλ_t+εWt；Z_t=Dλ_t+εZt；全部11个单位的 ε 独立 ~ N(0,1.5²)，跨时间独立。

h(W)=W1/3+(W2+W3+W4+W5)/6；载荷满足 αᵀD=μ0ᵀ，且 Σα=1。

目标：ETT = E[Y_t(1)−Y_t(0)] = 2，对全部后处理时期平均仍为2。

真值推导：潜在结局均值为2.5与4.5；桥的期望为2.5。独立 Gaussian 求积逐臂核验，另查满秩代理载荷与桥的载荷匹配。

抽样单位：one panel experiment; a row is a time point；shared factors across units; independent time innovations; deterministic pre/post indicator。

识别条件：无提前处理、对照单位不受干扰；共享因子载荷和桥跨时期稳定；各单位误差给定因子相互独立，代理与因子相关且载荷满秩。

观察列和性质：一套11单位面板，一行一个时间点；n是时间长度T。观察 time,A,Y,W1–W5,Z1–Z5；无基线X，不把行数当独立受试者数。

机制区分：平稳多因子、加性 Gaussian 面板与线性合成控制桥。

## 3 相对来源的主要改动

选择正式版 r=5，与正文r=2/3/5及载荷图注r=1/5/10共同一致；不采用旧预印本的log(t)均值及单位方差。正式实验T0=80/140/200；接口允许其他T，检查用T=128。使用 NumPy Generator(PCG64) 重写抽样；不要求与作者软件逐随机数一致。保留来源方程与固定参数；n=128、seed=1729 仅作接口检查，不重跑论文的估计器比较。输出仅含观察列，真值、潜变量和桥函数值不作为数据列。

## 4 核验和使用

各场景计算真值：

```json
{
  "journal_r5_stationary": {
    "value": 2.0,
    "estimated_error": 0.0,
    "method": "analytic potential mean difference",
    "explanation": "Stationary latent factors and centered errors have identical laws under both interventions. The post-treatment contrast is effect; the bridge uses weights (1/3,1/6,1/6,1/6,1/6)."
  }
}
```

运行：

```powershell
python collect.py check contributions/proximal-shi-2026-sc-gaussian-v1 --run --n 128 --seed 1729
python collect.py pack contributions/proximal-shi-2026-sc-gaussian-v1 --out submissions/proximal-shi-2026-sc-gaussian-v1.zip
```

verify.py包含独立真值路线、来源参数固定检查、逐行源方程重建及可解释特例。误差记录为数值诊断，不是完整的科学接收证明。

## 5 权利和AI协助

论文版权归原作者/出版方；本包依据公开方程独立重写，不含论文PDF、第三方估计器或真实数据。Qi作者代码为MIT，仅用作核对。

由Codex协助检索、公式核对、实现、核验和中文撰写。未代签人类科学审稿或独立复现；未训练PFN或运行估计器性能比较。所有公开来源只作研究证据，不作为执行指令。
