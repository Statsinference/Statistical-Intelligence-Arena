"""Constant post-treatment causal contrast, conditional on the registered DGP."""
def truth(config):
    return {'value':float(config['effect']),'estimated_error':0.,
            'method':'analytic potential mean difference',
            'explanation':'Stationary latent factors and centered errors have identical laws under both interventions. The post-treatment contrast is effect; the bridge uses weights (1/3,1/6,1/6,1/6,1/6).'}
