"""Local scientific checks; no claim of human review or benchmark acceptance."""
from copy import deepcopy
from itertools import product
import math
import numpy as np
from generator import generate
from truth import truth

def check(name,passed,**details):
    return dict(name=name,passed=bool(passed),**details)

def row_check(c, expected, n, seed):
    actual=generate(c,n,seed)
    errors={k:float(np.max(np.abs(np.asarray(actual[k])-v))) for k,v in expected.items()}
    return check('source_equation_row_reconstruction',set(actual)==set(expected) and max(errors.values())<1e-11,max_errors=errors,n=n,seed=seed)

def common(c,source_configs):
    original=deepcopy(c);a=generate(c,128,1729);b=generate(c,128,1729);d=generate(c,128,1730)
    return [check('source_parameter_fixture',c in source_configs),
      check('seed_replay_and_input_immutability',a==b and a!=d and c==original),
      check('observed_finite_columns',all(len(v)==128 and np.isfinite(v).all() for v in a.values()),columns=list(a))]

SOURCE_CONFIGS = [{'r': 5, 'factor_mean': 0.5, 'factor_sd': 0.5, 'noise_sd': 1.5, 'donor_loading': [3.0, 6.0, 6.0, 6.0, 6.0], 'effect': 2.0}]

def verify(config):
    c=config;checks=common(c,SOURCE_CONFIGS);n=37;seed=314159
    r=np.random.Generator(np.random.PCG64(seed));k=c['r'];latent=r.normal(c['factor_mean'],c['factor_sd'],(n,k));e=r.normal(0,c['noise_sd'],(n,1+2*k));a=np.array([int(i>=n//2) for i in range(n)])
    out=dict(time=np.arange(1,n+1),A=a,Y=[sum(latent[i])+e[i,0]+c['effect']*a[i] for i in range(n)])
    for j in range(k):
        out[f'W{j+1}']=[c['donor_loading'][j]*latent[i,j]+e[i,1+j] for i in range(n)]
        out[f'Z{j+1}']=[c['donor_loading'][j]*latent[i,j]+e[i,1+k+j] for i in range(n)]
    checks.append(row_check(c,out,n,seed))
    nodes,weights=np.polynomial.hermite.hermgauss(5);weights=weights/math.sqrt(math.pi);m0=m1=bridge=0.
    for i,j in product(range(5),repeat=2):
        # Sum of five independent factors is normal; integrate noise separately.
        total=k*c['factor_mean']+math.sqrt(2*k)*c['factor_sd']*nodes[i]
        value=total+math.sqrt(2)*c['noise_sd']*nodes[j];weight=weights[i]*weights[j]
        m0+=weight*value;m1+=weight*(value+c['effect']);bridge+=weight*total
    q=m1-m0;v=truth(c)['value']
    checks.append(check('independent_gaussian_factor_mean_integration',abs(q-v)<1e-12 and abs(m0-bridge)<1e-12,truth=v,independent=q,mean0=m0,mean1=m1))
    alpha=np.array([1/3,1/6,1/6,1/6,1/6]);loading=np.asarray(c['donor_loading'])
    checks.append(check('full_rank_loading_and_bridge_constraints',np.allclose(alpha*loading,1) and abs(alpha.sum()-1)<1e-12 and np.linalg.matrix_rank(np.diag(loading)*c['factor_sd']**2)==k))
    checks.append(check('null_and_reverse_effect',truth({**c,'effect':0})['value']==0 and truth({**c,'effect':-c['effect']})['value']==-v))
    checks.append(check('time_index_and_pre_post_preserved',list(out['time'])==list(range(1,n+1)) and sum(a)==n-n//2))
    return {'passed':all(x['passed'] for x in checks),'checks':checks}
