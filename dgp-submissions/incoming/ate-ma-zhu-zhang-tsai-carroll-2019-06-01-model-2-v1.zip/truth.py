"""Analytic population ATE of the source mechanism."""

def truth(config):
    return {'value': 1.0, 'estimated_error': 1e-14, 'method': 'Both arms share the same nonlinear baseline, so E[Y|X,A=1]-E[Y|X,A=0]=1 identically and population ATE=1.', 'error_interpretation': 'Analytic identity with floating-point allowance, not Monte Carlo uncertainty.'}
