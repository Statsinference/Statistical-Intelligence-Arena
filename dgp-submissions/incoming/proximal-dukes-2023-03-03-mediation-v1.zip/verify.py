import itertools
import numpy as np
from numpy.polynomial.hermite import hermgauss
from numpy.polynomial.legendre import leggauss
from generator import generate, _draw
from truth import truth


def verify(config):
    checks=[]
    def equal(name,observed,expected,tol=1e-10):
        error=float(np.max(np.abs(np.asarray(observed)-np.asarray(expected))))
        checks.append({"name":name,"passed":bool(np.isfinite(error) and error<=tol),"details":{"max_absolute_error":error,"tolerance":float(tol)}})
    def mc(name,values,expected):
        v=np.asarray(values);se=float(v.std(ddof=1)/np.sqrt(v.size))
        equal(name,v.mean(),expected,max(1e-12,6*se))
    c=config
    expected=dict(SOURCE_ANCHOR)
    if 'beta' in expected:expected['beta']=c['beta']
    checks.append({"name":"fixed_source_parameter_anchor","passed":c==expected,"details":"Config matches the fixed parameter transcription. This catches later edits but cannot detect an error in the original transcription."})
    # Independent potential-outcome construction, not generator or truth algebra.
    rng=np.random.default_rng(314161);n=65536
    x1,x2,u=rng.multivariate_normal([.25,.25,0],[[.25,0,.05],[0,.25,.05],[.05,.05,1]],n).T;xs=x1+x2
    w=.3+.2*xs-.6*u+rng.normal(size=n)
    m0=-.5*xs+.4*u+rng.normal(size=n);m1=m0-.3;error=rng.normal(0,2,n)
    y00=2+m0+2*w-xs-u+error;y10=4+m0+2*w-xs-u+error;y11=4+m1+2*w-xs-u+error
    equal('NDE_potential_outcomes',y10-y00,truth(c)['value'])
    equal('NIE_potential_outcomes',y11-y10,-.3)
    equal('TE_potential_outcomes',y11-y00,1.7)
    mc('mean_Y0',y00,2.05);mc('mean_Y1M0',y10,4.05);mc('mean_Y1',y11,3.75)
    y10_null=2+m0+2*w-xs-u+error
    equal('zero_direct_path_special_case',y10_null-y00,0)
    errors=[]
    for xs,u,m in itertools.product([-.5,.5,1.5],[-1.,0,1.],[-1.,1.]):
        ew=.3+.2*xs-.6*u
        h1=3.5+11/3*ew+m-4/3*xs
        ey=4+m+2*ew-xs-u
        h0=3.7+3*ew-1.7*xs
        ey10=4+(-.5*xs+.4*u)+2*ew-xs-u
        errors.extend([h1-ey,h0-ey10])
    equal('mediation_bridge_conditional_means',errors,0)
    d=_draw(c,n,np.random.default_rng(314162))
    covariance=np.asarray([[.25,0,.05],[0,.25,.05],[.05,.05,1.]])
    se=np.sqrt((covariance**2+np.outer(np.diag(covariance),np.diag(covariance)))/(n-1))
    equal('baseline_covariance_zscores',(np.cov([d['X1'],d['X2'],d['U']])-covariance)/se,0,6)
    mc('generated_outcome_error',d['Y']-2-2*d['A']-d['M']-2*d['W']+d['X1']+d['X2']+d['U'],0)
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'shared_components':'Every check uses the same transcribed source model. The structural, enumeration and quadrature calculations run separately from the generator; sample-moment tests call it. Independent review of the source transcription is still required.',
            'limits':'Finite grids and simulation checks cannot establish identification, behavior in the tails, or estimator coverage. Tolerances were set in advance. Null-path tests are diagnostic cases, not new scenarios.'}

SOURCE_ANCHOR = {'baseline_mean': [0.25, 0.25, 0], 'baseline_cov': [[0.25, 0, 0.05], [0, 0.25, 0.05], [0.05, 0.05, 1]], 'a_logit': [0, -0.5, -0.4], 'z': [0.2, -0.52, 0.2, -1], 'w': [0.3, 0.2, -0.6], 'm': [0, -0.3, -0.5, 0.4], 'y': [2, 2, 1, 2, -1, -1], 'proxy_sd': 1, 'mediator_sd': 1, 'y_sd': 2}
