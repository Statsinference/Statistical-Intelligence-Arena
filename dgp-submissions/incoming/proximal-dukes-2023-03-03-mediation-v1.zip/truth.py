def truth(config):
    nde=config['y'][1];nie=config['y'][2]*config['m'][1]
    return {"value":float(nde),"estimated_error":0.,"method":"Structural substitution holding M(0) and baseline errors fixed","target":"NDE=E[Y(1,M(0))-Y(0,M(0))]","auxiliary":{"NIE":float(nie),"TE":float(nde+nie)},"error_interpretation":"The primary value is analytic; no numerical integration or simulation error is involved."}
