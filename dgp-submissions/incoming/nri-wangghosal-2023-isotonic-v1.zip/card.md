# N07 二元等张回归的五类条件均值曲面

Contribution: `nri-wangghosal-2023-isotonic-v1` · `synthetic_dgp` · `nonparametric_regression` · **v1**

## Source and reconstruction

Wang, K. and Ghosal, S. (2023). Coverage of credible intervals in Bayesian multivariate isotonic regression. The Annals of Statistics 51(3), 1376-1400. DOI: 10.1214/23-AOS2298. Author preprint arXiv:2211.12566.

[DOI](https://doi.org/10.1214/23-AOS2298) · [固定阅读版本 2211.12566v1](https://arxiv.org/pdf/2211.12566v1)

实读 PDF SHA-256：`5da9295981f004087059be8ec78741e8ae256dc329336b7107c48ec78323fb12`。Author preprint, not an IMS electronic reprint.

Formula bodies: (3.1) on PDF p.6, (5.2) on PDF p.19. Section starts: Section 3.2 on PDF p.6, Section 3.5 on PDF p.9, Section 5.2 on PDF p.18. Unnumbered paragraph on PDF p.9: "To see the effect" (separate small experiment query (.5,.5) and sd=.1). Unnumbered paragraph on PDF p.19: "We propose five regression functions" (five unnumbered main-experiment functions). Unnumbered paragraph on PDF p.19: "Set epsilon_i" (standard-normal errors and mutually independent uniform covariates; anchor is a plaintext rendering of the displayed symbol). All PDF pages are 1-based pages of the fixed reading file 2211.12566v1. No printed journal page is inferred by adding an offset.

**原文参数逐页登记**

- PDF p.9：small example query(.5,.5); small example independent uniforms; small example sigma=.1。
- PDF p.19：five main functions: (x1+x2)^2,sqrt(x1+x2),x1*x2,exp(x1+x2),exp(x1*x2); main independent Uniform[0,1] covariates; main noiseN(0,1); n200,500,1000,2000。

**按实际执行顺序的生成步骤**

1. **First covariate** — X1_i iid Uniform(0,1). Source main simulation, Section 5.2.
2. **Second covariate** — X2_i iid Uniform(0,1), independent of X1. Independent rows and independent within-row coordinates.
3. **Innovation** — epsilon_i iid N(0,1), independent of X1,X2. Main simulation error sd=1; not the separate Section 3.5 small-example noise.
4. **Mean surface** — f1=(X1+X2)^2; f2=sqrt(X1+X2); f3=X1*X2; f4=exp(X1+X2); f5=exp(X1*X2). Deterministic source functions; the radical in f2 covers the whole sum.
5. **Observed response** — Y_i=f_k(X1_i,X2_i)+epsilon_i; return X1,X2,Y. No latent surface or oracle column. One selected surface per scenario.

**抽样单位与依赖**：individual observation, i.e. one independent (X1, X2, Y) triple；iid across observations; the two covariates are independent of each other and of the additive noise

**边界与尺度**：The square root is well-defined on [0,1]^2; the registered (.5,.5) is interior. The exponentials are bounded on this support. The square-root derivative at the corner is not claimed to be uniformly bounded.

**与来源的改动及理由**

1. Keep all five Section 5.2 functions as scenarios of one mechanism.
2. Use x0=(0.5,0.5) from the separate Section 3.5 example as a declared transferred query, not as a Section 5.2 setting.
3. Use scalar conditional-mean checks and requested n; do not reproduce posterior computation or confidence-band coverage.

固定点目标由已声明条件响应律识别：高斯模型使用零条件均值的误差/随机效应，广义回归直接用指定分布的链接均值。接口 n 和查询为适配；未把 n=128 说成论文原实验样本量。

**版本关系**：Five functions, independent uniform design, standard-normal errors, sample-size grid, and separate small-study query/noise match in compared passages. Mapping: {"arxiv model3.1 p6": "formal PDFp5 / printed1380", "arxiv section3.5 example p9": "formal PDFp8 / printed1383", "arxiv section5.2 header p18 and five DGPs p19": "formal PDFp16 / printed1391"}. Arxiv p18 DHZ pivotal normalization multiplier is sigma/sqrt(N); formal PDFp16 printed1391 gives sqrt(N)/sigma. This method formula is not implemented by the package. Entire-paper identity is not asserted. Formal typeset copies read: Project Euclid (DOI 10.1214/23-AOS2298; 25 pp.; printed 1376-1400; SHA-256 60fcdb78592ab20a1954bdcaa795e662224b1eee9fc483b1a76ec26a7c56ba7b; all three mapping entries and the DHZ multiplier independently re-checked against this copy on 2026-10-31) and NSF PAR purl/10450423 (SHA-256 e47f80864b74dc35f827ad31c3341e1af69091f23ce757883d552aa139de56fd; byte stream differs from the Project Euclid copy because hosting and pagination differ, not content). This is a comparison of relevant passages, not a claim that the entire paper is identical.

## Target and identification

`f_k(x0) = E[Y | X = x0]`

Pointwise conditional mean of Y at the fixed query point x0 = (query_x1, query_x2) = (0.5, 0.5) under the declared Section 5.2 law, for the regression function f_k selected by the scenario. This is a scalar pointwise query, not a simultaneous confidence band and not a coverage probability.

**登记场景与查询**

| Scenario | Parameters / query |
|:--|:--|
| `original-f1` | `{"curve": "f1", "noise_sd": 1.0, "query_x1": 0.5, "query_x2": 0.5}` |
| `original-f2` | `{"curve": "f2", "noise_sd": 1.0, "query_x1": 0.5, "query_x2": 0.5}` |
| `original-f3`（默认） | `{"curve": "f3", "noise_sd": 1.0, "query_x1": 0.5, "query_x2": 0.5}` |
| `original-f4` | `{"curve": "f4", "noise_sd": 1.0, "query_x1": 0.5, "query_x2": 0.5}` |
| `original-f5` | `{"curve": "f5", "noise_sd": 1.0, "query_x1": 0.5, "query_x2": 0.5}` |

场景中的 original-* 表示保留的来源生成参数，不代表新增查询和接口样本量属于原文实验。本包五场景对应原文五个回归函数 f1-f5，均保留原文生成参数，未另设自选查询；不复制同义场景充数。

**抽样、设计与支持条件**

- Observations (X1, X2, Y) are independent and identically distributed; there is no clustering, Markov, panel or network dependence.
- The design is Uniform on the unit square with independent coordinates, so the design density is bounded away from zero in a neighbourhood of the query point.
- The query point x0 = (0.5, 0.5) lies in the interior of the support [0, 1]^2, away from the boundary where isotonic estimators behave differently.
- The noise epsilon is Normal(0, sigma^2) with the declared sigma = 1 and is independent of X; the regression function is continuous at x0.
- Each f_k is non-decreasing in both coordinates on [0, 1]^2; this shape property is a feature of the declared DGP and is checked numerically, not assumed away.
- No missingness, censoring, measurement error, label-selection or sampling-weight mechanism is present; the observed table is the full sample.
- Pointwise evaluation at a single query point is not a simultaneous-band guarantee, and no credible-interval coverage claim for the source method is made here.

固定点条件均值正确，不等于点态区间或同时置信带覆盖率达标。非因果任务不套用干预/无混杂假设。

## Truth and independent verification

Closed-form evaluation of the declared regression function at the fixed query point: f1(0.5,0.5) = 1, f2(0.5,0.5) = 1, f3(0.5,0.5) = 0.25, f4(0.5,0.5) = e, f5(0.5,0.5) = e^0.25. No quadrature or Monte Carlo enters the truth itself; a Monte-Carlo window mean is used only as an independent verification check.

`truth.tolerance=1e-08`。estimated_error 是浮点/数值路线诊断，不是严格统一误差界或统计标准误；其非负且不大于 tolerance。

**不同路线与解析特例**：五曲面的独立初等函数求值、原点解析锚点、等张网格与另一随机数路线的局部窗口 Monte Carlo；根号必须覆盖 x1+x2 整体。

**实际共享函数与独立边界**：verify 调用 generator.mean_function 检查原文函数与原点/对称锚点，这些为被测函数检查；读取 truth.truth 作比较。独立曲面求值、网格形状及 NumPy Monte Carlo 不复用该助手；共享部分不计作独立计算证据。

外部另按论文公式用 mpmath 70 位重算全部登记查询；另对各场景 generate(n=4096, seed=7312026) 实际观察列独立重构残差，不导入私有均值助手或 verify 作外部参照。N08 的源数学参照取精确 1/sqrt(3)，与配置中最短十进制权重的浮点差计入比较；阈值仍逐包取 tolerance，不靠放宽阈值通过。

## Diversity and scope

`dimension=2`，`effective_dimension=2`。Both covariates enter the mean, so dimension = effective_dimension = 2; high_dimensional is false because there are only two covariates regardless of sample size. interactions = true comes from the product term x1*x2 in f3 and f5 and from the cross-term structure of (x1+x2)^2 in f1. nonlinear = true comes from f1 (quadratic), f2 (square root), f4 and f5 (exponential). The additional shape constraint is bivariate isotonicity: each f_k is non-decreasing in each coordinate on [0, 1]^2.

The query (.5,.5) comes from the separate Section 3.5 example and is transferred explicitly; it is not a source Section 5.2 query declaration. These are five scenarios of one mechanism, not five mechanism families.

处理分配、标注、缺失与真实数据分支均不适用。未执行论文估计器、bootstrap、点态/同时覆盖率、PFN 训练、大规模压力测试或第二人独立人工复现。

## Rights and assistance

Source equations are cited and independently implemented. Paper copyright is not transferred; no paper PDF, author software, original participant data or model weights are redistributed. No external author code was used. The contributor must confirm the release licence for the independently implemented code before publication; pending review is not a grant of rights. AI assisted equation extraction, implementation, numerical checks and drafting; named human scientific review and independent-person reproduction are not claimed.

**未使用作者原始代码或补充材料代码**；因此作者软件 commit 追溯项 N/A。本包依赖以 requirements.txt 为准：标准库或 NumPy 的使用不等于移植作者代码。论文全文、页图、作者软件、权重、数据银行、凭据不随贡献包分发。

**missing / 尚待确认**

- 当前已声明生成律不存在未给定的必要数值参数；这不等于作者算法、许可或科学接收已获确认。
- 本人须审核 AI 协助的来源提取、代码、数值和文本，并确认独立实现代码的发布许可；pending 不是授权。
- 具名科学审核、第二人独立人工复现：未执行。
- GitHub Fork/Sync/SUBMIT DGP/Actions/PR/收录确认：本次未执行。本地 submit 不等于网络提交或项目收件。

**状态**：以最终 checks/report.json 记录本地 runnable_dgp；归档仅 awaiting_scientific_review、scientific_acceptance=false。
