"""Population value of the fixed pointwise query f_k(x0) = E[Y | X = x0].

Closed form at the declared query point; the value is never estimated from generated rows.
"""
import math

ESTIMATED_ERROR = 1e-12


def _mean(curve, x1, x2):
    """Primary closed form, using the math.exp / math.sqrt primitives."""
    total = x1 + x2
    if curve == "f1":
        return total ** 2
    if curve == "f2":
        return math.sqrt(total)
    if curve == "f3":
        return x1 * x2
    if curve == "f4":
        return math.exp(total)
    if curve == "f5":
        return math.exp(x1 * x2)
    raise ValueError("unknown curve: " + str(curve))


def truth(config):
    x1 = float(config["query_x1"])
    x2 = float(config["query_x2"])
    value = _mean(config["curve"], x1, x2)
    return {
        "value": value,
        "estimated_error": ESTIMATED_ERROR,
        "method": "Closed-form evaluation of f_k at the fixed query point x0 = (query_x1, query_x2); no quadrature or Monte Carlo step is used.",
        "error_interpretation": "Round-off scale of the closed-form expression only; it is not a uniform bound over configurations and not a coverage claim.",
        "target": "f_k(x0) = E[Y | X = x0]",
        "query_point": [x1, x2],
        "curve": config["curve"],
    }
