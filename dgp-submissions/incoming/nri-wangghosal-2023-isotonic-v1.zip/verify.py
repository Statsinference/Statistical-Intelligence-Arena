"""Independent checks for the Wang and Ghosal (2023) bivariate isotonic query.

Routes used here are deliberately different from truth.py:
  * a second closed form written with different primitives (math.pow / ** 0.5 / math.prod),
  * hard-coded source fixture tables transcribed from the paper's five regression functions,
  * a vectorised 200x200 isotonicity grid,
  * a Monte-Carlo window mean that re-simulates the declared law with numpy instead of
    the standard-library generator used by generator.py.
Only the declared scientific equations and the config are shared.
"""
import importlib.util
import math
from pathlib import Path

import numpy as np

MC_N = 2_000_000
MC_HALF_WIDTH = 0.05
MC_SEED = 22111256
GRID_POINTS = 200
GRID_TOLERANCE = 1e-12

SOURCE_NOISE_SD = 1.0
SOURCE_QUERY = (0.5, 0.5)
SOURCE_SUPPORT = (0.0, 1.0)
CONFIG_KEYS = ("curve", "noise_sd", "query_x1", "query_x2")

PROBE_POINTS = ((0.0, 0.0), (0.25, 0.75), (0.5, 0.5), (1.0, 1.0))
SOURCE_FIXTURE = {
    "f1": (0.0, 1.0, 1.0, 4.0),
    "f2": (0.0, 1.0, 1.0, 1.4142135623730951),
    "f3": (0.0, 0.1875, 0.25, 1.0),
    "f4": (1.0, 2.718281828459045, 2.718281828459045, 7.38905609893065),
    "f5": (1.0, 1.2062302494209807, 1.2840254166877414, 2.718281828459045),
}
QUERY_FIXTURE = {
    "f1": 1.0,
    "f2": 1.0,
    "f3": 0.25,
    "f4": 2.718281828459045,
    "f5": 1.2840254166877414,
}
ORIGIN_FIXTURE = {"f1": 0.0, "f2": 0.0, "f3": 0.0, "f4": 1.0, "f5": 1.0}
E_LITERAL = 2.718281828459045


def _module(filename):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location("wg2023_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _second_closed_form(curve, x1, x2):
    """Independent closed form: different primitives from truth.py."""
    total = x1 + x2
    if curve == "f1":
        return (x1 + x2) * (x1 + x2)
    if curve == "f2":
        return total ** 0.5
    if curve == "f3":
        return math.prod([x1, x2])
    if curve == "f4":
        return math.pow(math.e, total)
    if curve == "f5":
        return math.pow(math.e, x1 * x2)
    raise ValueError("unknown curve: " + str(curve))


def _grid_mean(curve, a, b):
    total = a + b
    if curve == "f1":
        return total * total
    if curve == "f2":
        return np.sqrt(total)
    if curve == "f3":
        return a * b
    if curve == "f4":
        return np.exp(total)
    if curve == "f5":
        return np.exp(a * b)
    raise ValueError("unknown curve: " + str(curve))


def _isotonicity(curve):
    axis = np.linspace(SOURCE_SUPPORT[0], SOURCE_SUPPORT[1], GRID_POINTS)
    a, b = np.meshgrid(axis, axis, indexing="ij")
    surface = _grid_mean(curve, a, b)
    step_1 = np.diff(surface, axis=0).min()
    step_2 = np.diff(surface, axis=1).min()
    return float(step_1), float(step_2), float(surface.max() - surface.min())


def _mc_window(curve, noise_sd, query_x1, query_x2, target):
    rng = np.random.default_rng(MC_SEED)
    x1 = rng.random(MC_N)
    x2 = rng.random(MC_N)
    epsilon = rng.normal(0.0, float(noise_sd), MC_N)
    y = _grid_mean(curve, x1, x2) + epsilon
    mask = (np.abs(x1 - query_x1) < MC_HALF_WIDTH) & (np.abs(x2 - query_x2) < MC_HALF_WIDTH)
    inside = y[mask]
    count = int(inside.size)
    mean = float(inside.mean())
    sd = float(inside.std(ddof=1))
    tolerance = 6.0 * sd / math.sqrt(count)
    return mean, count, tolerance, abs(mean - target) < tolerance, count >= 1000


def verify(config):
    oracle = _module("truth.py")
    generator = _module("generator.py")
    curve = config["curve"]
    query_x1 = float(config["query_x1"])
    query_x2 = float(config["query_x2"])
    reference = oracle.truth(config)
    target = reference["value"]

    constants_ok = (
        set(config) == set(CONFIG_KEYS)
        and curve in SOURCE_FIXTURE
        and float(config["noise_sd"]) == SOURCE_NOISE_SD
        and (query_x1, query_x2) == SOURCE_QUERY
    )
    probe_errors = [
        abs(generator.mean_function(curve, px1, px2) - expected)
        for (px1, px2), expected in zip(PROBE_POINTS, SOURCE_FIXTURE[curve])
    ]
    constants_ok = constants_ok and max(probe_errors) <= 1e-12

    second = _second_closed_form(curve, query_x1, query_x2)
    if curve == "f4":
        literal_power = E_LITERAL ** (query_x1 + query_x2)
    elif curve == "f5":
        literal_power = E_LITERAL ** (query_x1 * query_x2)
    else:
        literal_power = second
    spread = max(
        abs(target - second),
        abs(second - QUERY_FIXTURE[curve]),
        abs(literal_power - QUERY_FIXTURE[curve]),
    )

    anchors_ok = (
        abs(target - QUERY_FIXTURE[curve]) <= 1e-12
        and abs(generator.mean_function(curve, 0.0, 0.0) - ORIGIN_FIXTURE[curve]) <= 1e-12
        and all(
            generator.mean_function(curve, a, b) == generator.mean_function(curve, b, a)
            for a, b in ((0.0, 1.0), (0.25, 0.75), (0.5, 0.5), (0.1, 0.9))
        )
    )

    step_1, step_2, surface_range = _isotonicity(curve)
    isotonic_ok = step_1 >= -GRID_TOLERANCE and step_2 >= -GRID_TOLERANCE and surface_range > 0.0

    mc_mean, mc_count, mc_tolerance, mc_ok, mc_enough = _mc_window(
        curve, config["noise_sd"], query_x1, query_x2, target
    )

    checks = [
        {
            "name": "source_constants_original",
            "passed": bool(constants_ok),
            "details": (
                "Section 5.2 fixtures: sigma = 1.0 (epsilon ~ Normal(0, 1)), X1 and X2 independent "
                "Uniform(0, 1), x0 = (0.5, 0.5), five monotone regression functions f1..f5. Config keys "
                f"{sorted(config)}; probe values at (0,0), (0.25,0.75), (0.5,0.5), (1,1) match the "
                f"transcribed source table within max error {max(probe_errors):.3g}. The query point is a "
                "declared adaptation (Section 5.2 does not print x0 coordinates)."
            ),
        },
        {
            "name": "independent_closed_form",
            "passed": bool(spread < 1e-9),
            "details": (
                f"truth.py closed form = {target:.15g}; second implementation (math.pow / ** 0.5 / math.prod) "
                f"= {second:.15g}; e-raised-to-power route = {literal_power:.15g}; fixture = "
                f"{QUERY_FIXTURE[curve]:.15g}; max spread = {spread:.3g} < 1e-9."
            ),
        },
        {
            "name": "exact_anchors",
            "passed": bool(anchors_ok),
            "details": (
                f"Query-point anchor f_{curve[1]}(0.5, 0.5) = {QUERY_FIXTURE[curve]:.15g}; origin anchor "
                f"f_{curve[1]}(0, 0) = {ORIGIN_FIXTURE[curve]:.15g}; coordinate-swap symmetry "
                "f(a, b) = f(b, a) holds bit-exactly at four probe pairs."
            ),
        },
        {
            "name": "isotonicity_check",
            "passed": bool(isotonic_ok),
            "details": (
                f"{GRID_POINTS}x{GRID_POINTS} grid on [0, 1]^2: minimum forward difference = "
                f"{min(step_1, step_2):.3g} along both coordinates (tolerance {-GRID_TOLERANCE:g}); "
                f"surface range = {surface_range:.6g} > 0, so the function is non-decreasing in each coordinate."
            ),
        },
        {
            "name": "mc_window_mean",
            "passed": bool(mc_ok and mc_enough),
            "details": (
                f"numpy re-simulation with {MC_N} draws and a fixed seed: {mc_count} draws fall in "
                f"|X1 - {query_x1}| < {MC_HALF_WIDTH}, |X2 - {query_x2}| < {MC_HALF_WIDTH}; window mean Y = "
                f"{mc_mean:.6g} vs truth {target:.6g}; |difference| = {abs(mc_mean - target):.3g} < "
                f"6*sd/sqrt(N_win) = {mc_tolerance:.3g}. Mechanism check only, not a coverage claim."
            ),
        },
    ]
    return {
        "passed": all(c["passed"] for c in checks),
        "checks": checks,
        "shared_components": (
            "Both the truth and the verifier encode the same five declared regression functions and the "
            "same config, but use different primitives, different arithmetic routes and an independent "
            "numpy simulation; no quadrature nodes or integration code are shared. Source reconstruction "
            "and independent-person reproduction still require named scientific review."
        ),
        "monte_carlo_seed": MC_SEED,
    }
