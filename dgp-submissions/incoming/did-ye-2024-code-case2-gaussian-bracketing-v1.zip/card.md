# Author code-version CaseII
User explicitly authorized code-version reproduction with differences disclosed. Primary executable-law source is author DIDBracket commit b82f4ae3f40c89b7a0a1aa49591fa223718d1e71 (2020-05-16), data_gen(1000,"case2") default att. Current author JASA publication entry links same repository and arXiv; formal2023 simulation section is not verified. CaseII matches v3 core parameters; fixed counts versus Pr(G) remains disclosed. No accepted-manuscript equivalence claimed. Source license placeholder unresolved; no Python license selected.

1000 rows, C0/trt300 then C1/b500 then C2/a200; G=I(C0). Four independent Gaussian observations per ordinal row. Original source has no unit ID; this is lossless reshaping of independent cells. Pre t1, post t2/t3/t4. Each t draws trt then a then b. Counts exact at N1000, no rounding/extrapolation. No observed X, latent, truth, potential outcomes, or IDs exported. NumPy seed is local and not R bitwise replay. Source contains no pinned seed.

Untreated means trt=(3,4,0,1),a=(10,11,10,11),b=(4,6,2,3), observed treated shifts=(0,2,3,1), SD1 independent. Population final ATT=1 from source defaults and t4 table coverage target. Source draws marginal observed Y directly; no finite-panel SATT guarantee or cross-world coupling. CaseI not separately registered; S_t/phi excluded.

Family: nonparallel fixed three-group paths plus independent cells. Distinct from M01 persistent nonlinear observed-X unit signal, M11 shared random AR factors, M12 donor AR history, G01 bridge/IV proxies, F04 count/log-link proxies, D05 truncation/shared damping/history selection. Bracketing method name alone is not the distinction.

Validation: authoritative tests/test_bn03.py records structure, local seed, strict parameter rejection, exact counts, source block mapping, cell moments/correlations and independent marginal-integral truth. checks stores run evidence. No estimator performance guarantee.
