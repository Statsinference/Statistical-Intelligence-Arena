"""Independent normal-mean integration for population ATT4."""
import math

def verify(config):
    expected={"scenario":"author_code_case2","units":1000,"T_pre":1,"T_post":3}
    if type(config)!=dict or set(config)!=set(expected) or any(type(config[k]) is not type(v) or config[k]!=v for k,v in expected.items()):
        raise ValueError("Only registered N1000 CaseII configuration is supported")
    # Symmetric normal law has zero residual expectation; integrate the two
    # marginal means separately, without defining a joint potential pair.
    steps=20000; h=16/steps
    mass=first=0.0
    for j in range(steps):
        z=-8+(j+.5)*h
        w=math.exp(-z*z/2)/math.sqrt(2*math.pi)*h
        mass+=w; first+=z*w
    untreated=1*mass+first
    treated=2*mass+first
    delta=treated-untreated
    checks=[{"name":"normal_marginal_mass","passed":abs(mass-1)<1e-10,"value":mass},
            {"name":"independent_population_ATT4","passed":abs(delta-1)<1e-10,"value":delta}]
    return {"passed":all(x["passed"] for x in checks),"checks":checks,"scope":"Population marginal means only; no finite-sample SATT assertion"}
