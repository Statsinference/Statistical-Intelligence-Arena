"""Source-declared population ATT4; no finite-sample coupling asserted."""
def truth(config):
    expected={"scenario":"author_code_case2","units":1000,"T_pre":1,"T_post":3}
    if type(config)!=dict or set(config)!=set(expected) or any(type(config[k]) is not type(v) or config[k]!=v for k,v in expected.items()):
        raise ValueError("Only registered N1000 CaseII configuration is supported")
    return {"value":1.0,"estimated_error":0.0,"method":"Exact source population ATT at t4 from att=(0,2,3,1); no SATT guarantee"}
