"""Authoritative audit. Run directly; no estimator or author script execution."""
import sys,json,copy
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from generator import generate
from truth import truth
from verify import verify
cfg=json.loads((ROOT/'config.json').read_text())['scenarios']['baseline']
checks=[]
def check(name,passed,**details):
    checks.append(dict(name=name,passed=bool(passed),**details))
def reject(name,fn):
    try: fn(); ok=False
    except ValueError: ok=True
    check(name,ok)
cols=['G','C','Y_pre001','Y_post001','Y_post002','Y_post003']
a=generate(cfg,1000,42)
check('six_observed_columns_exact',list(a)==cols and all(len(v)==1000 for v in a.values()))
check('finite',all(np.isfinite(v).all() for v in a.values()))
check('design_order_counts',a['G']==[1]*300+[0]*700 and a['C']==[0]*300+[1]*500+[2]*200)
check('repeat_seed',a==generate(cfg,1000,42))
check('different_seed',a!=generate(cfg,1000,43))
np.random.seed(789); state=np.random.get_state();generate(cfg,1000,42); after=np.random.get_state()
check('global_rng_unchanged',state[0]==after[0] and np.array_equal(state[1],after[1]) and state[2:]==after[2:])
for n in [999,1001,1000.0,True]:reject('reject_n_'+str(n),lambda n=n:generate(cfg,n,1))
for s in [-1,1.2,True]:reject('reject_seed_'+str(s),lambda s=s:generate(cfg,1000,s))
for bad in [{},dict(cfg,units=1000.0),dict(cfg,T_post=2),dict(cfg,extra=1)]:
    reject('reject_config_'+str(len(checks)),lambda bad=bad:generate(bad,1000,1))
# Independent block-by-block random oracle with literal observed means.
rng=np.random.default_rng(42);oracle=np.empty((1000,4))
for t,means in enumerate(zip([3,6,3,2],[10,11,10,11],[4,6,2,3])):
    oracle[:300,t]=rng.normal(means[0],1,300)
    oracle[800:,t]=rng.normal(means[1],1,200)
    oracle[300:800,t]=rng.normal(means[2],1,500)
check('source_draw_order_and_wide_mapping',np.array_equal(oracle,np.column_stack([a[k] for k in cols[2:]])))
# 400 independently seeded panels: 120k/200k/80k draws per group/time.
blocks=[[],[],[]]
for seed in range(400):
    d=generate(cfg,1000,10000+seed); y=np.column_stack([d[k] for k in cols[2:]])
    for g,ix in enumerate([slice(0,300),slice(300,800),slice(800,1000)]):blocks[g].append(y[ix])
for g,(parts,mu) in enumerate(zip(blocks,[[3,6,3,2],[4,6,2,3],[10,11,10,11]])):
    y=np.concatenate(parts);res=y-np.array(mu)
    se=1/np.sqrt(len(y)); mean=res.mean(axis=0); var=res.var(axis=0,ddof=1)
    check('group%d_cell_means_6SE'%g,np.max(np.abs(mean))<6*se,max_abs_error=float(np.max(np.abs(mean))),threshold=float(6*se))
    check('group%d_cell_variances'%g,np.max(np.abs(var-1))<.025,max_abs_error=float(np.max(np.abs(var-1))),threshold=.025)
    corr=np.corrcoef(res,rowvar=False)-np.eye(4)
    check('group%d_cross_time_independence'%g,np.max(np.abs(corr))<.02,max_abs_corr=float(np.max(np.abs(corr))),threshold=.02)
    adjacent=np.corrcoef(res[:-1,0],res[1:,0])[0,1]
    check('group%d_cross_unit_independence'%g,abs(adjacent)<.02,correlation=float(adjacent),threshold=.02)
# Source-declared marginal population shift independent of package truth hook.
expected=(1+1)-1
check('independent_population_truth',expected==1 and truth(cfg)['value']==expected)
check('independent_normal_integral',verify(cfg)['passed'])
report={'passed':all(c['passed'] for c in checks),'checks':checks,'panels':400,'rows_per_panel':1000,'truth_scope':'population ATT4 only; no SATT assertion'}
(ROOT/'checks'/'independent_audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'checks':len(checks),'panels':400}))
raise SystemExit(0 if report['passed'] else 1)
