# iv-ding-2017-binary-bias-v1
学生包独立贡献，1套 IV 机制，Table 1 三个参数场景。
先阅读 card.md / source_verification.md；运行和打包使用 collect.py。
登记目标为 LATE，原文 ATE 仅作为 source audit。
一对交付文件：submissions/iv-ding-2017-binary-bias-v1.zip 和 submissions/iv-ding-2017-binary-bias-v1_report_中文.pdf。
