# IV：二元混杂、偏差放大与局部平均处理效应

## 来源与定位
Ding, P., VanderWeele, T. J. and Robins, J. M. (2017). Instrumental variables as bias amplifiers with general outcome and confounding. Biometrika 104(2), 291–302. DOI: 10.1093/biomet/asx009.

固定原始全文：https://arxiv.org/abs/1701.04177v1

arXiv:1701.04177v1 (2017-01-16), §5.1 PDF p.8 and Table 1 p.9, Cases 1–3; causal graph Fig.1(b) p.2 and causal framework §2 pp.3–4. PDF page numbers refer to this fixed preprint, not journal pagination.

| 核对项 | 证据 / 边界 |
|---|---|
| 文献 | Ding, VanderWeele & Robins (2017), Biometrika 104(2),291–302; DOI 10.1093/biomet/asx009 |
| 固定全文版本 | arXiv:1701.04177v1, 2017-01-16；§5.1 PDF p.8, Table 1 p.9 |
| 期刊元数据 | Crossref DOI 记录及 PubMed PMID 29033459；出版商页面本次工具访问失败，未声称核对最终排版 PDF |
| Z,U 分布 | §5.1/Table 1：相互独立 Bernoulli(0.5) |
| p 与 r | Table 1 Cases 1–3 的全部八个条件概率，原序及配置矩阵见下文 |
| 原目标 | ACEtrue（ATE），以及 crude / Z-adjusted population risk differences；不是本文贡献的 LATE |
| 登记目标 | 本次明确适配为 LATE = E[Y(1)−Y(0)\|A(1)>A(0)] |
| 抽样单位 | 个体 iid，无 interference；没有观察基线协变量 |
| 补充结构 | 共享处理阈值保证单调性，独立结果阈值满足给定 U 的机制分解；跨干预耦合是本包选择 |
| 真值方法 | 解析 complier 加权均值；Fraction 精确联合概率枚举及阈值分块积分交叉验证 |
| 缺失与边界 | 所选观察分布无缺失参数；原文未定义跨干预耦合及本次 LATE，均已标 adaptation |


## 原始概率与实现
原文 p 的第一下标是 Z，第二下标是 U；r 的第一下标是 A，第二下标是 U。配置矩阵按行/列均为 0,1 排列。

| 场景 | p00 | p01 | p10 | p11 | r00 | r01 | r10 | r11 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| source_table1_case1 | .1 | .2 | .6 | .8 | .01 | .02 | .06 | .08 |
| source_table1_case2 | .1 | .3 | .2 | .3 | .01 | .03 | .02 | .03 |
| source_table1_case3 | .1 | .4 | .4 | .5 | .01 | .04 | .04 | .04 |

- Z ~ Bernoulli(0.5), U ~ Bernoulli(0.5), V_A,V_Y iid Uniform(0,1); all four independent.
- p[z,u]=P(A=1|Z=z,U=u), r[a,u]=P(Y=1|A=a,U=u); fixed values from source Table 1.
- A(z)=1{V_A<p[z,U]}, A=A(Z); Y(a)=1{V_Y<r[a,U]}, Y=Y(A).
- q=(0.5,0.5), delta[u]=p[1,u]-p[0,u], tau[u]=r[1,u]-r[0,u].
- LATE=sum_u q[u]*delta[u]*tau[u] / sum_u q[u]*delta[u].
- Source population ATE=sum_u q[u]*tau[u]; it is an audit quantity, not the registered IV target.

默认场景 Case 1；三组场景属于同一个 mechanism family。使用局部 NumPy PCG64，依次抽取 Z、U、V_A、V_Y 的 n 个均匀随机数。只返回 Z、A、Y 三列二元列表。生成器没有网络/文件读写。真值和参数是维护端核验信息，不是模型输入。

## 目标、识别和真值
E[Y(1)-Y(0) | A(1)>A(0)], treatment intervention 0 to 1 among instrument compliers.

独立 Z 与排除限制使 ΔY=Σq_u(p_1u−p_0u)(r_1u−r_0u)，ΔA=Σq_u(p_1u−p_0u)。共享处理阈值给出无 defier，故 ΔA 为 complier 比例，Wald 比值 ΔY/ΔA 等于 LATE。Case 1/2/3 的精确分数分别为 61/1100、1/100、9/400。

| 场景 | 一阶段 ΔA | reduced form ΔY | LATE（登记目标） | 原文 ATE（仅核验） |
|---|---:|---:|---:|---:|
| 1 | .55 | .0305 | 61/1100 ≈ .055454545455 | .055 |
| 2 | .05 | .0005 | 1/100 = .01 | .005 |
| 3 | .20 | .0045 | 9/400 = .0225 | .015 |

LATE 与总体 ATE 在三场景均不同。不能把 Wald 比值或 truth.value 称为总体 ATE，也不能把原文 ACEadj 误称为 IV 估计量；它是按 Z 标准化的风险差。

- Consistency and no interference; iid individuals.
- Randomized binary Z independent of U and all exogenous thresholds; 0<P(Z=1)<1.
- Exclusion: Y(a,z)=Y(a), so Z affects Y only through A.
- Treatment monotonicity A(1)>=A(0) under the declared shared-threshold coupling.
- Nonzero first stage P(A(1)>A(0))>0 in each source scenario.
- The chosen SCM has independent treatment/outcome thresholds given U; U is unobserved.
- These IV conditions identify LATE, not the overall ATE without further restrictions.

## 标签
无观察基线协变量，dimension=effective_dimension=0；1个工具 Z、1个隐藏混杂 U。三场景分别含 Z*U 概率交互系数 0.1,-0.1,-0.2，以及 A*U 系数 0.01,-0.01,-0.03。nonlinear=true 指双线性交互与二元阈值函数；不是 logistic 模型，也不声称高维。

## 明确的适配与范围
- 原文 Table 1 是偏差放大问题的总体数值例子；本包保留其三组观察分布参数，但将登记目标由原文 ATE 改为 LATE。
- 补充独立阈值 SCM：Z、U、V_A、V_Y 相互独立；同一 V_A 用于 A(0),A(1)，同一 V_Y 用于 Y(0),Y(1)。原文未指定这种跨干预耦合。
- p[1,u]>=p[0,u] 与共享 V_A 保证个体单调性；仅有源概率的均值单调性本身不足以推出个体单调性。
- 该 SCM 精确匹配所选条件概率；共享结果阈值是兼容实现的选择，并非声称恢复作者未指定的完整潜在结果联合分布。
- 独立编写 Python/NumPy PCG64 生成器；n=128、seed=1729 是学生包检查设置，不是论文报告的实验设置或精度保证。
- 仅导出 Z,A,Y；U、阈值噪声、潜在结果和个体效应留在机制定义中，不作为估计器特征。

此处是论文数值例子的可运行化，不声称复现作者的估计器 Monte Carlo。未纳入 §5.1 其他图示及随机参数空间实验；没有按原文百万次随机参数抽样构建超分布。Case 2 一阶段仅 .05，且三场景结果事件稀少；n=128 的接口检查不能证明小样本推断可靠。

## 独立核验
verify.py 使用 Fraction 精确枚举16个 (Z,U,A,Y) 单元格并边缘化 U，求观测 Wald 比值；第二路线对潜在结果的均匀阈值区间做精确分块积分，直接计算 complier 的 Y(1)−Y(0)。核验无 defier、complier 比例等于一阶段、概率质量归一化。

原始表格用独立的原序参数字面量核对矩阵映射，并将 ATE、crude、Z-adjusted population risk differences 四舍五入到4位与 Table 1 三行比较，同时核对 Z-Bias YES/YES/NO。该检查是总体恒等式核验，没有拟合估计器。

另有零效应、结果反向和恒定效应控制，以及零一阶段、非单调配置、无效概率拒绝；用独立展开的标量交互方程重建73行样本。接口检查使用原配置不变。验证路线共享配置、输入校验和随机数算法，不共享 truth 的因果代数；由同一 AI 编写，不能视作独立人员复现。

truth.estimated_error=0 表示解析式没有数值积分或 Monte Carlo 近似；不代表浮点舍入误差严格为零。容差 1e-12 预先固定。不得放宽容差来掩盖错误。

## 复跑与打包
在含 collect.py 的学生包根目录执行：
```powershell
& .\.venv\Scripts\python.exe collect.py check contributions/iv-ding-2017-binary-bias-v1 --run --n 128 --seed 1729
& .\.venv\Scripts\python.exe collect.py pack contributions/iv-ding-2017-binary-bias-v1 --out submissions/iv-ding-2017-binary-bias-v1.zip
```
所有声明场景均须检查。改动任一源文件后重跑检查并使用新 ZIP 文件名；报告 PDF 随 ZIP 单独提交。

## 权利、状态与未决项
独立实现，只提供来源链接与核对信息，不含论文 PDF 或作者程序。原文版权归原权利人；正式发布权利审核待维护人处理。

AI 辅助：OpenAI Codex，2026-10-25。未代签人类阅读或具名科学审核。状态为 awaiting_scientific_review；认领、跨库查重、独立人员复现和正式接收待维护人完成。未发送维护人，未训练 PFN，未运行估计器覆盖率实验。
