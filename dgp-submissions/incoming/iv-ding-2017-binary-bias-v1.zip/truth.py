"""Analytic LATE, not the paper's population ATE; assumptions in card.md."""
from generator import validate_config


def truth(config):
    validate_config(config)
    p, r = config['treatment_probabilities'], config['outcome_probabilities']
    q = [1 - config['u_probability'], config['u_probability']]
    first_stage = sum(q[u] * (p[1][u] - p[0][u]) for u in [0, 1])
    numerator = sum(q[u] * (p[1][u] - p[0][u]) * (r[1][u] - r[0][u]) for u in [0, 1])
    return {'value': float(numerator / first_stage), 'estimated_error': 0.0,
            'method': 'Analytic complier-weighted effect under the declared threshold SCM.',
            'first_stage': float(first_stage), 'reduced_form': float(numerator),
            'population_ate_audit_only': float(sum(q[u] * (r[1][u] - r[0][u]) for u in [0, 1])),
            'error_interpretation': 'No integration or Monte Carlo error; floating-point rounding remains.'}
