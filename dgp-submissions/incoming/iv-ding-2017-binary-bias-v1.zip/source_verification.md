# 来源核对表

| 核对项 | 证据 / 边界 |
|---|---|
| 文献 | Ding, VanderWeele & Robins (2017), Biometrika 104(2),291–302; DOI 10.1093/biomet/asx009 |
| 固定全文版本 | arXiv:1701.04177v1, 2017-01-16；§5.1 PDF p.8, Table 1 p.9 |
| 期刊元数据 | Crossref DOI 记录及 PubMed PMID 29033459；出版商页面本次工具访问失败，未声称核对最终排版 PDF |
| Z,U 分布 | §5.1/Table 1：相互独立 Bernoulli(0.5) |
| p 与 r | Table 1 Cases 1–3 的全部八个条件概率，原序及配置矩阵见下文 |
| 原目标 | ACEtrue（ATE），以及 crude / Z-adjusted population risk differences；不是本文贡献的 LATE |
| 登记目标 | 本次明确适配为 LATE = E[Y(1)−Y(0)\|A(1)>A(0)] |
| 抽样单位 | 个体 iid，无 interference；没有观察基线协变量 |
| 补充结构 | 共享处理阈值保证单调性，独立结果阈值满足给定 U 的机制分解；跨干预耦合是本包选择 |
| 真值方法 | 解析 complier 加权均值；Fraction 精确联合概率枚举及阈值分块积分交叉验证 |
| 缺失与边界 | 所选观察分布无缺失参数；原文未定义跨干预耦合及本次 LATE，均已标 adaptation |
