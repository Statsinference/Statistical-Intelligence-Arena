"""Exact joint-cell and threshold-rectangle checks independent of truth algebra.

Input validation is shared. Verification arithmetic and source fixtures do not
reuse causal calculations from generate/truth. This is AI-assisted verification,
not independent-person scientific reproduction.
"""
import copy
from fractions import Fraction as F
from itertools import product
import numpy as np
from generator import generate
from truth import truth

# Source Table 1 order: p11,p10,p01,p00,r11,r10,r01,r00;
# then printed ACEtrue, ACEunadj, ACEadj, Z-Bias.
SOURCE_ROWS = [
    ('0.8 0.6 0.2 0.1 0.08 0.06 0.02 0.01', ('0.0550', '0.0574', '0.0584'), True),
    ('0.3 0.2 0.3 0.1 0.03 0.02 0.03 0.01', ('0.0050', '0.0076', '0.0077'), True),
    ('0.5 0.4 0.4 0.1 0.04 0.04 0.04 0.01', ('0.0150', '0.0173', '0.0172'), False),
]


def fraction(x):
    return F(str(x))


def joint_cells(c):
    """16 cells P(Z,U,A,Y), calculated from the source factorization."""
    cells = {}
    for z, u, a, y in product([0, 1], repeat=4):
        chances = [fraction(c['z_probability']), fraction(c['u_probability']),
                   fraction(c['treatment_probabilities'][z][u]),
                   fraction(c['outcome_probabilities'][a][u])]
        mass = F(1)
        for bit, chance in zip([z, u, a, y], chances):
            mass *= chance if bit else 1 - chance
        cells[z, u, a, y] = mass
    return cells


def conditional_mean(cells, coordinate, given):
    selected = [(row, mass) for row, mass in cells.items()
                if all(row[j] == val for j, val in given.items())]
    return sum(row[coordinate] * mass for row, mass in selected) / sum(mass for _, mass in selected)


def wald_from_cells(c):
    cells = joint_cells(c)
    dy = conditional_mean(cells, 3, {0: 1}) - conditional_mean(cells, 3, {0: 0})
    da = conditional_mean(cells, 2, {0: 1}) - conditional_mean(cells, 2, {0: 0})
    return dy / da, da, dy


def threshold_integral(c):
    """Integrate potential outcomes over exact uniform-threshold rectangles."""
    strata = {(0, 0): F(0), (0, 1): F(0), (1, 0): F(0), (1, 1): F(0)}
    complier_effect_mass, ate = F(0), F(0)
    for u in [0, 1]:
        weight = fraction(c['u_probability']) if u else 1 - fraction(c['u_probability'])
        ps = [fraction(row[u]) for row in c['treatment_probabilities']]
        rs = [fraction(row[u]) for row in c['outcome_probabilities']]
        acuts, ycuts = sorted({F(0), F(1), *ps}), sorted({F(0), F(1), *rs})
        for alo, ahi in zip(acuts[:-1], acuts[1:]):
            av = (alo + ahi) / 2
            a0, a1 = (int(av < prob) for prob in ps)
            for ylo, yhi in zip(ycuts[:-1], ycuts[1:]):
                yv = (ylo + yhi) / 2
                y0, y1 = (int(yv < prob) for prob in rs)
                mass = weight * (ahi - alo) * (yhi - ylo)
                strata[a0, a1] += mass
                ate += mass * (y1 - y0)
                if (a0, a1) == (0, 1):
                    complier_effect_mass += mass * (y1 - y0)
    return complier_effect_mass / strata[0, 1], strata, ate


def source_table_audit():
    details = []
    for case, (values, expected, zbias) in enumerate(SOURCE_ROWS, 1):
        p11, p10, p01, p00, r11, r10, r01, r00 = map(F, values.split())
        c = {'z_probability': 0.5, 'u_probability': 0.5,
             'treatment_probabilities': [[float(p00), float(p01)], [float(p10), float(p11)]],
             'outcome_probabilities': [[float(r00), float(r01)], [float(r10), float(r11)]]}
        cells = joint_cells(c)
        _, _, ate = threshold_integral(c)
        crude = conditional_mean(cells, 3, {2: 1}) - conditional_mean(cells, 3, {2: 0})
        adjusted = sum(F(1, 2) * (conditional_mean(cells, 3, {0: z, 2: 1})
                                  - conditional_mean(cells, 3, {0: z, 2: 0})) for z in [0, 1])
        printed = tuple(f'{float(v):.4f}' for v in [ate, crude, adjusted])
        actual_zbias = abs(adjusted - ate) > abs(crude - ate)
        details.append({'case': case, 'printed': list(printed), 'expected': list(expected),
                        'z_bias': actual_zbias, 'passed': printed == expected and actual_zbias == zbias})
    return details


def verify(config):
    before = copy.deepcopy(config)
    checks = []

    def record(name, ok, **details):
        checks.append({'name': name, 'passed': bool(ok), **details})

    cells = joint_cells(config)
    record('joint_probability_normalization', sum(cells.values()) == 1 and min(cells.values()) >= 0,
           cell_count=len(cells))
    exact, stage, reduced = wald_from_cells(config)
    value = truth(config)['value']
    record('independent_joint_cell_wald', abs(float(exact) - value) < 1e-12,
           exact_fraction=str(exact), absolute_error=abs(float(exact) - value),
           first_stage=float(stage), reduced_form=float(reduced))
    causal, strata, ate = threshold_integral(config)
    record('independent_potential_outcome_integration', causal == exact and abs(float(causal) - value) < 1e-12,
           exact_fraction=str(causal), absolute_error=abs(float(causal) - value), population_ate=float(ate))
    record('monotonicity_and_principal_strata', strata[1, 0] == 0 and strata[0, 1] == stage
           and sum(strata.values()) == 1, never_taker=float(strata[0, 0]), complier=float(strata[0, 1]),
           defier=float(strata[1, 0]), always_taker=float(strata[1, 1]))
    p, r = config['treatment_probabilities'], config['outcome_probabilities']
    ordered = [p[1][1], p[1][0], p[0][1], p[0][0], r[1][1], r[1][0], r[0][1], r[0][0]]
    match = [i + 1 for i, (v, _, _) in enumerate(SOURCE_ROWS)
             if list(map(F, v.split())) == list(map(fraction, ordered))]
    record('source_parameter_mapping', len(match) == 1 and config['z_probability'] == config['u_probability'] == 0.5,
           source_case=match)
    audits = source_table_audit()
    record('source_table_population_functionals', all(x['passed'] for x in audits), cases=audits)
    controls = []
    for name, matrix, expected in [
        ('zero', [r[0][:], r[0][:]], 0.0),
        ('reverse', [[1-x for x in row] for row in r], -float(exact)),
        ('constant', [[0.1, 0.2], [0.3, 0.4]], 0.2),
    ]:
        c = copy.deepcopy(config)
        c['outcome_probabilities'] = matrix
        v = truth(c)['value']
        w, _, _ = wald_from_cells(c)
        vpo, _, _ = threshold_integral(c)
        controls.append({'control': name, 'value': v,
                         'passed': abs(v-expected) < 1e-12 and abs(float(w)-v) < 1e-12 and w == vpo})
    record('zero_reverse_constant_effect_controls', all(x['passed'] for x in controls), controls=controls)
    rejected = []
    for label in ['zero_first_stage', 'nonmonotone', 'invalid_probability']:
        c = copy.deepcopy(config)
        if label == 'zero_first_stage':
            c['treatment_probabilities'][1] = c['treatment_probabilities'][0][:]
        elif label == 'nonmonotone':
            c['treatment_probabilities'] = [[0.6, 0.1], [0.5, 0.8]]
        else:
            c['outcome_probabilities'][0][0] = 1.1
        both = []
        for fn in [lambda: truth(c), lambda: generate(c, 3, 1)]:
            try:
                fn()
                both.append(False)
            except ValueError:
                both.append(True)
        rejected.append({'case': label, 'passed': all(both)})
    record('invalid_configuration_rejection', all(x['passed'] for x in rejected), cases=rejected)
    n, seed = 73, 81025
    data = generate(config, n, seed)
    rng = np.random.Generator(np.random.PCG64(seed))
    vz, vu, va, vy = [rng.random(n) for _ in range(4)]
    replay = {'Z': [], 'A': [], 'Y': []}
    # Scalar saturated probability models, separately expanded from matrix indexing.
    for i in range(n):
        z, u = int(vz[i] < config['z_probability']), int(vu[i] < config['u_probability'])
        pa = p[0][0] + (p[1][0]-p[0][0])*z + (p[0][1]-p[0][0])*u + (p[1][1]-p[1][0]-p[0][1]+p[0][0])*z*u
        a = int(va[i] < pa)
        py = r[0][0] + (r[1][0]-r[0][0])*a + (r[0][1]-r[0][0])*u + (r[1][1]-r[1][0]-r[0][1]+r[0][0])*a*u
        y = int(vy[i] < py)
        for key, bit in [('Z', z), ('A', a), ('Y', y)]:
            replay[key].append(bit)
    record('scalar_source_equation_replay', replay == data, rows=n)
    record('observed_only_binary', set(data) == {'Z', 'A', 'Y'}
           and all(set(values) <= {0, 1} and len(values) == n for values in data.values()))
    record('configuration_unchanged', config == before)
    return {'passed': all(x['passed'] for x in checks), 'checks': checks,
            'scope': 'Exact population and mechanism checks; no estimator-performance or scientific-acceptance claim.'}
