# Source-grounded DGP contribution

Status: candidate; not scientifically accepted.

## Source and reconstruction

Primary source checked: Dimitriadis, Dümbgen, Henzi, Puke & Ziegel (2023), “Honest calibration assessment for binary outcome predictions”, *Biometrika* 110(3):663–680, DOI `10.1093/biomet/asac068`. The DGP reading for this contribution is the local preprint **arXiv:2203.04065v2 (2022-11-02), PDF printed page 8, Section 5, item 3 (Kink)**. That page states `X ~ U[0,1]`, `Y ~ Bern{p_s(X)}`, `s in S={0,0.1,...,1}`, and the simulation sample-size range 512 through 32768. The paper's replication link is `https://github.com/marius-cp/replication_DDHPZ22`.

The source describes `p_s` as the linear interpolation through `(0,0)`, `(0.2+0.8s,0.2)`, and `(1,1)`. Let `a_s=0.2+0.8s`. For `s<1`, the reconstructed law is:

`p_s(x)=0.2*x/a_s` for `0<=x<=a_s`,

`p_s(x)=0.2+0.8*(x-a_s)/(1-a_s)` for `a_s<x<=1`.

The source simulation uses 1000 replications, alpha=0.05, and raw/non-crossing simultaneous confidence-band methods with rounding `K=10^3`; those settings are recorded in every scenario for provenance. This contribution does not implement the confidence band or its coverage experiment.

At `s=1`, `a_1=1`, so the last two source anchors have the same x-coordinate and the right-segment formula divides by zero. The source page does not specify the endpoint implementation. This package makes the explicit library convention `p_1(x)=0.2*x` for `0<=x<1` and `p_1(1)=1`. It changes only the singleton endpoint under continuous Uniform sampling, but it changes any endpoint-query truth and is therefore recorded as an adaptation requiring scientific review.

The package keeps all eleven source shape values `s=0,...,1` as named scenarios, with `s=0.5` as the default. The `s=0` case has `a=0.2` and both segment slopes equal one, so it is the diagonal `p(x)=x`; if the monomial, S-shaped, or wave families are also collected, their s=0 diagonal cases must be deduplicated rather than registered as new mechanism families.

No fixed code commit was given in the PDF, and no local replication checkout was used. The formal Biometrika version and its DGP differences from arXiv v2 were not checked. These are unresolved provenance items for maintainer review.

## Target and identification

This is a **noncausal NRI** task. For each scenario, the scalar target is

`m_s(x*) = E[Y | X=x*] = p_s(x*)`, with fixed query `x*=0.5`.

It is a conditional event probability, not an intervention effect, NIE, NDE, ATE, or future-response prediction interval. Because `Y|X=x` is Bernoulli with mean `p_s(x)`, the target is identified directly by the declared conditional law. The applicable conditions are iid individual sampling, the stated Uniform[0,1] covariate law, the Bernoulli observation model, the piecewise-linear anchor law, and the fixed query. For every registered scenario, including the declared s=1 endpoint convention, `p_s` is nondecreasing. No causal exchangeability, treatment, mediator, interference, or missing-data assumption is introduced.

## Truth and independent verification

The truth hook evaluates the piecewise-linear function at `x*=0.5`. For the default `s=0.5`, `a=0.6`, so the query is on the left segment:

`p_0.5(0.5)=0.2*0.5/0.6=1/6=0.16666666666666666`.

The hook reports a floating-point agreement estimate from a separate slope/intercept representation; it is not a confidence-band error bound. `verify.py` independently recomputes the value without calling `truth.py`, checks support, monotonicity, anchors and knot continuity, the s=0 diagonal identity, and the s=1 endpoint convention. Both routes necessarily share the source anchors and query, so source reconstruction and an independent-person reproduction remain outstanding.

The scalar check does **not** validate the paper's simultaneous band over all x. The current collection interface supplies one scalar truth per scenario; multiple point checks would not constitute simultaneous-coverage validation.

## Diversity and scope

Total covariate dimension and effective dimension are both 1. There are no interactions. The regression curve is piecewise linear with a kink at `a_s=0.2+0.8s` for `s>0`; `s=0` is the nested linear diagonal. The s=1 convention creates a singleton endpoint discontinuity between the left limit 0.2 and assigned value 1, which has probability zero under continuous Uniform sampling. Outcomes are binary and bounded; there is no latent variable, oracle nuisance, potential outcome, or unobserved response column. The generator returns only observed `X` and `Y`, uses a local seeded RNG, and does not use source replication counts to launch a large simulation.

Unsupported here: the source's full confidence-band computation, 1000-replication coverage rates, large bootstrap, PFN training, and formal-version/code-commit comparison.

## Rights and assistance

The PDF is retained outside the contribution ZIP. The ZIP contains independently written code and metadata only; no PDF, replication checkout, model weights, credentials, sensitive data, or data bank is included. AI assistance was used to extract the cited equations from the supplied PDF, draft the metadata, implement the standard-library hooks, and inspect local check output. Automated PASS is a format/run result and does not constitute named scientific review or acceptance. Maintainer review must resolve the formal-version DGP comparison, replication code commit, independent reproduction, and the s=1 endpoint convention.
