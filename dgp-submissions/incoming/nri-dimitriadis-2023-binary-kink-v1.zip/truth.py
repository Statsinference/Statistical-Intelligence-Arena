"""Analytic scalar NRI truth for the selected kink scenario."""
import math
import sys


def _validate(config):
    if not isinstance(config, dict):
        raise ValueError("config must be a scenario dictionary")
    s = config.get("s")
    x_star = config.get("x_star")
    if isinstance(s, bool) or not isinstance(s, (int, float)) or not math.isfinite(float(s)):
        raise ValueError("s must be finite numeric")
    if not 0.0 <= float(s) <= 1.0:
        raise ValueError("s must lie in the source grid [0,1]")
    if isinstance(x_star, bool) or not isinstance(x_star, (int, float)) or not math.isfinite(float(x_star)):
        raise ValueError("x_star must be finite numeric")
    if abs(float(x_star) - 0.5) > 1e-15:
        raise ValueError("this contribution fixes the NRI query at x_star=0.5")


def _piecewise(x, s):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    a = 0.2 + 0.8 * s
    if s >= 1.0:
        return 1.0 if x >= 1.0 else 0.2 * x
    if x <= a:
        return 0.2 * x / a
    return 0.2 + 0.8 * (x - a) / (1.0 - a)


def _slope_intercept(x, s):
    a = 0.2 + 0.8 * s
    if s >= 1.0:
        return 1.0 if x >= 1.0 else 0.2 * x
    if x <= a:
        return (0.2 / a) * x
    slope = 0.8 / (1.0 - a)
    return 0.2 + slope * (x - a)


def truth(config):
    """Return m_s(0.5)=E[Y|X=0.5]=p_s(0.5)."""
    _validate(config)
    s = float(config["s"])
    x_star = float(config["x_star"])
    value = _piecewise(x_star, s)
    alternate = _slope_intercept(x_star, s)
    estimated_error = abs(value - alternate) + 2.0 * sys.float_info.epsilon
    return {
        "value": float(value),
        "estimated_error": float(estimated_error),
        "method": "Piecewise-linear interpolation through (0,0), (a_s,0.2), (1,1), a_s=0.2+0.8s, with p_1(1)=1 endpoint convention; independently audited by slope/intercept evaluation.",
        "error_interpretation": "Floating-point agreement between equivalent piecewise evaluations; not a confidence-band or coverage error bound.",
        "target": "m_s(x_star)=E[Y|X=x_star]=p_s(x_star)",
        "query": {"x_star": x_star, "s": s, "a": 0.2 + 0.8 * s}
    }
