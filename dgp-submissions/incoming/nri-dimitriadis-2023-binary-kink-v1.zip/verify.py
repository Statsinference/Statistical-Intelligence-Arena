"""Independent analytic and shape checks for the kink NRI target."""
import math


def _piecewise(x, s):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    a = 0.2 + 0.8 * s
    if s >= 1.0:
        return 1.0 if x >= 1.0 else 0.2 * x
    if x <= a:
        return 0.2 * x / a
    return 0.2 + 0.8 * (x - a) / (1.0 - a)


def _independent_segment(x, s):
    a = 0.2 + 0.8 * s
    if s >= 1.0:
        return 1.0 if x >= 1.0 else 0.2 * x
    if x <= a:
        slope = 0.2 / a
        return slope * x
    slope = 0.8 / (1.0 - a)
    intercept = 0.2 - slope * a
    return intercept + slope * x


def verify(config):
    s = float(config["s"])
    x_star = float(config["x_star"])
    a = 0.2 + 0.8 * s
    direct = _piecewise(x_star, s)
    alternate = _independent_segment(x_star, s)
    grid = [i / 100.0 for i in range(101)]
    grid_with_knot = sorted(set(grid + [a]))
    values = [_piecewise(x, s) for x in grid_with_knot]
    continuity_ok = (
        (
            s < 1.0
            and abs(_piecewise(a, s) - 0.2) <= 2e-15
            and abs(_piecewise(1.0, s) - 1.0) <= 2e-15
        )
        or (
            s >= 1.0
            and _piecewise(1.0, s) == 1.0
        )
    )
    checks = [
        {
            "name": "independent_piecewise_vs_slope_intercept",
            "passed": abs(direct - alternate) <= 2e-15,
            "details": f"piecewise={direct:.17g}; slope-intercept={alternate:.17g}; difference={abs(direct-alternate):.3g}."
        },
        {
            "name": "conditional_probability_support",
            "passed": all(0.0 <= value <= 1.0 for value in values),
            "details": "The kink probabilities on the checked grid and knot stay in [0,1]."
        },
        {
            "name": "source_monotonicity_on_grid",
            "passed": all(values[i] <= values[i + 1] + 1e-15 for i in range(len(values) - 1)),
            "details": "Both segment slopes are nonnegative; the checked grid is nondecreasing under the s=1 endpoint convention."
        },
        {
            "name": "anchor_and_continuity_checks",
            "passed": abs(_piecewise(0.0, s)) <= 1e-15 and continuity_ok,
            "details": "The source anchors are met; for s<1 the knot joins continuously, while s=1 uses the declared p_1(1)=1 endpoint convention."
        },
        {
            "name": "default_s05_anchor",
            "passed": (abs(s - 0.5) > 1e-15) or abs(direct - (1.0 / 6.0)) <= 2e-15,
            "details": "For s=0.5, a=0.6 and p_s(0.5)=0.2*0.5/0.6=1/6."
        }
    ]
    if abs(s) < 1e-15:
        checks.append({
            "name": "s0_diagonal_anchor",
            "passed": max(abs(_piecewise(x, s) - x) for x in grid) <= 2e-15,
            "details": "s=0 gives a=0.2 and both segment slopes equal one, so p_0(x)=x; this endpoint is retained for source fidelity and deduplicated across other shape families."
        })
    if abs(s - 1.0) < 1e-15:
        checks.append({
            "name": "s1_endpoint_convention",
            "passed": _piecewise(1.0, s) == 1.0 and abs(_piecewise(0.999999, s) - 0.1999998) < 1e-12,
            "details": "At s=1, a=1; the library assigns p_1(1)=1 and keeps the left-limit law p_1(x)=0.2x for x<1."
        })
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "shared_components": "The independent route shares the declared kink anchors and query, but does not call truth.py; no source replication code or confidence-band computation is included.",
        "scope": "These checks cover the scalar analytic truth and source shape conditions only; they do not establish simultaneous confidence-band coverage."
    }
