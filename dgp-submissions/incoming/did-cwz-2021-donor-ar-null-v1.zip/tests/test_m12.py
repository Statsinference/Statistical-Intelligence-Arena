"""Authoritative independent M12 tests; no author R code is executed."""
import copy
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import random
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import generator
import truth
import verify

DOCUMENT = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
SCENARIOS = DOCUMENT["scenarios"]
EVIDENCE = {"authoritative_test_source": "tests/test_m12.py"}


def source_weights(name):
    # Independent rational specification, not generator._source_weights.
    if name == "W1":
        return [F(1, 20) for _ in range(20)]
    if name == "W2":
        return [F(int(j < 3), 3) for j in range(20)]
    if name == "W3":
        return [F(-1, 20) for _ in range(20)]
    if name == "W4":
        return [F(int(j == 0)-int(j == 1)) for j in range(20)]
    raise ValueError("Unknown source scenario")


def reference_world(seed, name):
    """Dense innovation-loading filter, independent of recursive generator helper."""
    rng = random.Random(seed)
    first = [rng.gauss(0, 1) for _ in range(21)]
    second = [rng.gauss(0, 1) for _ in range(21)]

    def dense_path():
        innovations = [rng.gauss(0, 1) * 0.8 for _ in range(21)]
        start = rng.gauss(0, 1)
        return [math.fsum([0.6**(t+1)*start] +
                         [0.6**(t-k)*innovations[k] for k in range(t+1)])
                for t in range(21)]

    donor_errors = [dense_path() for _ in range(20)]
    donor_rows = [[(j+1)/20 + first[t] + ((j+1)/20)*second[t] + donor_errors[j][t]
                  for t in range(21)] for j in range(20)]
    extra = dense_path()
    weights = source_weights(name)
    treated = [math.fsum(float(weights[j])*donor_rows[j][t] for j in range(20)) + extra[t]
               for t in range(21)]
    return [treated] + donor_rows


class M12Tests(unittest.TestCase):
    def test_interface_shape_seed_and_isolation(self):
        self.assertEqual(DOCUMENT["default_scenario"], "W1")
        self.assertEqual(list(SCENARIOS), ["W1", "W2", "W3", "W4"])
        state = random.getstate()
        counts = {}
        for name, config in SCENARIOS.items():
            before = copy.deepcopy(config)
            data = generator.generate(config, 21, 1729)
            self.assertEqual(data, generator.generate(config, 21, 1729))
            self.assertNotEqual(data, generator.generate(config, 21, 1730))
            self.assertEqual(config, before)
            self.assertEqual(list(data), ["G"] + [f"Y_pre_{t:02d}" for t in range(1, 21)] + ["Y_post_01"])
            self.assertTrue(all(len(col) == 21 for col in data.values()))
            self.assertEqual(data["G"], [1] + [0]*20)
            self.assertTrue(all(math.isfinite(x) for col in data.values() for x in col))
            self.assertTrue(all(isinstance(x, float) for k, col in data.items() if k != "G" for x in col))
            counts[name] = {"rows": 21, "columns": 22, "treated": 1, "donors": 20,
                            "pre_periods": 20, "post_periods": 1}
        self.assertEqual(state, random.getstate())
        EVIDENCE["actual_table_structure"] = counts

    def test_reject_unapproved_parameters_and_sizes(self):
        config = SCENARIOS["W1"]
        for n in (0, 11, 20, 22, 32, 21.0, True):
            with self.assertRaises(ValueError):
                generator.generate(config, n, 1729)
        for seed in (True, 1.5, "1729"):
            with self.assertRaises(ValueError):
                generator.generate(config, 21, seed)
        changed = []
        for key, value in (("J", 19), ("T0", 19), ("T_post", 2),
                           ("rho_epsilon", 0.5), ("rho_u", 0.5),
                           ("innovation_variance", 1), ("initial_variance", 0),
                           ("factor_variance", 2), ("theta_T", 1),
                           ("weight_scheme", "W5"), ("J", 20.0)):
            changed.append(dict(config, **{key: value}))
        changed += [dict(config, hidden_weight=1),
                    {key: value for key, value in config.items() if key != "theta_T"}]
        for altered in changed:
            with self.assertRaises(ValueError):
                generator.generate(altered, 21, 1729)
            with self.assertRaises(ValueError):
                truth.truth(altered)
            self.assertFalse(verify.verify(altered)["passed"])
        EVIDENCE["rejected_parameter_cases"] = len(changed)

    def test_independent_dense_filter_and_time_mapping(self):
        largest_error = 0.0
        for name, config in SCENARIOS.items():
            for seed in (47, 1729, 12345):
                observed = generator.generate(config, 21, seed)
                expected = reference_world(seed, name)
                for row in range(21):
                    for t in range(21):
                        key = f"Y_pre_{t+1:02d}" if t < 20 else "Y_post_01"
                        error = abs(observed[key][row]-expected[row][t])
                        largest_error = max(largest_error, error)
                        self.assertLess(error, 1e-12)
        EVIDENCE["independent_dense_filter"] = {
            "scenarios": 4, "seeds": [47, 1729, 12345], "complete_panels": 12,
            "maximum_absolute_error": largest_error, "threshold": 1e-12,
            "passed": True,
            "independence": "Exact source weights plus a dense innovation convolution; no generator private helper calls",
        }

    def test_all_source_weights_and_extra_residual_identity(self):
        seed = 901
        tables = {name: generator.generate(config, 21, seed)
                  for name, config in SCENARIOS.items()}
        reference_extra = None
        expected_algebra = {
            "W1": (F(1), F(21, 40), F(1, 20)),
            "W2": (F(1), F(1, 10), F(1, 3)),
            "W3": (F(-1), F(-21, 40), F(1, 20)),
            "W4": (F(0), F(-1, 20), F(2)),
        }
        for name, table in tables.items():
            w = source_weights(name)
            triple = (sum(w), sum(w[j]*F(j+1, 20) for j in range(20)), sum(v*v for v in w))
            self.assertEqual(triple, expected_algebra[name])
            self.assertEqual([x for col, xs in table.items() if col != "G" for x in xs[1:]],
                             [x for col, xs in tables["W1"].items() if col != "G" for x in xs[1:]])
            recovered = [xs[0]-math.fsum(float(w[j])*xs[j+1] for j in range(20))
                         for key, xs in table.items() if key != "G"]
            if reference_extra is None:
                reference_extra = recovered
            else:
                self.assertTrue(all(abs(a-b)<1e-12 for a, b in zip(reference_extra, recovered)))
        self.assertNotEqual(tables["W1"]["Y_post_01"][0], tables["W3"]["Y_post_01"][0])
        EVIDENCE["all_weights"] = {
            name: [str(v) for v in source_weights(name)] for name in SCENARIOS}

    def test_analytic_truth_and_independent_verifier(self):
        results = {}
        for name, config in SCENARIOS.items():
            oracle = truth.truth(config)
            self.assertEqual(oracle["value"], 0)
            self.assertEqual(oracle["estimated_error"], 0)
            result = verify.verify(config)
            self.assertTrue(result["passed"])
            self.assertTrue(all(c["passed"] for c in result["checks"]))
            results[name] = result
        EVIDENCE["mathematical_verification"] = results
        EVIDENCE["truth_scope"] = "ATT and SATT are exact pointwise zero; no requirement that observed pre/post change vanish"

    def test_statistical_joint_process(self):
        replications = 4096
        times = (0, 1, 5, 20)
        donor_errors = {t: [[] for _ in range(20)] for t in times}
        factors = {k: {t: [] for t in times} for k in (1, 2)}
        states = {name: {key: {t: [] for t in times} for key in ("u", "r1", "y1")}
                  for name in SCENARIOS}
        for seed in range(50000, 50000+replications):
            # Independent test-side replay of only the first 42 source normal draws.
            # This reveals factors solely to the audit, never to generator output.
            rng = random.Random(seed)
            f1 = [rng.gauss(0, 1) for _ in range(21)]
            f2 = [rng.gauss(0, 1) for _ in range(21)]
            for t in times:
                factors[1][t].append(f1[t])
                factors[2][t].append(f2[t])
            for name, config in SCENARIOS.items():
                table = generator.generate(config, 21, seed)
                w = source_weights(name)
                weights = [float(v) for v in w]
                sw = float(sum(w))
                bw = float(sum(w[j]*F(j+1, 20) for j in range(20)))
                for t in times:
                    key = f"Y_pre_{t+1:02d}" if t < 20 else "Y_post_01"
                    ys = table[key]
                    if name == "W1":
                        for j in range(20):
                            donor_errors[t][j].append(ys[j+1]-(j+1)/20-f1[t]-((j+1)/20)*f2[t])
                    extra = ys[0]-math.fsum(weights[j]*ys[j+1] for j in range(20))
                    residual = ys[0]-(bw+sw*f1[t]+bw*f2[t])
                    states[name]["u"][t].append(extra)
                    states[name]["r1"][t].append(residual)
                    states[name]["y1"][t].append(ys[0])

        def mean(xs):
            return math.fsum(xs)/len(xs)

        def covariance(xs, ys):
            return mean([x*y for x, y in zip(xs, ys)])-mean(xs)*mean(ys)

        checks = {}
        EVIDENCE["statistical_audit"] = {
            "replications": replications, "panel_units": 21, "panel_periods": 21,
            "seeds": [50000, 50000+replications-1], "times_zero_based": list(times),
            "checks": checks,
            "threshold_policy": "Predeclared strict absolute deviation < 8 times analytic normal moment SE; covariance uses sqrt((VarX*VarY+target^2)/R). CDF distance <6/sqrt(R). No threshold relaxation.",
            "residual_reconstruction": "Test-only replay of the source's first 42 factor draws; actual donor errors are reconstructed from public observed Y. u is recovered from actual treated Y minus exact source-weighted observed donors.",
            "limits": "Finite-sample evidence, not proof of independence or scientific acceptance. Different weight scenarios share seed draws for diagnostic pairing. No latent/error arrays are exported in observations or evidence.",
        }

        def record(name, actual, target, bound):
            passed = abs(actual-target) < bound
            checks[name] = {"statistic": actual, "target": target,
                            "absolute_deviation": abs(actual-target),
                            "threshold": bound, "comparison": "absolute_deviation < threshold",
                            "passed": passed}
            self.assertTrue(passed, name)

        def check_cov(name, xs, ys, target, varx=1.0, vary=1.0):
            record(name, covariance(xs, ys), target,
                   8*math.sqrt((varx*vary+target*target)/replications))

        def check_normal(name, xs, variance=1.0, expected_mean=0.0):
            record(name+"_mean", mean(xs), expected_mean, 8*math.sqrt(variance/replications))
            record(name+"_variance", covariance(xs, xs), variance, 8*variance*math.sqrt(2/replications))
            ordered = sorted(xs)
            d = max(max((i+1)/replications-(.5*(1+math.erf((x-expected_mean)/math.sqrt(2*variance)))),
                        (.5*(1+math.erf((x-expected_mean)/math.sqrt(2*variance))))-i/replications)
                    for i, x in enumerate(ordered))
            record(name+"_normal_cdf_distance", d, 0, 6/math.sqrt(replications))

        for k in (1, 2):
            for t in (0, 20):
                check_normal(f"F{k}_t{t}", factors[k][t])
            check_cov(f"F{k}_time_independence", factors[k][0], factors[k][1], 0)
        check_cov("F1_F2_independence", factors[1][0], factors[2][0], 0)
        check_cov("F1_F2_cross_time_independence", factors[1][0], factors[2][1], 0)
        for j in range(20):
            check_normal(f"donor{j+1}_epsilon_first", donor_errors[0][j])
            check_normal(f"donor{j+1}_epsilon_post", donor_errors[20][j])
            for t in (1, 5, 20):
                check_cov(f"donor{j+1}_AR_lag{t}", donor_errors[0][j], donor_errors[t][j], .6**t)
            check_cov(f"donor{j+1}_epsilon_factor1", donor_errors[0][j], factors[1][0], 0)
            check_cov(f"donor{j+1}_epsilon_factor2", donor_errors[0][j], factors[2][0], 0)
            if j:
                check_cov(f"donor0_donor{j+1}_epsilon_independence",
                          donor_errors[0][0], donor_errors[0][j], 0)
        for name, process in states.items():
            w = source_weights(name)
            sw = float(sum(w))
            bw = float(sum(w[j]*F(j+1, 20) for j in range(20)))
            q = float(sum(v*v for v in w))
            for t in (0, 20):
                check_normal(f"{name}_extra_u_t{t}", process["u"][t])
                check_normal(f"{name}_treated_residual_t{t}", process["r1"][t], 1+q)
                check_normal(f"{name}_treated_observed_t{t}", process["y1"][t], sw*sw+bw*bw+q+1, bw)
            for t in (1, 5, 20):
                check_cov(f"{name}_extra_u_AR_lag{t}", process["u"][0], process["u"][t], .6**t)
                check_cov(f"{name}_treated_residual_AR_lag{t}", process["r1"][0], process["r1"][t],
                          (1+q)*.6**t, 1+q, 1+q)
                check_cov(f"{name}_treated_observed_lag{t}", process["y1"][0], process["y1"][t],
                          (1+q)*.6**t, sw*sw+bw*bw+q+1, sw*sw+bw*bw+q+1)
            check_cov(f"{name}_extra_u_factor1", process["u"][0], factors[1][0], 0)
            check_cov(f"{name}_extra_u_factor2", process["u"][0], factors[2][0], 0)
            for j in range(20):
                for t in (0, 1):
                    check_cov(f"{name}_extra_u_donor{j+1}_lag{t}", process["u"][0], donor_errors[t][j], 0)
                    check_cov(f"{name}_total_residual_donor{j+1}_lag{t}",
                              process["r1"][0], donor_errors[t][j], float(w[j])*.6**t, 1+q, 1)
        EVIDENCE["statistical_audit"]["all_passed"] = all(c["passed"] for c in checks.values())
        EVIDENCE["statistical_audit"]["check_count"] = len(checks)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(M12Tests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    EVIDENCE.update({"passed": result.wasSuccessful(), "tests_run": result.testsRun,
                     "failures": len(result.failures), "errors": len(result.errors),
                     "executed_at_utc": datetime.now(timezone.utc).isoformat()})
    EVIDENCE["source_sha256"] = {
        p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(ROOT.rglob("*"))
        if p.is_file() and "checks" not in p.relative_to(ROOT).parts
        and "__pycache__" not in p.relative_to(ROOT).parts
    }
    checks = ROOT / "checks"
    checks.mkdir(exist_ok=True)
    (checks / "independent_audit.json").write_text(
        json.dumps(EVIDENCE, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
