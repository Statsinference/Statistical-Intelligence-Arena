"""Independent exact-rational source and covariance checks, no generated data."""
from fractions import Fraction as F
import math


def verify(config):
    checks = []

    def record(name, passed, details):
        checks.append({"name": name, "passed": bool(passed), "details": details})

    frozen = {
        "J": 20, "T0": 20, "T_post": 1, "rho_epsilon": 0.6, "rho_u": 0.6,
        "innovation_variance": 0.64, "initial_variance": 1,
        "factor_variance": 1, "theta_T": 0,
    }
    valid = isinstance(config, dict) and set(config) == set(frozen) | {"weight_scheme"}
    valid = valid and all(isinstance(config[k], (int, float))
                          and not isinstance(config[k], bool)
                          and math.isfinite(config[k]) and config[k] == v
                          for k, v in frozen.items())
    valid = valid and all(isinstance(config[k], int) for k in ("J", "T0", "T_post"))
    valid = valid and config["weight_scheme"] in ("W1", "W2", "W3", "W4")
    record("frozen_source_parameters", valid, frozen)
    if not valid:
        return {"passed": False, "checks": checks}

    # The verifier uses exact source fractions, not generator helper arithmetic.
    scheme = config["weight_scheme"]
    vectors = {
        "W1": [F(1, 20)] * 20,
        "W2": [F(1, 3) if c < 3 else F(0) for c in range(20)],
        "W3": [F(-1, 20)] * 20,
        "W4": [F(1), F(-1)] + [F(0)] * 18,
    }
    w = vectors[scheme]
    s = sum(w)
    b = sum(w[c] * F(c+1, 20) for c in range(20))
    q = sum(x*x for x in w)
    references = {
        "W1": (F(1), F(21, 40), F(1, 20)),
        "W2": (F(1), F(1, 10), F(1, 3)),
        "W3": (F(-1), F(-21, 40), F(1, 20)),
        "W4": (F(0), F(-1, 20), F(2)),
    }
    record("source_weight_algebra", (s, b, q) == references[scheme],
           {"scenario": scheme, "weights": [str(x) for x in w],
            "sum": str(s), "weighted_loading": str(b), "squared_norm": str(q)})

    # Exact innovation-loading expansion independently proves stationary AR covariance.
    rho, variance = F(3, 5), F(16, 25)
    ar_ok = True
    maximum_error = F(0)
    for t in range(1, 22):
        for r in range(1, 22):
            expanded = rho ** (t+r) + variance * sum(
                rho ** (t+r-2*k) for k in range(1, min(t, r)+1))
            error = abs(expanded - rho ** abs(t-r))
            maximum_error = max(maximum_error, error)
            ar_ok = ar_ok and error == 0
    record("independent_finite_path_ar_covariance", ar_ok,
           {"initial_variance": 1, "innovation_variance": str(variance),
            "covariance": "(3/5)^abs(t-s)", "pairs_checked": 441,
            "maximum_exact_error": str(maximum_error),
            "method": "Finite innovation-loading expansion, not recursive generator output"})

    # Disjoint innovation blocks for u and all donor epsilon processes.
    r1 = w + [F(1)]
    u = [F(0)] * 20 + [F(1)]
    extra_covs, total_covs = [], []
    for j in range(20):
        donor = [F(int(k == j)) for k in range(21)]
        extra_covs.append(sum(a*c for a, c in zip(u, donor)))
        total_covs.append(sum(a*c for a, c in zip(r1, donor)))
    record("extra_u_independent_donor_gaussian_blocks",
           all(c == 0 for c in extra_covs),
           "u uses a separate independent initial/innovation Gaussian block; "
           "this is NOT independence of the total treated residual.")
    record("treated_donor_residual_sharing",
           total_covs == w,
           {"lag0_covariances": [str(c) for c in total_covs],
            "lag_h": "w_j*(3/5)^h"})
    total_variance = s*s + b*b + q + 1
    record("observed_signal_noise_moments",
           (scheme != "W1" or total_variance == F(3721, 1600)),
           {"mean": str(b), "variance": str(total_variance),
            "nonzero_lag_covariance": "(1+||w||^2)*(3/5)^h",
            "notes": "The common factors are iid across periods; AR dependence is residual."})

    # Independent response coefficient comparison in one exogenous world.
    # Coordinates: intercept, F1, F2, twenty donor errors, extra error.
    untreated = [b, s, b] + w + [F(1)]
    treated = [b + F(config["theta_T"]), s, b] + w + [F(1)]
    contrast = [a-c for a, c in zip(treated, untreated)]
    record("pointwise_satt_and_design_att_zero", all(c == 0 for c in contrast),
           {"contrast_coefficients": [str(c) for c in contrast],
            "SATT": 0, "design_ATT": 0,
            "reason": "All state terms cancel holding the same donor panel and u fixed."})
    return {
        "passed": all(c["passed"] for c in checks), "checks": checks,
        "scope": "Mathematics and declared source parameters only; no table or external n received",
        "independence": "No imports from generator.py or truth.py; exact rational expansion and Gaussian block algebra",
        "limits": "Actual generated counts, pairing and empirical moments require separate tests; no scientific acceptance claim",
    }
