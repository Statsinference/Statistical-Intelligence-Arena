"""Analytic single-post-period causal truth; no generator/verify imports."""
import math


def truth(config):
    expected = {
        "J": 20, "T0": 20, "T_post": 1, "rho_epsilon": 0.6, "rho_u": 0.6,
        "innovation_variance": 0.64, "initial_variance": 1,
        "factor_variance": 1, "theta_T": 0,
    }
    if not isinstance(config, dict) or set(config) != set(expected) | {"weight_scheme"}:
        raise ValueError("Oracle requires the registered M12 parameter object")
    for name, reference in expected.items():
        value = config[name]
        if (not isinstance(value, (int, float)) or isinstance(value, bool)
                or not math.isfinite(value) or value != reference):
            raise ValueError(f"Unapproved M12 parameter {name}")
    if any(not isinstance(config[name], int) for name in ("J", "T0", "T_post")):
        raise ValueError("Panel counts must be integers")
    if config["weight_scheme"] not in ("W1", "W2", "W3", "W4"):
        raise ValueError("Unknown weight scenario")
    return {
        "value": 0.0, "estimated_error": 0.0,
        "method": "Exact structural response identity for the fixed treated unit",
        "definition": "Y_1,T(1)-Y_1,T(0), T=21; its design expectation and SATT",
        "derivation": "Both responses hold the entire donor panel and the same "
                      "extra post-period residual fixed. Their difference is theta_T=0 "
                      "pointwise for all four weights. A single treated unit's SATT "
                      "and the design-population expectation are also exactly zero. "
                      "Neither the observed pre/post change nor the donor prediction "
                      "residual is the causal effect.",
    }
