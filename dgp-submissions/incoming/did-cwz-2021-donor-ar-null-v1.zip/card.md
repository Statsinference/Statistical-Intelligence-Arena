# M12: CWZ (2021), donor combination with stationary AR residuals

## Source and version

Chernozhukov, V., Wüthrich, K., and Zhu, Y. (2021). *An Exact and Robust Conformal Inference Method for Counterfactual and Synthetic Controls*. JASA116(536),1849–1864.
DOI: https://doi.org/10.1080/01621459.2021.1920957

Primary mathematical source: official Online Supplemental Appendix, dated2021-04-05, Appendix G PDF14–15; weight table and equations on14, Table I.2 on57.
Official publication-linked archive: https://doi.org/10.6084/m9.figshare.14473870.v1
File ID27702607, online_supplements.zip, MD5 45cd06497fcc35dcd7b30f5340565fc2.
This immutable archive version pins the actual simulation source; no Git commit is invented for it.
Package source path: online_supplements/replication_package_final/simulations_conformal_final.R.
Lines31–39: AR series and initial draw;43–73: complete single-panel mechanism;98:T1=1;149–150:J/T0 grid;164:rho=.6 null experiment.
The related scinference GitHub repository commit567c6889ce0a1d269a62d415b88aa6baf723a3fe is an inference package with a different illustrative example, not a substitute for the official simulation archive.

The publisher's final main-text PDF has not been read in full during this collection; no unverified main-text page/equation numbers are supplied. The simulation mechanism is explicitly located in the retrieved official supplement. An earlier arXiv v10 PDF bears a2022 page-header date; it was auxiliary during audit and is not the version used to override the official supplement.

## Frozen source baseline

One treated unit j=1;20 donors j=2,...,21;T0=20;one post period;T=21.
a_j=b_j=(j-1)/20.
rho_epsilon=rho_u=.6; AR innovation variance=.64 (standard deviation=.8).
Each independent AR initial state has distribution N(0,1).
Both common factors F1t and F2t are independently iid N(0,1).
theta_T=0.
This selects an original Table I.2 cell and includes its four original weight scenarios. It is not a new parameter extension.

Author R simulation settings seed12345,5000 replications and test level.1 concern estimator-performance experiments. Our local seed is an interface input; no R/Python bitwise equality or Table I.2 rejection-rate replication is claimed.

## Complete generation order

1. Generate one common factor vector F1 and an independent vector F2, each of length21.
2. For each donor, generate21 independent N(0,.64) innovations and an independent N(0,1) start. Recursively compute epsilon_jt=.6 epsilon_j,t-1+xi_jt, returning t=1,...,21. The initial t=0 draw is not returned; no extra burn-in.
3. Set Y_jt=a_j+F1t+b_j F2t+epsilon_jt.
4. Independently generate extra residual u with the same AR law and its own independent initial/innovation draws.
5. Set the treated unit's no-treatment response Y_1t(0)=sum_j w_j Y_jt+u_t.
6. Add theta_T=0 only at the last treated observation; all donors remain untreated.

All initial draws, factor vectors and innovation blocks are independent. Observed units are not independent: factors are shared, and the treated response also inherits actual donor-specific noise. In particular, replacing actual donor outcomes by just their factor means would change this DGP.

## Four weight scenarios, one family

The donor slot c=1,...,20 corresponds to paper j=c+1; fixed order is preserved.

|scenario|source weights|default|
|---|---|---|
|W1|all20 weights1/20|yes|
|W2|first3 weights1/3;remaining17 zero|no|
|W3|all20 weights-1/20|no|
|W4|first two weights1,-1;remaining18 zero|no|

Weights are specified by the DGP, not estimated by a synthetic-control optimizer. W3/W4 intentionally violate standard SC weight constraints; do not repair them.
Changing weights does not create a new mechanism family. All four retain the same mathematical process and the same panel size.
For the same local seed, the implementation draws the same donor paths and u across weight scenarios and then applies the scenario's fixed weights; this is a diagnostic coupling, not a fourth source of random sampling.

## Estimand and exact truth

The target is the single designated treated unit's last-period response contrast tau_T=Y_1T(1)-Y_1T(0).
Holding the same donor panel and u fixed, the only response change is theta_T; therefore tau_T=theta_T=0 for every realization.
The finite-sample single-treated-unit SATT and its design-population expectation are likewise exactly zero for every weight scenario.
This is not based on averaging a noisy estimate or assuming the realized donor prediction residual vanishes.
Observed Y_post-Y_pre generally differs from zero, and Y_1T-sum_j w_j Y_jT=u_T generally differs from zero.

No anticipation and no treatment feedback to donors/exogenous processes define the two treatment states. Source stability assumptions concern estimation/inference, not the algebraic validity of the oracle. Standard parallel-trend/SC correctness is not asserted simultaneously for all intentionally misspecified weights.

## Observation interface

Each row is a unit, not a time period or an independent panel replication. The table is one joint panel.
Exactly22 columns:
G,Y_pre_01,...,Y_pre_20,Y_post_01.
G=[1,0,...,0];20 pre columns correspond to t=1,...,20;post to21.
All columns are observed. G has treatment/binary role, the other21 outcome/float. Outcomes have no finite bounds and are not truncated.
A_pre=0 and A_post=G reconstruct actual exposure.
No ID, latent factors, errors, weights, potential outcomes, conditional means or oracle labels are exported.

generate(config,n,seed) requires n=21, an integer; all lists have exactly n entries.
No sample-size extension is approved. Any other n, including default32, raises an error, with no resampling, copying, truncation or silent replacement.
config is the selected scenario object. Scientific parameters are strictly validated, including frozen sizes, variances and response; unknown/missing keys and unknown scenarios are rejected.
The official check must explicitly use --run --n21 and include all declared scenarios. The toolkit accepts such an explicit n; it does not require scientifically changing this panel to32 rows.

## Mathematical covariance evidence

For an AR path, Var(Z0)=1 and innovation variance1-rho² imply Var(Zt)=1 and Cov(Zt,Zs)=rho^abs(t-s).
Let r_jt=epsilon_jt and r_1t=sum w_j epsilon_jt+u_t after removing the shared factors and intercept.
Then Cov(u_t,r_js)=0, but Cov(r_1t,r_js)=w_j*.6^abs(t-s).
Extra u independence must never be confused with total treated-residual independence.

With S=sum w, B=sum w_j b_j, Q=sum w_j²:
E[Y_1t(0)]=B,
Var(Y_1t(0))=S²+B²+Q+1,
and nonzero-lag Cov=(Q+1)*.6^lag.
For W1: S=1,B=21/40,Q=1/20,Var=3721/1600=2.325625.
The verifier computes source fractions and proves finite-path AR covariance by a separate exact innovation-loading expansion; it imports neither generator nor truth.

## Independent tests and scope

tests/test_m12.py is the only authoritative test source.
It checks fixed n/columns/finite numbers, group counts, reproducibility, global-RNG/config isolation, rejected unapproved parameters and all four weights.
An independent dense linear-filter reference reconstructs complete panels using exact source weights, without calling generator private helpers. This checks observations, source ordering and time mapping, not an oracle self-comparison.
Statistical diagnostics use4096 independent local-seed panels per scenario (QA replications, not a new source DGP parameter). They record actual means, variances, CDF distances, AR covariance, u/donor independence and total treated/donor sharing against predeclared thresholds.
Factor draws are replayed only inside the independent tests to reconstruct actual residuals; these values are not exported in generated tables or retained as a sample bank.
Thresholds are eight analytic normal moment standard errors for moment diagnostics and6/sqrt(R) for one-dimensional normal CDF distance. They are finite-sample diagnostic bounds, not simultaneous confidence guarantees.

verify(config) receives no generated table or external n; its scope is exact mathematical/parameter verification only.
Actual sample structure and empirical statistics are validated by the separate tests and generator checks, not by pretending verify saw the data.
checks/independent_audit.json records test outcomes, numeric evidence, thresholds and checked-source hashes.
Official pack includes the baseline report/sample and source inventory according to the tool's actual code; supplementary local audits are not assumed to be automatically included. The full local contribution directory preserves them for review.

## Rights, provenance and review status

source.license describes source rights only. Official Figshare14473870.v1 metadata identifies CC BY4.0 for the source supplemental item. This is not automatically a license for the publisher main paper or our independently written Python contribution.
Main-paper open-license/copyright terms were not independently confirmed from its final full PDF; no additional permission is inferred.
The separate scinference repository's GPLv3 concerns that estimator repository, not these source-archive simulation rights. No source PDFs, R files or empirical datasets are redistributed here.
No release license for the student's Python contribution is selected through this source-rights field.
Implementation and audit code were AI assisted under the user's frozen specification; machine checks and archive validation do not confer official scientific acceptance.
