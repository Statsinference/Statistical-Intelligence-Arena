# NRI collection: CCF2018 Model 3 — two Gaussian peaks (homoscedastic)

**Status: candidate; not scientifically accepted.**

Source: Calonico, S., Cattaneo, M. D., and Farrell, M. H. (2018). On the Effect of Bias Estimation on Coverage Accuracy in Nonparametric Inference. *Journal of the American Statistical Association* 113(522), 767–779. DOI [10.1080/01621459.2017.1285776](https://doi.org/10.1080/01621459.2017.1285776). Supplement dated December 16, 2017.

## Source and reconstruction

**Supplement §S.II.7** ("Complete Simulation Results", printed p. 80, PDF p. 81): all six regression DGP models. This contribution collects Model 3.

**Main text §4** (printed p. 776, PDF p. 10): the five-point evaluation grid x ∈ {−2/3, −1/3, 0, 1/3, 2/3}.

Attribution (supplement p. 81): "Models 1 to 3 were used by Fan and Gijbels (1996) and Cattaneo and Farrell (2013)."

### Shared DGP structure (§S.II.7)

```
Y_i = m(X_i) + eps_i,    i = 1, ..., n
X_i ~ U[-1, 1]           (iid)
eps_i ~ N(0, 1)          (iid, homoscedastic, independent of X_i)
```

Paper simulation: n = 500, 5000 replications. This collection uses population equations only.

### Model 3 — two Gaussian peaks (§S.II.7)

```
m(x) = 0.3 * exp(-4*(2x+1)^2) + 0.7 * exp(-16*(2x-1)^2)
```

**Left peak:** amplitude 0.3, centered at x = −1/2 (where 2x+1 = 0), width parameter 4 (effective width ~1/(2√2) ≈ 0.35).  
**Right peak:** amplitude 0.7, centered at x = +1/2 (where 2x−1 = 0), width parameter 16 (effective width ~1/(4√2) ≈ 0.18, sharper than left).  
The two peaks are well separated (centers at ±1/2; gap of 1).

### Cross-paper family note

The Chen–Qin (2000) two-peak structure satisfies `m_CQ(x) = m_CCF_M3(2x−1)`, so the *mean* is in the same family. However, CQ uses a **heteroscedastic** noise law, support **[0,1]**, and query points **{0, 0.5}**. Because the complete observation law differs, CQ is collected as a **separate independent contribution**; this contribution only does the CCF M3 homoscedastic scenario. A named reviewer should confirm the cross-paper family relationship.

## Target and identification

**Estimand:** `m(x₀) = E[Y | X = x₀]` at each fixed query point x₀.

Because `eps ~ N(0,1)` with `E[eps] = 0` (homoscedastic), `E[Y|X=x₀] = m(x₀)`. No causal interpretation. This is an NRI (nonparametric regression inference) task.

**Applicable assumptions:**

- X and eps independent; E[eps] = 0; Var(eps) = 1 constant (homoscedastic).
- m(x) is smooth (C-infinity); each Gaussian peak is smooth; peaks well separated.
- Pointwise inference at each fixed query point; the five-point grid is **not** a simultaneous confidence band.
- No treatment, mediator, or intervention.

## Truth and independent verification

### Five-point analytic decomposition

Each query point gives `exp` of an exact rational; the value is `0.3·exp(r₁) + 0.7·exp(r₂)` with r₁, r₂ rational.

| x₀ | peak1 arg | peak1 = 0.3·exp(·) | peak2 arg | peak2 = 0.7·exp(·) | m3(x₀) |
|---|---|---|---|---|---|
| −2/3 | −4/9 | 0.1923541165289864 | −784/9 | 1.03×10⁻³⁸ | **0.1923541165289864** |
| −1/3 | −4/9 | 0.1923541165289864 | −400/9 | 3.49×10⁻²⁰ | **0.1923541165289864** |
| 0 | −4 | 0.0054946916666203 | −16 | 7.877×10⁻⁸ | **0.0054947704412426** |
| 1/3 | −100/9 | 4.48×10⁻⁶ | −16/9 | 0.1183093207842463 | **0.1183138043858036** |
| 2/3 | −196/9 | 1.05×10⁻¹⁰ | −16/9 | 0.1183093207842463 | **0.1183093208887551** |

### Key symmetry identities for verification

- **Left pair symmetry:** `(2·(−2/3)+1)² = (−1/3)² = 1/9 = (2·(−1/3)+1)² = (1/3)²`. So peak1 contributes exactly `0.3·exp(−4/9)` at both x₀ = −2/3 and x₀ = −1/3.
- **Right pair symmetry:** `(2·(1/3)−1)² = (−1/3)² = 1/9 = (2·(2/3)−1)² = (1/3)²`. So peak2 contributes exactly `0.7·exp(−16/9)` at both x₀ = 1/3 and x₀ = 2/3.
- **Peak centers:** m3(−1/2) ≈ 0.3 (peak1 = 0.3·exp(0) = 0.3 exactly); m3(+1/2) ≈ 0.7 (peak2 = 0.7·exp(0) = 0.7 exactly).

### Independent verification routes (verify.py)

1. **Independent exponent-factored path:** same two-peak equation, different intermediate variable order. Agreement < 1e-12.
2. **Left-pair peak1 symmetry:** peak1(−2/3) = peak1(−1/3) = 0.3·exp(−4/9) to machine precision.
3. **Right-pair peak2 symmetry:** peak2(1/3) = peak2(2/3) = 0.7·exp(−16/9) to machine precision.
4. **Peak dominance:** at x₀ = −2/3, right peak < 1.1×10⁻³⁸; at x₀ = 2/3, left peak < 1.1×10⁻¹⁰.
5. **Peak-center exact values:** peak1(−1/2) = 0.3, peak2(+1/2) = 0.7.

**Shared components:** both truth.py and verify.py evaluate the declared two-peak equation. Paths differ in intermediate variable order; verify.py adds symmetry and peak-center special cases. Named scientific review and independent-person reproduction remain pending.

## Diversity and scope

- **dimension = 1, effective_dimension = 1.** Single covariate X.
- **nonlinear = true.** Mixture of two Gaussian peaks with different amplitudes (0.3, 0.7) and widths (4, 16); bimodal regression surface.
- **interactions = false.** Single-covariate model.
- **high_dimensional = false.**
- **Heteroscedasticity:** NOT a property of this scenario (homoscedastic eps ~ N(0,1)).

The two peaks create two regions of high curvature (near x = ±1/2); between and outside the peaks, m(x) is small. Coverage distortions are most pronounced near the peak centers; x₀ = 0 sits in the valley between peaks where m is small (≈ 0.0055).

## Rights and assistance

Paper copyright ASA / Taylor & Francis. No paper PDF or nprobust package code is distributed here. Equations are cited and independently implemented. Claude Code (AI assistant) extracted the equation from the PDF and wrote the Python code; a named human reviewer must verify equation transcription and independently reproduce the result.

**Open issues:**

- The supplement extraction may have distorted special characters; a named reviewer should verify `m(x) = 0.3*exp(-4*(2x+1)^2) + 0.7*exp(-16*(2x-1)^2)` against the original printed PDF (amplitudes 0.3, 0.7; width parameters 4, 16; centers via (2x±1)).
- The Chen–Qin (2000) cross-paper family relationship (`m_CQ(x) = m_CCF_M3(2x−1)`) and the separate-contribution decision (CQ heteroscedastic, support [0,1], query {0, 0.5}) should be confirmed by the reviewer.
- `reference_value` in collection.json is anchored to the default scenario `m3_x0_0` = 0.0054947704412426. The checker verifies truth() against `reference_value` only for the default scenario.
