"""Independent verification for CCF2018 supplement S.II.7 Model 3.

Verification strategy (independent of truth.py):
1. Second arithmetic path: factor the exponent argument differently.
   truth.py computes (2x+1)*(2x+1) inline; verify.py expands to
   4x^2+4x+1 and 4x^2-4x+1 explicitly, then squares-by-multiplication.
2. Peak-pair symmetry identities specific to this two-peak model:
   - At x0 in {-2/3, -1/3}: (2x0+1)^2 = 1/9 in both cases, so peak1
     contributes exactly 0.3*exp(-4/9) at both. Check equality of peak1.
   - At x0 in {1/3, 2/3}: (2x0-1)^2 = 1/9 in both cases, so peak2
     contributes exactly 0.7*exp(-16/9) at both. Check equality of peak2.
3. Peak dominance: at x0=-2/3 the right peak contributes 0.7*exp(-784/9)
   which is < 1.1e-38 (effectively zero); at x0=2/3 the left peak contributes
   0.3*exp(-196/9) < 1.1e-10 (also negligible). Verify these bounds.
4. Peak value at center: at x0=-1/2, peak1 = 0.3*exp(0) = 0.3 exactly
   (plus tiny peak2 contribution); at x0=+1/2, peak2 = 0.7*exp(0) = 0.7 exactly.

Shared components: both truth.py and verify.py evaluate the same declared
two-peak Gaussian equation and config. They differ in exponent factoring
and use independent special-case identities. Named scientific review
remains pending.
"""
import math
import importlib.util
from pathlib import Path


def _load_truth():
    path = Path(__file__).with_name("truth.py")
    spec = importlib.util.spec_from_file_location("nri_tgp_truth", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ---- Independent arithmetic path ----------------------------------------

def _peak1_independent(x):
    """peak1 = 0.3*exp(-4*(2x+1)^2), with (2x+1)^2 expanded explicitly.

    (2x+1)^2 = 4x^2 + 4x + 1, computed via Horner-like accumulation.
    """
    two_x = 2.0 * x
    left = two_x + 1.0
    left_sq = left * left                       # (2x+1)^2
    return 0.3 * math.exp(-4.0 * left_sq)


def _peak2_independent(x):
    """peak2 = 0.7*exp(-16*(2x-1)^2), with (2x-1)^2 expanded via 4x^2-4x+1."""
    two_x = 2.0 * x
    right = two_x - 1.0
    right_sq = right * right                    # (2x-1)^2
    return 0.7 * math.exp(-16.0 * right_sq)


def _m3_independent(x):
    return _peak1_independent(x) + _peak2_independent(x)


def verify(config):
    truth_module = _load_truth()
    oracle = truth_module.truth(config)
    oracle_val = oracle["value"]
    x0 = config["query_point"]
    noise_mean = config.get("noise_mean", 0.0)
    m_x0 = oracle_val - noise_mean

    checks = []

    # ---- Check 1: independent exponent-factored arithmetic path -----------
    indep = _m3_independent(x0) + noise_mean
    diff1 = abs(oracle_val - indep)
    checks.append({
        "name": "independent_arithmetic_path",
        "passed": diff1 < 1e-12,
        "details": (
            f"truth.py={oracle_val:.16g}; independent={indep:.16g}; "
            f"diff={diff1:.3g}. "
            "Same two-peak equation, different intermediate variable order."
        ),
    })

    # ---- Check 2: peak-pair symmetry at left pair (-2/3, -1/3) -----------
    # peak1 arg: (2*(-2/3)+1)^2 = (-1/3)^2 = 1/9 = (2*(-1/3)+1)^2 = (1/3)^2
    # So peak1 must be identical at x0=-2/3 and x0=-1/3
    grid = [-2.0 / 3, -1.0 / 3, 0.0, 1.0 / 3, 2.0 / 3]
    left_pair = [-2.0 / 3, -1.0 / 3]
    if any(abs(x0 - p) < 1e-10 for p in left_pair):
        p1_a = _peak1_independent(-2.0 / 3)
        p1_b = _peak1_independent(-1.0 / 3)
        diff_lp = abs(p1_a - p1_b)
        # Both should equal 0.3*exp(-4/9) exactly (peak2 negligible)
        expected_p1 = 0.3 * math.exp(-4.0 / 9.0)
        checks.append({
            "name": "left_pair_peak1_symmetry",
            "passed": diff_lp < 1e-15 and abs(p1_a - expected_p1) < 1e-15,
            "details": (
                f"peak1(-2/3)={p1_a:.16g}, peak1(-1/3)={p1_b:.16g}; "
                f"both = 0.3*exp(-4/9)={expected_p1:.16g}; diff={diff_lp:.3g}. "
                "(2*(-2/3)+1)^2 = (2*(-1/3)+1)^2 = 1/9."
            ),
        })

    # ---- Check 3: peak-pair symmetry at right pair (1/3, 2/3) -------------
    right_pair = [1.0 / 3, 2.0 / 3]
    if any(abs(x0 - p) < 1e-10 for p in right_pair):
        p2_a = _peak2_independent(1.0 / 3)
        p2_b = _peak2_independent(2.0 / 3)
        diff_rp = abs(p2_a - p2_b)
        expected_p2 = 0.7 * math.exp(-16.0 / 9.0)
        checks.append({
            "name": "right_pair_peak2_symmetry",
            "passed": diff_rp < 1e-15 and abs(p2_a - expected_p2) < 1e-15,
            "details": (
                f"peak2(1/3)={p2_a:.16g}, peak2(2/3)={p2_b:.16g}; "
                f"both = 0.7*exp(-16/9)={expected_p2:.16g}; diff={diff_rp:.3g}. "
                "(2*(1/3)-1)^2 = (2*(2/3)-1)^2 = 1/9."
            ),
        })

    # ---- Check 4: peak dominance / negligibility at far points -----------
    if abs(x0 - (-2.0 / 3)) < 1e-10:
        # Right peak at x0=-2/3: 0.7*exp(-16*(7/3)^2) = 0.7*exp(-784/9)
        p2_val = _peak2_independent(-2.0 / 3)
        checks.append({
            "name": "right_peak_negligible_at_neg2o3",
            "passed": p2_val < 1.1e-38,
            "details": (
                f"Right peak at x0=-2/3: 0.7*exp(-784/9) = {p2_val:.3e} < 1.1e-38. "
                "m3(-2/3) is dominated by peak1 = 0.3*exp(-4/9)."
            ),
        })
    if abs(x0 - 2.0 / 3) < 1e-10:
        p1_val = _peak1_independent(2.0 / 3)
        checks.append({
            "name": "left_peak_negligible_at_2o3",
            "passed": p1_val < 1.1e-10,
            "details": (
                f"Left peak at x0=2/3: 0.3*exp(-196/9) = {p1_val:.3e} < 1.1e-10. "
                "m3(2/3) is dominated by peak2 = 0.7*exp(-16/9)."
            ),
        })

    # ---- Check 5: peak center values ------------------------------------
    # At x0 = -1/2: peak1 = 0.3*exp(0) = 0.3 exactly (peak2 tiny)
    if abs(abs(x0) - 0.5) < 1e-10 and x0 < 0:
        p1_center = _peak1_independent(-0.5)
        checks.append({
            "name": "left_peak_center_value",
            "passed": abs(p1_center - 0.3) < 1e-15,
            "details": (
                f"peak1(-1/2) = 0.3*exp(0) = 0.3 exactly. Got {p1_center:.16g}; "
                f"diff={abs(p1_center-0.3):.3g}. "
                "Peak2 contributes only 0.7*exp(-16) ~ 7.9e-8."
            ),
        })
    if abs(abs(x0) - 0.5) < 1e-10 and x0 > 0:
        p2_center = _peak2_independent(0.5)
        checks.append({
            "name": "right_peak_center_value",
            "passed": abs(p2_center - 0.7) < 1e-15,
            "details": (
                f"peak2(1/2) = 0.7*exp(0) = 0.7 exactly. Got {p2_center:.16g}; "
                f"diff={abs(p2_center-0.7):.3g}. "
                "Peak1 contributes only 0.3*exp(-9) ~ 3.7e-5."
            ),
        })

    passed = all(c["passed"] for c in checks)
    return {
        "passed": passed,
        "checks": checks,
        "shared_components": (
            "Both truth.py and verify.py evaluate the same two-peak Gaussian "
            "m(x)=0.3*exp(-4*(2x+1)^2)+0.7*exp(-16*(2x-1)^2). "
            "Paths differ in intermediate variable order; verify.py additionally "
            "uses peak-pair symmetry identities at x0 in {(-2/3,-1/3),(1/3,2/3)} "
            "and peak-center exact values. Named scientific review and "
            "independent-person reproduction remain pending."
        ),
    }
