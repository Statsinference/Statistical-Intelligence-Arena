"""Population truth for CCF2018 supplement S.II.7 Model 3.

Estimand: m(x0) = E[Y | X = x0] at the fixed query point x0.
Because eps ~ N(0,1) with mean 0 (homoscedastic), E[Y|X=x0] = m(x0).

Model 3: m(x) = 0.3*exp(-4*(2x+1)^2) + 0.7*exp(-16*(2x-1)^2)

Exact exponent arguments at the five query points:
  x0 = -2/3:  peak1 = 0.3*exp(-4*(1/9)) = 0.3*exp(-4/9)
               peak2 = 0.7*exp(-16*(49/9)) = 0.7*exp(-784/9)  [~1e-38, negligible]
  x0 = -1/3:  peak1 = 0.3*exp(-4*(1/9)) = 0.3*exp(-4/9)      [same as x0=-2/3!]
               peak2 = 0.7*exp(-16*(25/9)) = 0.7*exp(-400/9)  [~3e-20, negligible]
  x0 =  0:    peak1 = 0.3*exp(-4)
               peak2 = 0.7*exp(-16)
  x0 =  1/3:  peak1 = 0.3*exp(-4*(25/9)) = 0.3*exp(-100/9)   [~4e-06, small]
               peak2 = 0.7*exp(-16*(1/9)) = 0.7*exp(-16/9)
  x0 =  2/3:  peak1 = 0.3*exp(-4*(49/9)) = 0.3*exp(-196/9)   [~1e-10, negligible]
               peak2 = 0.7*exp(-16*(1/9)) = 0.7*exp(-16/9)   [same as x0=1/3!]

Key symmetry: (2*(-2/3)+1)^2 = (-1/3)^2 = 1/9 = (2*(-1/3)+1)^2 = (1/3)^2
             → peak1 arg identical at x0=-2/3 and x0=-1/3
             Similarly: (2*(1/3)-1)^2 = (-1/3)^2 = 1/9 = (2*(2/3)-1)^2
             → peak2 arg identical at x0=1/3 and x0=2/3
"""
import math


def _m_model3(x):
    """m(x) = 0.3*exp(-4*(2x+1)^2) + 0.7*exp(-16*(2x-1)^2)."""
    left = 2.0 * x + 1.0
    right = 2.0 * x - 1.0
    return 0.3 * math.exp(-4.0 * left * left) + 0.7 * math.exp(-16.0 * right * right)


def truth(config):
    """Return the exact population conditional mean m(x0) at the fixed query point.

    Returns
    -------
    dict with keys:
        value           : m(x0), a finite float
        estimated_error : floating-point rounding bound (<= 1e-14)
        method          : analytic derivation string
        target          : estimand description
        query_point     : x0 used
        noise_mean_contribution : noise_mean (= 0 per paper)
        peak1           : 0.3*exp(-4*(2x0+1)^2) term
        peak2           : 0.7*exp(-16*(2x0-1)^2) term
    """
    x0 = config["query_point"]
    noise_mean = config.get("noise_mean", 0.0)
    model = config.get("model_name", "M3")
    if model != "M3":
        raise ValueError("model_name must be M3; got " + str(model))

    left = 2.0 * x0 + 1.0
    right = 2.0 * x0 - 1.0
    peak1 = 0.3 * math.exp(-4.0 * left * left)
    peak2 = 0.7 * math.exp(-16.0 * right * right)
    m_val = peak1 + peak2

    method = (
        "Closed-form: m(x0)=0.3*exp(-4*(2x0+1)^2)+0.7*exp(-16*(2x0-1)^2). "
        f"At x0={x0:.6g}: "
        f"peak1=0.3*exp(-4*{left**2:.6g})={peak1:.16g}, "
        f"peak2=0.7*exp(-16*{right**2:.6g})={peak2:.16g}, "
        f"sum={m_val:.16g}. "
        "Both peaks give exp of exact rationals at the five paper evaluation points."
    )

    return {
        "value": m_val + noise_mean,
        "estimated_error": 1e-14,
        "method": method,
        "target": "m(x0) = E[Y | X = x0] at fixed query point x0",
        "query_point": x0,
        "noise_mean_contribution": noise_mean,
        "peak1": peak1,
        "peak2": peak2,
    }
