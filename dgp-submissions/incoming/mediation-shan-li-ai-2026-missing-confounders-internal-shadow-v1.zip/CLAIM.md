# 来源认领记录

mediation-shan-li-ai-2026-missing-confounders-internal-shadow-v1

Shan, J., Li, W. and Ai, C. (2026). Efficient Nonparametric Inference for Mediation Analysis with Nonignorable Missing Confounders. Journal of the American Statistical Association, published online 25 June 2026, pages 1-12. DOI: 10.1080/01621459.2026.2654218.

实际阅读版本：arXiv:2402.05384 预印本，2025-12-16。出版社排版版未取得。该文为在线先发（2026-06-25），尚无卷期号，页码 1-12。引用字段已与 DOI 10.1080/01621459.2026.2654218 的 Crossref 记录核对。

定位：§5 Numerical studies，预印本 PDF 第 14 页（展示式生成机制、两个缺失指标、原文自报的 58/14/14/14 缺失比例）；§2.1，PDF 第 4 页（NIE/NDE/ATE 定义）与式 (1)，PDF 第 5 页（中介功能量 theta = E[Y(1,M(0))] 及识别公式）；Figure 2 及纵轴刻度，PDF 第 15 页。页码为预印本 PDF 页码。

机制区别：两个 Uniform(0,1) 混杂与一个 Bernoulli 混杂；logistic 倾向得分含平方项；中介方程含 T 与协变量的交互和正弦项；结局方程含 T 与中介的交互。三个混杂里有两个受**不可忽略缺失**影响，按观察指示列 + 掩码数值列导出。本包登记 DGP2 支，缺失指标为 U = 1.2 + X1 + X2^2 - X3 - 0.5 T + T X1^2。目标为跨世界中介功能量 theta = E[Y(1, M(0))]，不是自然间接效应、自然直接效应或总效应。

真值来源：原文未印出任何数值真值（只在 Figure 2 里画实线）。本包登记的 theta = 3.192275262794844 由收集者依 §5 的系数解析导出，并由 200 阶 Gauss-Legendre 求积与 40 万个体结构模拟交叉核对，需审稿人核对。四个真值均落在 Figure 2 对应面板印出的纵轴范围内。

缺失编码：Rj 为观察指示，Xj_obs0 = Rj * Xj 为数值列，0 是声明的传输填充值而非插补值；Rj = 0 的个体的真实 Xj 绝不导出。该约定与 T06 的 mediation-zuo-et-al-2025-continuous-mnar-v1 一致。

姊妹包：mediation-shan-li-ai-2026-missing-confounders-aux-shadow-v1 登记同一篇论文的另一个缺失机制，共享全数据律与真值，但观察数据律与观察列集合不同，mechanism_family_id 不同，不是重复。

已在 2026-10-30 的仓库快照内查重：mediation 域仅有 nie-eric-original-v1，incoming/ 中无 mediation-* 包。已与 peer 的 T06 八个提交件（2026-10-31 收到）比对，无同篇重复。未向维护人发送，待维护人认领/全库查重与具名科学审核。
