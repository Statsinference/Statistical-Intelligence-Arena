# Conditional quantile in the Bondell-Reich-Wang linear location-scale mechanism

编号 Q03 · 线性位置与线性尺度。状态：本地核验后仍待科学审核；未提交 GitHub。

## 来源与精确定位

Bondell, H. D., Reich, B. J. and Wang, H. (2010). Noncrossing quantile regression curve estimation. Biometrika 97(4), 825-838. DOI: https://doi.org/10.1093/biomet/asq048

实际读取：Published journal PDF, 14 pages, journal pagination 825-838。下载链接：https://www.math.pku.edu.cn/teachers/xirb/Courses/QR2013/ReadingForFinal/Biometrika-2010-Bondell-825-38.pdf

定位：Section 4.1, unnumbered location-scale model on PDF page 7 = journal page 831; beta0=gamma0=1 in same paragraph; Example 1 parameters on PDF page 8 = journal page 832.

读取 PDF 的 SHA-256：5eff78911ec3400db4bb6f9a41dd0a077d49f7ea07bf1a439544473569a5c974。不依赖作者源码，无代码 commit 需要引用。source_audit.json 另列版本及查重证据。

## 完整生成机制

\[
X_{ij}\overset{\mathrm{iid}}{\sim}U(0,1),\quad\varepsilon_i\sim\mathcal N(0,1),\quad\varepsilon_i\perp X_i
\]

\[
Y_i=1+\sum_{j=1}^4X_{ij}+\left(1+0.1\sum_{j=1}^4X_{ij}\right)\varepsilon_i
\]

\[
Q_\tau(x)=1+\sum_{j=1}^4x_j+\left(1+0.1\sum_{j=1}^4x_j\right)\Phi^{-1}(\tau)
\]

生成顺序：先抽协变量，再独立抽噪声，最后按显示方程构造响应。不同观察行独立；协变量和噪声按显示公式及下列实现约定独立。参数全部在 config.json。X1 到 X4 以及 Y 完全观测；无缺失、删失、标注抽样或因果处理分配。误差及混合成分只在生成器内部使用，不输出给模型。

样本量由 generate(config,n,seed) 的 n 决定；source_n 是原文样本量记录，不替代 n。随机数生成器为 NumPy PCG64，固定种子及相同依赖版本可复现；不声称与 R 或论文逐行随机数相同。所有列为等长有限数值列表。不对 Y 裁剪、截断或重新标准化；均匀分布的右端点在实现中不取，连续理论分布不受影响。

## 目标与真值

Conditional 0.9 quantile at X=(0.5,0.5,0.5,0.5) in source Example 1.

$m(x)=1+\sum_jx_j$，$s(x)=1+0.1\sum_jx_j\in[1,1.4]$。$Q_\tau(x)=m(x)+s(x)\Phi^{-1}(\tau)$；在查询点 $m=3,s=1.2$。

默认场景真值为 **4.53786187865352**。这是按本包目标推导的新真值；未将论文估计值当作 oracle。truth.py 返回标量以及 1e-12 的浮点/求根诊断，非严格统一误差界。数值反演使用初始区间 [-100,100] 和 60 次二分，适用于登记的固定水平。verify.py 不调用生成器，使用独立密度 Simpson 积分和 1024/2048 网格（Q01 卷积为 2048/4096），并核对对称/支持/边界特例。两条路线仍由同一 AI 编写，不等于独立研究者复现。

分位数统一定义为 $Q_\tau=\inf\{y:F(y)\ge\tau\}$。条件密度为 φ(Φ⁻¹(0.9))/s(x)，支持上 s∈[1,1.4]。

## 多样性及范围

Four active covariates. Both conditional location and scale are affine. The factor X_j*epsilon is a heteroscedastic noise modulation, not an interaction between input covariates. No covariate-covariate products. high_dimensional=false 指本包维数相对于原文样本量以及 n=128 核验而言，不承诺 n 小于维数时仍属低维。多个噪声或查询场景不重复计数。标量真值核验不意味着整条分布函数带或分位曲线的覆盖率通过。所有登记场景见 config.json。

## 相对来源的改动

1. Fixed x=(0.5,0.5,0.5,0.5) and tau=0.9 select a scalar query from the source quantile curves.
2. The source gives marginal laws without a separate dependence statement in Section 4.1. Independent coordinates, independent noise and iid rows are explicit implementation conventions; no claim of an undocumented correlated design is made. Only Example 1 is collected; coefficient/dimension variants Examples 2-3 are not counted as additional mechanisms.
3. Independent Python/NumPy implementation from mathematical formulas; no author code is redistributed. PCG64(seed) replaces unspecified/source software random-number generation. Sample size is the generate n argument; source_n only records the published sample sizes. No fitting, bootstrap, confidence-band coverage experiment or PFN training is included.

## 权利与 AI 协助

原论文归原著作权人；本包不含论文 PDF、真实个体数据或作者源码。方程被重新转写并单独实现。使用 AI 辅助提取、推导、编程、核验及排版，尚无具名科学审核人及独立复现者；不得将本地 PASS 或收件测试写为正式接收。提交人姓名由用户在 GitHub 提交说明中填写，不由 AI 代签。
