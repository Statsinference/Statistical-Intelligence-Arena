import numpy as np
def reference(c):
    # Difference of two independent per-period normal errors, then Bernoulli group mixture.
    p=c['pi'];var_change=np.dot([1.,-1.],np.diag([c['sigma']**2]*2)@[1.,-1.])
    return dict(pi=p,theta=c['effect'],m0=c['drift'],V=float(var_change/p+var_change/(1-p)))
