import numpy as np

def validate(c):
    assert .1 <= c['pi'] <= .9 and .1 <= c['control_a_share'] <= .9
    assert len(c['levels'])==3 and all(abs(x)<=20 for x in c['levels'])
    assert .25 <= c['sigma'] <= 2 and abs(c['effect']) <= 3 and abs(c['drift']) <= 3

def draw(c,n,seed):
    validate(c);r=np.random.default_rng(seed)
    p=c['pi'];q=c['control_a_share']
    g=r.choice(3,size=n,p=[(1-p)*q,(1-p)*(1-q),p]);d=(g==2).astype(int)
    level=np.asarray(c['levels'])[g]
    y0=level+c['sigma']*r.normal(size=n)
    y1=level+c['drift']+d*c['effect']+c['sigma']*r.normal(size=n)
    return dict(x0=np.zeros(n),D=d,y_pre=y0,y_post=y1,delta_y=y1-y0)

def moments(c,order=None):
    validate(c);p=c['pi']
    return dict(pi=p,theta=c['effect'],V=2*c['sigma']**2/(p*(1-p)),m0=c['drift'])

def nuisances(c,data,pop):
    n=len(data['D']);return np.full(n,pop['pi']),np.full(n,pop['m0'])
