# Ye et al. Case I, IID three-group two-period projection

## 来源与关系

Ye, T., Keele, L., Hasegawa, R. and Small, D. S. (2024). A Negative Correlation Strategy for Bracketing in Difference-in-Differences. JASA 119(547), 2256–2268. [DOI](https://doi.org/10.1080/01621459.2023.2252576)。定位：arXiv:2006.02423v3, Section 4 pp.22–23, Case I, periods 1 and 4.

**ADAPTED；不是原论文标量 DGP 的原样复现。**

- Replace fixed group counts by IID categorical draws with probabilities (0.2,0.5,0.3).
- Select original periods t=1 and t=4; merge the two controls; retain individual-level independent normal errors.
- Include treatment effect only for the treated group; the displayed preprint outcome formula omits that indicator. This choice is explicit and consistent with its stated ATT.
- Do not expose group type or baseline outcome as X. Parameters and effect signs may vary only within common-trend Case I.

## 数学定义与识别证明

Draw latent group G iid with a,b,treated probabilities. D=1{G=treated}; X is the empty set (stored as x0=0). Set Ypre=level_G+sigma E0 and Ypost(d)=level_G+drift+d effect+sigma E1. G affects levels but not the untreated change. Thus m0=drift, e=pi, ATT=effect, and V=2 sigma²/[pi(1-pi)]. This does not condition on noisy Ypre: adding Ypre to X would generally break this CPT argument because E0 then carries information about G. The source's Case II is excluded.

## 参数与家族

`config.json` 给出 3 个明确场景；`adapted_reference` 保留可保留的来源常数，不命名为 original。完整参数区间与采样分布在 `family_prior.json`，`family.sample_mechanism(seed)` 只生成固定参数，`generate(config,n,seed)` 再独立生成样本。改变场景、系数或随机种子不增加家族数。此家族的 paper lineage 为 `ye-keele-hasegawa-small-2024`。

## 输入与标签隔离

只使用 `fsp_adapter.model_input` 构造 X,D,delta_y。y_pre/y_post 仅供观察数据审核；特别是无协变量家族，不得擅自把 y_pre 加入 X。所有真实 propensity、m0、ATT、V、EIF、teacher 都在独立 sidecar 中。样本为空组时 teacher 明确报错，不重抽、不截断分母。

## 真值与验证

`truth.py` 不依赖当前 episode。`independent_reference.py` 用不同积分或枚举路径核验人口矩；`verify.py` 另外核验真实生成数据的处理概率、EIF 一二阶矩。更完整的重复抽样、区间覆盖率、家族抽样检查见 `audit_results.json` 与 `audit.md`。数值积分阶数差是误差诊断，不冒称严格误差上界。

## 使用

安装 requirements.txt，在本目录运行 `python -c "import json; from generator import generate; c=json.load(open('config.json'))['scenarios']['adapted_reference']; print(generate(c,5,1729))"`。

学生工具：`python collect.py check <本目录> --run --n 128 --seed 1729`；随后 `python collect.py pack <本目录> --out <新 ZIP>`。包内 `checks/report.json` 是格式及执行检查，科学审核以 `audit.md` 为准。本文档与实现由 AI 辅助完成，不伪造人工评审或独立研究者复现签名。
