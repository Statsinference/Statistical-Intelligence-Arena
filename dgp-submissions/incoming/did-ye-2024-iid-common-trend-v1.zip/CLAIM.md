# Contribution claim

Family: did-ye-2024-iid-common-trend-v1. Source lineage: ye-keele-hasegawa-small-2024.

Claim only the explicitly adapted scalar IID panel distribution and parameter prior described here. No claim of reproducing the source estimator, source tables, geodesic target, or entire article. Parameter variants are not additional families. These are five collections from three articles, with the three Zhou mechanisms sharing a paper-level split group.

Collector checks do not themselves confer scientific acceptance. See audit.md for the scoped Proposal review and actual statistical evidence. No external upload or registry admission is performed by this package.
