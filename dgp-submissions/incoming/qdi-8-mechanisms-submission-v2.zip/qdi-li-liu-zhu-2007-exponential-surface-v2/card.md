# Conditional quantiles on the Li-Liu-Zhu exponential surface with non-Gaussian noise scenarios

编号 Q07 · 二维指数曲面与厚尾及混合误差。状态：本地核验后仍待科学审核；未提交 GitHub。

## 来源与精确定位

Li, Y., Liu, Y. and Zhu, J. (2007). Quantile Regression in Reproducing Kernel Hilbert Spaces. Journal of the American Statistical Association 102(477), 255-268. DOI: https://doi.org/10.1198/016214506000000979

实际读取：Author-hosted published journal PDF, 14 pages, journal pagination 255-268。下载链接：https://dept.stat.lsa.umich.edu/~jizhu/pubs/Li-JASA07.pdf?download=1

定位：Section 5.1, equation (40) and following error-distribution paragraph; PDF page 8 = journal page 262. Section 5.2 on PDF page 9 = journal page 263 reuses this law.

读取 PDF 的 SHA-256：cfdfb87b7f8491ca97fdb048ee70ed6915436226745da8d359c939d3dd7c602a。不依赖作者源码，无代码 commit 需要引用。source_audit.json 另列版本及查重证据。

## 完整生成机制

\[
X_{i1},X_{i2}\overset{\mathrm{iid}}{\sim}U(0,1),\quad\varepsilon_i\perp X_i
\]

\[
m(x)=\frac{40e^{8\{(x_1-0.5)^2+(x_2-0.5)^2\}}}{e^{8\{(x_1-0.2)^2+(x_2-0.7)^2\}}+e^{8\{(x_1-0.7)^2+(x_2-0.2)^2\}}}
\]

\[
Y_i=m(X_i)+\varepsilon_i,\quad\varepsilon_i\sim\mathcal N(0,1)\;\text{or}\;t_3\;\text{or}\;0.1\mathcal N(0,25)+0.9\mathcal N(0,1)
\]

\[
Q_\tau(x)=m(x)+F_\varepsilon^{-1}(\tau)
\]

生成顺序：先抽协变量，再独立抽噪声，最后按显示方程构造响应。不同观察行独立；协变量和噪声按显示公式及下列实现约定独立。生成常数由上述方程及 config.json 共同给出；不是所有固定常数都作为可配置参数。X1 到 X2 以及 Y 完全观测；无缺失、删失、标注抽样或因果处理分配。误差及混合成分只在生成器内部使用，不输出给模型。

样本量由 generate(config,n,seed) 的 n 决定；source_n 仅在已找到明确原文依据时记录样本量，否则为 null；它不替代 n。随机数生成器为 NumPy PCG64，固定种子及相同依赖版本可复现；不声称与 R 或论文逐行随机数相同。所有列为等长有限数值列表。不对 Y 裁剪、截断或重新标准化；均匀分布的右端点在实现中不取，连续理论分布不受影响。

## 目标与真值

Conditional 0.1 quantile at X=(0.5,0.5); normal, t3, and specified normal-mixture errors are scenarios within ONE mechanism family.

$Q_\tau(x)=m(x)+F_\varepsilon^{-1}(\tau)$。混合误差的 CDF 为 $0.1\Phi(z/5)+0.9\Phi(z)$；$t_3$ 的 CDF 有反正切闭式。本包对后二者用二分法反演。

默认场景真值为 **5.787542073631**。这是按本包目标推导的新真值；未将论文估计值当作 oracle。truth.py 返回标量以及 1e-12 的浮点/求根诊断，非严格统一误差界。数值反演使用初始区间 [-100,100] 和 60 次二分，适用于登记的固定水平。verify.py 不调用生成器，使用独立密度 Simpson 积分和 1024/2048 网格（Q01 卷积为 2048/4096），并核对对称/支持/边界特例。两条路线仍由同一 AI 编写，不等于独立研究者复现。

分位数统一定义为 $Q_\tau=\inf\{y:F(y)\ge\tau\}$。t₃ 不做方差标准化，方差为 3；混合误差方差为 0.1×25+0.9×1=3.4。三个分布在固定分位处均有正密度。

## 多样性及范围

Two active covariates and a nonadditive response surface. Cancelling common squares gives 40/[exp(8*(.6*x1-.4*x2+.03))+exp(8*(-.4*x1+.6*x2+.03))], which has cross-coordinate curvature; this is the stated meaning of interactions, not an explicit polynomial product. high_dimensional=false 指本包维数相对于原文样本量以及 n=128 核验而言，不承诺 n 小于维数时仍属低维。多个噪声或查询场景不重复计数。标量真值核验不意味着整条分布函数带或分位曲线的覆盖率通过。所有登记场景见 config.json。

## 相对来源的改动

1. Fixed x=(0.5,0.5) and tau=0.1 select a scalar query. Normal, unscaled Student t3 and the stated normal mixture are three source noise scenarios, not three different families.
2. The unspecified scale of the source double-exponential error is not guessed; that fourth noise case is excluded. Independent X1,X2, noise and rows are explicit implementation conventions because the paragraph states marginal distributions only.
3. The computationally equivalent log-sum-exp form avoids unnecessary exponential overflow; no negative signs are inserted in the positive exponents in equation (40).
4. Independent Python/NumPy implementation from mathematical formulas; no author code is redistributed. PCG64(seed) replaces unspecified/source software random-number generation. Sample size is the generate n argument; source_n only records the published sample sizes. No fitting, bootstrap, confidence-band coverage experiment or PFN training is included.

## 权利与 AI 协助

原论文归原著作权人；本包不含论文 PDF、真实个体数据或作者源码。方程被重新转写并单独实现。使用 AI 辅助提取、推导、编程、核验及排版，尚无具名科学审核人及独立复现者；不得将本地 PASS 或收件测试写为正式接收。提交人姓名由用户在 GitHub 提交说明中填写，不由 AI 代签。


## 2026-11-03 原文逐项复核

已重新查看实际读取 PDF 的完整相关页面，对照生成器、配置、schema 和真值。方程、已选分布与数值参数未发现抄录错误；原文事实与实现补充约定逐项记录在 source_recheck.json。

独立性证据状态：implementation_convention_not_explicitly_source_verified。Published PDF p.8 / journal p.262 gives marginal uniform covariates and four named error distributions. Joint coordinate/noise independence is not separately specified in that paragraph. No author simulation code was obtained; product sampling is disclosed and needs maintainer review.

边界处理：Unit-square support; both covariates observed. Positive exponent signs retained. Surface evaluated using log-sum-exp; no clipping. t3 is not variance standardized; mixture uses .1 probability of standard deviation 5, otherwise standard deviation 1. Source kernel bandwidth sigma=.2 is not an error standard deviation. Ambiguous double-exponential scale remains excluded.

本版不能声称不存在任何潜在错误，也不能以程序 PASS 替代科学审核。Q03 至 Q08 的补充独立性约定尚需维护人确认。
