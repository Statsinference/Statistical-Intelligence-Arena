"""Deterministic cross-checks; independent numerical route, not an independent human reproduction."""
import math
from statistics import NormalDist
from truth import truth

def simpson(f,a,b,n):
    h=(b-a)/n
    return h/3*(f(a)+f(b)+4*sum(f(a+h*i) for i in range(1,n,2))+2*sum(f(a+h*i) for i in range(2,n,2)))

def normal_integral(z,n):
    return .5+simpson(lambda t:math.exp(-t*t/2)/math.sqrt(2*math.pi),0,z,n)

def check(name,error,tolerance):
    return dict(name=name,passed=bool(error<=tolerance),absolute_error=float(error),tolerance=tolerance)

def normal_checks(z,tau):
    p1=normal_integral(z,1024);p2=normal_integral(z,2048)
    return [check('Integrate normal density at the proposed quantile',abs(p2-tau),1e-9),check('Quadrature refinement',abs(p2-p1),1e-9),check('Normal symmetry at zero',abs(normal_integral(0,128)-.5),1e-12)]

def verify(config):
    value=truth(config)['value']
    checks=[]
    v=config['x_query'][0]
    g=config['intercept']+config['slope']*v+math.sin(config['frequency']*v)*math.cos(config['phase'])+math.cos(config['frequency']*v)*math.sin(config['phase'])
    z=(value-3*v)/g
    checks.extend(normal_checks(z,config['tau']))
    # Exact minimum candidates: endpoints and stationary points in [0,1].
    a=math.acos(-config['slope']/config['frequency'])
    points=[0.,1.]
    for k in range(-2,3):
        for sign in [-1,1]:
            v=(sign*a+2*math.pi*k-config['phase'])/config['frequency']
            if 0<=v<=1: points.append(v)
    minimum=min(config['intercept']+config['slope']*v+math.sin(config['frequency']*v+config['phase']) for v in points)
    checks.append({'name':'Exact stationary-point scale minimum on [0,1]','passed':minimum>0,'minimum_scale':minimum})
    return {"passed":all(c["passed"] for c in checks),"checks":checks}
