import math
from statistics import NormalDist

def truth(config):
    v=config['x_query'][0]
    g=config['intercept']+config['slope']*v+math.sin(config['frequency']*v+config['phase'])
    value=3*v+g*NormalDist().inv_cdf(config['tau'])
    return {"value":float(value),"estimated_error":1e-12,"error_interpretation":"Floating-point and bisection diagnostic; not a rigorous uniform error bound"}
