# Conditional quantile in the Li-Liu-Zhu sinc demonstration mechanism

编号 Q06 · sinc 回归与小尺度高斯误差。状态：本地核验后仍待科学审核；未提交 GitHub。

## 来源与精确定位

Li, Y., Liu, Y. and Zhu, J. (2007). Quantile Regression in Reproducing Kernel Hilbert Spaces. Journal of the American Statistical Association 102(477), 255-268. DOI: https://doi.org/10.1198/016214506000000979

实际读取：Author-hosted published journal PDF, 14 pages, journal pagination 255-268。下载链接：https://dept.stat.lsa.umich.edu/~jizhu/pubs/Li-JASA07.pdf?download=1

定位：Section 1, illustrative solution-path example; PDF page 2 = journal page 256; unnumbered sinc model in left column, six training observations.

读取 PDF 的 SHA-256：cfdfb87b7f8491ca97fdb048ee70ed6915436226745da8d359c939d3dd7c602a。不依赖作者源码，无代码 commit 需要引用。source_audit.json 另列版本及查重证据。

## 完整生成机制

\[
X_i\sim U(-2,2),\quad\varepsilon_i\sim\mathcal N(0,0.2^2),\quad X_i\perp\varepsilon_i
\]

\[
Y_i=\frac{\sin(\pi X_i)}{\pi X_i}+\varepsilon_i,\quad \operatorname{sinc}(0)=1
\]

\[
Q_\tau(x)=\operatorname{sinc}(x)+0.2\Phi^{-1}(\tau)
\]

生成顺序：先抽协变量，再独立抽噪声，最后按显示方程构造响应。不同观察行独立；协变量和噪声按显示公式及下列实现约定独立。生成常数由上述方程及 config.json 共同给出；不是所有固定常数都作为可配置参数。X1 到 X1 以及 Y 完全观测；无缺失、删失、标注抽样或因果处理分配。误差及混合成分只在生成器内部使用，不输出给模型。

样本量由 generate(config,n,seed) 的 n 决定；source_n 仅在已找到明确原文依据时记录样本量，否则为 null；它不替代 n。随机数生成器为 NumPy PCG64，固定种子及相同依赖版本可复现；不声称与 R 或论文逐行随机数相同。所有列为等长有限数值列表。不对 Y 裁剪、截断或重新标准化；均匀分布的右端点在实现中不取，连续理论分布不受影响。

## 目标与真值

Conditional 0.9 quantile at X=0.5, using the sinc data law of the Section 1 demonstration.

$m(x)=\sin(\pi x)/(\pi x)$，$m(0)=1$，$s=0.2$。故 $Q_\tau(x)=m(x)+0.2\Phi^{-1}(\tau)$。

默认场景真值为 **0.892930085476502**。这是按本包目标推导的新真值；未将论文估计值当作 oracle。truth.py 返回标量以及 1e-12 的浮点/求根诊断，非严格统一误差界。数值反演使用初始区间 [-100,100] 和 60 次二分，适用于登记的固定水平。verify.py 不调用生成器，使用独立密度 Simpson 积分和 1024/2048 网格（Q01 卷积为 2048/4096），并核对对称/支持/边界特例。两条路线仍由同一 AI 编写，不等于独立研究者复现。

分位数统一定义为 $Q_\tau=\inf\{y:F(y)\ge\tau\}$。误差标准差为 0.2，方差为 0.04；不可将 N(0,0.2²) 的第二参数误当标准差。

## 多样性及范围

One active covariate; sinc is nonlinear and has a removable singularity at zero. numpy.sinc uses sin(pi*x)/(pi*x), exactly the normalized convention in the paper. high_dimensional=false 指本包维数相对于原文样本量以及 n=128 核验而言，不承诺 n 小于维数时仍属低维。多个噪声或查询场景不重复计数。标量真值核验不意味着整条分布函数带或分位曲线的覆盖率通过。所有登记场景见 config.json。

## 相对来源的改动

1. The source uses n=6 to illustrate a solution path. generate accepts arbitrary n for collection checks; source_n=6 is retained as metadata. This is not the Section 5 main experiment.
2. A fixed conditional 0.9 quantile at x=0.5 is registered; independent covariate/noise draws and iid rows are explicit implementation conventions.
3. Independent Python/NumPy implementation from mathematical formulas; no author code is redistributed. PCG64(seed) replaces unspecified/source software random-number generation. Sample size is the generate n argument; source_n only records the published sample sizes. No fitting, bootstrap, confidence-band coverage experiment or PFN training is included.

## 权利与 AI 协助

原论文归原著作权人；本包不含论文 PDF、真实个体数据或作者源码。方程被重新转写并单独实现。使用 AI 辅助提取、推导、编程、核验及排版，尚无具名科学审核人及独立复现者；不得将本地 PASS 或收件测试写为正式接收。提交人姓名由用户在 GitHub 提交说明中填写，不由 AI 代签。


## 2026-11-03 原文逐项复核

已重新查看实际读取 PDF 的完整相关页面，对照生成器、配置、schema 和真值。方程、已选分布与数值参数未发现抄录错误；原文事实与实现补充约定逐项记录在 source_recheck.json。

独立性证据状态：implementation_convention_not_explicitly_source_verified。Published PDF p.2 / journal p.256 gives U(-2,2) and N(0,0.2^2) marginals. The paragraph does not explicitly write X perpendicular epsilon; independent sampling is a disclosed implementation convention.

边界处理：Normalized sinc sin(pi*x)/(pi*x), continuous value 1 at zero, uniform support [-2,2]. Noise standard deviation .2, variance .04. No ad hoc denominator epsilon is inserted.

本版不能声称不存在任何潜在错误，也不能以程序 PASS 替代科学审核。Q03 至 Q08 的补充独立性约定尚需维护人确认。
