# Conditional CDF in the Hall-Yao additive sine mechanism

编号 Q02 · 四维加性正弦的条件分布函数。状态：本地核验后仍待科学审核；未提交 GitHub。

## 来源与精确定位

Hall, P. and Yao, Q. (2005). Approximating conditional distribution functions using dimension reduction. The Annals of Statistics 33(3), 1404-1421. DOI: https://doi.org/10.1214/009053604000001282

实际读取：Published journal PDF, 18 pages, journal pagination 1404-1421。下载链接：https://stats.lse.ac.uk/q.yao/qyao.links/paper/hy02.pdf

定位：Section 4, Example 2; PDF page 12 = journal page 1415; unnumbered model. Distribution and total independence of X_ij and epsilon_i specified on PDF page 10 = journal page 1413.

读取 PDF 的 SHA-256：fd896d24a6c2589eef2797704b677c1b0b3c8bd4837b03aa513fbf5b83ac3569。不依赖作者源码，无代码 commit 需要引用。source_audit.json 另列版本及查重证据。

## 完整生成机制

\[
X_{ij},\varepsilon_i\overset{\mathrm{ind}}{\sim}\mathcal N(0,1),\quad j=1,\ldots,4
\]

\[
Y_i=\frac12\sum_{j=1}^4\sin(X_{ij})+\varepsilon_i
\]

\[
F_{Y\mid X}(y\mid x)=\Phi\!\left(y-\frac12\sum_{j=1}^4\sin x_j\right)
\]

生成顺序：先抽协变量，再独立抽噪声，最后按显示方程构造响应。不同观察行独立；协变量和噪声按显示公式及下列实现约定独立。生成常数由上述方程及 config.json 共同给出；不是所有固定常数都作为可配置参数。X1 到 X4 以及 Y 完全观测；无缺失、删失、标注抽样或因果处理分配。误差及混合成分只在生成器内部使用，不输出给模型。

样本量由 generate(config,n,seed) 的 n 决定；source_n 仅在已找到明确原文依据时记录样本量，否则为 null；它不替代 n。随机数生成器为 NumPy PCG64，固定种子及相同依赖版本可复现；不声称与 R 或论文逐行随机数相同。所有列为等长有限数值列表。不对 Y 裁剪、截断或重新标准化；均匀分布的右端点在实现中不取，连续理论分布不受影响。

## 目标与真值

Conditional CDF P(Y<=0.5 | X=(0.5,0.25,-0.5,1)); conditioning is on the full four-dimensional X, not on the fitted index.

$m(x)=\frac12\sum_{j=1}^4\sin x_j$，$Y\mid X=x\sim N(m(x),1)$。真值为 $\Phi(0.5-m(x_0))$。这不同于论文对 $Y\mid\theta^TX$ 的近似目标。

默认场景真值为 **0.482277846387853**。这是按本包目标推导的新真值；未将论文估计值当作 oracle。truth.py 返回标量以及 1e-12 的浮点/求根诊断，非严格统一误差界。数值反演使用初始区间 [-100,100] 和 60 次二分，适用于登记的固定水平。verify.py 不调用生成器，使用独立密度 Simpson 积分和 1024/2048 网格（Q01 卷积为 2048/4096），并核对对称/支持/边界特例。两条路线仍由同一 AI 编写，不等于独立研究者复现。

分位数统一定义为 $Q_\tau=\inf\{y:F(y)\ge\tau\}$。高斯条件密度在任意有限阈值为正；当前阈值为 0.5。

## 多样性及范围

All four coordinates enter through sine; additive nonlinear effects, no cross-coordinate products. Dimension 4, effective dimension 4. high_dimensional=false 指本包维数相对于原文样本量以及 n=128 核验而言，不承诺 n 小于维数时仍属低维。多个噪声或查询场景不重复计数。标量真值核验不意味着整条分布函数带或分位曲线的覆盖率通过。所有登记场景见 config.json。

## 相对来源的改动

1. The full-X conditional CDF at a fixed query is used instead of the source least-squares single-index approximation; source data law is retained.
2. Independent Python/NumPy implementation from mathematical formulas; no author code is redistributed. PCG64(seed) replaces unspecified/source software random-number generation. Sample size is the generate n argument; source_n only records the published sample sizes. No fitting, bootstrap, confidence-band coverage experiment or PFN training is included.

## 权利与 AI 协助

原论文归原著作权人；本包不含论文 PDF、真实个体数据或作者源码。方程被重新转写并单独实现。使用 AI 辅助提取、推导、编程、核验及排版，尚无具名科学审核人及独立复现者；不得将本地 PASS 或收件测试写为正式接收。提交人姓名由用户在 GitHub 提交说明中填写，不由 AI 代签。


## 2026-11-03 原文逐项复核

已重新查看实际读取 PDF 的完整相关页面，对照生成器、配置、schema 和真值。方程、已选分布与数值参数未发现抄录错误；原文事实与实现补充约定逐项记录在 source_recheck.json。

独立性证据状态：explicit_in_source。Same explicit total-independence statement on published PDF p.10 / journal p.1413 applies to Example 2 on PDF p.12 / journal p.1415.

边界处理：No clipping of normal covariates. CDF is evaluated at the full four-dimensional query and finite threshold, not at a fitted index.

本版不能声称不存在任何潜在错误，也不能以程序 PASS 替代科学审核。Q03 至 Q08 的补充独立性约定尚需维护人确认。
