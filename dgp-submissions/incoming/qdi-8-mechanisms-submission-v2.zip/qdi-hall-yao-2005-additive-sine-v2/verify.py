"""Deterministic cross-checks; independent numerical route, not an independent human reproduction."""
import math
from statistics import NormalDist
from truth import truth

def simpson(f,a,b,n):
    h=(b-a)/n
    return h/3*(f(a)+f(b)+4*sum(f(a+h*i) for i in range(1,n,2))+2*sum(f(a+h*i) for i in range(2,n,2)))

def normal_integral(z,n):
    return .5+simpson(lambda t:math.exp(-t*t/2)/math.sqrt(2*math.pi),0,z,n)

def check(name,error,tolerance):
    return dict(name=name,passed=bool(error<=tolerance),absolute_error=float(error),tolerance=tolerance)

def normal_checks(z,tau):
    p1=normal_integral(z,1024);p2=normal_integral(z,2048)
    return [check('Integrate normal density at the proposed quantile',abs(p2-tau),1e-9),check('Quadrature refinement',abs(p2-p1),1e-9),check('Normal symmetry at zero',abs(normal_integral(0,128)-.5),1e-12)]

def verify(config):
    value=truth(config)['value']
    checks=[]
    m=sum(config['sine_coefficient']*math.sin(v) for v in config['x_query'])
    z=(config['y_threshold']-m)/config['noise_sd']
    prob1=normal_integral(z,1024)
    prob2=normal_integral(z,2048)
    checks.append(check('Normal density integration for full-X CDF',abs(prob2-value),1e-9))
    checks.append(check('CDF quadrature refinement',abs(prob2-prob1),1e-9))
    checks.append(check('CDF at the conditional median',abs(normal_integral(0,1024)-.5),1e-12))
    return {"passed":all(c["passed"] for c in checks),"checks":checks}
