import math
from statistics import NormalDist

def truth(config):
    m=config['sine_coefficient']*sum(math.sin(v) for v in config['x_query'])
    value=NormalDist().cdf((config['y_threshold']-m)/config['noise_sd'])
    return {"value":float(value),"estimated_error":1e-12,"error_interpretation":"Floating-point and bisection diagnostic; not a rigorous uniform error bound"}
