import math
from statistics import NormalDist

def truth(config):
    m=config['intercept']+sum(b*v for b,v in zip(config['beta'],config['x_query']))
    s=config['scale_intercept']+sum(b*v for b,v in zip(config['gamma'],config['x_query']))
    value=m+s*NormalDist().inv_cdf(config['tau'])
    return {"value":float(value),"estimated_error":1e-12,"error_interpretation":"Floating-point and bisection diagnostic; not a rigorous uniform error bound"}
