"""Deterministic cross-checks; independent numerical route, not an independent human reproduction."""
import math
from statistics import NormalDist
from truth import truth

def simpson(f,a,b,n):
    h=(b-a)/n
    return h/3*(f(a)+f(b)+4*sum(f(a+h*i) for i in range(1,n,2))+2*sum(f(a+h*i) for i in range(2,n,2)))

def normal_integral(z,n):
    return .5+simpson(lambda t:math.exp(-t*t/2)/math.sqrt(2*math.pi),0,z,n)

def check(name,error,tolerance):
    return dict(name=name,passed=bool(error<=tolerance),absolute_error=float(error),tolerance=tolerance)

def normal_checks(z,tau):
    p1=normal_integral(z,1024);p2=normal_integral(z,2048)
    return [check('Integrate normal density at the proposed quantile',abs(p2-tau),1e-9),check('Quadrature refinement',abs(p2-p1),1e-9),check('Normal symmetry at zero',abs(normal_integral(0,128)-.5),1e-12)]

def verify(config):
    value=truth(config)['value']
    checks=[]
    m=config['intercept']+sum(config['beta'][j]*config['x_query'][j] for j in range(4))
    s=config['scale_intercept']+sum(config['gamma'][j]*config['x_query'][j] for j in range(4))
    z=(value-m)/s
    checks.extend(normal_checks(z,config['tau']))
    minimum_scale=config['scale_intercept']+sum(min(0,g) for g in config['gamma'])
    checks.append({'name':'Scale positive on whole unit cube','passed':minimum_scale>0,'minimum_scale':minimum_scale})
    return {"passed":all(c["passed"] for c in checks),"checks":checks}
