"""Independent analytic and shape checks for the upper step NRI target.

Uses fractions.Fraction for exact rational arithmetic as the primary independent
route, completely separate from the float-based truth.py implementation.

Checks cover:
  1. Exact rational route vs float route (independent computation)
  2. All k knot values p_s(j/k) = (j+1)/k via exact Fraction arithmetic
  3. Endpoint special cases: p_s(0) = 1/k, p_s(1) = 1
  4. Conditional probability support: values in [0, 1] on a dense grid
  5. Source monotonicity: p_s nondecreasing on a dense grid
  6. Equal step height: each step has height exactly 1/k
  7. Default-scenario anchor: s=0.5, x*=0.5 gives 0.6 exactly
  8. Step-interval bracket: x_star bracketed by correct knots

These checks do NOT call truth.py; they share only the declared DGP formula
and config parameters.
"""
import math
from fractions import Fraction


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _k_from_s(s):
    """Return integer k = 15 - 10*s; raises if not in {5,...,14}."""
    k_float = 15.0 - 10.0 * float(s)
    k = int(round(k_float))
    if abs(k_float - k) > 1e-9 or not (5 <= k <= 14):
        raise ValueError(
            f"s={s} gives k={k_float:.6g}, not an integer in {{5,...,14}}"
        )
    return k


def _p_step_fraction(x_frac, k):
    """Compute p_s(x) exactly for x as Fraction, k as int.

    Uses the floor of the Fraction k*x via integer truncation (safe for x>=0).
    Returns a Fraction.
    """
    if x_frac >= Fraction(1):
        return Fraction(1)
    kx = k * x_frac          # exact Fraction
    # floor of non-negative Fraction p/q = p // q (Python floor division)
    j = kx.numerator // kx.denominator
    return Fraction(j + 1, k)


def _p_step_float(x, k):
    """Float step function (independent of truth.py)."""
    if x >= 1.0:
        return 1.0
    j = int(math.floor(k * x))
    if j >= k:
        return 1.0
    return (j + 1) / k


# ---------------------------------------------------------------------------
# Main verify function
# ---------------------------------------------------------------------------

def verify(config):
    s = float(config["s"])
    x_star = float(config["x_star"])
    k = _k_from_s(s)

    # Float route (independent re-implementation, does not call truth.py)
    direct = _p_step_float(x_star, k)

    # Exact rational route via fractions.Fraction
    x_star_frac = Fraction(x_star).limit_denominator(10 ** 12)
    exact_val = _p_step_fraction(x_star_frac, k)
    frac_route = float(exact_val)

    # All k knot values: p_s(j/k) == (j+1)/k in exact arithmetic
    knot_passed = []
    knot_details = []
    for j in range(k):
        x_knot_frac = Fraction(j, k)
        p_knot = _p_step_fraction(x_knot_frac, k)
        expected = Fraction(j + 1, k)
        ok = (p_knot == expected)
        knot_passed.append(ok)
        if not ok:
            knot_details.append(
                f"j={j}: got {p_knot}={float(p_knot):.6g}, expected {expected}={float(expected):.6g}"
            )
    all_knots_ok = all(knot_passed)
    knot_summary = (
        f"All {k} knots p_s(j/{k}) = (j+1)/{k} verified in exact Fraction arithmetic."
        if all_knots_ok
        else "FAILED knots: " + "; ".join(knot_details)
    )

    # Endpoints
    p_at_0 = _p_step_fraction(Fraction(0), k)
    p_at_1 = _p_step_fraction(Fraction(1), k)

    # Dense-grid monotonicity and range check (1001 float points)
    grid = [i / 1000.0 for i in range(1001)]
    grid_vals = [_p_step_float(x, k) for x in grid]
    monotone = all(
        grid_vals[i] <= grid_vals[i + 1] + 1e-15
        for i in range(len(grid_vals) - 1)
    )
    in_range = all(0.0 <= v <= 1.0 for v in grid_vals)

    # Equal step height: each step value is (j+1)/k for j=0,...,k-1
    step_values = [(j + 1) / k for j in range(k)]
    equal_spacing = all(
        abs(step_values[j] - (j + 1) / k) < 1e-15
        for j in range(k)
    )

    checks = [
        {
            "name": "independent_rational_truth_route",
            "passed": abs(direct - frac_route) <= 2e-15,
            "details": (
                f"float_floor_route={direct:.17g}; "
                f"fractions.Fraction_route={frac_route:.17g}; "
                f"difference={abs(direct - frac_route):.3g}. "
                f"(x_star approximated as {x_star_frac} in Fraction arithmetic.)"
            ),
        },
        {
            "name": "all_knot_values_exact",
            "passed": all_knots_ok,
            "details": knot_summary,
        },
        {
            "name": "endpoint_p_at_0",
            "passed": p_at_0 == Fraction(1, k),
            "details": (
                f"p_s(0) = 1/k = 1/{k} = {float(Fraction(1, k)):.6g}; "
                f"computed {float(p_at_0):.6g}."
            ),
        },
        {
            "name": "endpoint_p_at_1",
            "passed": p_at_1 == Fraction(1),
            "details": (
                f"p_s(1) = 1 (indicator 1{{x!=1}} = 0); "
                f"computed {float(p_at_1):.6g}."
            ),
        },
        {
            "name": "conditional_probability_support",
            "passed": in_range,
            "details": "Step probabilities lie in [0, 1] on a 1001-point uniform grid.",
        },
        {
            "name": "source_monotonicity_on_grid",
            "passed": monotone,
            "details": (
                f"p_s is nondecreasing on the 1001-point grid (k={k}); "
                "matches the monotonicity condition of the source band method."
            ),
        },
        {
            "name": "equal_step_height",
            "passed": equal_spacing,
            "details": (
                f"Each of the {k} steps has height 1/{k} = {1/k:.6g}; "
                "verified for all j=0,...,k-1."
            ),
        },
    ]

    # Special-case anchor: default s=0.5, x_star=0.5 -> 0.6 exactly
    if abs(s - 0.5) < 1e-9 and abs(x_star - 0.5) < 1e-9:
        # k=10, x_star=0.5: kx=5.0 (exact), j=5, value=6/10=0.6
        checks.append({
            "name": "default_s05_x05_anchor",
            "passed": abs(direct - 0.6) < 1e-14,
            "details": (
                f"s=0.5, k=10, x_star=0.5: k*x_star=5.0 (exact), "
                f"floor(5.0)=5, (5+1)/10=0.6; computed={direct:.17g}."
            ),
        })

    # Step-interval bracket: verify x_star sits in the expected step
    if 0.0 < x_star < 1.0:
        j_int = int(math.floor(k * x_star))
        if j_int >= k:
            j_int = k - 1
        lower_knot = j_int / k
        upper_knot = (j_int + 1) / k if j_int + 1 < k else 1.0
        expected_val = (j_int + 1) / k
        bracket_ok = (lower_knot <= x_star <= upper_knot + 1e-15) and abs(direct - expected_val) < 1e-14
        checks.append({
            "name": "step_interval_bracket",
            "passed": bracket_ok,
            "details": (
                f"x_star={x_star} in step interval [{lower_knot:.6g}, {upper_knot:.6g}); "
                f"step index j={j_int}, value=({j_int}+1)/{k}={expected_val:.6g}; "
                f"computed={direct:.6g}."
            ),
        })

    # Check that p_s is strictly greater than 0 everywhere (p_s(0) = 1/k > 0)
    checks.append({
        "name": "strictly_positive_lower_bound",
        "passed": all(v > 0.0 for v in grid_vals),
        "details": (
            f"p_s(0) = 1/k = 1/{k} > 0; all 1001 grid values are strictly positive "
            f"(min={min(grid_vals):.6g})."
        ),
    })

    return {
        "passed": all(c["passed"] for c in checks),
        "checks": checks,
        "shared_components": (
            "The independent Fraction route shares only the declared step formula "
            "and config parameters; it does not call truth.py or use the same "
            "float floor implementation. Knot and grid checks are independent "
            "numerical verifications. Source reconstruction and independent-person "
            "reproduction remain separate review tasks."
        ),
        "scope": (
            "These checks cover the scalar analytic truth and source shape conditions. "
            "Discontinuities at knot points x=j/k are expected behavior of the "
            "right-continuous upper step function and are explicitly verified. "
            "Point-wise checks do not establish simultaneous confidence-band coverage."
        ),
    }
