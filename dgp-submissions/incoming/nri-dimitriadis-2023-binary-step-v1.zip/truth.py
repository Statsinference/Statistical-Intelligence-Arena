"""Analytic scalar NRI truth for the selected step scenario.

The upper step function p_s(x) = (floor(k*x) + 1{x != 1}) / k,
k = 15 - 10*s, s in {0.1, 0.2, ..., 1.0}.

Truth at x_star: exact rational arithmetic (j+1)/k where j = floor(k * x_star).
For interior x_star (not a knot), this is a pure integer division.
At a knot x_star = j/k the value is (j+1)/k (right-continuous / upper step convention).

Floating-point rounding of 0.6 (= 6/10) is the only source of error for the
default scenario; estimated_error is 2 * machine_epsilon.
"""
import math
import sys
from fractions import Fraction


def _validate(config):
    if not isinstance(config, dict):
        raise ValueError("config must be a scenario dictionary")
    s = config.get("s")
    x_star = config.get("x_star")
    if isinstance(s, bool) or not isinstance(s, (int, float)) or not math.isfinite(float(s)):
        raise ValueError("s must be a finite numeric value")
    s_f = float(s)
    if not (0.0 < s_f <= 1.0 + 1e-12):
        raise ValueError("s must lie in (0, 1]")
    k_float = 15.0 - 10.0 * s_f
    k = int(round(k_float))
    if abs(k_float - k) > 1e-9 or not (5 <= k <= 14):
        raise ValueError(
            f"k = 15 - 10*s = {k_float:.6g} must be an integer in {{5,...,14}}"
        )
    if isinstance(x_star, bool) or not isinstance(x_star, (int, float)) or not math.isfinite(float(x_star)):
        raise ValueError("x_star must be a finite numeric value")
    if not 0.0 < float(x_star) < 1.0:
        raise ValueError("x_star must be an interior point of (0, 1) for NRI scalar query")


def truth(config):
    """Return p_s(x_star) = E[Y | X = x_star] for the step DGP.

    Derivation
    ----------
    For x in [0, 1):
        p_s(x) = (floor(k * x) + 1) / k
    where k = 15 - 10 * s (integer in {5,...,14}).

    At the query x_star (interior, x_star != 1):
        j = floor(k * x_star)     <- integer step index
        value = (j + 1) / k       <- exact rational

    Independent audit route: the same formula evaluated with float(j + 1) / k
    is compared against k * x_star recomputed; agreement to within 2 * eps
    confirms no integer rounding error.

    For the default s=0.5, k=10, x_star=0.5:
        j = floor(5.0) = 5,  value = 6/10 = 0.6 (exact rational).
    """
    _validate(config)
    s = float(config["s"])
    x_star = float(config["x_star"])
    k = int(round(15.0 - 10.0 * s))

    # Primary route: floor formula on floats
    kx = k * x_star
    j = int(math.floor(kx))
    if j >= k:          # defensive guard (x_star < 1 should prevent this)
        j = k - 1
    value = (j + 1) / k

    # Independent audit route: exact rational arithmetic via fractions.Fraction.
    # Fraction(x_star) converts the float to its exact binary-fraction value;
    # limit_denominator caps it to avoid spurious rounding in limit_denominator itself.
    # For x_star = 0.5, Fraction(0.5) = Fraction(1, 2) exactly.
    # NOTE: ceil(kx) is WRONG at exact-integer knots (ceil(7.0)=7 != floor(7.0)+1=8),
    # so we use Fraction floor division instead.
    x_frac = Fraction(x_star).limit_denominator(10 ** 12)
    kx_frac = k * x_frac                               # exact Fraction
    j2 = kx_frac.numerator // kx_frac.denominator     # exact floor via //
    value2 = (j2 + 1) / k

    estimated_error = abs(value - value2) + 2.0 * sys.float_info.epsilon

    return {
        "value": float(value),
        "estimated_error": float(estimated_error),
        "method": (
            "Exact step formula: p_s(x_star) = (floor(k*x_star) + 1) / k, "
            "k = 15 - 10*s; independently audited via fractions.Fraction exact "
            "rational arithmetic (floor of k*x_star via Fraction floor division)."
        ),
        "error_interpretation": (
            "Rational-valued truth (j+1)/k for integers j, k; floating-point "
            "representation error bounded by 2 * machine_epsilon (~4.4e-16). "
            "Not a confidence-band or coverage error bound."
        ),
        "target": "m_s(x_star) = E[Y | X=x_star] = p_s(x_star), NRI point query",
        "query": {"x_star": x_star, "s": s, "k": k, "step_index_j": j},
    }
