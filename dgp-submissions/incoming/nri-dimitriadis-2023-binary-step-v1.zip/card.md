# Upper step binary regression DGP: nri-binary-step-v1

**Status: candidate; not scientifically accepted.**

Source: Dimitriadis, T., Dümbgen, L., Henzi, A., Puke, M. and Ziegel, J. (2023).
Honest calibration assessment for binary outcome predictions.
*Biometrika* 110(3), 663–680. DOI [10.1093/biomet/asac068](https://doi.org/10.1093/biomet/asac068).
[arXiv:2203.04065v2](https://arxiv.org/abs/2203.04065) (2022-11-02), PDF p.8, Section 5, item 4 (Step).

**[*] Caveat on source version**: The DGP was checked against arXiv preprint v2 (2022-11-02).
Differences between the preprint and the final Biometrika publication have **not** been verified.
The replication repository https://github.com/marius-cp/replication_DDHPZ22 has no pinned commit.
Maintainer review of the formal version is required before scientific acceptance.

---

## Source fidelity and adaptation

The two observed columns are `X` and `Y`. The DGP as stated in arXiv v2 PDF p.8, §5:

- `X ~ Uniform[0, 1]`
- `Y | X ~ Bernoulli(p_s(X))`
- Upper step function: `p_s(x) = (floor(k·x) + 1{x ≠ 1}) / k`
- Step count: `k = 15 − 10·s`, `s ∈ {0.1, 0.2, …, 1.0}`, so `k ∈ {14, 13, …, 5}`
- Source excludes `s = 0` (which would give `k = 15`, outside the declared range {5,…,14}).

The source paper studies **simultaneous confidence bands** for monotone regression functions.
This contribution changes the target to the **scalar NRI query** `E[Y | X = 0.5] = p_s(0.5)`,
which is required by the collection interface. No confidence band, bootstrap, or coverage
result is reproduced.

---

## Original equations

1. `X_i ~ Uniform[0, 1]` independently.
2. `p_s(x) = (floor(k·x) + 1{x ≠ 1}) / k`, where `k = 15 − 10·s`.
3. `Y_i | X_i = x ~ Bernoulli(p_s(x))` independently.

**Special values** (right-continuous upper step):
- `p_s(0) = 1/k` (step j=0 starts at x=0, value = (0+1)/k)
- `p_s(j/k) = (j+1)/k` for `j = 0, 1, …, k−1` (each left endpoint takes the upper value)
- `p_s(x) = (j+1)/k` for `x ∈ [j/k, (j+1)/k)`, `j = 0, …, k−1`
- `p_s(1) = 1` (indicator `1{x≠1} = 0` at the right endpoint)

**Interpretation**: the function is right-continuous (piecewise constant on half-open intervals),
with a jump of size `1/k` at each knot `x = j/k`. It is nondecreasing, consistent with the
source's monotonicity assumption.

Sampling unit: independent individuals. No interference, clustering, or panel structure.
`dimension = 1`, `effective_dimension = 1` (single covariate X). No interaction terms.
`nonlinear = true` (non-smooth piecewise constant; not a polynomial or smooth function).

---

## Target and identification

**Estimand**: `m_s(x*) = E[Y | X = x*] = p_s(x*)` at fixed query `x* = 0.5`.

This is a conditional Bernoulli probability evaluated under the known DGP.
It is a **noncausal** regression target: no intervention, no mediator, no treatment is defined.
The source paper frames the problem as nonparametric calibration assessment; this contribution
registers the scalar NRI query for use in the collection benchmark.

**Applicable assumptions**:
- iid observations (no clustering, panel, or network dependence)
- `X ~ Uniform[0, 1]`; the fixed query `x* = 0.5` lies in the open support
- `Y | X ~ Bernoulli(p_s(X))` for the declared `k`
- Monotonicity of `p_s` (satisfied by construction for all `k ∈ {5,…,14}`)
- No causal identification, exchangeability, or interference assumption is needed or claimed

---

## Truth and independent verification

For interior query `x* ∈ (0, 1)`, `x* ≠ 1`:

```
j     = floor(k · x*)          # integer step index
value = (j + 1) / k            # exact rational truth
```

For the **default scenario** `s = 0.5`, `k = 10`, `x* = 0.5`:
```
k · x* = 10 × 0.5 = 5.0  (exact)
j      = floor(5.0) = 5
value  = (5 + 1) / 10 = 6/10 = 0.6  (exact rational)
```

**Floating-point note**: `0.6 = 3/5` is not exactly representable in IEEE 754 binary64.
The computed `float(6/10)` is the nearest double, with absolute error `< 2 × machine_epsilon ≈ 4.4 × 10⁻¹⁶`.

**All 10 scenario truth values** at `x* = 0.5`:

| Scenario | s | k | j=floor(k×0.5) | value = (j+1)/k |
|---|---|---|---|---|
| s01 | 0.1 | 14 | 7 | 8/14 ≈ 0.571429 |
| s02 | 0.2 | 13 | 6 | 7/13 ≈ 0.538462 |
| s03 | 0.3 | 12 | 6 | 7/12 ≈ 0.583333 |
| s04 | 0.4 | 11 | 5 | 6/11 ≈ 0.545455 |
| **s05** | **0.5** | **10** | **5** | **6/10 = 0.6** |
| s06 | 0.6 | 9 | 4 | 5/9 ≈ 0.555556 |
| s07 | 0.7 | 8 | 4 | 5/8 = 0.625 |
| s08 | 0.8 | 7 | 3 | 4/7 ≈ 0.571429 |
| s09 | 0.9 | 6 | 3 | 4/6 ≈ 0.666667 |
| s10 | 1.0 | 5 | 2 | 3/5 = 0.6 |

**Independent verification route** (`verify.py`): uses `fractions.Fraction` for exact rational
arithmetic, independently of `truth.py`'s float floor implementation. Checks:
1. Fraction route vs float route agree to within `2 × 10⁻¹⁵`
2. All `k` knot values `p_s(j/k) = (j+1)/k` in exact Fraction arithmetic
3. Endpoint special cases `p_s(0) = 1/k` and `p_s(1) = 1`
4. Values in `[0,1]` and nondecreasing on a 1001-point dense grid
5. All steps have equal height `1/k`
6. Default-scenario anchor: `s=0.5, x*=0.5 → 0.6` exactly
7. Step-interval bracket: `x_star` lies in the correct step interval

**Boundary/knot note**: the step function is discontinuous at each knot `x = j/k`.
`p_s` is right-continuous (constant on `[j/k, (j+1)/k)` taking the upper value).
For `x* = 0.5` with even `k`, `k · 0.5` is an exact integer so `floor` is unambiguous.
For odd `k`, `k · 0.5` is a half-integer, also unambiguous. The verify check
"all_knot_values_exact" uses exact Fraction arithmetic to avoid floating-point issues
at the knot points.

**Shared components**: both `truth.py` and `verify.py` share the declared DGP formula
and `config` parameters; they do not share code paths. An independent human reproduction
is required for scientific acceptance.

---

## Diversity and scope

- **Total dimension**: 1 (covariate X only)
- **Effective dimension**: 1 (X is the only predictor; no irrelevant variables added)
- **High-dimensional**: false
- **Interactions**: false (single variable, no cross-terms)
- **Nonlinear**: true (piecewise constant, discontinuous at k knots; not smooth)
- **Number of steps k**: varies from 14 (s=0.1) to 5 (s=1.0); larger s → fewer steps → coarser function
- **Unsupported settings**: s=0 excluded (k=15 outside {5,…,14}); x_star must be in (0,1)
- **Source simultaneous bands**: the source targets the whole curve under monotonicity; this collection
  registers only the scalar point query at x*=0.5 (point-wise check ≠ band coverage)

---

## Rights and assistance

Paper copyright belongs to Biometrika/Oxford/authors. No paper PDF or replication repository
code is redistributed. Equations are cited and independently reimplemented from the arXiv v2 text.

AI assistance (Claude Code / Claude Opus 5.5) was used to extract equations, write and debug
all Python code, and draft this card; all content reflects the contributor's declared source
description and the cited DGP formula. Scientific acceptance requires maintainer verification
of the formal Biometrika version.

**Unresolved issues / open gaps**:
- [*] Formal Biometrika (2023) DGP vs. arXiv v2 differences not checked
- No fixed replication code commit; GitHub commit hash pending maintainer review
- `item 4 (Step)` numbering within §5 inferred from sibling contributions; not confirmed from unopened PDF
- Source coverage/band experiments not reproduced; only scalar smoke check run
