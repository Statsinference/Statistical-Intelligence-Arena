# MAR mean response with ten Gaussian covariates

**Candidate MDI mechanism. Local validation is not scientific acceptance.**

Hu, Follmann and Wang (2014), “Estimation of mean response via the effective balancing score,” *Biometrika* 101(3):613–624, DOI [10.1093/biomet/asu022](https://doi.org/10.1093/biomet/asu022). [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC4365779/) gives the DGP in Section 4, “Numerical Studies,” simulation 1, the paragraph beginning “In simulation 1.” A local full-text HTML review copy is at `/Users/xu/Desktop/PEN/论文资料/Hu_Follmann_Wang_2014_Biometrika_Effective_Balancing_Score_fulltext.html` (outside the contribution ZIP).

For each iid individual, `X1,...,X10` are independent N(0,1). Conditional on X, `Y=3X1+5X2+epsilon`, with independent `epsilon~N(0,1)`. Let `R=1` mean Y is observed. Given X, draw R independently of epsilon with `Pr(R=1|X)=expit(X1)`. Thus missing Y is MAR conditional on fully observed X. Positivity holds at every finite X1, though not uniformly over the unbounded Gaussian support.

The target is the full-data population mean `theta=E(Y)=0`. This value is **derived from centered Gaussian covariates and independent centered noise**, not read from a reported table. Only X1 and X2 affect Y or R; X3 through X10 are inactive. There are ten total covariates, but this is not a high-dimensional setting relative to the source's n=200 or n=1000. The outcome mean and observation logit are linear predictors with no interaction.

The paper compares estimators over 200 generated datasets for n=200 and n=1000. This generator returns one sample per call and does not repeat estimator comparisons. It exports ten covariates, R and Y_observed. When R=0, Y_observed=0 is a **finite missing-value placeholder**, never a measured outcome; analysis must apply the R mask. Full unobserved Y is not exported. This numeric encoding and single-call interface are the only DGP adaptations.

Truth uses linear expectation. Independent verification uses two-dimensional Gaussian quadrature and source-constant/probability checks. Those checks do not test estimator coverage or confer scientific acceptance. No PDF, author code or real dataset is redistributed in the contribution ZIP. AI assisted extraction, implementation and drafting; named scientific, source-rights and duplicate reviews remain pending.
