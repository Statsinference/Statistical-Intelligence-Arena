"""Independent Gaussian quadrature and source-constant checks."""
import math


def verify(config):
    fixture = {
        "covariate_sd": 1.0,
        "outcome_coefficients": [3.0, 5.0],
        "outcome_noise_sd": 1.0,
        "observation_logit_coefficient": 1.0,
        "missing_outcome_placeholder": 0.0,
        "paper_sample_sizes": [200, 1000],
        "paper_simulation_repetitions": 200,
    }
    nodes = (-math.sqrt(3.0), 0.0, math.sqrt(3.0))
    weights = (1/6, 2/3, 1/6)
    sx = float(config["covariate_sd"])
    b1, b2 = (float(v) for v in config["outcome_coefficients"])
    quadrature = sum(w1*w2*(b1*sx*z1+b2*sx*z2)
                     for z1,w1 in zip(nodes,weights)
                     for z2,w2 in zip(nodes,weights))
    a = float(config["observation_logit_coefficient"])
    probabilities = [1/(1+math.exp(-a*x)) for x in (-1.0,0.0,1.0)]
    references = [1/(1+math.e), 0.5, math.e/(1+math.e)]
    checks = [
        {"name":"source_constants","passed":config == fixture,
         "details":"Section 4 simulation 1: ten independent standard Gaussians; 3X1+5X2+N(0,1); expit(X1); 200 datasets of n=200 or 1000."},
        {"name":"independent_gaussian_quadrature","passed":abs(quadrature)<1e-12,
         "details":f"Two-dimensional three-point Gaussian quadrature yields E(Y)={quadrature:.17g}."},
        {"name":"observation_probability_spot_checks",
         "passed":all(abs(v-w)<1e-12 for v,w in zip(probabilities,references)),
         "details":"At X1=-1,0,1 probabilities are expit(-1), 1/2, expit(1); inactive covariates do not enter."},
        {"name":"finite_placeholder","passed":math.isfinite(float(config["missing_outcome_placeholder"])),
         "details":"Unobserved full Y is not exported."}
    ]
    return {"passed":all(check["passed"] for check in checks),"checks":checks,
            "shared_components":"Quadrature reuses source coefficients, but not truth.py's linear expectation calculation."}
