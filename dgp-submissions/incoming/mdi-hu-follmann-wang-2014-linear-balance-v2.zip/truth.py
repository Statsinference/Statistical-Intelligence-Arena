"""Exact full-data population mean, independent of generated rows."""
import math


def truth(config):
    sx = float(config["covariate_sd"])
    sy = float(config["outcome_noise_sd"])
    b = [float(v) for v in config["outcome_coefficients"]]
    if not (math.isfinite(sx) and sx > 0 and math.isfinite(sy) and sy > 0):
        raise ValueError("standard deviations must be positive and finite")
    if len(b) != 2 or not all(math.isfinite(v) for v in b):
        raise ValueError("invalid outcome coefficients")
    return {"value": 0.0, "estimated_error": 0.0,
            "method": "Exact linear mean of centered Gaussians and independent centered noise",
            "target": "Full-data E(Y)"}
