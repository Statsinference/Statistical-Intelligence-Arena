"""Population conditional mean at a prespecified point, not a fitted prediction."""
import math
from generator import validate_config


def truth(config):
    validate_config(config)
    x = config['query_x']
    denominator = 1 if x <= 0 else 1 + 36 * x * x
    value = math.sin(3 * math.pi * x / 2) / denominator
    return {'value': float(value), 'estimated_error': 0.0,
            'target': 'm(query_x) = E[Y | X=query_x], using the continuous conditional-mean version',
            'method': 'Analytic source equation and E[epsilon | X]=0; no sampled rows used.',
            'error_interpretation': 'No integration/Monte Carlo approximation; floating-point and trigonometric rounding remain.'}
