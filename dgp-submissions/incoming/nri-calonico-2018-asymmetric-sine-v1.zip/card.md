# NRI：非对称正弦回归函数的逐点条件均值推断

## 来源、版本与最小贡献单位
Calonico, S., Cattaneo, M. D., and Farrell, M. H. (2018). On the Effect of Bias Estimation on Coverage Accuracy in Nonparametric Inference. Journal of the American Statistical Association, 113(522), 767–779. DOI: 10.1080/01621459.2017.1285776.

来源：https://rdpackages.github.io/references/Calonico-Cattaneo-Farrell_2018_JASA.pdf

Final journal typeset PDF, Section 4 Simulation Results and Figure 1, printed p.776 (PDF p.10); Table 1, printed p.777 (PDF p.11); conditional mean definition in Section 3.1. Version cross-check: arXiv:1508.02973v6 (2018-03-07).

| 项目 | 核对结果 |
|---|---|
| 文献与期刊 | Calonico, Cattaneo & Farrell (2018), JASA 113(522),767–779; DOI 10.1080/01621459.2017.1285776 |
| 版本 | 作者软件项目托管的期刊排版 PDF；正文第10页（印刷776）§4与Figure 1；arXiv v6 日期2018-03-07 |
| X 分布 | §4：Uniform[-1,1] |
| 误差 | §4：N(0,1)；实现显式采用与 X 独立的噪声，原段落没有单列独立性等式 |
| m(x) | §4：sin(3*pi*x/2)/{1+18*x^2[sgn(x)+1]}；逐字公式已视觉核对 |
| 查询与原实验 | §4：x0=-2/3,-1/3,0,1/3,2/3；n=500，重复5000次 |
| 目标 | §3.1/§4：固定点条件均值 m(x0)=E[Y\|X=x0]；本包保留这一目标 |
| 真值 | 此处解析推导：0,-1,0,1/5,0；不是论文估计值或覆盖率 |
| 单位/假设 | iid 个体、正设计密度、独立零均值误差、预先固定查询点、连续条件均值版本 |
| 检查样本量 | n=128、seed=1729 来自学生指南，不是原文实验规模 |
| 缺失参数 | 所选固定数值/函数无缺失；作者 RNG、逐行序列未复现，独立噪声约定已明示 |
| 访问限制 | DOI/出版商网页本次访问失败或403；通过作者项目的期刊排版 PDF、作者主页、arXiv 与 Crossref 核实 |


本包选取正文 §4 的一套非对称正弦回归机制，五个查询点是同一分布下的查询场景；不是五套独立 DGP。论文补充材料中的其他回归函数和密度估计问题未纳入本轮。

## 原始机制
- X ~ Uniform[-1,1], epsilon ~ N(0,1), X independent of epsilon in the declared implementation.
- Y=m(X)+epsilon; m(x)=sin(3*pi*x/2)/(1+18*x^2*(sgn(x)+1)); sgn(0)=0.
- Equivalently, m(x)=sin(3*pi*x/2) for x<=0; m(x)=sin(3*pi*x/2)/(1+36*x^2) for x>0.
- theta(x0)=E[Y|X=x0]=m(x0); x0 in {-2/3,-1/3,0,1/3,2/3}.
- Ordered exact source-query truths: 0,-1,0,1/5,0. These are analytically derived here, not reported estimator results.

生成器使用局部 `numpy.random.Generator(PCG64(seed))`，依次抽取全部 n 个 X 和 n 个正态误差。只导出 X,Y；不输出 epsilon、m(X)、噪声方差标签或逐行 oracle。query_x 是查询参数，不是一列输入特征，也不影响样本生成。

## 目标、真值和推断范围
本包评测对象是给定点的总体条件均值 m(x0)。连续 X 下通过机制定义的连续条件均值版本指定点值，不能用样本均值或局部拟合结果充当 oracle。

E[Y|X=x0] = m(x0)+E[epsilon|X=x0] = m(x0)。

| scenario | x0 | 精确真值 | 来源 |
|---|---:|---:|---|
| source_x_neg_two_thirds | -2/3 | 0 | §4 原查询点 |
| source_x_neg_one_third | -1/3 | -1 | §4 原查询点 |
| source_x_zero | 0 | 0 | §4 原查询点 |
| source_x_pos_one_third | 1/3 | 1/5 | §4 原查询点，默认 |
| source_x_pos_two_thirds | 2/3 | 0 | §4 原查询点 |

解析浮点计算的零值可能呈现约1e-16的残差，这是三角函数舍入；truth 不把它变成数据估计。estimated_error=0 表示没有数值积分/Monte Carlo 近似，并非严格的浮点零误差界。固定 tolerance=1e-12。

这不是总体均值、预测区间或因果效应任务。原标量接口不能宣称已实现整个连续域的同时置信带。五个逐点 CI 也不自动构成联合95%置信带。CI估计器、标准误、覆盖率和长度尚未运行；本轮是机制收集与规范包测试。

## 抽样及识别条件
- IID individuals (X_i,Y_i) with random design X_i uniform on [-1,1].
- Declared implementation uses epsilon_i independent of X_i and iid N(0,1); hence E[epsilon_i|X_i]=0.
- Finite conditional moments and positive design density in neighborhoods of the five interior queries.
- The continuous conditional-mean version m(x) defines the point target; the query is prespecified, not selected from outcomes.
- This is a descriptive conditional mean, with no treatment, intervention, ignorability or IV assumptions.
- No claim that every CI method or high-order smoothness theorem applies at every point; m is C2 but not C3 at x=0.

推导备注（本包分析，非原文新增结论）：令 k=3*pi/2，左侧 m(x)=kx−k^3*x^3/6+O(x^5)，右侧 m(x)=kx−(k^3/6+36k)*x^3+O(x^5)。因此在0处前两阶导数连续，但两侧三阶导数相差−216k。不能把该函数说成在全区间无限光滑，也不能仅凭运行通过推定高阶 CI 定理在0处的所有前提成立。

## 维数与属性
一个基线预测变量 X，dimension=effective_dimension=1，不是高维。无跨变量交互，无无关特征。同方差 Var(Y|X)=1。非线性是正弦与正半轴有理衰减。五个注册查询点均在支持内部；端点仅作为 verify 的解析特例，不计入源场景。分类概率、异方差与边界压力场景留待后续独立登记。

## 适配与约定
- 原文 §4 的均值函数、Uniform[-1,1] 设计、N(0,1) 误差及五个查询点保持不变；独立编写 Python/NumPy PCG64 实现，不声称与原作者随机数逐行相同。
- 实现明确采用 X 与 epsilon 独立的加性正态噪声构造。§4 列出二者分布而未单列独立性等式；本包将这一实现约定显式登记，得到 E[epsilon|X]=0 与 Var(Y|X)=1。
- 为适配学生包标量 truth 接口，将原文五个查询点登记为同一 DGP 下的五个 query scenarios；不是五个机制家族。
- 原文 n=500、重复5000次；本轮 n=128、seed=1729 用于接口核验，不声称复跑论文的 CI 覆盖率。
- 默认查询点选为原文的 x=1/3；noise_sd=1 保留源设置，sd=2 仅用于内部核验控制，未登记为额外源场景。
- 非因果 NRI 使用显式 nonparametric-regression-family-v1 本地类别扩展；未扩展原版会拒绝 family，未放宽其他检查。

## 独立核验与重现性
1. 用源查询点的精确三角函数值核验所有五个目标，默认非零真值0.2。
2. 独立用 sin(3t)=3sin(t)−4sin(t)^3 与正部函数重写均值；对条件高斯密度做16/32阶 Gauss–Hermite 积分，检查条件均值、方差及概率质量。
3. 用 x=−1,−1/2,0,1/2,1 的可解析值检查零点、符号和衰减；这些是验证探针。
4. 独立标量源方程重建73行数据，核对观察列与支持；变换查询点应保持同种子样本不变。
5. 将噪声标准差乘2，检验同种子残差对应缩放、条件均值不变；拒绝越界查询、非正或非有限标准差；检查输入配置未被改动。

验证与实现共享输入校验、随机数基础库及源参数，不共享 generator 的回归函数实现；真值验证通过不同恒等式和积分计算。由同一 AI 辅助完成，不冒充独立人员科学复现。16/32阶差异是数值诊断，不是一般严格误差界。

同种子下五个查询场景故意复用相同 X,Y；这样才能在同一数据上评价不同 x0。将来划分训练/测试时应按 mechanism_family_id 分组，不能把这些查询当成五个独立 family。

## 规范文件与执行流程
先阅读 toolkit_compatibility.md。原版学生包必须显式启用 NRI 类别；不能将本包误标为 CATE。以下在包含 collect.py 的学生包根目录运行：

```powershell
python contributions/nri-calonico-2018-asymmetric-sine-v1/enable_nri_family.py .
python collect.py check contributions/nri-calonico-2018-asymmetric-sine-v1 --run --n 128 --seed 1729
python collect.py pack contributions/nri-calonico-2018-asymmetric-sine-v1 --out submissions/nri-calonico-2018-asymmetric-sine-v1.zip
```

init 已由官方 collect.py 创建模板。所有场景检查后再 pack；不手工拼 ZIP。ZIP 根目录直接是 collection.json 等文件，包含 checks/report.json、checks/sample.json 与 MANIFEST.json，不再嵌套一层贡献目录。改源文件后须重新检查并使用新 ZIP 文件名。

必需8项：collection.json、card.md、config.json、schema.csv、generator.py、truth.py、verify.py、requirements.txt。辅助文件包括来源核对、环境记录和类别启用脚本。没有 PDF 报告、原文 PDF、模型权重或大数据。

## 权利、AI与未决状态
独立实现，不复制作者程序。原文版权归原权利人。本包与原作者代码没有逐行种子相等承诺。

AI 辅助：OpenAI Codex，2026-10-27。人类原文阅读、独立人员复现、维护人认领去重及科学接收均未代签。本地检查通过不代表科学接收；NRI类别扩展仍需维护人正式采用。未发送到外部维护人。未训练 PFN、拟合估计器、运行 bootstrap 或报告 CI 覆盖率。
