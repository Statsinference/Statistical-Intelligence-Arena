"""Source fixtures, conditional-density quadrature, and independent scalar replay.

Verification shares input validation/RNG primitives with the contribution but does
not call generator.regression_mean. These are computationally different checks by
the same AI-assisted contributor, not independent-person scientific reproduction.
"""
import copy
import math
import numpy as np
from generator import generate
from truth import truth

TOLERANCE = 1e-12
SOURCE_QUERIES = [(-2/3, 0.0), (-1/3, -1.0), (0.0, 0.0), (1/3, 1/5), (2/3, 0.0)]


def scalar_mean(x):
    """Alternative trigonometric identity sin(3t)=3 sin(t)-4 sin(t)^3."""
    sine = math.sin(math.pi * x / 2)
    numerator = 3 * sine - 4 * sine**3
    positive_x = max(x, 0.0)
    return numerator / (1 + 36 * positive_x**2)


def conditional_moments(x, sd, order):
    """Integrate Y and Y^2 under the declared conditional Gaussian law."""
    nodes, weights = np.polynomial.hermite.hermgauss(order)
    outcomes = scalar_mean(x) + math.sqrt(2) * sd * nodes
    mass = float(weights.sum() / math.sqrt(math.pi))
    mean = float(np.dot(weights, outcomes) / math.sqrt(math.pi))
    second = float(np.dot(weights, outcomes**2) / math.sqrt(math.pi))
    return mass, mean, second - mean**2


def check_truth(config):
    errors = [abs(truth({**config, 'query_x': x})['value'] - expected) for x, expected in SOURCE_QUERIES]
    probes = [-1, -.77, -.5, -1e-7, 0, 1e-7, .27, .5, .89, 1, config['query_x']]
    quadrature_errors, variance_errors, mass_errors, convergence = [], [], [], []
    for x in probes:
        expected = truth({**config, 'query_x': x})['value']
        low = conditional_moments(x, config['noise_sd'], 16)
        high = conditional_moments(x, config['noise_sd'], 32)
        quadrature_errors.append(abs(high[1] - expected))
        variance_errors.append(abs(high[2] - config['noise_sd']**2))
        mass_errors.append(abs(high[0] - 1))
        convergence.append(abs(high[1] - low[1]))
    fixtures = [(-1, 1), (-.5, -math.sqrt(2)/2), (0, 0), (.5, math.sqrt(2)/20), (1, -1/37)]
    special_errors = [abs(truth({**config, 'query_x': x})['value'] - value) for x, value in fixtures]
    return [
        {'name': 'source_five_query_exact_targets', 'passed': max(errors) < TOLERANCE,
         'max_absolute_error': max(errors), 'analytic_targets': [v for _, v in SOURCE_QUERIES]},
        {'name': 'independent_conditional_gaussian_quadrature', 'passed': max(quadrature_errors) < TOLERANCE,
         'max_absolute_error': max(quadrature_errors), 'queries': len(probes), 'orders': [16,32],
         'max_order_difference': max(convergence), 'strict_error_bound': False},
        {'name': 'conditional_variance_and_normalization',
         'passed': max(variance_errors + mass_errors) < TOLERANCE,
         'max_variance_error': max(variance_errors), 'max_mass_error': max(mass_errors)},
        {'name': 'zero_and_exact_special_points', 'passed': max(special_errors) < TOLERANCE,
         'max_absolute_error': max(special_errors), 'note': 'Includes zero mean at x=0 and exact endpoint values; endpoints are verification probes, not registered source queries.'},
    ]


def check_generator(config):
    n, seed = 73, 271027
    data = generate(config, n, seed)
    rng = np.random.Generator(np.random.PCG64(seed))
    x = rng.uniform(-1, 1, n)
    errors = rng.normal(0, config['noise_sd'], n)
    expected_y = [scalar_mean(float(value)) + float(error) for value, error in zip(x, errors)]
    replay_error = max(abs(a-b) for a,b in zip(data['Y'],expected_y))
    doubled = generate({**config, 'noise_sd': 2 * config['noise_sd']}, n, seed)
    scale_errors = [abs((y2 - scalar_mean(value)) - 2*(y1 - scalar_mean(value)))
                    for value,y1,y2 in zip(data['X'],data['Y'],doubled['Y'])]
    queries_unchanged = all(generate({**config,'query_x':query},n,seed) == data for query,_ in SOURCE_QUERIES)
    scale_truth = truth({**config,'noise_sd':2*config['noise_sd']})['value']
    return [
        {'name':'scalar_source_equation_replay','passed':data['X']==x.tolist() and replay_error<TOLERANCE,
         'rows':n,'seed':seed,'max_outcome_error':replay_error},
        {'name':'query_does_not_change_sample','passed':queries_unchanged,'queries':len(SOURCE_QUERIES)},
        {'name':'noise_scale_control','passed':max(scale_errors)<TOLERANCE and scale_truth==truth(config)['value'],
         'max_residual_scale_error':max(scale_errors),'note':'sd=2 is a verification control, not an extra source scenario.'},
        {'name':'observed_columns_and_support','passed':set(data)=={'X','Y'} and all(-1<=v<=1 for v in data['X'])
         and all(len(values)==n and all(math.isfinite(v) for v in values) for values in data.values())},
    ]


def check_rejections(config):
    invalid = [{**config,'query_x':1.01},{**config,'noise_sd':0},{**config,'noise_sd':float('nan')}]
    rejected = []
    for parameters in invalid:
        for hook in [lambda:truth(parameters),lambda:generate(parameters,5,10)]:
            try:
                hook()
                rejected.append(False)
            except ValueError:
                rejected.append(True)
    return {'name':'invalid_configuration_rejection','passed':all(rejected),'calls':len(rejected)}


def verify(config):
    before = copy.deepcopy(config)
    checks = check_truth(config) + check_generator(config) + [check_rejections(config)]
    checks.append({'name':'configuration_unchanged','passed':config==before})
    return {'passed':all(check['passed'] for check in checks),'checks':checks,
            'scope':'DGP/source/analytic-truth verification only; no fitted estimator, CI coverage, prediction interval or simultaneous band evaluation.'}
