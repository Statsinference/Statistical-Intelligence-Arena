# NRI 类别扩展与原版兼容性

2026-10-21 原版学生包只允许 ate/cate/mediation/iv/proximal/did_sc。本地既有 quantile_regression 扩展也不包含 NRI。因此本包**不能直接通过未扩展原版**；family 不得伪写为 cate 或 quantile_regression。

本轮明确启用 `nonparametric-regression-family-v1`：仅向 `collection/core.py` 的 FAMILIES 和 `collection/schemas/collection.schema.json` 的 family enum 添加 `nonparametric_regression`。schema_version 仍为1.0，collection.json 另列 schema_extension；这不是项目组已正式发布或接受的新版协议。

脚本支持原版以及已有 QR 扩展的学生包，先验证两处枚举一致、校验备份，再保存原文件与前后 SHA-256。重复启用无变化。脚本不联网、不执行贡献，不修改真值容差、观察列规则、哈希和打包检查。

## 在新解压的原版学生包复跑

将本 ZIP 解压至 `contributions/nri-calonico-2018-asymmetric-sine-v1/`，确保该目录直接含 collection.json；以下命令在含 collect.py 的学生包根目录运行：

```powershell
python -m pip install -r requirements-collection.txt
python -m pip install -r contributions/nri-calonico-2018-asymmetric-sine-v1/requirements.txt
python contributions/nri-calonico-2018-asymmetric-sine-v1/enable_nri_family.py .
python collect.py check contributions/nri-calonico-2018-asymmetric-sine-v1 --run --n 128 --seed 1729
```

只有经审阅的本地代码才能用 --run。维护人首次收到 ZIP 时可先用标准 ZIP 工具审阅扩展说明和脚本；原版 collect.py submit 也需要启用这个类别后才能接收。本包不修改原版 API：generate 返回观察表，truth.value 是标量，verify 返回具名检查。

五个 query scenarios 只支持逐点目标 m(x0)。逐点覆盖率不能当作同时置信带覆盖率；连续域置信带接口与校准是后续任务。

本包满足指南的文件结构与执行流程，同时具有明确的类别扩展依赖。自动检查、哈希收件与科学接收是不同状态；未发送项目组，类别批准与科学审核待维护人完成。
