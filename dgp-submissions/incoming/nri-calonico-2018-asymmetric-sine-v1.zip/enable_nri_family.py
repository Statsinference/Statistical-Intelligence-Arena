"""Explicit additive NRI family extension for the 2026-10-21 collection toolkit.

Usage: python enable_nri_family.py PATH_TO_TOOLKIT
Only two family enumerations are extended. No contribution code is executed.
Supports the original toolkit or the existing local quantile_regression extension.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re

BASE_FAMILIES = {'ate','cate','mediation','iv','proximal','did_sc'}
FAMILY = 'nonparametric_regression'
EXTENSION = 'nonparametric-regression-family-v1'


def enable(toolkit_root):
    root = Path(toolkit_root).resolve()
    core = root/'collection/core.py'
    schema = root/'collection/schemas/collection.schema.json'
    raw_core, raw_schema = core.read_bytes(), schema.read_bytes()
    matches = list(re.finditer(rb'^FAMILIES = (\{[^\r\n]+\})\r?$',raw_core,re.MULTILINE))
    if len(matches) != 1:
        raise ValueError('Unexpected toolkit family declaration; no files changed')
    match = matches[0]
    families = ast.literal_eval(match.group(1).decode('ascii'))
    contract = json.loads(raw_schema)
    enum = contract['properties']['family']['enum']
    if not isinstance(families,set) or set(enum)!=families or len(enum)!=len(families):
        raise ValueError('Core/schema family mismatch; no files changed')
    prior = families-{FAMILY}
    if prior not in (BASE_FAMILIES,BASE_FAMILIES|{'quantile_regression'}):
        raise ValueError('Unrecognized base family set; review compatibility manually')
    if FAMILY in families:
        return {'changed':False,'extension':EXTENSION}
    enum_matches = list(re.finditer(rb'"family":\s*\{\s*"enum":\s*(\[[^\]]+\])\s*\}',raw_schema))
    if len(enum_matches)!=1 or json.loads(enum_matches[0].group(1))!=enum:
        raise ValueError('Unexpected schema enum formatting; no files changed')
    declaration = match.group(1)[:-1]+b', "nonparametric_regression"}'
    updated_core = raw_core[:match.start(1)]+declaration+raw_core[match.end(1):]
    schema_match = enum_matches[0]
    enum_text = json.dumps(enum+[FAMILY]).encode('ascii')
    updated_schema = raw_schema[:schema_match.start(1)]+enum_text+raw_schema[schema_match.end(1):]
    changes = [(core,raw_core,updated_core),(schema,raw_schema,updated_schema)]
    evidence = root/'extensions/nonparametric_regression'
    # Validate all backups before the first mutation; never overwrite a differing backup.
    for path,before,_ in changes:
        backup = evidence/(path.name+'.original.txt')
        if backup.exists() and backup.read_bytes()!=before:
            raise ValueError('Conflicting previous backup; no files changed')
    evidence.mkdir(parents=True,exist_ok=True)
    audit = {'extension':EXTENSION,'base_schema_version':'1.0','official_base_compatible':False,
             'change_scope':'Add only nonparametric_regression to core and JSON schema family enums',
             'scientific_acceptance':False,'files':[]}
    for path,before,after in changes:
        (evidence/(path.name+'.original.txt')).write_bytes(before)
        path.write_bytes(after)
        audit['files'].append({'path':path.relative_to(root).as_posix(),
            'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest()})
    (evidence/'extension_audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
    return {'changed':True,**audit}


if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('toolkit_root',type=Path)
    print(json.dumps(enable(parser.parse_args().toolkit_root),indent=2))
