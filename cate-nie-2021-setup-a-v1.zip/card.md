# Nie–Wager (2021) Setup A: Friedman baseline with a sinusoidal propensity

**Contribution `cate-nie-2021-setup-a-v1` — candidate; not scientifically accepted.**
Task family: `cate` · mechanism family: `nie-wager-2021-setup-a`

## Source and reconstruction

- Citation: Nie, X. and Wager, S. (2021). Quasi-oracle estimation of heterogeneous treatment effects. Biometrika 108(2), 299-319. DOI: 10.1093/biomet/asaa076.
- Venue / year: Biometrika, 2021
- Link: https://arxiv.org/abs/1712.04912
- **Exact locator**: Section 6.1 'Baseline methods and simulation setups', arXiv:1712.04912v4 (6 Aug 2020) PDF p.15 (general data-generating law) and PDF p.16 (unnumbered Setup A paragraph, since the setups carry no equation numbers: 'We use the scaled Friedman (1991) function ... e*(Xi) = trim0.1{sin(pi Xi1 Xi2)} and tau*(Xi) = (Xi1 + Xi2)/2').
- Source relation: `adapted_from_source`

### Equations, in generation order

1. **X1-X5**: `Xj ~ Uniform(0,1) independently, j = 1..5`
2. **Treatment**: `e(X) = trim_{0.1}{ sin(pi X1 X2) }, trim_eta(u) = max{eta, min(u, 1-eta)}`
3. **Baseline**: `b(X) = sin(pi X1 X2) + 2 (X3 - 1/2)^2 + X4 + 0.5 X5`
4. **Heterogeneity**: `tau(X) = (X1 + X2) / 2`
5. **Outcome**: `Y = b(X) + A tau(X) + sigma eps, eps ~ Normal(0,1), sigma = 1`

Sampling unit: individual · dependence: independent and identically distributed

Fixed parameters: trimming level 0.1, baseline coefficients as above, effect slope 1/2, noise sigma = 1.

### Adaptations relative to the source

- Dimension fixed at d = 5, the smallest dimension for which the source's baseline is fully defined (it uses X1..X5); the source varies d in {6, 12} for the reported grid.
- The source writes Y = b(X) + (W - 0.5) tau(X) + sigma eps; this package uses Y = b(X) + A tau(X) + sigma eps with A in {0,1}. The CATE is unchanged; the marginal outcome law differs by the constant 0.5 tau(X).
- Noise scale is fixed at sigma = 1 (the source also reports sigma in {0.5, 2, 3}); those are scenarios, not implemented here.
- trim_eta is implemented as np.clip(., 0.1, 0.9), matching trim_0.1 in the source.

## Target and identification

- Symbol: `tau(x0) = E[Y(1) - Y(0) | X = x0]`
- Definition: Conditional average treatment effect at the declared query points; a simple linear surface in the first two coordinates, embedded in a deliberately difficult nuisance structure.
- Query points (part of the estimand): `primary`: (X1 = 0.2, X2 = 0.3, X3 = 0.5, X4 = 0.5, X5 = 0.5); `secondary`: (X1 = 0.9, X2 = 0.8, X3 = 0.5, X4 = 0.5, X5 = 0.5)

Identification assumptions:

- SUTVA: one version of treatment, no interference
- Unconfoundedness: treatment depends on X only through sin(pi X1 X2), which is also part of the baseline; the design is observational by construction
- Overlap: e(X) is trimmed to [0.1, 0.9], so positivity holds with margin 0.1
- Homoscedastic Gaussian noise; sigma = 1 in this scenario

Setup A is the 'hard nuisance, easy effect' regime: the propensity and the baseline share the same interaction term, so any estimator that does not model that interaction will be biased even though the target surface is trivial.

## Truth and independent verification

Additive outcome with Gaussian noise: E[Y|A=1,X=x] - E[Y|A=0,X=x] = tau(x) = (x1+x2)/2. At the primary query point (0.2, 0.3) this is 0.25 exactly.

`verify.py` types the same surface a second time from the source equations, checks
the zero-effect and scale identities, and confirms end-to-end that the realised
outcome column of `generator.py` carries the declared surface (arm-contrast shift
equals the mean of tau over treated rows, at identical seed). Both routes share the
declared mechanism; they are not an independent-person reproduction.

## Diversity and scope

- Baseline dimension 5 (effective 5) · high dimensional: False · interactions: True · nonlinear: True
- Overlap is trimmed at 0.1, so no tail region is unsupported, but the propensity is a deterministic function of the same interaction that drives the baseline, which is the intended source of bias. Nothing here speaks to effect heterogeneity beyond a linear ramp.

Observed columns:

| name | role | dtype | min | max | observed |
|---|---|---|---|---|---|
| X1 | covariate | float | 0.0 | 1.0 | true |
| X2 | covariate | float | 0.0 | 1.0 | true |
| X3 | covariate | float | 0.0 | 1.0 | true |
| X4 | covariate | float | 0.0 | 1.0 | true |
| X5 | covariate | float | 0.0 | 1.0 | true |
| A | treatment | binary | 0 | 1 | true |
| Y | outcome | float | · | · | true |

## Rights and assistance

- Rights: Paper copyright by Oxford University Press for Biometrika. No PDF or author code is redistributed; equations cited and independently implemented.
- AI assistance: the formulas were transcribed into `specs_v2.py` with AI assistance and re-checked line by line against the PDF by the contributor; the eight files were rendered by a local template.
- Open issues: d is fixed at 5 and sigma at 1; the source's (d, sigma) grid is not reproduced.

CPU smoke checks establish format, reproducibility and internal numerical identity
only. They do not establish identification, coverage, permission or scientific
acceptance.
